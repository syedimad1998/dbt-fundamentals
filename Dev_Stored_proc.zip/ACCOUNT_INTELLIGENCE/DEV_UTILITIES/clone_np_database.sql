use role SYSADMIN;
CREATE OR REPLACE PROCEDURE DEV_UTILITIES.PUBLIC.CLONE_NP_DATABASE("SRCDB" VARCHAR(16777216), "NEWDATABASE" VARCHAR(16777216), "OVERWRITE" VARCHAR(16777216))
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS 
$$
-- lets make sure  variables are  clean to  protect against  sql insertion
if (( !SRCDB.match("^[a-zA-Z0-9\\_]*$") && SRCDB.length < 100 ) &&  ( !NEWDATABASE.match("^[a-zA-Z0-9\\_]*$") && NEWDATABASE.length < 100 ))
{
return `Bad parameter only a-z, A-Z, and _ are allowed!`;
}

-- test overwrite variable
if (OVERWRITE.toLowerCase() != "true" && OVERWRITE.toLowerCase() != "false" )
{
 return "The overwrite parameter must be `true` or `false`.";
}

-- databases not allowed to copy
if ((SRCDB.toLowerCase() == "dev_utilities") || (SRCDB.toLowerCase() == "qa_utilities") || (SRCDB.toLowerCase() == "prod_utilities") || (SRCDB.toLowerCase() == "devops_utilities") )
{
 return "You are not allowed to clone this database.";
}

-- databases allowed to copy from
if (!SRCDB.toLowerCase().startsWith("np_"))
{
 return "You can only clone np_ databases.";
}

--make sure that we are only allowing new  databases to  be written to dev
if (!NEWDATABASE.toLowerCase().startsWith("dev_") || NEWDATABASE.toLowerCase() == "dev_")
{
 return "Development databases must be of format dev_[name]";
}

--make sure that we are only allowing new databases to be written to dev
--Check disabled
--if (SRCDB.toLowerCase().endsWith("dtx") && !NEWDATABASE.toLowerCase().endsWith("dtx"))
--{
-- return "A database ending in 'dtx' can only be cloned to a target ending in 'dtx'";
--}

-- Does source exist
try
{
  var rsSrcDB = snowflake.execute(
  { sqlText:
      `SELECT database_name
      FROM snowflake.information_schema.databases
      WHERE database_name ILIKE ?`,
    binds: [SRCDB]
  });
  if (rsSrcDB.getRowCount() == 0)
  {
  return "The Source database does not exists";
  }
}
catch (err)
{
  return "Source check failed: " + err; -- Return a success/error indicator.
}

--Check for overwrite on destination
try
{
  var rsNewDB = snowflake.execute(
  { sqlText:
        `SELECT database_name
        FROM snowflake.information_schema.databases
        WHERE database_name ILIKE ?`,
    binds: [NEWDATABASE]
  });

  if (rsNewDB.getRowCount() > 0  &&   OVERWRITE.toLowerCase() != "true")
  {
    -- exists, overwrite = false
    return "The database already exist and you have not not set the overwrite variable to true in command (<newdatabasenane>,<sorcedatabase>,<overwrite>)";
  }
--   Removing the requirement to check for allowing overwrite permission
--   else if (rsNewDB.getRowCount() > 0 && OVERWRITE.toLowerCase() == "true")
--   {
--     -- exists, overwrite = true.  Check for delete permission
--     var rsAllowed = snowflake.execute(
--     { sqlText:
--         `SELECT CURRENT_USER() = username AS allowed, CURRENT_USER() as current_user, username as allowed_user
--         FROM devops_utilities.public.userdbcreationlog where db = ? order by creationdate desc LIMIT 1`,
--       binds: [NEWDATABASE]
--     });
--     while (rsAllowed.next())
--     {
--         var allowed = rsAllowed.getColumnValue("ALLOWED");
--         var current_user = rsAllowed.getColumnValue("CURRENT_USER");
--         var allowed_user = rsAllowed.getColumnValue("ALLOWED_USER");

--         if(allowed!=true){
--             return "The database already exists and you do not have delete or overwrite permission.  Current user: " + current_user + " , Allowed user: " + allowed_user;
--         }
--     }
--   }
}
catch (err)
{
  return "Destination check failed: " + err; -- Return a success/error indicator.
}



-- This function is used to execute command that are sent to it
function executesql(command)
{
	var cmd_dict = {sqlText: command};
	var stmt = snowflake.createStatement(cmd_dict);
	return stmt.execute();
}

--Perform Clone
try
{

  executesql(`begin transaction;`);
  
  --1. Clone DB
  if(OVERWRITE.toLowerCase() == "true")
  {
    var rs = snowflake.execute(
    { sqlText:
        `CREATE OR REPLACE DATABASE ` + NEWDATABASE + ` CLONE ` + SRCDB
    });
  }
  else
  {
    var rs = snowflake.execute(
    { sqlText:
        `CREATE DATABASE ` + NEWDATABASE + ` CLONE ` + SRCDB
    });
  }
  --Applying collation en-ci to database
   var rs = snowflake.execute(
    { sqlText:
        `ALTER DATABASE ` + NEWDATABASE + ` set DEFAULT_DDL_COLLATION='en-ci'`
    });
  --IS THIS EVEN NEEDED?
  --2. change ownership to systemadmin
  --command = "grant ownership on database " + NEWDATABASE + " to role SYSADMIN;";
  --executesql(command);

  --3. insert into log
  var rs = snowflake.execute(
  { sqlText:
      `INSERT INTO devops_utilities.public.userdbcreationlog (username, db, creationdate)
      VALUES (CURRENT_USER(), ? ,CURRENT_TIMESTAMP())`,
    binds: [NEWDATABASE]
  });

  --4. we need apply permisions to the new database by calling stored procedure
  var rs = snowflake.execute(
  { sqlText:
      `CALL devops_utilities.public.set_database_permissions(?)`,
    binds: [NEWDATABASE]
  });
  
  executesql(`commit;`);

  return "Database " + NEWDATABASE + " has been created and permissions applied you may need to refresh the database panel for it to show up!";
 }
 catch (err)
 {
    return "Clone failed: " + err; -- Return a success/error indicator.
 }
$$;

grant usage on procedure DEV_UTILITIES.PUBLIC.CLONE_NP_DATABASE(VARCHAR(16777216),  VARCHAR(16777216), VARCHAR(16777216))to role RBAR_P_SNOWFLAKE_INTELLIGENCE_DEV_DBO_ANY;