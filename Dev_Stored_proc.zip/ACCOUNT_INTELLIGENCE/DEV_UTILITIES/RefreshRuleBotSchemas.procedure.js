--RUN AS SYSADMIN

CREATE OR REPLACE PROCEDURE dev_utilities.public.RefreshRulebotSchemas(CUST_NUMBER varchar)
RETURNS varchar
LANGUAGE JAVASCRIPT
EXECUTE AS owner
AS

$$
// lets make sure  variables are  clean to  protect against  sql insertion
if (!CUST_NUMBER.match("^[0-9]*$")) {
    return 'Bad parameter only 0-9 are allowed!';
} else if (CUST_NUMBER.length > 5) {
    return 'lenth of CUSTNUMBER is too long'
}
snowflake.execute({ sqlText: `BEGIN;`});
//Check for overwrite on destination
try {
    var rsSrcDB = snowflake.execute({
        sqlText: `SELECT database_name
      FROM snowflake.information_schema.databases
      WHERE database_name ILIKE 'PROD_DF_` + CUST_NUMBER + `'`
    });
    if (rsSrcDB.getRowCount() == 0) {
        return "The Source database does not exists";
    }
} catch (err) {
    return "Destination check failed: " + err; // Return a success/error indicator.
}

try {
    var rsTgtDB = snowflake.execute({
        sqlText: `SELECT database_name
      FROM snowflake.information_schema.databases
      WHERE database_name ILIKE 'DEV_RULEBOT_` + CUST_NUMBER + `'`
    });
} catch (err) {
    return "Destination check failed: " + err; // Return a success/error indicator.
}

try {
    //2.a.  get the schemas to clone
    var rs = snowflake.execute({
        sqlText: `SELECT 'CREATE OR REPLACE SCHEMA DEV_RULEBOT_` + CUST_NUMBER + `.' || SCHEMA_NAME || ' CLONE PROD_DF_` + CUST_NUMBER + `.' || SCHEMA_NAME || ';' as rsSQL
        FROM PROD_DF_` + CUST_NUMBER + `.information_schema.schemata
        WHERE SCHEMA_NAME IN  ('FSS', 'TFC', 'RCM')`
    });

    if (rsTgtDB.getRowCount() == 0) {
        if (rs.getRowCount() > 0) {
            var rsTgtCreateDB = snowflake.execute({
                sqlText: `CREATE DATABASE IF NOT EXISTS DEV_RULEBOT_` + CUST_NUMBER + `;`
            })
        } else {
            return `PROD_DF_` + CUST_NUMBER + ` database does not contain cloning schemas`
        }
    }


    //2.b. Clone the schemas
    // Loop through the results, processing one row at a time... 
    var counter = 0;
    while (rs.next()) {
        counter = counter + 1;
        var tmp_script = rs.getColumnValue(1);
        var tmp_rs = snowflake.execute({
            sqlText: tmp_script
        });
        tmp_rs.next();
    };
} catch (err) {
    return "Cloning of the schemas failed: " + err; // Return a success/error indicator.
}
//3. we need apply permisions to the new database by calling stored procedure
try {
    snowflake.execute({
        sqlText: `CALL devops_utilities.public.set_database_permissions( 'DEV_RULEBOT_` + CUST_NUMBER + `')`
    });
    snowflake.execute({
        sqlText: `call devops_utilities.public.set_ssas_role_permission('RBAR_P_SSAS_RCM_DEV');`
    });
    snowflake.execute({ sqlText: `COMMIT;`});

    return `Database DEV_RULEBOT_` + CUST_NUMBER + ` has been refeshed and security applied.`;
} catch (err) {
    return "Clone failed: " + err; // Return a success/error indicator.
}
$$;
-- begin  set permissions
use role securityadmin;
grant usage on procedure dev_utilities.public.RefreshRulebotSchemas(varchar) to role RBAR_P_SNOWFLAKE_ACCOUNT_INTELLIGENCE_MDM;
grant usage on procedure dev_utilities.public.RefreshRulebotSchemas(varchar) to role RBAR_P_SNOWFLAKE_INTELLIGENCE_DEV_DBO_ANY;
grant usage on procedure dev_utilities.public.RefreshRulebotSchemas(varchar) to role RBAR_P_SNOWFLAKE_INTELLIGENCE_RULEBOT;
-- end  set permissions
