CREATE OR REPLACE PROCEDURE DEV_MDM_UTILITIES.MDM.FIX_VIEWS_SCRIPT(DB_NAME STRING, PARAMETER STRING, SUFFIX STRING)
RETURNS STRING
LANGUAGE JAVASCRIPT
EXECUTE AS CALLER
AS
$$
//To call this procedure & fix PROD_ references in DEV_DTX_HEALTHTERM, you can run this as follows: call  DEV_MDM_UTILITIES.MDM.FIX_VIEWS_SCRIPT('DEV_DTX_HEALTHTERM','DEV_','_HEALTHTERM');
    
    //SQL Injection check
	var alloweddatabasenames = /^[a-zA-Z_0-9]+$/;
      if (DB_NAME.match(alloweddatabasenames) == null){
      return "Possible SQL Injection: "+ DB_NAME;
      }
	
	var parameternames = /^[a-zA-Z_0-9]+$/;
      if (PARAMETER.match(parameternames) == null){
      return "Possible SQL Injection: "+ PARAMETER;
      }
     
    var suffixnames = /^[a-zA-Z_0-9]*$/;
      if (SUFFIX.match(suffixnames) == null){
      return "Possible SQL Injection: "+ SUFFIX;
      }
	
	// Execute the query to get the view script modifications
    var sql = `
    SELECT
        REGEXP_REPLACE(REGEXP_REPLACE(UPPER(VIEW_DEFINITION), 'PROD_DF_(\\\\d+)', '` + PARAMETER + `DF_\\\\1' || '` + SUFFIX + `'), 'PROD_DTX', '` + PARAMETER + `DTX' || '` + SUFFIX + `')
        AS MODIFIED_VIEW_SCRIPT
    FROM
        ` + DB_NAME + `.INFORMATION_SCHEMA.VIEWS
    WHERE
        UPPER(VIEW_DEFINITION) ILIKE '%PROD_DF_%'
        OR UPPER(VIEW_DEFINITION) ILIKE '%PROD_DTX%';

    `;
    var stmt = snowflake.createStatement({ sqlText: sql });
    var resultSet = stmt.execute();
    try {
        while (resultSet.next()) {
            var modifiedViewScript = resultSet.getColumnValue('MODIFIED_VIEW_SCRIPT');
            var executeSql = 'EXECUTE IMMEDIATE \'' + modifiedViewScript + '\'';
            // Execute the modified view script
            snowflake.execute({ sqlText: modifiedViewScript });
        }
        return 'View scripts executed successfully.';
    } catch (err) {
        return 'Error executing the view scripts: ' + err.message;
    }
$$;