--RUN AS SECURITYADMIN
use role securityadmin;

CREATE OR REPLACE PROCEDURE devops_utilities.public.set_mobilize_database_permissions(DATABASENAME varchar)
RETURNS varchar
LANGUAGE JAVASCRIPT
EXECUTE AS owner
AS
$$
// This function is used to execute GRANT COMMANDS and return any caught error as txt.
function executeGrant(command)
{
    try
    {
        var rs = snowflake.execute({sqlText: command});
        return "";
    }
    catch(err){return "Grant failed: " + err + "\n";}
}

//THIS FUNTION IS USED TO SET THE PERMISSION IN A DATABASE BASED ON ROLE
if ( !DATABASENAME.match("^[a-zA-Z0-9\_]*$") && DATABASENAME.length < 100 )
{
    return 'Bad parameter only a-z, A-Z, and _ are allowed!';
}
var schemaOwners = ['RBAR_SNOWFLAKE_INTELLIGENCE_DEV_SCHEMA_OWNER', 'RBAR_SNOWFLAKE_INTELLIGENCE_QA_SCHEMA_OWNER', 'RBAR_SNOWFLAKE_INTELLIGENCE_PROD_SCHEMA_OWNER',
                    'RBAR_SNOWFLAKE_INTELLIGENCE_DEV_SCHEMA_OWNER_DTX', 'RBAR_SNOWFLAKE_INTELLIGENCE_QA_SCHEMA_OWNER_DTX', 'RBAR_SNOWFLAKE_INTELLIGENCE_PROD_SCHEMA_OWNER_DTX',
                    'RBAR_SNOWFLAKE_INTELLIGENCE_MOBILIZE_SCHEMA_OWNER'];
//EVERYTHING NON-RULEBOT DB
if(DATABASENAME.toLowerCase().startsWith("mobilize_"))
{
    var schemaRole = 'RBAR_SNOWFLAKE_INTELLIGENCE_MOBILIZE_SCHEMA_OWNER'; 
    var devopsRole = 'RBAR_P_SNOWFLAKE_ACCOUNT_INTELLIGENCE_DEVOPS';
    var mdmRole = 'RBAR_P_SNOWFLAKE_ACCOUNT_INTELLIGENCE_MDM';
    var dboRole = 'RBAR_P_SNOWFLAKE_INTELLIGENCE_MOBILIZE_DBO';
}
else
{
    return 'This procedure only supports mobilize_ databases';
}

try{
    var errors = "";

    //DATABASE OWNERSHIP
    errors = errors + executeGrant(`GRANT OWNERSHIP ON DATABASE ` + DATABASENAME + ` to SYSADMIN revoke current grants`);

    //SCHEMA OWNERSHIP
    errors = errors + executeGrant(`GRANT USAGE ON DATABASE ` + DATABASENAME + ` to ` + schemaRole);
    errors = errors + executeGrant(`GRANT OWNERSHIP ON ALL SCHEMAS in DATABASE ` + DATABASENAME + ` to ` + schemaRole + ' revoke current grants');
    for(var so of schemaOwners)
    {
      try{
        snowflake.execute({ sqlText: `REVOKE OWNERSHIP ON FUTURE SCHEMAS in DATABASE ` + DATABASENAME + ` FROM ` + so });
      }catch{}
    }
    errors = errors + executeGrant(`GRANT OWNERSHIP ON FUTURE SCHEMAS in DATABASE ` + DATABASENAME + ` to ` + schemaRole);

    //OBJECT OWNERSHIP
    errors = errors + executeGrant(`GRANT OWNERSHIP ON ALL TABLES in DATABASE ` + DATABASENAME + ` to ` + schemaRole +  ` revoke current grants` );
    for(var oldSchemaRole of schemaOwners){try{snowflake.execute({ sqlText: `REVOKE OWNERSHIP ON FUTURE TABLES in DATABASE ` + DATABASENAME + ` from ` + oldSchemaRole });}catch{ }}
    if(DATABASENAME.toLowerCase() != "prod_dtx" && DATABASENAME.toLowerCase() != "prod_admin"){errors = errors + executeGrant(`GRANT OWNERSHIP ON FUTURE TABLES in DATABASE ` + DATABASENAME + ` to ` + schemaRole +  ` revoke current grants` );}
    errors = errors + executeGrant(`GRANT OWNERSHIP ON ALL EXTERNAL TABLES in DATABASE ` + DATABASENAME + ` to ` + schemaRole +  ` revoke current grants` );
    for(var oldSchemaRole of schemaOwners){try{snowflake.execute({ sqlText: `REVOKE OWNERSHIP ON FUTURE EXTERNAL TABLES in DATABASE ` + DATABASENAME + ` from ` + oldSchemaRole});}catch{}}
    errors = errors + executeGrant(`GRANT OWNERSHIP ON FUTURE EXTERNAL TABLES in DATABASE ` + DATABASENAME + ` to ` + schemaRole +  ` revoke current grants` );
    errors = errors + executeGrant(`GRANT OWNERSHIP ON ALL VIEWS in DATABASE ` + DATABASENAME + ` to ` + schemaRole +  ` revoke current grants` );
    for(var oldSchemaRole of schemaOwners){try{snowflake.execute({ sqlText: `REVOKE OWNERSHIP ON FUTURE VIEWS in DATABASE ` + DATABASENAME + ` from ` + oldSchemaRole});}catch{}}
    errors = errors + executeGrant(`GRANT OWNERSHIP ON FUTURE VIEWS in DATABASE ` + DATABASENAME + ` to ` + schemaRole +  ` revoke current grants` );
    errors = errors + executeGrant(`GRANT OWNERSHIP ON ALL MATERIALIZED VIEWS in DATABASE ` + DATABASENAME + ` to ` + schemaRole +  ` revoke current grants` );
    for(var oldSchemaRole of schemaOwners){try{snowflake.execute({ sqlText: `REVOKE OWNERSHIP ON FUTURE MATERIALIZED VIEWS in DATABASE ` + DATABASENAME + ` from ` + oldSchemaRole});}catch{}}
    errors = errors + executeGrant(`GRANT OWNERSHIP ON FUTURE MATERIALIZED VIEWS in DATABASE ` + DATABASENAME + ` to ` + schemaRole +  ` revoke current grants` );
    //errors = errors + executeGrant(`GRANT OWNERSHIP ON ALL MASKING POLICIES in DATABASE ` + DATABASENAME + ` to ` + schemaRole +  ` revoke current grants` );
    errors = errors + executeGrant(`GRANT OWNERSHIP ON ALL FILE FORMATS in DATABASE ` + DATABASENAME + ` to ` + schemaRole +  ` revoke current grants` );
    for(var oldSchemaRole of schemaOwners){try{snowflake.execute({ sqlText: `REVOKE OWNERSHIP ON FUTURE FILE FORMATS in DATABASE ` + DATABASENAME + ` from ` + oldSchemaRole});}catch{}}
    errors = errors + executeGrant(`GRANT OWNERSHIP ON FUTURE FILE FORMATS in DATABASE ` + DATABASENAME + ` to ` + schemaRole +  ` revoke current grants` );
    //errors = errors + executeGrant(`GRANT OWNERSHIP ON ALL PIPES in DATABASE ` + DATABASENAME + ` to ` + schemaRole +  ` revoke current grants` );
    errors = errors + executeGrant(`GRANT OWNERSHIP ON ALL STREAMS in DATABASE ` + DATABASENAME + ` to ` + schemaRole +  ` revoke current grants` );
    for(var oldSchemaRole of schemaOwners){try{snowflake.execute({ sqlText: `REVOKE OWNERSHIP ON FUTURE STREAMS in DATABASE ` + DATABASENAME + ` from ` + oldSchemaRole});}catch{}}
    errors = errors + executeGrant(`GRANT OWNERSHIP ON FUTURE STREAMS in DATABASE ` + DATABASENAME + ` to ` + schemaRole +  ` revoke current grants` );
    errors = errors + executeGrant(`GRANT OWNERSHIP ON ALL TASKS in DATABASE ` + DATABASENAME + ` to ` + schemaRole +  ` revoke current grants` );
    for(var oldSchemaRole of schemaOwners){try{snowflake.execute({ sqlText: `REVOKE OWNERSHIP ON FUTURE TASKS in DATABASE ` + DATABASENAME + ` from ` + oldSchemaRole});}catch{}}
    errors = errors + executeGrant(`GRANT OWNERSHIP ON FUTURE TASKS in DATABASE ` + DATABASENAME + ` to ` + schemaRole +  ` revoke current grants` );
    errors = errors + executeGrant(`GRANT OWNERSHIP ON ALL SEQUENCES in DATABASE ` + DATABASENAME + ` to ` + schemaRole +  ` revoke current grants` );
    for(var oldSchemaRole of schemaOwners){try{snowflake.execute({ sqlText: `REVOKE OWNERSHIP ON FUTURE SEQUENCES in DATABASE ` + DATABASENAME + ` from ` + oldSchemaRole});}catch{}}
    errors = errors + executeGrant(`GRANT OWNERSHIP ON FUTURE SEQUENCES in DATABASE ` + DATABASENAME + ` to ` + schemaRole +  ` revoke current grants` );
    errors = errors + executeGrant(`GRANT OWNERSHIP ON ALL FUNCTIONS in DATABASE ` + DATABASENAME + ` to ` + schemaRole +  ` revoke current grants` );
    for(var oldSchemaRole of schemaOwners){try{snowflake.execute({ sqlText: `REVOKE OWNERSHIP ON FUTURE FUNCTIONS in DATABASE ` + DATABASENAME + ` from ` + oldSchemaRole});}catch{}}
    errors = errors + executeGrant(`GRANT OWNERSHIP ON FUTURE FUNCTIONS in DATABASE ` + DATABASENAME + ` to ` + schemaRole +  ` revoke current grants` );
    errors = errors + executeGrant(`GRANT OWNERSHIP ON ALL PROCEDURES in DATABASE ` + DATABASENAME + ` to ` + schemaRole +  ` revoke current grants` );
    for(var oldSchemaRole of schemaOwners){try{snowflake.execute({ sqlText: `REVOKE OWNERSHIP ON FUTURE PROCEDURES in DATABASE ` + DATABASENAME + ` from ` + oldSchemaRole});}catch{}}
    errors = errors + executeGrant(`GRANT OWNERSHIP ON FUTURE PROCEDURES in DATABASE ` + DATABASENAME + ` to ` + schemaRole +  ` revoke current grants` );


    //STAGE OWNERSHIP
    errors = errors + executeGrant(`GRANT OWNERSHIP ON ALL STAGES in DATABASE ` + DATABASENAME + ` to SYSADMIN revoke current grants` );
    try{
      snowflake.execute({ sqlText: `REVOKE OWNERSHIP ON FUTURE STAGES in DATABASE ` + DATABASENAME + ` FROM SYSADMIN` });
    }catch{}
    errors = errors + executeGrant(`GRANT OWNERSHIP ON FUTURE STAGES in DATABASE ` + DATABASENAME + ` to SYSADMIN` );

    //DBO
    errors = errors + executeGrant(`GRANT USAGE, MONITOR, CREATE SCHEMA ON DATABASE ` + DATABASENAME + ` to ` + dboRole  );
    errors = errors + executeGrant(`GRANT MONITOR, USAGE, CREATE TABLE, CREATE VIEW, CREATE MATERIALIZED VIEW, CREATE MASKING POLICY, CREATE FILE FORMAT, CREATE SEQUENCE, CREATE FUNCTION, CREATE TASK, CREATE PROCEDURE ON ALL SCHEMAS IN DATABASE ` + DATABASENAME + ` to ` + dboRole  );
    errors = errors + executeGrant(`GRANT MONITOR, USAGE, CREATE TABLE, CREATE VIEW, CREATE MATERIALIZED VIEW, CREATE MASKING POLICY, CREATE FILE FORMAT, CREATE SEQUENCE, CREATE FUNCTION, CREATE TASK, CREATE PROCEDURE ON FUTURE SCHEMAS IN DATABASE ` + DATABASENAME + ` to ` + dboRole  );
    errors = errors + executeGrant(`GRANT SELECT, INSERT, UPDATE, TRUNCATE, DELETE ON ALL TABLES IN DATABASE ` + DATABASENAME + ` to ` + dboRole  );
    errors = errors + executeGrant(`GRANT SELECT, INSERT, UPDATE, TRUNCATE, DELETE ON FUTURE TABLES IN DATABASE ` + DATABASENAME + ` to ` + dboRole  );
    errors = errors + executeGrant(`GRANT SELECT ON ALL EXTERNAL TABLES IN DATABASE ` + DATABASENAME + ` to ` + dboRole  );
    errors = errors + executeGrant(`GRANT SELECT ON FUTURE EXTERNAL TABLES IN DATABASE ` + DATABASENAME + ` to ` + dboRole  );
    errors = errors + executeGrant(`GRANT SELECT ON ALL VIEWS IN DATABASE ` + DATABASENAME + ` to ` + dboRole  );
    errors = errors + executeGrant(`GRANT SELECT ON FUTURE VIEWS IN DATABASE ` + DATABASENAME + ` to ` + dboRole  );
    errors = errors + executeGrant(`GRANT USAGE ON ALL FILE FORMATS IN DATABASE ` + DATABASENAME + ` to ` + dboRole  );
    errors = errors + executeGrant(`GRANT USAGE ON FUTURE FILE FORMATS IN DATABASE ` + DATABASENAME + ` to ` + dboRole  );
    errors = errors + executeGrant(`GRANT MONITOR, OPERATE ON ALL TASKS IN DATABASE ` + DATABASENAME + ` to ` + dboRole  );
    errors = errors + executeGrant(`GRANT MONITOR, OPERATE ON FUTURE TASKS IN DATABASE ` + DATABASENAME + ` to ` + dboRole  );
    //errors = errors + executeGrant(`GRANT APPLY ON ALL MASKING POLICIES IN DATABASE ` + DATABASENAME + ` to ` + dboRole  );
    //errors = errors + executeGrant(`GRANT APPLY ON FUTURE MASKING POLICIES IN DATABASE ` + DATABASENAME + ` to ` + dboRole  );
    errors = errors + executeGrant(`GRANT ALL PRIVILEGES ON ALL SEQUENCES IN DATABASE ` + DATABASENAME + ` to ` + dboRole  );
    errors = errors + executeGrant(`GRANT ALL PRIVILEGES ON FUTURE SEQUENCES IN DATABASE ` + DATABASENAME + ` to ` + dboRole  );
    errors = errors + executeGrant(`GRANT ALL PRIVILEGES ON ALL PROCEDURES IN DATABASE ` + DATABASENAME + ` to ` + dboRole  );
    errors = errors + executeGrant(`GRANT ALL PRIVILEGES ON FUTURE PROCEDURES IN DATABASE ` + DATABASENAME + ` to ` + dboRole  );
    errors = errors + executeGrant(`GRANT ALL PRIVILEGES ON ALL FUNCTIONS IN DATABASE ` + DATABASENAME + ` to ` + dboRole  );
    errors = errors + executeGrant(`GRANT ALL PRIVILEGES ON FUTURE FUNCTIONS IN DATABASE ` + DATABASENAME + ` to ` + dboRole  );

    
    //MDM
    errors = errors + executeGrant(`GRANT USAGE, MONITOR, CREATE SCHEMA ON DATABASE ` + DATABASENAME + ` to ` + mdmRole  );
    errors = errors + executeGrant(`GRANT MONITOR, USAGE, CREATE TABLE, CREATE VIEW, CREATE MATERIALIZED VIEW, CREATE MASKING POLICY, CREATE FILE FORMAT, CREATE SEQUENCE, CREATE FUNCTION, CREATE TASK, CREATE PROCEDURE ON ALL SCHEMAS IN DATABASE ` + DATABASENAME + ` to ` + mdmRole  );
    errors = errors + executeGrant(`GRANT MONITOR, USAGE, CREATE TABLE, CREATE VIEW, CREATE MATERIALIZED VIEW, CREATE MASKING POLICY, CREATE FILE FORMAT, CREATE SEQUENCE, CREATE FUNCTION, CREATE TASK, CREATE PROCEDURE ON FUTURE SCHEMAS IN DATABASE ` + DATABASENAME + ` to ` + mdmRole  );
    errors = errors + executeGrant(`GRANT SELECT, INSERT, UPDATE, TRUNCATE, DELETE ON ALL TABLES IN DATABASE ` + DATABASENAME + ` to ` + mdmRole  );
    errors = errors + executeGrant(`GRANT SELECT, INSERT, UPDATE, TRUNCATE, DELETE ON FUTURE TABLES IN DATABASE ` + DATABASENAME + ` to ` + mdmRole  );
    errors = errors + executeGrant(`GRANT SELECT ON ALL EXTERNAL TABLES IN DATABASE ` + DATABASENAME + ` to ` + mdmRole  );
    errors = errors + executeGrant(`GRANT SELECT ON FUTURE EXTERNAL TABLES IN DATABASE ` + DATABASENAME + ` to ` + mdmRole  );
    errors = errors + executeGrant(`GRANT SELECT ON ALL VIEWS IN DATABASE ` + DATABASENAME + ` to ` + mdmRole  );
    errors = errors + executeGrant(`GRANT SELECT ON FUTURE VIEWS IN DATABASE ` + DATABASENAME + ` to ` + mdmRole  );
    errors = errors + executeGrant(`GRANT USAGE, READ, WRITE ON ALL STAGES IN DATABASE ` + DATABASENAME + ` to ` + mdmRole  );
    errors = errors + executeGrant(`GRANT USAGE, READ, WRITE ON FUTURE STAGES IN DATABASE ` + DATABASENAME + ` to ` + mdmRole  );
    errors = errors + executeGrant(`GRANT ALL PRIVILEGES ON ALL FILE FORMATS IN DATABASE ` + DATABASENAME + ` to ` + mdmRole  );
    errors = errors + executeGrant(`GRANT ALL PRIVILEGES ON FUTURE FILE FORMATS IN DATABASE ` + DATABASENAME + ` to ` + mdmRole  );
    errors = errors + executeGrant(`GRANT MONITOR, OPERATE ON ALL TASKS IN DATABASE ` + DATABASENAME + ` to ` + mdmRole  );
    errors = errors + executeGrant(`GRANT MONITOR, OPERATE ON FUTURE TASKS IN DATABASE ` + DATABASENAME + ` to ` + mdmRole  );
    //errors = errors + executeGrant(`GRANT APPLY ON ALL MASKING POLICIES IN DATABASE ` + DATABASENAME + ` to ` + mdmRole  );
    //errors = errors + executeGrant(`GRANT APPLY ON FUTURE MASKING POLICIES IN DATABASE ` + DATABASENAME + ` to ` + mdmRole  );
    errors = errors + executeGrant(`GRANT ALL PRIVILEGES ON ALL SEQUENCES IN DATABASE ` + DATABASENAME + ` to ` + mdmRole  );
    errors = errors + executeGrant(`GRANT ALL PRIVILEGES ON FUTURE SEQUENCES IN DATABASE ` + DATABASENAME + ` to ` + mdmRole  );
    errors = errors + executeGrant(`GRANT ALL PRIVILEGES ON ALL PROCEDURES IN DATABASE ` + DATABASENAME + ` to ` + mdmRole  );
    errors = errors + executeGrant(`GRANT ALL PRIVILEGES ON FUTURE PROCEDURES IN DATABASE ` + DATABASENAME + ` to ` + mdmRole  );
    errors = errors + executeGrant(`GRANT ALL PRIVILEGES ON ALL FUNCTIONS IN DATABASE ` + DATABASENAME + ` to ` + mdmRole  );
    errors = errors + executeGrant(`GRANT ALL PRIVILEGES ON FUTURE FUNCTIONS IN DATABASE ` + DATABASENAME + ` to ` + mdmRole  );
    
    
    //DEVOPS
    errors = errors + executeGrant(`GRANT USAGE, MONITOR, CREATE SCHEMA ON DATABASE ` + DATABASENAME + ` to ` + devopsRole  );
    errors = errors + executeGrant(`GRANT MONITOR, USAGE, CREATE TABLE, CREATE VIEW, CREATE MATERIALIZED VIEW, CREATE MASKING POLICY, CREATE FILE FORMAT, CREATE SEQUENCE, CREATE FUNCTION, CREATE TASK, CREATE PROCEDURE ON ALL SCHEMAS IN DATABASE ` + DATABASENAME + ` to ` + devopsRole  );
    errors = errors + executeGrant(`GRANT MONITOR, USAGE, CREATE TABLE, CREATE VIEW, CREATE MATERIALIZED VIEW, CREATE MASKING POLICY, CREATE FILE FORMAT, CREATE SEQUENCE, CREATE FUNCTION, CREATE TASK, CREATE PROCEDURE ON FUTURE SCHEMAS IN DATABASE ` + DATABASENAME + ` to ` + devopsRole  );
    errors = errors + executeGrant(`GRANT SELECT, INSERT, UPDATE, TRUNCATE, DELETE ON ALL TABLES IN DATABASE ` + DATABASENAME + ` to ` + devopsRole  );
    errors = errors + executeGrant(`GRANT SELECT, INSERT, UPDATE, TRUNCATE, DELETE ON FUTURE TABLES IN DATABASE ` + DATABASENAME + ` to ` + devopsRole  );
    errors = errors + executeGrant(`GRANT SELECT ON ALL EXTERNAL TABLES IN DATABASE ` + DATABASENAME + ` to ` + devopsRole  );
    errors = errors + executeGrant(`GRANT SELECT ON FUTURE EXTERNAL TABLES IN DATABASE ` + DATABASENAME + ` to ` + devopsRole  );
    errors = errors + executeGrant(`GRANT SELECT ON ALL VIEWS IN DATABASE ` + DATABASENAME + ` to ` + devopsRole  );
    errors = errors + executeGrant(`GRANT SELECT ON FUTURE VIEWS IN DATABASE ` + DATABASENAME + ` to ` + devopsRole  );
    errors = errors + executeGrant(`GRANT USAGE, READ, WRITE ON ALL STAGES IN DATABASE ` + DATABASENAME + ` to ` + devopsRole  );
    errors = errors + executeGrant(`GRANT USAGE, READ, WRITE ON FUTURE STAGES IN DATABASE ` + DATABASENAME + ` to ` + devopsRole  );
    errors = errors + executeGrant(`GRANT ALL PRIVILEGES ON ALL FILE FORMATS IN DATABASE ` + DATABASENAME + ` to ` + devopsRole  );
    errors = errors + executeGrant(`GRANT ALL PRIVILEGES ON FUTURE FILE FORMATS IN DATABASE ` + DATABASENAME + ` to ` + devopsRole  );
    errors = errors + executeGrant(`GRANT MONITOR, OPERATE ON ALL TASKS IN DATABASE ` + DATABASENAME + ` to ` + devopsRole  );
    errors = errors + executeGrant(`GRANT MONITOR, OPERATE ON FUTURE TASKS IN DATABASE ` + DATABASENAME + ` to ` + devopsRole  );
    //errors = errors + executeGrant(`GRANT APPLY ON ALL MASKING POLICIES IN DATABASE ` + DATABASENAME + ` to ` + devopsRole  );
    //errors = errors + executeGrant(`GRANT APPLY ON FUTURE MASKING POLICIES IN DATABASE ` + DATABASENAME + ` to ` + devopsRole  );
    errors = errors + executeGrant(`GRANT ALL PRIVILEGES ON ALL SEQUENCES IN DATABASE ` + DATABASENAME + ` to ` + devopsRole  );
    errors = errors + executeGrant(`GRANT ALL PRIVILEGES ON FUTURE SEQUENCES IN DATABASE ` + DATABASENAME + ` to ` + devopsRole  );
    errors = errors + executeGrant(`GRANT ALL PRIVILEGES ON ALL PROCEDURES IN DATABASE ` + DATABASENAME + ` to ` + devopsRole  );
    errors = errors + executeGrant(`GRANT ALL PRIVILEGES ON FUTURE PROCEDURES IN DATABASE ` + DATABASENAME + ` to ` + devopsRole  );
    errors = errors + executeGrant(`GRANT ALL PRIVILEGES ON ALL FUNCTIONS IN DATABASE ` + DATABASENAME + ` to ` + devopsRole  );
    errors = errors + executeGrant(`GRANT ALL PRIVILEGES ON FUTURE FUNCTIONS IN DATABASE ` + DATABASENAME + ` to ` + devopsRole  );

    if(errors.trim().length == 0)
    {
        return "Permissions granted.";
    }
    else
    {
        return "Permission granted with errors: " + errors;
    }

}
catch (err)
{
   return "Permission grant failed: " + err; // Return a success/error indicator.
}

$$;

-- begin  set permissions
grant USAGE ON PROCEDURE  devops_utilities.public.set_mobilize_database_permissions(varchar) to role SYSADMIN;
-- end  set permissions
