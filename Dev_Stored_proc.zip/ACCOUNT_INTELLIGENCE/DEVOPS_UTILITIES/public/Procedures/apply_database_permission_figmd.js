use role securityadmin;

CREATE OR REPLACE PROCEDURE DEVOPS_UTILITIES.PUBLIC.APPLY_DATABASE_PERMISSION_FIGMD("DATABASENAME" VARCHAR, "SCHEMANAME" VARCHAR )
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '
// Setup the role variable
//var DATABASENAME = "PROD_DF_105";
//var SCHEMANAME = "OMOP";
var ROLE_NAME = "RBAR_P_SNOWFLAKE_INTELLIGENCE_FIGMD";
//Only allow prod databases
if (!DATABASENAME.toLowerCase().startsWith("prod_") || DATABASENAME.toLowerCase() == "prod_")
{
 return "FIGMD can only have access to prod_[name] databases";
}

// This function is used to execute GRANT COMMANDS and return any caught error as txt.
function executeGrant(command) {
    try {
        var rs = snowflake.execute({
            sqlText: command
        });
        return "";
    } catch (err) {
        return "Grant failed: " + err + "\\n";
    }
}
try {
    var errors = "";
    if (SCHEMANAME == "OMOP") {
        //OMOP - this is used to grant permission to omop schema for FIGMD role 
        errors = errors + executeGrant(`grant usage on database ` + DATABASENAME + ` to role ` + ROLE_NAME + `;`);
        errors = errors + executeGrant(`grant usage on schema ` + DATABASENAME + `.` + SCHEMANAME + `  to role ` + ROLE_NAME + `;`);
        errors = errors + executeGrant(`grant select on all tables in database ` + DATABASENAME + ` to role ` + ROLE_NAME + `;`);


    }
    //check to see if the SSAS Role has been inputed correctly
    else {
        return ''Bad parameter passed in procedure contact devops'';
    }
    if (errors.trim().length == 0) {
        return `Permissions granted to ` + DATABASENAME + `.` + SCHEMANAME + `.`;
    } else {
        return "Permission granted with errors: " + errors;
    }
} catch (err) {
    return "Permission grant failed: " + err; // Return a success/error indicator.
}
';

grant usage on procedure DEVOPS_UTILITIES.PUBLIC.APPLY_DATABASE_PERMISSION_FIGMD() to role RBA_P_DATAFACTORY;