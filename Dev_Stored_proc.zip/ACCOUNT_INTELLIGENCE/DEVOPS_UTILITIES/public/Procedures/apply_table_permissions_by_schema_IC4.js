CREATE OR REPLACE PROCEDURE DEVOPS_UTILITIES.public.apply_table_permissions_by_schema_IC4(DEBUGMODE boolean, SECURE_SCHEMA_NAME varchar(255))
RETURNS VARCHAR
LANGUAGE JAVASCRIPT
EXECUTE AS caller
AS
$$

/*
    This procedure will generate safely and run (or return, if we're running in debug mode)
    the GRANT SELECT statements on the specified secure view schema in the "SECURE_SCHEMA_NAME" variable.

    These grants will cover the views in those schemas, plus any dependencies those views have.
    
    NOTE:  The proc compares new rights to existing rights, and only missing rights are granted.

    eg:  CALL apply_table_permissions_by_schema_IC4(0,'PQDATAWAREHOUSE');
*/

    /************************
    *                       *
    *       FUNCTIONS       *
    *                       *
    ************************/

    // This function checks to make sure that the object names are all a combination of:
    // letters, numbers, underscores, and periods only.
    function safeForSql(name) {
        var rgxAllowedNames = /^[a-zA-Z0-9._]+$/;
        if (name.match(rgxAllowedNames) == null) {
            throw Error(`Possible SQL Injection: ${name}`);
            return;
        }
    }

    // This function is used to execute GRANT COMMANDS and return any caught error as txt.
    function executeGrant(command) {
        try {
            var rs = snowflake.execute( {sqlText: command} );
            return "";
        }
        catch(err) {
            throw Error(`Grant failed: ${err}\n`);
        }
    }

    // This function is used to run SQL command and throw an error on empty resultset
    function runQuery(command) {
        var result_set = snowflake.execute( {sqlText: command} );

        // if the result set is empty, return a warning message
        if (result_set.getRowCount() == 0) {
            throw Error("No results returned from query");
        }
        // otherwise, return the result set
        else {
            return result_set;
        }
    }


    /************************
    *                       *
    *       VARIABLES       *
    *                       *
    ************************/

    var accountname = "DTX_PROD_INTELLIGENCE_TO_HEOR";

    // var for our final long string of grant statements
    var final_grant_statements = [];

    // array for our final list of tables to create grant statements for
    var final_table_list = [];

    var schema_name = SECURE_SCHEMA_NAME;

    // check the hard-coded schema for sql injection
    safeForSql(schema_name);

    /************************
    *    EXISTING GRANTS    *
    ************************/

    // var for the query ID we'll be using to get the existing grants
    var existing_grants_query_id = "";

    // get the list of existing grants
    try {

        var noResult = runQuery(`SHOW GRANTS TO SHARE ${accountname};`);

        var last_qry_id = runQuery(`SELECT last_query_id() AS LAST_QUERY_ID;`);

        // loop through the query results
        while (last_qry_id.next()) {
            existing_grants_query_id = last_qry_id.getColumnValue("LAST_QUERY_ID");
        }

    }
    catch(err) {
        throw Error(`Error retrieving existing grants: ${err}\n`);
    }

    /************************
    *       NEW GRANTS      *
    ************************/

    // query to get the list of views that we need to create grant statements for
    var get_secure_view_list_sql = `
        SELECT  v.TABLE_CATALOG AS VIEW_CATALOG
                ,v.TABLE_SCHEMA AS VIEW_SCHEMA
                ,v.TABLE_NAME AS VIEW_NAME
        FROM    PROD_DTX.INFORMATION_SCHEMA.VIEWS v
        WHERE   v.table_catalog = 'PROD_DTX'
                AND v.is_secure = 'YES'
                AND v.table_schema = '${schema_name}'
    `;

    // query to get whether or not a grant for a given schema already exists
    var get_is_schema_grant_existing = `
        SELECT 1
        FROM table(result_scan('${existing_grants_query_id}')) z
        WHERE z."privilege" = 'USAGE'
            AND z."granted_on" = 'SCHEMA'
            AND UPPER(z."name") = '@{!__SchemaName__!}'
            AND z."grantee_name" ilike '%${accountname}'
    `;

    
    // query to get whether or not a grant for a given view already exists
    var get_is_view_grant_existing = `
        SELECT 1
        FROM table(result_scan('${existing_grants_query_id}')) z
        WHERE z."privilege" = 'SELECT'
            AND z."granted_on" = 'VIEW'
            AND UPPER(z."name") = '@{!__ViewName__!}'
            AND z."grantee_name" ilike '%${accountname}'
    `;

    // query to get object references that we need to create grant statements for
    var get_object_references_sql = `
        SELECT z."REFERENCED_DATABASE_NAME" || '.' || z."REFERENCED_SCHEMA_NAME" || '.' || z."REFERENCED_OBJECT_NAME" AS FULL_OBJECT_NAME
        FROM TABLE(PROD_DTX.INFORMATION_SCHEMA.GET_OBJECT_REFERENCES(database_name=>'@{!__ViewCatalog__!}', schema_name=>'@{!__ViewSchema__!}', object_name=>'@{!__ViewName__!}')) z
        WHERE z."REFERENCED_OBJECT_TYPE" = 'TABLE'
            -- make sure we don't already have a grant on these tables
            AND NOT EXISTS (
                SELECT 1
                FROM table(result_scan('${existing_grants_query_id}')) z
                WHERE z."privilege" = 'SELECT'
                    AND z."granted_on" = 'TABLE'
                    AND UPPER(z."name") = UPPER(CONCAT(z."REFERENCED_DATABASE_NAME",'.',z."REFERENCED_SCHEMA_NAME",'.',z."REFERENCED_OBJECT_NAME"))
                    AND z."grantee_name" ilike '%${accountname}'
            )
    `;

    // sql stubs for our grant statements
    var grant_select_on_view_sql = `grant select on view @{!__ViewName__!} to share ${accountname}; `;
    var grant_select_on_table_sql = `grant select on table @{!__TableName__!} to share ${accountname}; `;
    var grant_usage_on_schema_sql = `grant usage on view @{!__SchemaName__!} to share ${accountname}; `;


    /************************
    *                       *
    *         MAIN          *
    *                       *
    ************************/


    /************************
    *  SECURE VIEW GRANTS   *
    ************************/
        
    var secure_view_set = "";

    // run the query
    try {
        secure_view_set = runQuery(get_secure_view_list_sql);
    }
    catch(err) {
        // exit here if this step failed, no need to continue
        throw Error(`Query to get list of secure views failed: ${err}\n\n`);
    }

    try {
        var firsttime = 1;

        // loop through the query results
        while (secure_view_set.next()) {

            // get the name of the view we're currently working on
            var view_catalog = secure_view_set.getColumnValue("VIEW_CATALOG");
            var view_schema = secure_view_set.getColumnValue("VIEW_SCHEMA");
            var view_name = secure_view_set.getColumnValue("VIEW_NAME");

            // check for sql injection
            var full_view_name = `${view_catalog}.${view_schema}.${view_name}`;
            safeForSql(full_view_name);
            var schema_name = `${view_catalog}.${view_schema}`;
            safeForSql(schema_name);

            // Run this the first time only
            if (firsttime==1) {

                // check whether a grant for this schema already exists
                var get_is_schema_grant_existing_statement = get_is_schema_grant_existing.replaceAll("@{!__SchemaName__!}",schema_name);

                var existing_grant_set = "";

                try {
                    existing_grant_set = snowflake.execute( {sqlText: get_is_schema_grant_existing_statement} );
                }
                catch(err) {
                    // exit here if this step failed, no need to continue
                    throw Error(`Query to get existing grants for schema ${schema_name} failed: ${err}\n\n`);
                }

                // if the result set is empty, that means the grant doesn't exist and we need to create a statement for it
                if (existing_grant_set.getRowCount() == 0) {
                    // create a grant statement for the schema
                    var grant_usage_on_schema_sql_statement = grant_usage_on_schema_sql.replaceAll("@{!__SchemaName__!}",schema_name);

                    // push to our final list of grant statements
                    final_grant_statements.push(grant_usage_on_schema_sql_statement);
                }

                firsttime = 0;
            }


            // check whether a grant for this view already exists
            var get_is_view_grant_existing_statement = get_is_view_grant_existing.replace("@{!__ViewName__!}",full_view_name);

            var existing_grant_set = "";

            try {
                existing_grant_set = snowflake.execute( {sqlText: get_is_view_grant_existing_statement} );
            }
            catch(err) {
                // exit here if this step failed, no need to continue
                throw Error(`Query to get existing grants for secure view ${full_view_name} failed: ${err}\n\n`);
            }

            // if the result set is empty, that means the grant doesn't exist and we need to create a statement for it
            if (existing_grant_set.getRowCount() == 0) {
                // create a grant statement for the view
                var grant_select_on_view_statement = grant_select_on_view_sql.replace("@{!__ViewName__!}",full_view_name);

                // push to our final list of grant statements
                final_grant_statements.push(grant_select_on_view_statement);
            }

    /*********************
        TABLE GRANTS 
    **********************/

            // create a select statement to get object references for the view
            var get_object_references_statement = get_object_references_sql.replace("@{!__ViewCatalog__!}",view_catalog);
            get_object_references_statement = get_object_references_statement.replace("@{!__ViewSchema__!}",view_schema);
            get_object_references_statement = get_object_references_statement.replace("@{!__ViewName__!}",view_name);
            
            // run the query
            try {
                referenced_table_list = snowflake.execute( {sqlText: get_object_references_statement} );
            }
            catch(err) {
                // error condition - no results
                throw Error(`Failed to get list of object references for secure view ${full_view_name} with error: ${err}\n\n`);
            }

            // if the result set is not empty, we have an object to create a grant for
            if (referenced_table_list.getRowCount() != 0) {
                // we need to create a statement for each of the referenced tables
                while (referenced_table_list.next()) {                
                    // get the name of the table we're currently working on
                    var full_object_name = referenced_table_list.getColumnValue("FULL_OBJECT_NAME");
    
                    // check for sql injection
                    safeForSql(full_object_name);
    
                    // push to our list of tables
                    final_table_list.push(full_object_name);
                }
            }
        }
    }
    catch(err) {
        // exit here if this step failed, no need to continue
        throw Error(`Failed to get list of secure views: ${err}\n`);
    }

    try {

        // now that we have the tables we need to write grant sql statements for,
        // we want to get a DISTINCT list of those since there's overlap in the set.
        distinct_tables_to_grant = Array.from(new Set(final_table_list));
        
        // using that distinct list, write a grant sql statement and append it to our final output.
        for (var full_table_name of distinct_tables_to_grant) {

            // create a grant statement for the view
            var grant_select_on_table_statement = grant_select_on_table_sql.replace("@{!__TableName__!}",full_table_name);

            // push to our final list of grant statements
            final_grant_statements.push(grant_select_on_table_statement);
        }
    }
    catch(err) {
        // exit here if this step failed, no need to continue
        throw Error(`Failed to write grant statements for objects referenced by secured views: ${err}\n`);
    }
    
    /************************
    *       EXECUTION       *
    ************************/
    
    // we found nothing to grant permissions on, great news!
    if (final_grant_statements.length == 0) {
        return "Found no missing permissions to grant, exiting with success.";
    }
    // we're in debug mode, don't run the script, just return it
    else if (DEBUGMODE == 1) {
        return final_grant_statements.join("");
    }
    // go mode, run the final grant statements
    else {

        for (var stmt in final_grant_statements) {
            executeGrant(final_grant_statements[stmt]);
        }

    }
    
    return "Success";

$$;

CALL apply_table_permissions_by_schema_IC4(1,'PQDATAWAREHOUSE');
