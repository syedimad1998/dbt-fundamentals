--RUN AS SECURITYADMIN

CREATE OR REPLACE PROCEDURE devops_utilities.public.set_ssas_role_permission(ROLE_NAME varchar)
RETURNS varchar
LANGUAGE JAVASCRIPT
EXECUTE AS owner
AS

$$
// This function is used to execute GRANT COMMANDS and return any caught error as txt.
function executeGrant(command) {
    try {
        var rs = snowflake.execute({
            sqlText: command
        });
        return "";
    } catch (err) {
        return "Grant failed: " + err + "\n";
    }
}
try {
    var errors = "";
    if (ROLE_NAME == "RBAR_P_SSAS_RCM_DEV") {
       //DEV_RULEBOT_139
        errors = errors + executeGrant(`grant usage on database DEV_RULEBOT_139 to role ` + ROLE_NAME + `;`);
        errors = errors + executeGrant(`grant usage on future schemas in database DEV_RULEBOT_139 to role ` + ROLE_NAME + `;`);
        errors = errors + executeGrant(`grant select on future tables in database DEV_RULEBOT_139 to role ` + ROLE_NAME + `;`);
        errors = errors + executeGrant(`grant select on future views in database DEV_RULEBOT_139 to role ` + ROLE_NAME + `;`);
        errors = errors + executeGrant(`grant usage on all schemas in database DEV_RULEBOT_139 to role ` + ROLE_NAME + `;`);
        errors = errors + executeGrant(`grant select on all tables in database DEV_RULEBOT_139 to role ` + ROLE_NAME + `;`);
        errors = errors + executeGrant(`grant select on all views in database DEV_RULEBOT_139 to role ` + ROLE_NAME + `;`);
        //DEV_DTX
        errors = errors + executeGrant(`grant usage on database DEV_DTX to role ` + ROLE_NAME + `;`);
        errors = errors + executeGrant(`grant usage on schema DEV_DTX.DATA_OPS_DASHBOARD to role ` + ROLE_NAME + `;`);
        errors = errors + executeGrant(`grant select on all tables in schema DEV_DTX.DATA_OPS_DASHBOARD to role ` + ROLE_NAME + `;`);
        errors = errors + executeGrant(`grant select on all views in schema DEV_DTX.DATA_OPS_DASHBOARD to role ` + ROLE_NAME + `;`)
        //warehouse
        errors = errors + executeGrant(`grant usage on warehouse WH_RULEBOT_XS to role ` + ROLE_NAME + `;`);
    }
    //check to see if the SSAS Role has been inputed correctly
    else {
        return 'Bad parameter passed in procedure contact devops';
    }
    if (errors.trim().length == 0) {
        return "Permissions granted.";
    } else {
        return "Permission granted with errors: " + errors;
    }
} catch (err) {
    return "Permission grant failed: " + err; // Return a success/error indicator.
}
$$;
-- begin  set permissions
grant USAGE ON PROCEDURE devops_utilities.public.set_ssas_role_permission(varchar) to role SYSADMIN;
-- end  set permissions
