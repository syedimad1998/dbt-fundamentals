create table PROD_ADMIN.Datavant.Transformed_Tokens_Private (
    operation varchar(10) null,
    yearofbirth89 varchar(20) null,
    monthofdeath varchar(20) null,
    verification varchar(10) null,
    gender varchar(10) null,
    genderprob varchar(5) null,
    state varchar(20) null,
    causeofdeath varchar(20) null,
    token_1 varchar(50) null,
    token_2 varchar(50) null,
    token_4 varchar(50) null,
    token_5 varchar(50) null,
    token_16 varchar(50) null,
    token_encryption_key varchar(50) null
)