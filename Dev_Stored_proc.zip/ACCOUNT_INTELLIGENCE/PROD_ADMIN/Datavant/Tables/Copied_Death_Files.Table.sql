create table PROD_ADMIN.Datavant.Copied_Death_Files (
    file_name varchar(100) not null,
    last_modified_date varchar(20) not null
)