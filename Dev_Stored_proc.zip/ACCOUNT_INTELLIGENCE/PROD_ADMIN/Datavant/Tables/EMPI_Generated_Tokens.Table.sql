create table PROD_ADMIN.Datavant.EMPI_GENERATED_TOKENS (
    EMPI varchar(30) not null,
    token_1 varchar(50) null,
    token_2 varchar(50) null,
    token_3 varchar(50) null,
    token_4 varchar(50) null,
    token_5 varchar(50) null,
    token_16 varchar(50) null,
    token_encryption_key varchar(50) null
);