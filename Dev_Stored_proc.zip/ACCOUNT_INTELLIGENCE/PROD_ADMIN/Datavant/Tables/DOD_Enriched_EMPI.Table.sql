create table PROD_ADMIN.Datavant.DOD_ENRICHED_EMPI (
    EMPI varchar(30) not null,
    token_1 varchar(50) null,
    token_2 varchar(50) null,
    token_3 varchar(50) null,
    token_4 varchar(50) null,
    token_5 varchar(50) null,
    token_16 varchar(50) null,
    dod varchar(20) null,
    dod_source varchar(20) null
)