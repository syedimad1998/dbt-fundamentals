create or replace view PROD_ADMIN.EMPI.EMPI_XWALK_VERATO as 
SELECT person_source_value, system_source_value, client_source_value, EMPI, VERATOID from PROD_ADMIN.EMPI.EMPI_XWALK;