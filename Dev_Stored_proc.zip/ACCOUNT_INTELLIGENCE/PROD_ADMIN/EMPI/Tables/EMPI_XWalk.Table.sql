CREATE TABLE EMPI.EMPI_XWalk(
	last_name varchar (100) null
	, first_name varchar (100) null
	, middle_name varchar (100) null
	, ssn varchar (20) null
	, birthdate date null
	, zip varchar (9) null
	, person_source_value varchar (100) null
	, EMPI bigint null
	, system_source_value varchar (500) null
	, client_source_value varchar (500) null
	, created_date datetime null
	, VeratoId varchar(50) null
);
