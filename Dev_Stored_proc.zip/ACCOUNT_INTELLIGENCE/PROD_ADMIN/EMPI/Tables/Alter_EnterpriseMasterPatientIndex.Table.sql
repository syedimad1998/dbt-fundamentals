alter table PROD_ADMIN.EMPI.EnterpriseMasterPatientIndex
add ( 
  dateofdeath date null,
  dod_source varchar(20) null
)