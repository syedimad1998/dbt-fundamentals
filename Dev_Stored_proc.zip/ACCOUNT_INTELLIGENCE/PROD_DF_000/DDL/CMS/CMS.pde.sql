CREATE OR REPLACE TABLE CMS.pde(  
 PDE_ID varchar(50) NULL,  
 BENE_ID varchar(50) NULL,  
 DRUG_CVRG_STUS_CD varchar(50) NULL,  
 CTSTRPHC_CVRG_CD varchar(50) NULL,  
 PROD_SRVC_ID varchar(50) NULL,  
 PRSCRBR_ID varchar(50) NULL,  
 SRVC_DT date NULL,  
 FILL_NUM varchar(50) NULL,  
 QTY_DSPNSD_NUM varchar(50) NULL,  
 DAYS_SUPLY_NUM varchar(50) NULL,  
 GDC_BLW_OOPT_AMT varchar(50) NULL,  
 GDC_ABV_OOPT_AMT varchar(50) NULL,  
 LICS_AMT varchar(50) NULL,  
 TOT_RX_CST_AMT varchar(50) NULL,  
 EP_ID varchar(50) NULL,  
 Practice varchar(9) NULL  
) cluster by (PDE_ID, TOT_RX_CST_AMT, BENE_ID, PROD_SRVC_ID, PRSCRBR_ID, SRVC_DT, QTY_DSPNSD_NUM, DAYS_SUPLY_NUM );