CREATE OR REPLACE TABLE CMS.EpisodesLog(  
 TableName nvarchar(256) NULL,  
 TableCreateDate datetime NULL,  
 ProcessDate datetime NULL  
);