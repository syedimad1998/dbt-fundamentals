CREATE OR REPLACE TABLE CMS.FacilityTypeCodes(
              FacilityCode varchar(5) NOT NULL,
              FacilityName varchar(500) NOT NULL,
              CreateDate datetime NOT NULL,
              CreateUser varchar(100) NOT NULL
) ;