CREATE OR REPLACE TABLE CMS.inpRev(  
 BENE_ID varchar(255) NULL,  
 CLM_ID varchar(255) NULL,  
 CLM_THRU_DT date NULL,  
 CLM_LINE_NUM varchar(255) NULL,  
 REV_CNTR varchar(255) NULL,  
 HCPCS_CD varchar(255) NULL,  
 REV_CNTR_UNIT_CNT varchar(255) NULL,  
 REV_CNTR_RATE_AMT varchar(255) NULL,  
 REV_CNTR_NDC_QTY varchar(255) NULL,  
 REV_CNTR_NDC_QTY_QLFR_CD varchar(255) NULL,  
 EP_ID varchar(255) NULL,  
 REV_CNTR_TOT_CHRG_AMT varchar(255) NULL,  
 REV_CNTR_NCVRD_CHRG_AMT varchar(255) NULL,  
 Practice varchar(9) NULL  
);