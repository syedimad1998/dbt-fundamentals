CREATE OR REPLACE TABLE CMS.PlaceOfServiceCodes(
              ServiceCode varchar(5) NOT NULL,
              ServiceName varchar(100) NOT NULL,
              ServiceDescription varchar(800) NOT NULL,
              CreateDate datetime NOT NULL,
              CreateUser varchar(100) NOT NULL
) ;