

create or replace table cms.MEOSRecoup (
     CCW_Beneficiary_ID varchar(500) NULL
    ,CCW_Claim_ID varchar(500) NULL
    ,Claim_Control_Number varchar(500) NULL
    ,Claim_Line_Number varchar(500) NULL
    ,Date_of_Birth date NULL
    ,First_Name varchar(500) NULL
    ,HICN varchar(500) NULL
    ,Last_Name varchar(500) NULL
    ,MBI varchar(500) NULL
    ,OCM_Episode_ID varchar(500) NULL
    ,Payment_Amount varchar(500) NULL
    ,Performing_NPI varchar(500) NULL
    ,Procedure_Code varchar(500) NULL
    ,Service_Date date NULL
    ,TIN varchar(500) NULL
    ,Recoupment_Reason varchar(500) NULL
    ,Recoupment_Reason_Detail varchar(500) NULL
    ,Eligibility_Assessment_Detail varchar(500) NULL
    ,Episodes_Initiating_MEOS_Eligibility_Assessment varchar(500) NULL
    ,Eligibility_Assessment varchar(500) NULL
    ,Perf_Period varchar(20) null
)