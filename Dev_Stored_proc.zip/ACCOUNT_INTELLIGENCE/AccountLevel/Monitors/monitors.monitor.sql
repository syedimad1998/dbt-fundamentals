CREATE OR REPLACE RESOURCE MONITOR intelligence_account_limit WITH credit_quota = 25000
    TRIGGERS ON 33 percent DO notify
             ON 50 percent DO notify
             ON 100 percent DO suspend
             ON 101 percent DO suspend_immediate;

ALTER ACCOUNT SET RESOURCE_MONITOR = intelligence_account_limit;

CREATE OR REPLACE RESOURCE MONITOR dev_qa_warehouse_limit WITH credit_quota = 11250
    TRIGGERS ON 50 percent DO notify
             ON 75 percent DO notify
             ON 100 percent DO suspend
             ON 101 percent DO suspend_immediate;

ALTER WAREHOUSE wh_deid_dev SET RESOURCE_MONITOR = dev_qa_warehouse_limit;
ALTER WAREHOUSE wh_p_dev SET RESOURCE_MONITOR = dev_qa_warehouse_limit;
ALTER WAREHOUSE xs SET RESOURCE_MONITOR = dev_qa_warehouse_limit;

CREATE OR REPLACE RESOURCE MONITOR analyst_warehouse_limit WITH credit_quota = 6250
    TRIGGERS ON 50 percent DO notify
             ON 75 percent DO notify
             ON 100 percent DO suspend
             ON 101 percent DO suspend_immediate;

ALTER WAREHOUSE wh_p_dataanalyst SET RESOURCE_MONITOR = analyst_warehouse_limit;
ALTER WAREHOUSE wh_np_dataanalyst SET RESOURCE_MONITOR = analyst_warehouse_limit;
ALTER WAREHOUSE wh_p_dataanalys SET RESOURCE_MONITOR = analyst_warehouse_limit;


CREATE OR REPLACE RESOURCE MONITOR prod_warehouse_limit WITH credit_quota = 7500
    TRIGGERS ON 50 percent DO notify
             ON 75 percent DO notify
             ON 100 percent DO suspend
             ON 101 percent DO suspend_immediate;

ALTER WAREHOUSE wh_p_abstraction SET RESOURCE_MONITOR = prod_warehouse_limit;
ALTER WAREHOUSE wh_mdm_large SET RESOURCE_MONITOR = prod_warehouse_limit;
ALTER WAREHOUSE wh_mdm_small SET RESOURCE_MONITOR = prod_warehouse_limit;
ALTER WAREHOUSE wh_administration SET RESOURCE_MONITOR = prod_warehouse_limit;
ALTER WAREHOUSE wh_architect_small SET RESOURCE_MONITOR = prod_warehouse_limit;
ALTER WAREHOUSE wh_architect_large SET RESOURCE_MONITOR = prod_warehouse_limit;
ALTER WAREHOUSE wh_p_integration SET RESOURCE_MONITOR = prod_warehouse_limit;
ALTER WAREHOUSE wh_jobs_xs SET RESOURCE_MONITOR = prod_warehouse_limit;
ALTER WAREHOUSE wh_jobs_s SET RESOURCE_MONITOR = prod_warehouse_limit;
ALTER WAREHOUSE wh_jobs_m SET RESOURCE_MONITOR = prod_warehouse_limit;
ALTER WAREHOUSE wh_jobs_l SET RESOURCE_MONITOR = prod_warehouse_limit;
