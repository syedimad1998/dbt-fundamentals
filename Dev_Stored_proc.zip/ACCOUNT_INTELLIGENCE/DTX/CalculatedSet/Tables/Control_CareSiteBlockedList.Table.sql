CREATE TABLE CalculatedSet.Control_CareSiteBlockedList(
	Division varchar (100) not null
	, MeasureName varchar (100) null
	, CareSiteTin varchar (100) not null
);
