CREATE TABLE CalculatedSet.dimVisitDefinitionCriteria(
	VisitDefinitionCriteriaId int not null
	, FriendlyDescription varchar null
	, VisitProcedureOccurrenceQualifierSourceValue int null
	, VisitProcedureOccurrenceProcedureSourceValue varchar null
	, VisitVisitOccurrenceVisitConceptId int null
	, AnyEmrNotedVisitNotFlaggedInOtherCategories boolean null
);
