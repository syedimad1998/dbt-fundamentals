CREATE TABLE CalculatedSet.Control_OCMQualifyingTherapies(
	GenericName nvarchar not null
	, EffectiveStartDate date not null
	, EffectiveEndDate date null
);
