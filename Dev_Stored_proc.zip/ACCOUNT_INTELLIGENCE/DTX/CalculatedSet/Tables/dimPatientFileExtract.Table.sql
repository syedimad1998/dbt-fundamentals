CREATE TABLE CalculatedSet.dimPatientFileExtract(
	Division varchar (100) not null
	, RecordInsertionDate datetime (8) not null
	, MpiId int not null
	, CombinedDivisionMpi varchar (128) not null
	, EventType varchar (24) not null
	, EventDate date not null
	, SuggestedFilename varchar (255) not null
	, FileContent varchar not null
);
