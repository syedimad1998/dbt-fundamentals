CREATE TABLE CalculatedSet.dimPatient(
	Division varchar (100) not null
	, RecordInsertionDate datetime (8) not null
	, MpiId int not null
	, CombinedDivisionMpi varchar (128) not null
	, LastName varchar (100) null
	, FirstName varchar (100) null
	, MiddleName varchar (100) null
	, MRN varchar (100) null
	, BirthDateTime date null
	, ProviderId int null
	, ProviderMpiId int null
	, GenderName varchar (9) null
	, Race varchar null
	, Ethnicity varchar (255) null
	, GeneralizedRace varchar null
	, GeneralizedEthnicity varchar (255) null
	, DateOfDeath date null
	, LungCancerCellSize varchar (100) null
	, ER_WITHOUT_NOTE varchar (100) null
	, PR_WITHOUT_NOTE varchar (100) null
	, HER2_WITHOUT_NOTE varchar (100) null
	, ER_WITH_NOTE varchar (100) null
	, PR_WITH_NOTE varchar (100) null
	, HER2_WITH_NOTE varchar (100) null
	, NOTE_TRIPLE_NEGATIVE boolean null
	, NumberOfOcmEpisode int not null
	, LastOcmEpisodeStartDate date null
	, LastOcmEpisodeEndDate date null
	, Address_1 varchar (50) null
	, Address_2 varchar (50) null
	, Address_City varchar (50) null
	, Address_State char (2) null
	, Address_Zip varchar (9) null
	, Address_County varchar (20) null
	, PatientHadAbstractionEvent boolean not null
	, RecordSourceIdentifier varchar (10) null
	, PrimaryProviderCareSiteHashId char (130)null
);
