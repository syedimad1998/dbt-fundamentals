CREATE TABLE CalculatedSet.Control_SourceSystem(
	RecordSourceIdentifier varchar (10) not null
	, Classification varchar (25) not null
);
