CREATE TABLE CalculatedSet.Control_CancerCodeToDescriptionMatching(
	CodeSystem varchar (5) not null
	, CancerMatchCode varchar (20) not null
	, DescriptionMajorClassification varchar (200) not null
	, DescriptionMinorClassification varchar (200) not null
	, CancerPrimarySecondaryClassification varchar (10) not null
	, ExactLocation varchar (50) not null
	, GeneralLocation varchar (20) not null
	, Control_CancerCodeToDescriptionMatchingId int not null
);
