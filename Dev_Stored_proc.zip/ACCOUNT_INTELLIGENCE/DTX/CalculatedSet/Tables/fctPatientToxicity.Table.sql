CREATE TABLE CalculatedSet.fctPatientToxicity(
	Division varchar (100) not null
	, RecordInsertionDate datetime (8) not null
	, MpiId int not null
	, CombinedDivisionMpi varchar (128) not null
	, AdverseEventDescription varchar (100) not null
	, SourceLocation varchar (100) not null
	, LabSpecificTestName varchar (300) null
	, SourceValue varchar (300) not null
	, SourceUnit varchar (100) null
	, SourceValueComparison varchar (100) null
	, EventDateInstance date not null
	, DaysSinceLastChemotherapyTreatment int not null
	, EventObserver varchar (20) null
	, QualitativeAssessment varchar (20) null
	, Grade varchar (20) null
	, AdverseEventPresent boolean not null
	, RecordSourceIdentifier varchar (10) null
	, SymptomCategory varchar (100) null
);
