CREATE TABLE CalculatedSet.fctPatientTargetedTherapy(
	Division varchar (100) not null
	, RecordInsertionDate datetime (8) not null
	, MpiId int not null
	, CombinedDivisionMpi varchar (128) not null
	, ConditionType varchar (50) not null
	, ConditionDescription varchar (100) not null
	, ConditionSampleIcdCode varchar (10) null
	, ConditionDate date null
	, TherapyProvided varchar (2000) null
	, TherapyStartDate date null
	, TherapyEndDate date null
	, IsPositiveForConditionIsPositiveForTargetTherapy boolean not null
	, IsPositiveForConditionIsNegativeForTargetTherapy boolean not null
	, IsNegativeForConditionIsPositiveForTargetTherapy boolean not null
	, RecordSourceIdentifier varchar (10) null
);
