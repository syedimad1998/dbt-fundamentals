CREATE TABLE CalculatedSet.fctPatientDailyCostOfCare(
	Division varchar (100) not null
	, RecordInsertionDate datetime (8) not null
	, MpiId int not null
	, CombinedDivisionMpi varchar (128) not null
	, CareDate date not null
	, PayerName varchar (255) not null
	, IsOcmPayer boolean not null
	, TotalCost decimal (19,4) not null
	, GeneralizedPayerCategory varchar (100) null
	, RecordSourceIdentifier varchar (10) null
);
