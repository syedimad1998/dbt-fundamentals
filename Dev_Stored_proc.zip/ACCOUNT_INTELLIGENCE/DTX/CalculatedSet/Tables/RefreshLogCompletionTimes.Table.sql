CREATE TABLE CalculatedSet.RefreshLogCompletionTimes(
	RefreshLogCompletionTimesId int not null
	, RefreshLogId int not null
	, Division varchar (100) not null
	, Section varchar (100) not null
	, SubSection varchar (200) not null
	, StartDate date not null
	, StartDateTime_UTC datetime (8) not null
	, EndDateTime_UTC datetime (8) not null
	, DurationInSeconds int not null
	, DurationInMinutes int null
);
