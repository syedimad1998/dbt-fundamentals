CREATE TABLE CalculatedSet.Control_CancerHistologyCodeDescription(
	Code varchar (8) null
	, Description varchar (4000) not null
);
