CREATE TABLE CalculatedSet.LoadError(
	ErrorLogID int not null
	, ErrorTime_Local datetime (8) not null
	, ErrorTime_UTC datetime (8) not null
	, Division varchar (100) not null
	, UserName nvarchar not null
	, ErrorSeverity int null
	, ErrorState int null
	, ErrorProcedure nvarchar null
	, ErrorLine int null
	, ErrorMessage nvarchar null
	, RefreshLogId int null
);
