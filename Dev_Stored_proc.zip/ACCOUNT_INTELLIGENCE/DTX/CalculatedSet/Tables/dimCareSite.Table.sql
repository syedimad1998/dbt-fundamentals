CREATE TABLE CalculatedSet.dimCareSite(
	Division varchar (100) not null
	, RecordInsertionDate datetime (8) not null
	, CareSiteHashId char (130)not null
	, CareSiteName varchar (500) not null
	, TIN varchar (100) null
	, CareSiteNPI varchar (255) null
	, Address_Line1 varchar (1000) null
	, Address_Line2 varchar (1000) null
	, Address_City varchar (1000) null
	, Address_State varchar (250) null
	, Address_ZIP varchar (250) null
	, CareSiteIsConfirmedByDivision boolean not null
	, RecordSourceIdentifier varchar (10) null
);
