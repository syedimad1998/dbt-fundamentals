CREATE TABLE CalculatedSet.Control_PayerMapping(
	MatchCode varchar (100) not null
	, PayerNameOrPayerTypeLocation varchar (50) not null
	, PayerCategory varchar (100) not null
	, Division varchar (100) null
	, IsOCMPayer boolean not null
);
