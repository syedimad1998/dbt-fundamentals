CREATE TABLE CalculatedSet.fctPatientCancerMetastaticSite(
	Division varchar (100) not null
	, RecordInsertionDate datetime (8) not null
	, MpiId int not null
	, CombinedDivisionMpi varchar (128) not null
	, DateFirstProofOfMetastaticSpread date not null
	, DateLastProofOfMetastaticSpread date not null
	, SiteLocation varchar (200) not null
	, RolledUpGeneralSiteLocation varchar (200) not null
	, SiteGrouping varchar (200) null
	, RecordSourceIdentifier varchar (10) null
);
