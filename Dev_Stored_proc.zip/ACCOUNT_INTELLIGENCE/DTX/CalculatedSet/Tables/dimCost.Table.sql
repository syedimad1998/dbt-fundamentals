CREATE TABLE CalculatedSet.dimCost(
	Division varchar (100) not null
	, MpiId int not null
	, CombinedDivisionMpi varchar (128) not null
	, CostId char (36)not null
	, CostDomain varchar (200) not null
	, DateOfService date null
	, TotalCharge float null
	, TotalPaid float null
	, PayerName varchar (255) null
	, GeneralizedPayerCategory varchar (100) null
	, IsOcmPayer boolean not null
	, RecordSourceIdentifier varchar (10) null
);
