CREATE TABLE CalculatedSet.dimAbstraction(
	AbstractionTypeId int not null
	, Name varchar (100) not null
	, Description varchar (1000) null
);
