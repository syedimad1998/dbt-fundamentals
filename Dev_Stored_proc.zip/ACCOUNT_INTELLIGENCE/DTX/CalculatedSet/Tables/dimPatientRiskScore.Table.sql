CREATE TABLE CalculatedSet.dimPatientRiskScore(
	Division varchar (100) null
	, RecordInsertionDate datetime null
	, MpiID int null
	, CombinedDivisionMpi varchar (128) not null
	, RiskName varchar (100) not null
	, ValueAsInt int null
	, ValueAsFloat float null
	, ValueAsString varchar (100) null
	, TestDate date not null
	, RecordSourceIdentifier varchar (10) null
);
