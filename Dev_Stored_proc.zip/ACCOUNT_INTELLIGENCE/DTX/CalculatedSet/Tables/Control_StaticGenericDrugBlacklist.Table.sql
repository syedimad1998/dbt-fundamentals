CREATE TABLE CalculatedSet.Control_StaticGenericDrugBlacklist(
	MatchCode varchar (200) not null
);
