CREATE TABLE CalculatedSet.fctPatientVital(
	Division varchar (100) not null
	, RecordInsertionDate datetime (8) not null
	, MpiId int not null
	, CombinedDivisionMpi varchar (128) not null
	, TestDate date not null
	, TestName varchar (100) not null
	, ValueAsNumber float null
	, UnitValue varchar (50) null
	, NormalRangeLow float null
	, NormalRangeHigh float null
	, Recordsourceidentifier varchar (10) null
);
