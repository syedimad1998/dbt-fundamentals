CREATE TABLE CalculatedSet.Control_LabUnitConversion
(
	TestName varchar(100) NOT NULL
	,UnitValueFrom varchar(50) NOT NULL
	,UnitValueTo varchar(50) NOT NULL
	,ConversionFormula varchar(50) NULL
	,ConversionOperator char(1) NULL
	,ConversionValue varchar(50) NULL
)
;