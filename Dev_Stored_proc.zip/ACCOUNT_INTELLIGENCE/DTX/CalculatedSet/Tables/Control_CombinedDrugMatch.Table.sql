CREATE TABLE CalculatedSet.Control_CombinedDrugMatch(
	MatchCode varchar (200) not null
	, MatchType char (10) not null
	, GenericName varchar (200) not null
	, NdcProductId varchar (200) null
	, NdcId varchar (200) null
	, Priority int not null
	, DrugCategory varchar (200) null
	, DrugSubCategory varchar (200) null
	, BrandName varchar (200) null
    , RxNormId int NULL
    , RxNormDescription varchar(500) NULL
);
