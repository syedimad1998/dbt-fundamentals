CREATE TABLE CalculatedSet.dimVisitDefinitionCriteriaCriteriaGroup(
	VisitDefinitionCriteriaGroupId int not null
	, VisitDefinitionCriteriaId int not null
);
