CREATE TABLE CalculatedSet.Control_DiagnosisCode(
	CodeSystem varchar (5) not null
	, MatchCode varchar (20) not null
	, DiagnosisName varchar (200) not null
	, DescriptionMajorClassification varchar (200) null
	, DescriptionMinorClassification varchar (200) null
	, PrimarySecondaryClassification varchar (10) null
	, ExactLocation varchar (50) null
	, GeneralLocation varchar (50) null
	, TestDefinitionSource varchar (255) null
	, IsCancer boolean not null
	, IsDisease boolean not null
	, IsAdverseEvent boolean not null
	, IsComorbidity boolean not null
	, Control_CancerCodeToDescriptionMatchingId int null
	, TestDefaultVisibleInUserFacingDashboards boolean null
);
