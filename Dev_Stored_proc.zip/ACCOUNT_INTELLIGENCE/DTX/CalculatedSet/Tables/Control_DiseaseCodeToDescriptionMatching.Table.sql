CREATE TABLE CalculatedSet.Control_DiseaseCodeToDescriptionMatching(
	CodeSystem varchar (5) not null
	, DiseaseMatchCode varchar (20) not null
	, DescriptionMajorClassification varchar (200) null
	, DescriptionMinorClassification varchar (200) null
);
