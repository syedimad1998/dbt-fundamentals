CREATE TABLE CalculatedSet.dimDate(
	TheDate date not null
	, TheDay int not null
	, TheDaySuffix char (2) not null
	, TheDayName nvarchar not null
	, TheDayOfWeek int not null
	, TheDayOfWeekInMonth tinyint not null
	, TheDayOfYear int not null
	, IsUSHoliday boolean not null
	, IsUSBankHoliday boolean not null
	, IsWeekend boolean not null
	, TheWeek int not null
	, TheISOweek int not null
	, WeekSinceAnchorDate int not null
	, TheFirstOfWeek date not null
	, TheLastOfWeek date not null
	, TheWeekOfMonth tinyint not null
	, TheMonth int not null
	, TheMonthName nvarchar not null
	, TheFirstOfMonth date not null
	, TheLastOfMonth date not null
	, TheFirstOfNextMonth date not null
	, TheLastOfNextMonth date not null
	, TheQuarter int not null
	, TheFirstOfQuarter date not null
	, TheLastOfQuarter date not null
	, TheYear int not null
	, TheISOYear int not null
	, TheFirstOfYear date not null
	, TheLastOfYear date not null
	, IsLeapYear boolean not null
	, Has53Weeks int not null
	, Has53ISOWeeks int not null
	, MMYYYY char (6) not null
	, Style101 char (10) not null
	, Style103 char (10) not null
	, Style112 char (8) not null
	, Style120 char (10) not null
	, YearWeekStyle varchar (8) not null
	, IsoYearWeekStyle varchar (10) not null
	, PQStyle1 varchar (10) not null
	, PQStyle2 varchar (10) not null
	, PQStyle3 varchar (20) not null
	, WeekEndSaturdayDate date not null
	, WeekEndSundayDate date not null
);
