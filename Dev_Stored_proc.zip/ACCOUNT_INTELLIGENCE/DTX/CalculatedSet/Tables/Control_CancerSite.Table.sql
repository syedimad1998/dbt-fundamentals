CREATE TABLE CalculatedSet.Control_CancerSite (
	CancerSiteId int NOT NULL,
	CancerSiteName varchar(500) NOT NULL
);