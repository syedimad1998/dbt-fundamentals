CREATE TABLE CalculatedSet.RefreshLogActivity(
	RefreshLogId int not null
	, ActivityDate datetime (8) null
	, MessageType varchar (30) null
	, MessageCategory varchar (50) null
	, Message varchar null
);
