CREATE TABLE CalculatedSet.Control_SourceSystemDivisionMapping(
	Division varchar (100) null
	, MatchCode varchar (100) not null
	, Classification varchar (25) not null
	, SubClassification varchar (25) null
	, StartDate datetime not null
	, EndDate datetime null
	, Priority tinyint not null
	, RecordSourceIdentifier varchar (10) null
);
