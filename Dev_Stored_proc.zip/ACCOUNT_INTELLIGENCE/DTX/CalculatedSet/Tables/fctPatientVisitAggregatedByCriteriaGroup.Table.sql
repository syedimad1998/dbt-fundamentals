CREATE TABLE CalculatedSet.fctPatientVisitAggregatedByCriteriaGroup(
	Division varchar (100) not null
	, RecordInsertionDate datetime (8) not null
	, VisitDefinitionCriteriaGroupId int not null
	, MpiId int not null
	, CombinedDivisionMpi varchar (128) not null
	, TotalVisits int not null
	, RecordSourceIdentifier varchar (10) null
);
