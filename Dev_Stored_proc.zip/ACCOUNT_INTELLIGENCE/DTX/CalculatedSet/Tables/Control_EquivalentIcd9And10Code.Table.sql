CREATE TABLE CalculatedSet.Control_EquivalentIcd9And10Code(
	ICD9 varchar (10) null
	, ICD10 varchar (10) null
);
