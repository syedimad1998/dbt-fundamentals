CREATE TABLE CalculatedSet.Control_ServiceCodeDescription(
	ServiceCodeDescriptionId int not null
	, PlaceOfServiceCode char (2) not null
	, PlaceOfServiceName varchar (100) not null
	, PlaceOfServiceGeneralizedName varchar (100) not null
	, PlaceOfServiceDescription varchar (1000) not null
);
