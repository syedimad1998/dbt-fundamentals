CREATE TABLE CalculatedSet.Control_CareSiteCleanedIdentifier(
	Division varchar (100) not null
	, SystemSourceValue varchar (100) not null
	, CareSiteSourceValue varchar (500) not null
	, CareSiteName varchar (500) not null
	, TIN varchar (100) null
	, CareSiteNPI varchar (255) null
	, Address_Line1 varchar (1000) null
	, Address_Line2 varchar (1000) null
	, Address_City varchar (1000) null
	, Address_State varchar (250) null
	, Address_ZIP varchar (250) null
);
