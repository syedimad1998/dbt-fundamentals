CREATE TABLE CalculatedSet.fctPatientProcedure(
	Division varchar (100) not null
	, RecordInsertionDate datetime null
	, MpiId int not null
	, CombinedDivisionMpi varchar (128) not null
	, DateOfEvent date not null
	, ProcedureName varchar (200) not null
	, ProcedureSourceCode varchar (25) null
	, ProcedureSourceCodeName varchar (500) null
	, ProcedureSourceCodeType varchar (15) null
	, CombinedDivisionProviderMpi varchar (128) null
	, ProviderCareSiteHashId char (130)null
	, ValueAsString varchar (200) null
	, DateOfEventEnd date null
	, RecordSourceIdentifier varchar (10) null
	, PrimaryValueAsInt int null
	, PrimaryValueAsFloat float null
	, PrimaryUnit varchar (20) null
	, SecondaryValueAsInt int null
	, SecondaryValueAsFloat float null
	, SecondaryUnit varchar (20) null
	, PrimaryAnatomicSiteLocation varchar (50) null
	, SecondaryAnatomicSiteLocation varchar (50) null
	, CostId char (36)null
	, GeneralizedProcedureCategory varchar (100) null
	, ServiceCodeDescriptionId int null
	, Laterality varchar (50) null
	, TreatmentIntent varchar (50) null
);
