CREATE TABLE CalculatedSet.fctPatientCancer(
	Division varchar (100) not null
	, RecordInsertionDate datetime (8) not null
	, MpiId int not null
	, CombinedDivisionMpi varchar (128) not null
	, CodeType varchar (10) not null
	, CancerCode varchar (100) not null
	, CancerCodeMajorCategory varchar (4) not null
	, DateFirstInstanceOfCancerCode date not null
	, DateLastInstanceOfCancerCode date not null
	, ConditionConceptId int not null
	, MinConditionStartDate date not null
	, MaxConditionStartDate date not null
	, MinConditionEndDate date not null
	, MaxConditionEndDate date not null
	, DescriptionMajorClassification varchar (200) null
	, DescriptionMinorClassification varchar (200) null
	, CancerPrimarySecondaryClassification varchar (10) null
	, ExactLocation varchar (50) null
	, GeneralLocation varchar (20) null
	, RecordSourceIdentifier varchar (10) null
	, CancerCodeMajorFirstDiagnosisDate date not null CONSTRAINT DF_CancerCodeMajorFirstDiagnosisDate_fctPatientCancer  DEFAULT '1900-01-01'
);
