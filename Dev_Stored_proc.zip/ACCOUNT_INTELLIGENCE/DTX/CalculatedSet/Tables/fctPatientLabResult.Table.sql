CREATE TABLE CalculatedSet.fctPatientLabResult(
	Division varchar (100) not null
	, RecordInsertionDate datetime (8) not null
	, MpiId int not null
	, CombinedDivisionMpi varchar (128) not null
	, TestDate date not null
	, PatientLabTestId int not null
	, TestConceptId int null
	, ValueAsInt int null
	, ValueAsFloat float null
	, ValueAsString varchar null
	, UnitValue varchar (50) null
	, RawData_Value varchar not null
	, NormalRangeLow float null
	, NormalRangeHigh float null
	, RecordSourceIdentifier varchar (10) null
	, ResultDate date null
	, OrderingProviderMpi int null
	, OrderingCombinedDivisionProviderMpi varchar (113) null
	, SampleType varchar (100) null
	, ServiceCodeDescriptionId int null
	, TestingCompany varchar (100) null
	, GenomicPanelTested varchar (100) null
	, CommercialTestName varchar (50) null
	, SpecimenCollectionMethod varchar (50) null
	, SpecimenCollectionDate date null
    , ExperimentalUnitValue varchar(50) null
	, ExperimentalValueAsInt int null
	, ExperimentalValueAsFloat float null	
	, ExperimentalValueAsBigInt bigint null	-- PQ-14028
	, TestCategory Varchar(100) null
);
