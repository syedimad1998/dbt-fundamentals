CREATE TABLE CalculatedSet.Control_LookupCode_AdverseEvent(
	GeneralAdverseEventName varchar (100) not null
	, CodeSystem varchar (5) not null
	, ConditionMatchCode_MajorCategory varchar (11) null
	, ConditionMatchCode_FullCode varchar (11) null
);
