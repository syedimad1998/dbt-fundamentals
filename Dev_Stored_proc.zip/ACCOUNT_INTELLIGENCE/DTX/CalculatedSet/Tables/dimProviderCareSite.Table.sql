CREATE TABLE CalculatedSet.dimProviderCareSite(
	Division varchar (100) not null
	, RecordInsertionDate datetime (8) not null
	, ProviderMpiId int not null
	, CombinedDivisionProviderMpi varchar (128) not null
	, ProviderCareSiteHashId char (130)not null
	, CareSiteHashId char (130)not null
	, RecordSourceIdentifier varchar (10) null
	, CareSiteIsConfirmedByDivision boolean null
);
