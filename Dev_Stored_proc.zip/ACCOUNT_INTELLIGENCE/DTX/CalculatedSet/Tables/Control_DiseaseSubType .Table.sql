CREATE TABLE CalculatedSet.Control_DiseaseSubType ( 
    MatchCode VARCHAR(200) NOT NULL , 
    DiseaseSubType VARCHAR(200) NOT NULL
)