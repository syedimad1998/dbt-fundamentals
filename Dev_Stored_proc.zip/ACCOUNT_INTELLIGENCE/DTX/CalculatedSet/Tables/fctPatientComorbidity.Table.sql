CREATE TABLE CalculatedSet.fctPatientComorbidity(
	Division varchar (100) not null
	, RecordInsertionDate datetime (8) not null
	, MpiId int not null
	, CombinedDivisionMpi varchar (128) not null
	, ConditionDescription varchar (100) not null
	, SampleFoundIcdCode varchar (24) not null
	, ConditionStartDate date not null
	, ConditionEndDate date not null
	, ComorbidityDefinitionSource varchar (255) not null
	, ComorbidityDefaultVisibleInUserFacingDashboards boolean not null
	, RecordSourceIdentifier varchar (10) null
);
