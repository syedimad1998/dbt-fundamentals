CREATE TABLE CalculatedSet.Control_StaticProjectSpecificPersonInclusion(
	ViewName varchar (128) not null
	, Division varchar (100) not null
	, MpiId int not null
);
