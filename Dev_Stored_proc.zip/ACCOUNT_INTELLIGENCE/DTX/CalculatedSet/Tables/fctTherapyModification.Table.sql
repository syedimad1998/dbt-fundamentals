CREATE TABLE CalculatedSet.fctTherapyModification(
	Division varchar (100) not null
	, RecordInsertionDate datetime (8) not null
	, MpiId int not null
	, CombinedDivisionMpi varchar (128) not null
	, ChangeDate date not null
	, CareType varchar (100) not null
	, ChangeType varchar (100) not null
	, ChangeReasonCSV varchar (500) not null
	, RelevantTherapyName varchar (200) null
	, FromAsString varchar (600) null
	, ToAsString varchar (600) null
	, FromTreatmentIntention varchar (50) null
	, FromAsNumber float null
	, ToAsNumber float null
	, RecordSourceIdentifier varchar (10) not null
);
