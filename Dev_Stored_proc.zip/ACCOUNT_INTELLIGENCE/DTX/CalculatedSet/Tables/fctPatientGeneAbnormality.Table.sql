CREATE TABLE CalculatedSet.fctPatientGeneAbnormality(
	Division varchar (100) not null
	, RecordInsertionDate datetime (8) not null
	, MpiId int not null
	, CombinedDivisionMpi varchar (128) not null
	, TestDate date not null
	, GeneticAbnormalityType varchar (20) not null
	, Gene varchar (1000) not null
	, RawGene varchar (1000) not null
	, GeneDefinition varchar (250) null
	, AbnormalityFinding varchar (100) null
	, IsCancerRelated boolean null
	, SourceLocation varchar (100) null
	, Context varchar (2000) null
	, Alteration varchar (500) null
	, RecordSourceIdentifier varchar (10) null
	, GeneGranularity varchar (50) not null
	, Mutation varchar(1000) not null
	, RawMutation varchar(1000) not null
);
