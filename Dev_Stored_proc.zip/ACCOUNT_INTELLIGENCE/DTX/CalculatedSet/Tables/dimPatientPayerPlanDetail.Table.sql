CREATE TABLE CalculatedSet.dimPatientPayerPlanDetail(
	Division varchar (100) not null
	, RecordInsertionDate datetime (8) not null
	, MpiId int not null
	, CombinedDivisionMpi varchar (128) not null
	, PayerPlanPeriodId int not null
	, PayerPlanPeriodStartDate date not null
	, PayerPlanPeriodEnddate date null
	, PayerName varchar (255) null
	, PayerType varchar (100) null
	, PayerPrimaryIndicator varchar (50) null
	, DeductibleAmount float null
	, PayerCategory varchar (100) null
	, RecordSourceIdentifier varchar (10) null
);
