CREATE TABLE CalculatedSet.fctPatientVisit(
	Division varchar (100) not null
	, RecordInsertionDate datetime (8) not null
	, VisitDefinitionCriteriaId int not null
	, MpiId int not null
	, CombinedDivisionMpi varchar (128) not null
	, Year int not null
	, Quarter int not null
	, TotalVisits int not null
	, RecordSourceIdentifier varchar (10) null
);
