CREATE TABLE CalculatedSet.ConcurrencyHelper(
	Resource varchar (100) not null
	, OwnerSpid int not null
	, OwnerUniqueIdentifier char (36)not null
	, LockCreationDate datetime (8) not null
	, LockValidUntildate datetime (8) not null
);
