CREATE TABLE CalculatedSet.Control_ReasonsForNoTest(
	ReasonMatchcode varchar (100) not null
	, ReasonString varchar (100) not null
);
