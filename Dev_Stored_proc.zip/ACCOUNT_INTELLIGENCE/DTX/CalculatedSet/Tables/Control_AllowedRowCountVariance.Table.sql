CREATE TABLE CalculatedSet.Control_AllowedRowCountVariance(
	SchemaName varchar(255) not null
	, TableName varchar(255) not null
	, AllowedVarianceRowGrowth int null
	, AllowedVarianceRowLoss int null
	, RowCountUnderWhichWeDoNotBlock int null
	, IsOverrideVarianceCheck boolean not null
	, TempTableName Varchar(255) NOT NULL
);
