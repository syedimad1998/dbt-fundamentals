CREATE TABLE CalculatedSet.dimVisitDefinitionCriteriaGroup(
	VisitDefinitionCriteriaGroupId int not null
	, FriendlyName varchar (100) null
	, FriendlyDescription varchar null
);
