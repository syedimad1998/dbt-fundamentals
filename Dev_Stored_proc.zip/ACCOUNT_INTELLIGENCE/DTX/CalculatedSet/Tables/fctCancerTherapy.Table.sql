CREATE TABLE CalculatedSet.fctCancerTherapy(
	Division varchar (100) not null
	, RecordInsertionDate datetime (8) not null
	, MpiId int not null
	, CombinedDivisionMpi varchar (128) not null
	, DrugGenericName varchar (200) not null
	, MatchCode varchar (200) not null
	, MatchType varchar (10) not null
	, SourceLocation varchar (20) not null
	, MatchLocation varchar (50) not null
	, DrugConceptId int null
	, DrugExposureStartDate date not null
	, DrugExposureEndDate date null
	, DrugTypeConceptId int null
	, StopReason varchar (20) null
	, Refills int null
	, Quantity float null
	, QuantityPerDay float null
	, DaysSupply int null
	, Sig varchar null
	, RouteConceptId int null
	, VaccineFlag boolean null
	, NDC varchar (200) null
	, ProviderId int null
	, DrugSourceValue varchar null
	, RouteSourceValue varchar (50) null
	, DoseUnitSourceValue varchar (50) not null
	, QuantitySourceValue varchar (255) null
	, DoseSourceValue varchar (8000) not null
	, StrengthSourceValue varchar (800) null
	, CareSiteName varchar (255) null
	, CareSiteAddress1 varchar (50) null
	, CareSiteCity varchar (50) null
	, CareSiteState char (2) null
	, CareSiteZipCode varchar (9) null
	, SourceKey int null
	, HeightInMeters float null
	, WeightInKg float null
	, BMIFromChart float null
	, BSAFromChart float null
	, BMICalculated float null
	, BSACalculated float null
	, DosePerKg float null
	, DosePerMeterSquared float null
	, DoseSourceUnit varchar (50) null
	, DoseNormalizedUnit varchar (50) null
	, ChangeInDosePercentageSinceFirstAdministration float null
	, ChangeInDosePerKgSinceFirstAdministration float null
	, ChangeInDosePerMeterSquaredSinceFirstAdministration float null
	, NewAgent boolean null
	, DaysSinceLastAdministrationOfDrug int null
	, DrugCategory varchar (200) null
	, DrugSubCategory varchar (200) null
	, CostId char (36)null
	, TotalCharge float null
	, CancerTherapyHashId char (130)not null
	, PrescribedBrand varchar (200) null
	, TherapyRoute varchar (50) null
	, Classification varchar (50) null
	, ProviderMpiId int null
	, RecordSourceIdentifier varchar (10) null
	, CombinedDivisionProviderMpiId varchar (113) null
	, IntentToTreat varchar (20) null
	, ServiceCodeDescriptionId int null
	, TherapyForm varchar (30) null
	, Frequency varchar (50) null
	, QuantityPerFrequency float null
	, NumberOfAdministrations float null
    , RxNormId int NULL
    , RxNormDescription varchar(500) NULL
);
