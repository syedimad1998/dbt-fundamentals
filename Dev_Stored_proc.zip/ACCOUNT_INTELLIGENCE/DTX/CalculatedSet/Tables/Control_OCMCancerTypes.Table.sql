CREATE TABLE CalculatedSet.Control_OCMCancerTypes(
	CancerType varchar (100) not null
	, ICD10Code varchar (10) not null
	, ReconciliationEligible varchar (5) null
	, EffectiveStartDate date not null
	, EffectiveEndDate date not null
);
