CREATE TABLE CalculatedSet.Control_ProviderAllowedList(
	Division varchar (100) not null
	, ProviderName varchar (100) not null
	, NPI varchar (50) not null
	, Location varchar (100) not null
	, TIN varchar (50) null
	, ProviderActiveStartDate date not null
	, ProviderActiveEndDate date not null
	, FirstName varchar (50) not null
	, LastName varchar (50) not null
	, MeasureName varchar (100) not null
	, Region varchar (100) not null
	, ValidRecordFromDate date not null
	, ValidRecordToDate date not null
);
