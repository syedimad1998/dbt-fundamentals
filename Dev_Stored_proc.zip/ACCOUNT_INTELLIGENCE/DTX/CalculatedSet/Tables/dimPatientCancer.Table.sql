CREATE TABLE CalculatedSet.dimPatientCancer(
	Division varchar (100) not null
	, RecordInsertionDate datetime (8) not null
	, MpiId int not null
	, CombinedDivisionMpi varchar (128) not null
	, CodeType varchar (10) not null
	, CancerCode varchar (100) not null
	, CancerCodeMajorCategory varchar (4) not null
	, DateInstanceOfCancerCode date not null
	, Control_CancerCodeToDescriptionMatchingId int null
	, RecordSourceIdentifier varchar (10) null
	, DateOfProgression date null
	, IsNotedAsInRemission  boolean null -- PQ-11006
	, IsNotedAsInRelapse boolean null    -- PQ-11006 
);
