CREATE TABLE CalculatedSet.Control_MetastaticMatch(
	MatchCode varchar (100) null
	, NumberOfCharactersToLookForContextNegativeMatches int null
	, NegativeMatchCode varchar (100) null
);
