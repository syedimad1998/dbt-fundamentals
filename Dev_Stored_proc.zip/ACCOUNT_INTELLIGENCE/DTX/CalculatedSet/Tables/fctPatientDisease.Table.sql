CREATE TABLE CalculatedSet.fctPatientDisease(
	Division varchar (100) not null
	, RecordInsertionDate datetime (8) not null
	, MpiId int not null
	, CombinedDivisionMpi varchar (128) not null
	, CodeType varchar (10) not null
	, DiseaseCode varchar (100) not null
	, DiseaseCodeMajorCategory varchar (4) not null
	, DateFirstInstanceOfDiseaseCode date not null
	, DateLastInstanceOfDiseaseCode date not null
	, ConditionConceptId int not null
	, MinConditionStartDate date not null
	, MaxConditionStartDate date not null
	, MinConditionEndDate date not null
	, MaxConditionEndDate date not null
	, DescriptionMajorClassification varchar (200) null
	, DescriptionMinorClassification varchar (200) null
	, RecordSourceIdentifier varchar (10) null
	, DiseaseSubType Varchar(200) null
);
