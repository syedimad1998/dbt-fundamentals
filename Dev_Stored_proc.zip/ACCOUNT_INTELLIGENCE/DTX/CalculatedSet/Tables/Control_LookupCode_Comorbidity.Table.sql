CREATE TABLE CalculatedSet.Control_LookupCode_Comorbidity(
	GeneralComorbidityName varchar (100) not null
	, CodeSystem varchar (5) not null
	, ConditionMatchCode_MajorCategory varchar (11) null
	, ConditionMatchCode_FullCode varchar (11) null
	, TestDefinitionSource varchar (255) not null
	, TestDefaultVisibleInUserFacingDashboards boolean not null
);
