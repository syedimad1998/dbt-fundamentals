CREATE TABLE CalculatedSet.Control_PatientLabTest(
	PatientLabTestId int not null
	, TestName varchar (100) not null
	, Result_RemoveItemsWithoutAppropriateStringOrNumberValue boolean not null
	, Result_ResultValue varchar (100) not null
	, PositiveStringMatchCode varchar (100) null
	, NegativeStringMatchCode varchar (100) null
	, CptMatchCode varchar (100) null
);
