CREATE TABLE CalculatedSet.fctPatientAbstractionEvent(
	Division varchar (100) not null
	, RecordInsertionDate datetime (8) not null
	, MpiId int not null
	, CombinedDivisionMpi varchar (128) not null
	, AbstractionTypeId int not null
	, EarliestAbstractionRelatedDate date not null
	, LastAbstractionRelatedDate date not null
	, LastAbstractionCompletionDate datetime (8) null
	, NumberOfTimesAbstracted int not null
	, LastAbstractionAbandonDate datetime (8) null
	, LastAbstractionAbandonReason varchar (50) null
);
