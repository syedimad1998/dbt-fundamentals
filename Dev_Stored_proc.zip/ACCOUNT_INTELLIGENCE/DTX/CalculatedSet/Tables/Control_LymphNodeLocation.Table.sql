CREATE TABLE CalculatedSet.Control_LymphNodeLocation ( 
      MatchCode VARCHAR(100)  NOT NULL
	, LymphNodeLocation VARCHAR(100) NOT NULL
)