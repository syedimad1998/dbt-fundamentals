CREATE TABLE CalculatedSet.Control_CancerStaging (
	ConditionSourceValue varchar(1000) NOT NULL
	,CodeSystem varchar(5) NULL
	,CancerStageFrom varchar(1000) NOT NULL
	,CancerTValueFrom varchar(50) NULL
	,CancerNValueFrom varchar(50) NULL
	,CancerMValueFrom varchar(50) NULL
	,CancerGValueFrom varchar(50) NULL
	,CancerStageTo varchar(50) NULL
	,CancerTValueTo varchar(50) NULL
	,CancerNValueTo varchar(50) NULL
	,CancerMValueTo varchar(50) NULL
	,CancerGValueTo varchar(50) NULL
);