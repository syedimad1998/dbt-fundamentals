CREATE TABLE CalculatedSet.dimPatientReferral(
	Division varchar (100) not null
	, RecordInsertionDate datetime (8) not null
	, MpiId int not null
	, CombinedDivisionMpi varchar (128) not null
	, Direction varchar (15) not null
	, DateReferralWasGenerated date null
	, DateReferralWasActedOn date null
	, ReferFromCareSiteHashId char (130)null
	, ReferFromProviderMpiId int null
	, ReferFromProviderLastName varchar (100) null
	, ReferFromProviderFirstName varchar (100) null
	, ReferFromProviderFullName varchar (250) null
	, ReferToCareSiteHashId char (130)null
	, ReferToProviderMpiId int null
	, ReferToProviderLastName varchar (100) null
	, ReferToProviderFirstName varchar (100) null
	, ReferToProviderFullName varchar (250) null
	, ReferToProviderSpecialty varchar (1000) null
	, ReferDueToProblemCodeType varchar (5) null
	, ReferDueToProblemCode varchar (10) null
	, ReferDueToProblemDescription varchar (200) null
	, ReferDueToProcedureCodeType varchar (5) null
	, ReferDueToProcedureCode varchar (10) null
	, ReferDuetoProcedureDescription varchar (200) null
	, RecordSourceIdentifier varchar (10) null
);
