CREATE TABLE CalculatedSet.dimCancerTherapyCostMap(
	Division varchar (100) not null
	, MpiId int not null
	, CostId int not null
	, CancerTherapyHashId char (130)not null
);
