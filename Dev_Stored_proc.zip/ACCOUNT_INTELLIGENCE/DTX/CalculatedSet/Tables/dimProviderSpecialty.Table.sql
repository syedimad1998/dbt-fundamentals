CREATE TABLE CalculatedSet.dimProviderSpecialty(
	Division varchar (100) not null
	, RecordInsertionDate datetime (8) not null
	, ProviderMpiId int not null
	, CombinedDivisionProviderMpi varchar (128) not null
	, SpecialtyNumber int not null
	, TaxonomyCode varchar (50) not null
	, Specialty varchar (1000) not null
	, IndicatesSpecialtyInRadiationOncology boolean not null
	, IndicatesSpecialtyInHematologyOncology boolean not null
	, IndicatesSpecialtyInMedicalOncology boolean not null
	, IndicatesSpecialtyInUrology boolean not null
	, IndicatesSpecialtyInAdvancedPracticePractitioner boolean not null
	, ProviderTypeDescription varchar (1000) not null
	, ProviderTaxonomyDescription varchar (1000) not null
	, ExtendedProviderTaxonomyDescription varchar (1000) not null
	, RecordSourceIdentifier varchar (10) null
);
