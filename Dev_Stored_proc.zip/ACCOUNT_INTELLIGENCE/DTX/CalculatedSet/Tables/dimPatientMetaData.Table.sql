CREATE TABLE CalculatedSet.dimPatientMetaData(
	Division varchar (100) not null
	, Mpiid int not null
	, CombinedDivisionMPI varchar (128) not null
	, MetadataDate date not null
	, MetadataSource varchar (100) not null
	, MetadataType varchar (100) not null
	, MetadataValue varchar (100) not null
);
