CREATE TABLE CalculatedSet.dimProvider(
	Division varchar (100) not null
	, RecordInsertionDate datetime (8) not null
	, ProviderMpiId int not null
	, CombinedDivisionProviderMpi varchar (128) not null
	, FullProviderName varchar (255) not null
	, FirstName varchar (100) not null
	, LastName varchar (100) not null
	, EmailAddress varchar (1000) not null
	, PhoneNumber varchar (50) not null
	, FaxNumber varchar (50) not null
	, FederalTaxId varchar (20) not null
	, NPI varchar (20) not null
	, DEA varchar (20) not null
	, PracticeSite varchar null
	, HasSpecialtyInRadiationOncology boolean null
	, HasSpecialtyInHematologyOncology boolean null
	, HasSpecialtyInMedicalOncology boolean null
	, HasSpecialtyInUrology boolean null
	, HasSpecialtyInAdvancedPracticePractitioner boolean null
	, PrimarySpecialty varchar (1000) null
	, NonFlaggedSpecialty varchar null
	, AllSpecialty varchar null
	, GenderName varchar (9) null
	, EpisodeRelatedScore_OCM1 decimal (6,5) null
	, EpisodeRelatedScore_OCM2 decimal (6,5) null
	, EpisodeRelatedScore_OCM3 decimal (6,5) null
	, EpisodeRelatedScore_OCM4a decimal (6,5) null
	, EpisodeRelatedScore_OCM4b decimal (6,5) null
	, EpisodeRelatedScore_OCM5 decimal (6,5) null
	, EpisodeRelatedScore_OCM8 decimal (6,5) null
	, EpisodeRelatedScore_OCM9 decimal (6,5) null
	, EpisodeRelatedScore_OCM10 decimal (6,5) null
	, EpisodeRelatedScore_OCM11 decimal (6,5) null
	, EpisodeRelatedScore_OCM12 decimal (6,5) null
	, EpisodeRelatedScore_OCM24 decimal (6,5) null
	, EpisodeRelatedScore_OCM30 decimal (6,5) null
	, IdentifyingDataProhibitedFromDisclosureToThirdParties boolean not null
	, RecordSourceIdentifier varchar (10) not null
	, ProviderIsConfirmedByDivision boolean not null
);
