CREATE TABLE CalculatedSet.Control_ProcedureCode(
	Code varchar (15) not null
	, ProcedureName varchar (200) null
	, ProcedureDescription varchar null
	, ProcedureSourceCodeType varchar (10) not null
	, GeneralizedProcedureCategory varchar (100) null
);
