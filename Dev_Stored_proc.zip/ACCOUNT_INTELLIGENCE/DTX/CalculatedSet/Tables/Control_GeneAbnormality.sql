CREATE TABLE CalculatedSet.Control_GeneAbnormality(
	Gene varchar(1000) not null
	, Karyotype varchar(1000) not null
	, GeneticAbnormalityType varchar(20) not null
);
