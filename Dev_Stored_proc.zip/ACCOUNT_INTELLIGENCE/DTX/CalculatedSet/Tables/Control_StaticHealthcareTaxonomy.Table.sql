CREATE TABLE CalculatedSet.Control_StaticHealthcareTaxonomy(
	ProviderTaxonomyCode varchar (20) not null
	, ProviderTypeDescription varchar (1000) not null
	, ProviderTaxonomyDescription varchar (1000) not null
	, ExtendedProviderTaxonomyDescription varchar (1000) not null
	, DisplayDescription varchar (1000) not null
);
