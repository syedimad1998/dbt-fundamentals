CREATE TABLE CalculatedSet.LineOfTherapyResponse(
	Division varchar (100) not null
	, RecordInsertionDate datetime (8) not null
	, MpiId int not null
	, CombinedDivisionMpi varchar (128) not null
	, LineOfTherapyStartDate date not null
	, LineOfTherapyEndDate date not null
	, Regimen varchar (600) not null
	, ResponseAtStartOfTherapy varchar (30) not null
	, ResponseAtEndOfTherapy varchar (30) not null
	, RecordSourceIdentifier varchar (10) null
);
