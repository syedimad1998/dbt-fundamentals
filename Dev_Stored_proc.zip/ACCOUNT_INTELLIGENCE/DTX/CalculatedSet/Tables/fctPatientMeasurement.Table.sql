CREATE TABLE CalculatedSet.fctPatientMeasurement(
	Division varchar (100) not null
	, RecordInsertionDate datetime (8) not null
	, MpiId int not null
	, CombinedDivisionMpi varchar (128) not null
	, MeasurementDate date not null
	, MeasurementCategory varchar (20) not null
	, AnatomicSiteLocation varchar (50) not null
	, ObservationMethod varchar (50) not null
	, MeasurementClass varchar (20) not null
	, ValueAsString varchar (40) null
	, Unit varchar (20) null
	, ValueAsInt int null
	, ValueAsFloat float null
	, RecordSourceIdentifier varchar (10) null
);
