CREATE TABLE CalculatedSet.dimPatientEpisodeOfCare(
	Division varchar (100) not null
	, RecordInsertionDate datetime (8) not null
	, MpiId int not null
	, CombinedDivisionMpi varchar (128) not null
	, RecordValidFromDate date not null
	, RecordValidToDate date not null
	, EpisodeType varchar (50) not null
	, EpisodeStartDate date not null
	, EpisodeEndDate date not null
	, EpisodeNumber int not null
	, CombinedDivisionProviderMpi varchar (128) null
	, EpisodeID varchar (500) not null
	, RecordSourceIdentifier varchar (10) null
	, CombinedDivisionProviderMpiId varchar (128) null
	, IsCMS boolean not null
);
