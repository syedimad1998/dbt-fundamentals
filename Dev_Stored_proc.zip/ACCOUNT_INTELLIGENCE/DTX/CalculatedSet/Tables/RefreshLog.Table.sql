CREATE TABLE CalculatedSet.RefreshLog(
	RefreshLogId int not null
	, Division varchar (100) null
	, StartDate datetime (8) not null
	, EndDate datetime (8) null
	, WasSuccessful boolean null
	, DataGatheringStartDate datetime (8) null
	, DataGatheringEndDate datetime (8) null
	, NonTransactionalDataSwapInStartDate datetime (8) null
	, NonTransactionalDataSwapInEndDate datetime (8) null
	, TransactionalDataSwapInStartDate datetime (8) null
	, TransactionalDataSwapInEndDate datetime (8) null
	, FinalDeletionStartDate datetime (8) null
	, FinalDeletionEndDate datetime (8) null
	, TransactionalDataSwapInCompletionPercentage int null
	, SourceSystemValue varchar (500) null
);
