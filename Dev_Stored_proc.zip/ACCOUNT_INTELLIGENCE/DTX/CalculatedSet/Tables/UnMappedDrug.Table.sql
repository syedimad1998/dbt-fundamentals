CREATE TABLE CalculatedSet.UnMappedDrug(
	DrugName varchar (900) not null
	, FirstSeenDate date null
	, RecordCount int null
	, RecordSourceIdentifier varchar (10) null
	, Division Varchar(100) not null
);
