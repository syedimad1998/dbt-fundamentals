CREATE TABLE CalculatedSet.Control_CancerDiagnosisStaging(
	CancerDiagnosisStagingId int NOT NULL,
	CancerSiteId int NOT NULL,
	CancerSiteName varchar(500) NOT NULL,
	DiagnosisCode varchar(20) NOT NULL,
	DiagnosisName varchar(200) NULL,
	DiagnosisMatchCode varchar(20) NULL,
	DescriptionMajorClassification varchar(200) NULL,
	DescriptionMinorClassification varchar(200) NULL,
	CancerStage varchar(200) NULL,
	CancerTValue varchar(50) NULL,
	CancerNValue varchar(50) NULL,
	CancerMValue varchar(50) NULL,
	CancerGValue varchar(50) NULL,
	CancerHValue varchar(50) NULL
);
