CREATE TABLE CalculatedSet.dimFuturePatientVisit(
	Division varchar (100) not null
	, RecordInsertionDate datetime (8) not null
	, MpiId int not null
	, CombinedDivisionMpi varchar (128) not null
	, VisitDate date not null
	, VisitDefinitionCriteriaId int not null
	, ProviderCareSiteHashId char (130)null
	, ProviderMpiId int null
	, CombinedDivisionProviderMpi varchar (128) null
	, TotalCharge float null
	, RecordSourceIdentifier varchar (10) null
);
