CREATE TABLE CalculatedSet.dimPatientCancerStaging(
	Division varchar (100) not null
	, RecordInsertionDate datetime (8) not null
	, MpiId int not null
	, CombinedDivisionMpi varchar (128) not null
	, ConditionSourceValueId varchar (255) null
	, ConditionSourceValue varchar null
	, StagingId int not null
	, StagingDate date not null
	, CareSiteId int null
	, CareSiteName varchar (255) null
	, CancerStage varchar null
	, CancerTValue varchar (50) null
	, CancerNValue varchar (50) null
	, CancerMValue varchar (50) null
	, CancerGValue varchar (50) null
	, CancerHistology varchar null
	, CancerCritDescr varchar null
	, CancerStageMajorCategory varchar (3) null
	, CancerStageMinorCategory varchar (4) null
	, RecordSourceIdentifier varchar (10) null
	, stagingType varchar (10) NULL
    , CleanedCancerStage varchar(50) NULL
	, CleanedCancerTValue varchar(50) NULL
	, CleanedCancerNValue varchar(50) NULL
	, CleanedCancerMValue varchar(50) NULL
	, CleanedCancerGValue varchar(50) NULL
);
