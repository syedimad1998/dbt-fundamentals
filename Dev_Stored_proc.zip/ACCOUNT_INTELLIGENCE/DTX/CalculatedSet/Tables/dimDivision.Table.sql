CREATE TABLE CalculatedSet.dimDivision(
	Division varchar (100) not null
	, RecordInsertionDate datetime (8) not null
	, ClientName varchar (500) not null
	, ClientNameLong varchar (500) not null
	, Specialty varchar (50) not null
);
