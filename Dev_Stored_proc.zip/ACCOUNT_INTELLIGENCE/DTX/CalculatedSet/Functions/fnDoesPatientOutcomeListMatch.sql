CREATE OR REPLACE  FUNCTION CalculatedSet.fnDoesPatientOutcomeListMatch (
	v_List1 varchar(255)
	, v_List2 varchar(255)
	, v_Seperator varchar(1)
	, v_isExact boolean --default 1
)
RETURNS boolean  
AS    
$$ 
	with listdata1 as
	(
		select collate(cast(trim(value) as varchar), 'en-ci') as value
		from lateral flatten(input=>split(v_List1, v_Seperator)) x
	),
	listdata2 as
	(
		select collate(cast(trim(value) as varchar), 'en-ci') as value
		from lateral flatten(input=>split(v_List2, v_Seperator)) x
	)
	select coalesce((
			case when v_isExact = true 
			then 
				min(case when l1.value is null or l2.value is null then false else true end) 
			else
				max(case when l1.value is null or l2.value is null then false else true end)
            end
			),false)
	from listdata1 l1
	full outer join listdata2 l2
	on l1.value = l2.value
    
$$
;