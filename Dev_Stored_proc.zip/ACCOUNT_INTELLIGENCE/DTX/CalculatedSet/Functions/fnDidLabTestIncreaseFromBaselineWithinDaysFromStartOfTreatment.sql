CREATE OR REPLACE  FUNCTION CalculatedSet.fnDidLabTestIncreaseFromBaselineWithinDaysFromStartOfTreatment (  
	  v_Division varchar(100)
	, v_MpiId int
	, v_LabTestName varchar(100)
	, v_InitialDate date
	, v_LabInterval int
	, v_BaselineInterval int
	, v_IncreaseAmount float 
)
RETURNS NUMBER(1,0) 
language sql
AS  
$$  
    -- select CalculatedSet.fnDidLabTestIncreaseFromBaselineWithinDaysFromStartOfTreatment('100', 248921883, 'White Blood Cell Count', '2017-04-01', 30, 30, 1)
    
    
	-- before doing anything, if the increase amount is zero, return NULL since there will never be a case of an increase
	-- IF v_increaseAmount = 0.0
	-- RETURN( NULL );  
	WITH lab AS
	(
		-- get all labs between the baseline start date and the lab end date as total set of records to work with
		SELECT Division
            , MpiId
            , CombinedDivisionMpi
            , TestDate
            , TestName
            , ValueAsFloat AS Dose
            , UnitValue
            , ABS(DATEDIFF(day, v_InitialDate, TestDate)) AS DaysFromInitialDate
		FROM CalculatedSet.fctPatientLab 
		WHERE Division = v_Division
            AND MpiId = v_MpiId
            AND TestName = v_LabTestName
            AND TestDate BETWEEN DATEADD(day, -ABS(v_BaselineInterval), v_InitialDate) AND DATEADD(day, v_LabInterval, v_InitialDate)
            AND ValueAsFloat IS NOT NULL
	),
	base AS
	(
		-- determine the baseline lab
        SELECT	TestDate, Dose AS BaseLine, DaysFromInitialDate, ROW_NUMBER() OVER(ORDER BY ABS(DATEDIFF(day, v_InitialDate, TestDate)), TestDate) AS RowID
        FROM	lab
        WHERE	TestDate BETWEEN DATEADD(day, -ABS(v_BaselineInterval), v_InitialDate) AND DATEADD(day, ABS(v_BaselineInterval), v_InitialDate)
	)
	-- and store lab results
	-- only get the first lab after the baseline lab
	, v_final as (
        SELECT top 1
             lab.CombinedDivisionMpi
            ,lab.Dose
            ,base.BaseLine
        FROM lab 
        INNER JOIN base ON base.RowID = 1
        WHERE lab.TestDate > base.TestDate
            and lab.TestDate >= v_InitialDate
        ORDER BY 
            -- Bias towards the one over the baseline value.
            case when (lab.Dose - (base.BaseLine + ABS(v_IncreaseAmount))) > 0 then 1 else 0 end desc
            -- Bias towards the earliest test.
            , lab.TestDate asc
    )
	-- now check lab results to determine if there was no data (NULL), a rise (1) or no rise (0)
	-- only set ReturnValue if we have at least one test to do comparison with baseline test.
	-- if we don't have more than one test, we are unable to determine increase/decrease, and should return default ReturnValue of NULL

        -- now determine the difference between dose and the baseline
        SELECT case 
                    when max(f.Dose - f.BaseLine) is null then null 
                    when max(f.Dose - f.BaseLine) >= ABS(v_IncreaseAmount) then 1 
                    else 0 end
        FROM	v_final AS f


$$
;

 