CREATE OR REPLACE FUNCTION CalculatedSet.fnHasOneOfBrandDrugMatchesBetweenPeriod (
	v_Division varchar(100)
	, v_MpiId int
	, v_StartPeriodBeginSearch date
	, v_NumberOfDaysToAllowSearch int
	, v_GenericDrugName   varchar(200)
	, v_BrandDrugName  varchar(200)
)  
RETURNS boolean  
AS  
$$

	select case when cnt > 0 then true else false end as rtn
    from (
		select count(*) as cnt
		from
			Calculatedset.fctcancertherapy th 
		where 
			th.Division = v_Division
			and th.MpiId = v_MpiId
			and th.DrugGenericName = v_GenericDrugName
			and th.PrescribedBrand = v_BrandDrugName
			and (
				drugexposurestartdate between v_StartPeriodBeginSearch and dateadd(day, v_NumberOfDaysToAllowSearch, v_StartPeriodBeginSearch)
				or
				drugexposureenddate between v_StartPeriodBeginSearch and dateadd(day, v_NumberOfDaysToAllowSearch, v_StartPeriodBeginSearch)
			)
	) x 

$$
