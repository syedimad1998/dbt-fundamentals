CREATE OR REPLACE   FUNCTION CalculatedSet.fnGetPatientPayerCategoryBetweenPeriod (
  v_CombinedDivisionMpi varchar(128) 
  , v_PeriodBeginDate date 
  , v_PeriodEndDate date 
)
returns varchar(100)
as 
$$
        
    select 
        cast(
            case 
                when Numeric_GeneralizedPayerCategory = 1 then 'Medicare'
                when Numeric_GeneralizedPayerCategory = 2 then 'Commercial'
                when Numeric_GeneralizedPayerCategory = 3 then 'Self Pay'
            end as varchar(100))
    from (
        select min(
                case
                    when GeneralizedPayerCategory like '%Medicare%' then 1
                    when GeneralizedPayerCategory like '%Commercial%' then 2
                    when GeneralizedPayerCategory like '%Self Pay%' then 3
                end
            ) as Numeric_GeneralizedPayerCategory
        from calculatedset.fctPatientDailyCostOfCare 
        where combineddivisionmpi = v_CombinedDivisionMpi 
            and careDate between v_PeriodBeginDate and v_PeriodEndDate
    ) x
        
$$
;