CREATE OR REPLACE FUNCTION CalculatedSet.fnGetFirstDateOfAdverseEventWithin (
	v_Division varchar(100)
	, v_MpiId int
	, v_AdverseEventDescription varchar(100)
	, v_InitialDate date
	, v_Interval int
	, v_IsIntervalinMonths boolean --default 0
)  
RETURNS date
AS  
$$

    select min(EventDateInstance)
    from CalculatedSet.fctPatientAdverseEvent
    where
        division = v_Division
        and mpiid = v_MpiId
        and AdverseEventDescription = v_AdverseEventDescription
        and EventDateInstance between v_InitialDate and (case when v_IsIntervalinMonths = 1 then dateadd(month, v_Interval, v_InitialDate) else dateadd(day, v_Interval, v_InitialDate) end)

$$
;