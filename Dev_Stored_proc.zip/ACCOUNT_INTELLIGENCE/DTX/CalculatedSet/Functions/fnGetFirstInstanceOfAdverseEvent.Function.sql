CREATE OR REPLACE FUNCTION CalculatedSet.fnGetFirstInstanceOfAdverseEvent (
	v_Division varchar(100)
	, v_MpiId int
	, v_AdverseEventDescription varchar(100)
)  
RETURNS date  
AS  
$$

		select min(EventDateInstance)
		from CalculatedSet.fctPatientAdverseEvent
		where
			division = v_Division
			and mpiid = v_MpiId
			and AdverseEventDescription = v_AdverseEventDescription

$$
; 