CREATE OR REPLACE FUNCTION CalculatedSet.fnGetFirstInstanceOfOneOfBrandDrugMatchesBetweenPeriod (
	v_Division varchar(100)
	, v_MpiId int
	, v_StartPeriodBeginSearch date
	, v_NumberOfDaysToAllowSearch int
	, v_GenericDrugName   varchar(200)
	, v_BrandDrugName  varchar(200)
)  
RETURNS date  
AS  
$$
	select min(DrugExposureStartDate)
	from
		Calculatedset.fctcancertherapy th 
	where 
		th.Division = v_Division
		and th.MpiId = v_MpiId
		and th.DrugGenericName = v_GenericDrugName
		and th.PrescribedBrand = v_BrandDrugName
		and (
			drugexposurestartdate between v_StartPeriodBeginSearch and dateadd(day, v_NumberOfDaysToAllowSearch, v_StartPeriodBeginSearch)
			or
			drugexposureenddate between v_StartPeriodBeginSearch and dateadd(day, v_NumberOfDaysToAllowSearch, v_StartPeriodBeginSearch)
		)
$$
;