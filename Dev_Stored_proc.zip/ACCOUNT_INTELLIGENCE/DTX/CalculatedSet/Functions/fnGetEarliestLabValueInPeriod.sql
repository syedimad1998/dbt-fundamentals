create or REPLACE function CalculatedSet.fnGetEarliestLabValueInPeriod (
	v_Division varchar(100)
	,v_MpiId int
	,v_labname varchar(75)
	,v_InitialDate date
	,v_Interval int
	,v_IsIntervalinMonths boolean
	)
returns float 
as 
$$

    with cte_x as (
		select min(testdate) as testdate, Division, Mpiid, testname
		from CalculatedSet.fctPatientLab
		where Division = v_Division
			and MpiId = v_MpiId
			and testname = v_LabName
			and testdate between --If positive use current date else lookback
					case 
						when v_Interval > 0
							then v_InitialDate
						else case 
								when v_IsIntervalinMonths = true
									then dateadd(month, v_Interval, v_InitialDate)
								else dateadd(day, v_Interval, v_InitialDate)
								end
						end
					--If positive use lookforward else use current date
				and case 
						when v_Interval > 0
							then case 
									when v_IsIntervalinMonths = true
										then dateadd(month, v_Interval, v_InitialDate)
									else dateadd(day, v_Interval, v_InitialDate)
									end
						else v_InitialDate
						end
         group by Division, Mpiid, testname, ValueAsFloat
		)
        
    select max(ValueAsFloat)
    from CalculatedSet.fctPatientLab l 
    join cte_x x 
        on x.Division = l.Division
            and x.Mpiid = l.Mpiid
            and x.testname = l.testname
            and x.testdate = l.testdate
        where l.Division = v_Division
            and l.MpiId = v_MpiId
            and l.testname = v_LabName
            
$$
;
