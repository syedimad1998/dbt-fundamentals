CREATE OR REPLACE  FUNCTION CalculatedSet.fnGetTotalPatientVisitsWithin (
	v_Division varchar(100)
	, v_MpiId int
	, v_InitialDate date
	, v_Interval int
	,v_IsIntervalinMonths boolean
)  
RETURNS int 
AS  
$$


	select count(1)
	from
		Calculatedset.dimpatientvisit v  
	where 
		v.Division = v_Division
		and v.MpiId = v_MpiId
		and v.visitdate between v_InitialDate and (case when v_IsIntervalinMonths = 1 then dateadd(month, v_Interval, v_InitialDate) else dateadd(day, v_Interval, v_InitialDate) end)

$$
;