CREATE OR REPLACE FUNCTION CalculatedSet.fnGetNumberOfDaysForLabTestToIncreaseFromBaseline (  
	  v_Division varchar(100)
	, v_MpiId int
	, v_LabTestName varchar(100)
	, v_InitialDate date
	, v_LabInterval int
	, v_BaselineInterval int
	, v_IncreaseAmount float -- defaul 0
)
RETURNS int 
AS   
$$ 
    /***********************************************************************************************************
        NOTE: 
            this funciton is not currently being used in the MIs and will need 
            heavy refactoring to for a Snowflak implimentation!  Therefore is 
            if only returning NULL for now!!

    ***********************************************************************************************************/


	-- before doing anything, if the increase amount is zero, return NULL since there will never be a case of an increase
	-- IF v_increaseAmount = 0.0
	-- RETURN( NULL );  
    
	WITH lab AS
	(
		-- get all labs between the baseline start date and the lab end date as total set of records to work with
		SELECT Division
            , MpiId
            , CombinedDivisionMpi
            , TestDate
            , TestName
            , ValueAsFloat AS Dose
            , UnitValue
            , ABS(DATEDIFF(day, v_InitialDate, TestDate)) AS DaysFromInitialDate
		FROM CalculatedSet.fctPatientLab 
		WHERE Division = v_Division
            AND MpiId = v_MpiId
            AND TestName = v_LabTestName
            AND TestDate BETWEEN DATEADD(day, -abs(v_BaselineInterval), v_InitialDate) AND DATEADD(day, v_LabInterval, v_InitialDate)
            AND ValueAsFloat IS NOT NULL
	),
	base AS
	(
		-- determine the baseline lab
        select TestDate
            , Dose AS BaseLine
            , DaysFromInitialDate
        from lab a 
        join (
                SELECT min(DaysFromInitialDate) as min_DaysFromInitialDate
                FROM lab
                WHERE TestDate BETWEEN DATEADD(day, -abs(v_BaselineInterval), v_InitialDate) AND DATEADD(day, v_BaselineInterval, v_InitialDate)
        ) b on a.DaysFromInitialDate = b.min_DaysFromInitialDate
	)
	-- and store lab results
	-- only get the first lab after the baseline lab
    , final as (
        SELECT top 1 lab.TestDate, lab.Dose, base.BaseLine
        FROM lab 
        INNER JOIN base ON 1=1
        WHERE lab.TestDate > base.TestDate
                and lab.TestDate >= v_InitialDate
        ORDER BY 
            -- Bias towards the one over the baseline value.
            case when (lab.Dose - (base.BaseLine + abs(v_IncreaseAmount))) > 0 then 1 else 0 end desc
            -- Bias towards the earliest test.
            , lab.TestDate asc
    ) 
            
            
            
	-- now check lab results to determine if there was no data (NULL), a rise (1) or no rise (0)
	-- only set ReturnValue if we have at least one test to do comparison with baseline test.
	-- if we don't have more than one test, we are unable to determine increase/decrease, and should return default ReturnValue of NULL
	-- now check lab results to determine if there was no data (NULL), a rise (1) or no rise (0)
    select null
        -- max(case
        --      when f.Dose is null then null 
        --      when f.Dose - f.BaseLine >= 1 then  DATEDIFF(day, v_InitialDate, TestDate)
        --      else 0 
        --    end) as rtn
    from final f
    
$$
; 
