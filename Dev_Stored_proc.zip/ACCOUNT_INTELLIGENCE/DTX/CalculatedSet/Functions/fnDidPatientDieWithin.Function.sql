CREATE OR REPLACE FUNCTION CalculatedSet.fnDidPatientDieWithin (
	v_Division varchar(100)
	, v_MpiId int
	, v_InitialDate date
	, v_Interval int
	,v_IsIntervalinMonths boolean
)  
RETURNS int  
AS  
$$
		select 
                case 
                    when max(1) is not null 
                    then 1 else 0
                end as rtn
		from Calculatedset.dimPatient th 
		where th.Division = v_Division
			and th.MpiId = v_MpiId
			and DateOfDeath between v_InitialDate and (case when v_IsIntervalinMonths = 1 then dateadd(month, v_Interval, v_InitialDate) else dateadd(day, v_Interval, v_InitialDate) end)
	
$$
;