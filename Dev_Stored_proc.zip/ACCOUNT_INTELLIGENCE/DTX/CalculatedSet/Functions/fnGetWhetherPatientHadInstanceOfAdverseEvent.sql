CREATE OR REPLACE  FUNCTION CalculatedSet.fnGetWhetherPatientHadInstanceOfAdverseEvent (  
	v_Division varchar(100)
	, v_MpiId int
	, v_adverseEventname varchar(75)
	, v_InitialDate date
	, v_Interval int
	, v_IsIntervalinMonths boolean -- default 0
)
RETURNS boolean  
AS    
$$

    select case when cnt > 0 then true else false end as rtn
    from (
        select count(*) cnt
        from CalculatedSet.fctPatientAdverseEvent 
        where Division = v_Division
            and MpiId = v_MpiId
            and AdverseEventDescription = v_adverseEventname
            and EventDateInstance between  --If positive use current date else lookback
                    case when v_Interval > 0 
                        then v_InitialDate 
                    else 
                        case when v_IsIntervalinMonths = 1 then dateadd(month, v_Interval, v_InitialDate)
                            else dateadd(day, v_Interval, v_InitialDate) 
                        end
                    end
                    --If positive use lookforward else use current date
            and case when v_Interval > 0 then 
                        case when v_IsIntervalinMonths = 1 
                            then dateadd(month, v_Interval, v_InitialDate)
                          else dateadd(day, v_Interval, v_InitialDate) 
                        end
                    else v_InitialDate 
                end
	) x 
                    
$$
;


