CREATE OR REPLACE FUNCTION CalculatedSet.fnHasOneOfBrandDrugMatches (
	v_Division varchar(100)
	, v_MpiId int
	, v_GenericDrugName   varchar(200)
	, v_BrandDrugName  varchar(200)
)  
RETURNS boolean  
AS  
$$

    select case when cnt > 0 then true else false end as rtn
    from (
		select count(*) as cnt
		from
			Calculatedset.fctcancertherapy th 
		where 
			th.Division = v_Division
			and th.MpiId = v_MpiId
			and th.DrugGenericName = v_GenericDrugName
			and th.PrescribedBrand = v_BrandDrugName
	) x 

$$
/*
select CalculatedSet.fnHasOneOfBrandDrugMatches('102', 643120258, 'Pegfilgrastim', 'Neulasta PFS')
*/