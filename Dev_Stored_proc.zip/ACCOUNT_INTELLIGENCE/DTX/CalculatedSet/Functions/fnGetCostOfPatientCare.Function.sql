CREATE OR REPLACE  FUNCTION CalculatedSet.fnGetCostOfPatientCare (
	v_Division varchar(100)
	, v_MpiId int
	, v_InitialDate date
	, v_Interval int
	,v_IsIntervalinMonths boolean
	,v_IsOcmPatient boolean
)  
RETURNS int  
AS  
$$

	select sum(TotalCost)
	from
		Calculatedset.fctPatientDailyCostOfCare c 
	where 
		c.Division = v_Division
		and c.MpiId = v_MpiId
		and c.CareDate between v_InitialDate and (case when v_IsIntervalinMonths = 1 then dateadd(month, v_Interval, v_InitialDate) else dateadd(day, v_Interval, v_InitialDate) end)
		and IsOcmPayer = case when v_IsOcmPatient = 1 then 1 else IsOcmPayer end 

$$
;