CREATE OR REPLACE FUNCTION CalculatedSet.fnGetTotalOCMEpisodesCount (
	v_Division varchar(100)
	, v_MpiId int
)  
RETURNS int  
AS  
$$
    
	select max(NumberOfOcmEpisode)
	from
		Calculatedset.dimPatient c 
	where 
		c.Division = v_Division
		and c.MpiId = v_MpiId
    
$$