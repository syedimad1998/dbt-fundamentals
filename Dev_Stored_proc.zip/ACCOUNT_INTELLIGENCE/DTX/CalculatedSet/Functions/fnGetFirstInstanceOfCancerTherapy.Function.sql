CREATE OR REPLACE FUNCTION CalculatedSet.fnGetFirstInstanceOfCancerTherapy (
	  v_Division varchar(100)
	, v_MpiId int
	, v_DrugGenericName varchar(200)
)  
RETURNS date 
AS  
$$
		SELECT	MIN(DrugExposureStartDate)
		FROM	CalculatedSet.fctCancerTherapy
		WHERE	Division = v_Division
				AND MpiId = v_MpiId
				AND DrugGenericName = v_DrugGenericName

$$