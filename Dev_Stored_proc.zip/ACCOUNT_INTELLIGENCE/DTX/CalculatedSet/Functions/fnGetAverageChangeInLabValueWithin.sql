CREATE OR REPLACE  FUNCTION CalculatedSet.fnGetAverageChangeInLabValueWithin (  
	  v_Division varchar(100)
	, v_MpiId int
	, v_LabTestName varchar(100)
	, v_InitialDate date
	, v_LabInterval int
)
RETURNS float 
AS    
$$

	with NextLabs as (
    	SELECT a.Division
             , a.MpiId
             , min(b.testdate) as testdate
             , a.ValueAsFloat as PreviousDose
		FROM CalculatedSet.fctPatientLab a 
        join CalculatedSet.fctPatientLab b 
            on a.division = b.division 
            and a.mpiid = b.mpiid
            and a.testname = b.testname
            and b.testdate > a.testdate
		WHERE a.Division = v_Division
            AND a.MpiId = v_MpiId
            AND a.TestName = v_LabTestName
            AND a.TestDate BETWEEN v_InitialDate AND DATEADD(day, v_LabInterval, v_InitialDate)
            AND b.TestDate BETWEEN v_InitialDate AND DATEADD(day, v_LabInterval, v_InitialDate)
            AND a.ValueAsFloat IS NOT NULL
            and b.ValueAsFloat is not null 
        group by a.Division
             , a.MpiId
             , a.ValueAsFloat
    )

      
    select avg(a.ValueAsFloat - b.PreviousDose) as rtn
    FROM CalculatedSet.fctPatientLab a
    join NextLabs b on a.testdate = b.testdate
        and a.division = b.division 
        and a.mpiid = b.mpiid
    WHERE a.Division = v_Division
        AND a.MpiId = v_MpiId
        AND a.TestName = v_LabTestName
        AND a.TestDate BETWEEN v_InitialDate AND DATEADD(day, v_LabInterval, v_InitialDate)
        AND a.ValueAsFloat IS NOT NULL
        and b.PreviousDose is not null
$$
;


