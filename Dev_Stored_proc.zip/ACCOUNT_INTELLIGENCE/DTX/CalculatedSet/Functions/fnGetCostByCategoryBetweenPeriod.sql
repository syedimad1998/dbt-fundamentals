CREATE OR REPLACE  FUNCTION CalculatedSet.fnGetCostByCategoryBetweenPeriod (
	  v_CombinedDivisionMpi varchar(128)
	, v_GeneralizedPayerCategory varchar(100) 
	/*
	 * 'Commercial'
	 * 'Medicare/Medicaid'
	 * 'Self Pay/Other'
	 * 'Unknown'
	 */
	, v_PeriodBeginDate date
	, v_PeriodEndDate date
)  
RETURNS numeric(19,4)
AS  
$$
    
	SELECT CAST(SUM(TotalCost) AS numeric(19,4)) 
	FROM CalculatedSet.fctPatientDailyCostOfCare
	WHERE CombinedDivisionMpi = v_CombinedDivisionMpi
		AND GeneralizedPayerCategory = v_GeneralizedPayerCategory
		AND CareDate BETWEEN v_PeriodBeginDate AND v_PeriodEndDate

$$
;