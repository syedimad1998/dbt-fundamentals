CREATE OR REPLACE FUNCTION CalculatedSet.fnDidPatientHaveAdverseEventWithin (
	v_Division varchar(100)
	, v_MpiId int
	, v_AdverseEventDescription varchar(100)
	, v_InitialDate date
	, v_Interval int
	, v_IsIntervalinMonths boolean -- defualt as 0
)  
RETURNS int
AS  
$$
		select 
                case 
                    when max(1) is not null 
                    then 1 else 0
                end as rtn
		from CalculatedSet.fctPatientAdverseEvent
		where
			division = v_Division
			and mpiid = v_MpiId
			and AdverseEventDescription = v_AdverseEventDescription
			and EventDateInstance between v_InitialDate and (case when v_IsIntervalinMonths = 1 then dateadd(month, v_Interval, v_InitialDate) else dateadd(day, v_Interval, v_InitialDate) end)

$$
;