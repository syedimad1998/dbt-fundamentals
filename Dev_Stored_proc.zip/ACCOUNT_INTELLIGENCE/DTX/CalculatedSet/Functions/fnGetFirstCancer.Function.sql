CREATE OR REPLACE  FUNCTION CalculatedSet.fnGetFirstCancer (  
	v_Division varchar(100)
	, v_MpiId int
	, v_CodeType varchar(5)
	, v_CancerPrimarySecondaryClassification varchar(10)
)
RETURNS varchar(4)  
AS    
$$

    select min(CancerCodeMajorCategory)
    from CalculatedSet.fctPatientCancer c
    join (
        select min(DateFirstInstanceOfCancerCode) as DateFirstInstanceOfCancerCode, Division, MpiId
        from CalculatedSet.fctPatientCancer 
        where Division = v_Division
            and MpiId = v_MpiId
            and (v_CodeType is null or CodeType = v_CodeType)
            and (v_CancerPrimarySecondaryClassification is null or CancerPrimarySecondaryClassification = v_CancerPrimarySecondaryClassification)
           group by Division, MpiId
    ) x
    on x.division = c.division 
      and x.mpiid = c.mpiid
      and x.DateFirstInstanceOfCancerCode = c.DateFirstInstanceOfCancerCode
    where c.Division = v_Division
        and c.mpiid = v_MpiId
        and (v_CodeType is null or c.CodeType = v_CodeType)
        and (v_CancerPrimarySecondaryClassification is null or c.CancerPrimarySecondaryClassification = v_CancerPrimarySecondaryClassification)
            
$$
; 