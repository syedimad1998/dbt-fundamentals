CREATE OR REPLACE FUNCTION CalculatedSet.fnDidPatientHaveProcedureWithin (  
	v_Division varchar(100)
	, v_MpiId int
	, v_ProcedureName varchar(75)
	, v_InitialDate date
	, v_Interval int
	, v_IsIntervalinMonths boolean -- default 0
)
RETURNS int 
AS    
$$
        select
                case 
                    when max(1) is not null 
                    then 1 else 0
                end as rtn
        from CalculatedSet.fctPatientProcedure 
        where Division = v_Division
            and MpiId = v_MpiId
            and ProcedureName = v_ProcedureName
            and DateOfEvent between  --If positive use current date else lookback
                    case when v_Interval > 0 
                        then v_InitialDate 
                    else 
                        case when v_IsIntervalinMonths = 1 then dateadd(month, v_Interval, v_InitialDate)
                            else dateadd(day, v_Interval, v_InitialDate) 
                        end
                    end
                    --If positive use lookforward else use current date
                and case when v_Interval > 0 then 
                            case when v_IsIntervalinMonths = 1 
                                then dateadd(month, v_Interval, v_InitialDate)
                              else dateadd(day, v_Interval, v_InitialDate) 
                            end
                      else v_InitialDate 
                    end
$$
; 