CREATE OR REPLACE FUNCTION CalculatedSet.fnGetFirstInstanceOfOneOfDrugMatchesBetweenPeriod (
	v_Division varchar(100)
	, v_MpiId int
	, v_StartPeriodBeginSearch date
	, v_NumberOfDaysToAllowSearch int
	, v_GenericDrugName1  varchar(200)
	, v_GenericDrugName2  varchar(200) -- default null
	, v_GenericDrugName3  varchar(200) -- default null
	, v_GenericDrugName4  varchar(200) -- default null
	, v_GenericDrugName5  varchar(200) -- default null
	, v_GenericDrugName6  varchar(200) -- default null
	, v_GenericDrugName7  varchar(200) -- default null
	, v_GenericDrugName8  varchar(200) -- default null
	, v_GenericDrugName9  varchar(200) -- default null
	, v_GenericDrugName10 varchar(200) -- default null
	, v_GenericDrugName11 varchar(200) -- default null
	, v_GenericDrugName12 varchar(200) -- default null
	, v_GenericDrugName13 varchar(200) -- default null
	, v_GenericDrugName14 varchar(200) -- default null
	, v_GenericDrugName15 varchar(200) -- default null
	, v_GenericDrugName16 varchar(200) -- default null
	, v_GenericDrugName17 varchar(200) -- default null
	, v_GenericDrugName18 varchar(200) -- default null
	, v_GenericDrugName19 varchar(200) -- default null
	, v_GenericDrugName20 varchar(200) -- default null
)  
RETURNS date  
AS  
$$

	select min(DrugExposureStartDate)
	from
		Calculatedset.fctcancertherapy th 
	where 
		th.Division = v_Division
		and th.MpiId = v_MpiId
		and th.DrugGenericName in (
			  v_GenericDrugName1 
			, v_GenericDrugName2 
			, v_GenericDrugName3 
			, v_GenericDrugName4 
			, v_GenericDrugName5 
			, v_GenericDrugName6 
			, v_GenericDrugName7 
			, v_GenericDrugName8 
			, v_GenericDrugName9 
			, v_GenericDrugName10
			, v_GenericDrugName11
			, v_GenericDrugName12
			, v_GenericDrugName13
			, v_GenericDrugName14
			, v_GenericDrugName15
			, v_GenericDrugName16
			, v_GenericDrugName17
			, v_GenericDrugName18
			, v_GenericDrugName19
			, v_GenericDrugName20
		)
		and (
			drugexposurestartdate between v_StartPeriodBeginSearch and dateadd(day, v_NumberOfDaysToAllowSearch, v_StartPeriodBeginSearch)
			or
			drugexposureenddate between v_StartPeriodBeginSearch and dateadd(day, v_NumberOfDaysToAllowSearch, v_StartPeriodBeginSearch)
		)

$$
;