CREATE OR REPLACE FUNCTION CalculatedSet.fnGetPatientNeutropeniaGradeBetweenPeriod (  
     v_CombinedDivisionMpi varchar(128) 
	,v_PeriodBeginDate date 
	,v_PeriodEndDate date 
)  
RETURNS int  
AS  
$$

    with cte_output as (
        select min(ValueAsInt) as min_ValueAsInt
        From CalculatedSet.fctPatientLab
        where testname ilike 'Neutrophils #/volume in Blood' 
            and CombinedDivisionMpi = v_CombinedDivisionMpi 
            and TestDate >= CAST(v_PeriodBeginDate as date) 
            and TestDate <= CAST(v_PeriodEndDate as date)
	)


    select 
        case 
            when min_ValueAsInt < 500 then 4
            when min_ValueAsInt >= 500 and min_ValueAsInt < 1000 then 3
            when min_ValueAsInt >= 1000 and min_ValueAsInt < 1500 then 2
            when min_ValueAsInt < 2000 then 1
            else 0
        end
    from cte_output

$$
;