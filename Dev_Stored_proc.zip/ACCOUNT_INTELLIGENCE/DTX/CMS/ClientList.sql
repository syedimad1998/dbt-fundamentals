CREATE or REPLACE TABLE PROD_DTX.CMS.ClientList(
	ClientName varchar(50),
	DatabaseName varchar(20),
	OCMId varchar(10),
	EPPE varchar(10));