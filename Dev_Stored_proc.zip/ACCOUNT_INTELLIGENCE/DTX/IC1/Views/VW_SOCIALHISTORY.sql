create or replace view IC1_VIEW.VW_SOCIALHISTORY(
	SOCIALHISTORYID,
	SOCIALHISTORYRECORDCREATEDDATETIME,
	SOCIALHISTORYRECORDCREATEDBY,
	SOCIALHISTORYRECORDDELETEDDATETIME,
	SOCIALHISTORYSNOMEDCODE,
	SOCIALHISTORYCATEGORYNAME,
	SOCIALHISTORYCATEGORYDESCRIPTION,
	SOCIALHISTORYRESPONSEANSWERDESCRIPTION,
	SOCIALHISTORYPATIENTAGEOFFIRSTUSENUMBER,
	SOCIALHISTORYSUBSTANCECONSUMEDPERDAYQUANTITY,
	SOCIALHISTORYSUBSTANCECONSUMEDPERYEARQUANTITY,
	SOCIALHISTORYTOBACCOTYPECONSUMEDDESCRIPTION,
	SOCIALHISTORYYEARSTOBACCOPRODUCTCONSUMEDDESCRIPTION,
	SOCIALHISTORYAGEOFLASTSUBSTANCEUSENUMBER,
	SOCIALHISTORYSUBSTANCECESSATIONYEARSNUMBER,
	SOCSOCIALHISTORYILLEGALDRUGUSEINDICATOR,
	SOCIALHISTORYRADIATIONEXPOSUREINDICATOR,
	SOCIALHISTORYASBESTOSEXPOSUREINDICATOR,
	SOCIALHISTORYBENZENEEXPOSUREINDICATOR,
	SOCIALHISTORYLEADEXPOSUREINDICATOR,
	SOCIALHISTORYENVIRONMENTALEXPOSUREDATE,
	SOCIALHISTORYCOMMENTTEXT,
	PRACTICEID,
	PRACTICENAME,
	DATASOURCESYSTEMID,
	PATIENTID,
	SOCIALHISTORYSTRESSFULLIFESTYLEINDICATOR,
	SOCIALHISTORYISOLATEDLIFESTYLEINDICATOR,
	SOCIALHISTORYEXCESSIVEWORKHOURSINDICATOR
) as (
    /*
******************************************** NOTES START ********************************************
Table: SocialHistory
Comments: Requires t_patients_medical_history_use and t_patients
******************************************** NOTES END ********************************************
*/



select t_patients_medical_history_use.patientmedicalhistoryuseguid as socialhistoryid
	,t_patients_medical_history_use.createdate as socialhistoryrecordcreateddatetime
	,t_patients_medical_history_use.userguid as socialhistoryrecordcreatedby
	,t_patients_medical_history_use.deletedate as socialhistoryrecorddeleteddatetime
	,t_patients_medical_history_use.snomed as socialhistorysnomedcode
	,t_patients_medical_history_use.type as socialhistorycategoryname
	,t_patients_medical_history_use.value as socialhistorycategorydescription
	,t_patients_medical_history_use.name as socialhistoryresponseanswerdescription
	,t_patients_medical_history_use.ageoffirstuse as socialhistorypatientageoffirstusenumber
	,t_patients_medical_history_use.perday as socialhistorysubstanceconsumedperdayquantity
	,t_patients_medical_history_use.peryear as socialhistorysubstanceconsumedperyearquantity
	,t_patients_medical_history_use.tobaccotype as socialhistorytobaccotypeconsumeddescription
	,t_patients_medical_history_use.yearstobaccoused as socialhistoryyearstobaccoproductconsumeddescription
	,t_patients_medical_history_use.ageoflastuse as socialhistoryageoflastsubstanceusenumber
	,t_patients_medical_history_use.yearstopped as socialhistorysubstancecessationyearsnumber
	,t_patients_medical_history_use.illegaldrugs as socsocialhistoryillegaldruguseindicator
	,t_patients_medical_history_use.radiation as socialhistoryradiationexposureindicator
	,t_patients_medical_history_use.asbestos as socialhistoryasbestosexposureindicator
	,t_patients_medical_history_use.benzene as socialhistorybenzeneexposureindicator
	,t_patients_medical_history_use.lead as socialhistoryleadexposureindicator
	,t_patients_medical_history_use.exposuredate as socialhistoryenvironmentalexposuredate
	,t_patients_medical_history_use.comments as socialhistorycommenttext
	,t_member.homecommunityguid as practiceid
    ,t_community.license as practicename
	,'IC-EHR' as datasourcesystemid
	,t_patients_medical_history_use.patientguid as patientid
	,null socialhistorystressfullifestyleindicator
	,null socialhistoryisolatedlifestyleindicator
	,null socialhistoryexcessiveworkhoursindicator

from ICEHR.t_patients_medical_history_use t_patients_medical_history_use
inner join ICEHR.t_patients on (t_patients_medical_history_use.patientguid = t_patients.patientguid)
inner join ICEHR.t_member on (t_member.memberguid = t_patients.memberguid )
inner join ICEHR.t_community t_community on (t_community.communityguid = t_member.homecommunityguid) 


union all

select t_patients_medical_history.patientmedicalhistoryguid as socialhistoryid
	,t_patients_medical_history.createdate as socialhistoryrecordcreateddatetime
	,t_patients_medical_history.userguid as socialhistoryrecordcreatedby
	,t_patients_medical_history.deletedate as socialhistoryrecorddeleteddatetime
	,null as socialhistorysnomedcode
	,'Life Style' as socialhistorycategoryname
	,null as socialhistorycategorydescription
	,null as socialhistoryresponseanswerdescription
	,null as socialhistorypatientageoffirstusenumber
	,null as socialhistorysubstanceconsumedperdayquantity
	,null as socialhistorysubstanceconsumedperyearquantity
	,null as socialhistorytobaccotypeconsumeddescription
	,null as socialhistoryyearstobaccoproductconsumeddescription
	,null as socialhistoryageoflastsubstanceusenumber
	,null as socialhistorysubstancecessationyearsnumber
	,null socsocialhistoryillegaldruguseindicator
	,null socialhistoryradiationexposureindicator
	,null socialhistoryasbestosexposureindicator
	,null socialhistorybenzeneexposureindicator
	,null socialhistoryleadexposureindicator
	,null socialhistoryenvironmentalexposuredate
	,t_patients_medical_history.socialcomment socialhistorycommenttext
	,t_member.homecommunityguid practiceid
	,t_community.license as practicename
	,'IC-EHR' as datasourcesystemid
	,t_patients_medical_history.patientguid patientid
	,t_patients_medical_history.stresslifestyle socialhistorystressfullifestyleindicator
	, t_patients_medical_history.isolatedlifestyle socialhistoryisolatedlifestyleindicator
	,t_patients_medical_history.work60hours socialhistoryexcessiveworkhoursindicator

from ICEHR.t_patients_medical_history t_patients_medical_history
inner join ICEHR.t_patients on (t_patients_medical_history.patientguid = t_patients.patientguid) 
inner join ICEHR.t_member on (t_member.memberguid = t_patients.memberguid )
inner join ICEHR.t_community t_community on (t_community.communityguid = t_member.homecommunityguid) 
where (t_patients_medical_history.stresslifestyle is not null) 
  );