create or replace view IC1_VIEW.VW_MEDICALEQUIPMENT(
	MEDICALEQUIPMENTID,
	MEDICALEQUIPMENTDESCRIPTION,
	MEDICALDEVICENAME,
	MEDICALDEVICEUNIVERSALDEVICEIDENTIFIER,
	MEDICALDEVICEEQUIPMENTEFFECTIVEDATE,
	MEDICALEQUIPMENTSTATUSDESCRIPTION,
	PATIENTID,
	PRACTICEID,
	PRACTICENAME,
	DATASOURCESYSTEMID
) as (
    /* 
********************************************  NOTES START  ********************************************
Table: Medical Equipment
Comments: Reads data from Surgical medical equipment

********************************************  NOTES END    ********************************************

*/



with cte as (


select
	 t_patients_implant_udi.patientudiid as medicalequipmentid
	,t_patients_implant_udi.devicedescription as medicalequipmentdescription
	,t_patients_implant_udi.devicename as medicaldevicename
	,t_patients_implant_udi.deviceid as medicaldeviceuniversaldeviceidentifier
	,t_patients_implant_udi.udiimplantdatetime as medicaldeviceequipmenteffectivedate
	,(
		case 
			when t_patients_implant_udi.deletestatus = FALSE
				then 'active'
			else 'inactive'
			end
		) as medicalequipmentstatusdescription
	,t_patients_implant_udi.patientguid as patientid
	,t_member.homecommunityguid as practiceid
    ,t_community.license as practicename
	,'IC-EHR' as datasourcesystemid

from ICEHR.t_patients_implant_udi
inner join ICEHR.t_patients on (t_patients.patientguid = t_patients_implant_udi.patientguid) 
inner join ICEHR.t_member on (t_member.memberguid = t_patients.memberguid) 
inner join ICEHR.t_community on ( t_member.homecommunityguid = t_community.communityguid) 

)
select * from cte where medicalequipmentstatusdescription ='active'
  );