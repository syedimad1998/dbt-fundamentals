create or replace view IC1_VIEW.VW_ALLERGY(
	ALLERGYID,
	ALLERGYRECORDCREATEDDATETIME,
	ALLERGYCREATEDBYUSERID,
	ALLERGYNONEKNOWNINDICATOR,
	ALLERGYREVIEWEDDATE,
	ALLERGYREVIEWEDBYUSERID,
	ALLERGYNAME,
	ALLERGYDESCRIPTION,
	ALLERGYREACTIONDESCRIPTION,
	ALLERGYSEVERITYDESCRIPTION,
	ALLERGYSEVERITYSNOMEDCODE,
	ALLERGYCATEGORYDESCRIPTION,
	ALLERGYONSETDATE,
	ALLERGYSTOPDATETIME,
	ALLERGYSTOPREASONDESCRIPTION,
	ALLERGYRXNORMDRUGID,
	ALLERGYFIRSTDATABANKDRUGID,
	ACTIVESTATUSINDICATOR,
	ALLERGYINACTIVATEDBYUSERID,
	ALLERGYFIRSTDATABANKGROUPID,
	PATIENTID,
	PRACTICEID,
	PRACTICENAME,
	DATASOURCESYSTEMID,
	VISITID,
	ALLERGYDRFIRSTID
) as (
    /*
******************************************** NOTES START ********************************************
Table: Allergy
Comments: Allergy table - populated from t_patients_allergy, t_visits, t_visits_additional_data,
t_patients_additional_data
******************************************** NOTES END ********************************************
*/



with cte as (


select t_patients_allergy.patientallergyguid as allergyid 
	,t_patients_allergy.createdate as allergyrecordcreateddatetime 
	,t_patients_allergy.userguid as allergycreatedbyuserid 
	,t_patients_additional_data.allergynoknown as allergynoneknownindicator 
	,t_visits_additional_data.allergyreviewdate as allergyrevieweddate 
	,t_visits_additional_data.allergyuserguid as allergyreviewedbyuserid 
	,t_patients_allergy.allergy as allergyname 
	,t_patients_allergy.description as allergydescription 
	,t_patients_allergy.reaction as allergyreactiondescription 
	,t_patients_allergy.severity as allergyseveritydescription 
	,t_patients_allergy.severitysnomed as allergyseveritysnomedcode 
	,t_patients_allergy.allergygroup as allergycategorydescription 
	,t_patients_allergy.createdate as allergyonsetdate 
	,t_patients_allergy.deactivatedatetime as allergystopdatetime 
	,t_patients_allergy.deactivatereason as allergystopreasondescription 
	,t_patients_allergy.rxnorm as allergyrxnormdrugid 
	,t_patients_allergy.firstdatabankmedid as allergyfirstdatabankdrugid 
	,(
		case 
			when t_patients_allergy.active = TRUE
				then 'active'
			else 'inactive'
			end
		) as activestatusindicator 
	,t_patients_allergy.deactivateuserguid as allergyinactivatedbyuserid
	,t_patients_allergy.firstdatabankallergyid as allergyfirstdatabankgroupid 
	,t_patients_allergy.patientguid as patientid 
	,t_member.homecommunityguid as practiceid 
	,t_community.license as practicename
	,'IC-EHR' as datasourcesystemid 
	,t_patients_allergy.visitguid as visitid 
	,t_patients_allergy.rcopiaid as allergydrfirstid 
	
from  ICEHR.t_patients_allergy t_patients_allergy
left outer join  ICEHR.t_patients_additional_data t_patients_additional_data on (t_patients_allergy.patientguid = t_patients_additional_data.patientguid)  
inner join  ICEHR.t_patients t_patients on (t_patients.patientguid = t_patients_allergy.patientguid) 
inner join  ICEHR.t_member t_member on (t_member.memberguid = t_patients.memberguid) 
left outer join  ICEHR.t_visits t_visits on (t_patients_allergy.visitguid = t_visits.visitguid) 
left outer join  ICEHR.t_visits_additional_data t_visits_additional_data on (t_visits_additional_data.visitguid = t_visits.visitguid) 
inner join ICEHR.t_community t_community on (t_community.communityguid = t_member.homecommunityguid) 
)
select * from cte where activestatusindicator = 'active'
  );