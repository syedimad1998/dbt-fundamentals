create or replace view IC1_VIEW.VW_PROVIDER(
	PROVIDERID,
	REFERRINGPROVIDERID,
	ADDRESSID,
	FACILITYID,
	PROVIDERUSERNAME,
	PROVIDERFULLNAME,
	PROVIDERFIRSTNAME,
	PROVIDERMIDDLENAME,
	PROVIDERLASTNAME,
	PROVIDERSUFFIXNAME,
	PROVIDEREXTENDEDCREDENTIALSDESCRIPTION,
	PROVIDERGENDERDESCRIPTION,
	PROVIDERNPINUMBER,
	PROVIDERACTIVESTATUSINDICATOR,
	PROVIDERPROFILECREATEDDATETIME,
	PROVIDERROLEDESCRIPTION,
	PRACTICEID,
	PRACTICENAME,
	DATASOURCESYSTEMID
) as (
    /*
******************************************** NOTES START ********************************************
Table: Provider
Comments: Read Provider Master Data and Referral Providers
******************************************** NOTES END ********************************************
*/



with cte as (
with uf as(
    select t_users_facility.facilityguid
    ,t_users_facility.userguid
    ,row_number() over(partition by t_users_facility.userguid
		order by t_users_facility.isfavoritefacility desc) as rn
    from ICEHR.t_users_facility
    where (t_users_facility.active = TRUE)  
)

select distinct t_users.userguid as providerid
	,null as referringproviderid
	,null as addressid
	,uf.facilityguid as facilityid
	,t_member.loginname as providerusername
	,concat(t_member.firstname , ' ',t_member.middlename, ' ' , t_member.lastname) as providerfullname
	,t_member.firstname as providerfirstname
	,t_member.middlename as providermiddlename
	,t_member.lastname as providerlastname
	,t_member.prefix as providersuffixname
	,t_member.suffix as providerextendedcredentialsdescription
	,t_member.sex as providergenderdescription
	,t_users_personalization.value as providernpinumber
	,(
		case 
			when t_member.active = TRUE
				then 'active'
			else 'inactive'
			end
		) as provideractivestatusindicator
	,t_member.createdate as providerprofilecreateddatetime
	,'physician' as providerroledescription
	,t_member.homecommunityguid as practiceid
    ,t_community.license as practicename
	,'IC-EHR' as datasourcesystemid
from ICEHR.t_users t_users
left outer join ICEHR.t_users_personalization t_users_personalization on (t_users_personalization.userguid = t_users.userguid)
	and lower(t_users_personalization.name) = 'npi' 
inner join ICEHR.t_member t_member on (t_member.memberguid = t_users.memberguid) 
inner join ICEHR.t_community t_community on (t_community.communityguid = t_member.homecommunityguid)  
inner join ICEHR.t_member_community t_member_community on (t_member_community.memberguid = t_member.memberguid) 
inner join ICEHR.t_member_community_application_role t_member_community_application_role on (t_member_community_application_role.membercommunityguid = t_member_community.membercommunityguid) 
inner join ICEHR.t_community_application_role t_community_application_role on (t_community_application_role.communityapplicationroleguid = t_member_community_application_role.communityapplicationroleguid) 
inner join ICEHR.t_roles r on (r.roleguid = t_community_application_role.roleguid) 
inner join ICEHR.t_community c on (c.communityguid = t_member_community.communityguid) 
left outer join uf on (uf.userguid = t_users.userguid) and uf.rn = 1
where t_users.scheduleable = TRUE
	and r.description = 'physician' -- should be schedulable and should belong to role

union all

-- read referral providers list
select t_community_referral.communityreferralguid as providerid
	,t_community_referral.communityreferralguid as referringproviderid -- this field differenciate if the provider is in house provider or referral provider
	,t_community_referral.addressguid as addressid
	,null as facilityid
	,null as providerusername
	,concat(t_community_referral.firstname ,' ',t_community_referral.middlename, ' ' ,t_community_referral.lastname) as providerfullname
	,t_community_referral.firstname as providerfirstname
	,t_community_referral.middlename as providermiddlename
	,t_community_referral.lastname as providerlastname
	,null as providersuffixname
	,null as providerextendedcredentialsdescription
	,null as providergenderdescription
	,t_community_referral.IdentificationCode AS providernpinumber
	,(
		case 
			when t_community_referral.active = TRUE
				then 'active'
			else 'inactive'
			end
		) as provideractivestatusindicator
	,t_community_referral.createdate as providerprofilecreateddatetime
	,'' as providerroledescription
	,t_community_referral.communityguid as practiceid
    ,t_community.license as practicename
	,'IC-EHR' as datasourcesystemid
from ICEHR.t_community_referral t_community_referral
inner join ICEHR.t_community t_community on (t_community.communityguid = t_community_referral.communityguid) 

)
select * from cte where 
provideractivestatusindicator ='active'
  );