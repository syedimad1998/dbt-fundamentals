create or replace view IC1_VIEW.VW_SURGERY(
	SURGERYID,
	SURGERYRECORDCREATEDDATETIME,
	SURGERYRECORDCREATEDBYUSERID,
	SURGERYRECORDDELETEDDATETIME,
	SURGERYRECORDDELETEDBYUSERID,
	PATIENTADMISSIONDATE,
	PATIENTDISCHARGEDATE,
	SURGERYPROCEDUREDESCRIPTION,
	FACILITYNAME,
	PATIENTID,
	PRACTICEID,
	PRACTICENAME,
	DATASOURCESYSTEMID
) as (
    /*
******************************************** NOTES START ********************************************
Table: Surgery
Comments: Requires t_patients_surgical_history, t_patients and t_member
******************************************** NOTES END ********************************************
*/



with cte as (
	
select t_patients_surgical_history.patientsurgicalhistoryguid as surgeryid
	,t_patients_surgical_history.createdate as surgeryrecordcreateddatetime
	,t_patients_surgical_history.userguid as surgeryrecordcreatedbyuserid
	,t_patients_surgical_history.deletedate as surgeryrecorddeleteddatetime
	,t_patients_surgical_history.deleteuserguid as surgeryrecorddeletedbyuserid
	,t_patients_surgical_history.surgeryyear as patientadmissiondate  
	,t_patients_surgical_history.surgeryyear as patientdischargedate  
	,t_patients_surgical_history.description as surgeryproceduredescription
	,t_patients_surgical_history.location as facilityname
	,t_patients_surgical_history.patientguid as patientid
	,t_member.homecommunityguid as practiceid
	,t_community.license as practicename
	,'IC-EHR' as datasourcesystemid
from ICEHR.t_patients_surgical_history
inner join ICEHR.t_patients on ( t_patients_surgical_history.patientguid = t_patients.patientguid ) 
inner join ICEHR.t_member on (t_patients.memberguid = t_member.memberguid ) 
inner join ICEHR.t_community t_community on (t_community.communityguid = t_member.homecommunityguid )
)
select * from cte where 
surgeryrecorddeleteddatetime IS NULL
  );