create or replace view IC1_VIEW.VW_VISIT(
	VISITID,
	VISITRECORDCREATEDDATETIME,
	VISITRECORDCREATEDBYUSERID,
	VISITISACTIVEINDICATOR,
	VISITDATE,
	VISITTYPEDESCRIPTION,
	VISITVIRTUALEVENTINDICATOR,
	VISITSTATUSDESCRIPTION,
	VISITSCHEDULEDSTARTTIME,
	VISITSCHEDULEDENDTIME,
	VISITACTUALSTARTDATETIME,
	VISITACTUALENDDATETIME,
	VISITPATIENTCHECKEDINBYUSERID,
	VISITPATIENTCHECKEDOUTBYUSERID,
	FACILITYNAME,
	VISITSIGNOFFRECORDCREATEDDATETIME,
	VISITSIGNEDOFFBYUSERID,
	VISITSIGNEDOFFDATETIME,
	VISITSIGNOFFSTATUS,
	VISITREASONFOREVENTDESCRIPTION,
	VISITCANCELLEDAPPOINTMENTREASONTEXT,
	PATIENTID,
	PRACTICEID,
	PRACTICENAME,
	DATASOURCESYSTEMID,
	FACILITYID,
	VISITCANCELLEDDATETIME,
	VISITCANCELLEDAPPOINTMENTREASONNOTETEXT,
	VISITCANCELLEDBYUSERID
) as (
    /* 
********************************************  NOTES START  ********************************************
Table: Visit
Comments: Reads data from Visit and Appointments

Note: VisitTypeDescription is going to differentiate between Visits, Virtual Visit and Appointments

********************************************  NOTES END    ********************************************

*/



with cte as (

-- regular encounters
select t_visits.visitguid as visitid
	,t_visits.createdate as VisitRecordCreatedDatetime
	,t_visits.userguid as VisitRecordCreatedByUserId
	,(
		case 
			when t_visits.billingstatus in (
					'deleted'
					,'void'
					)
				then '0'
			else '1'
			end
		) as visitisactiveindicator
	,t_patients_schedule.schedulebegintime as visitdate
	,'visit' as visittypedescription
	,'0' as visitvirtualeventindicator
	,t_visits.billingstatus as VisitStatusDescription
	,t_patients_schedule.schedulebegintime as visitscheduledstarttime
	,t_patients_schedule.scheduleendtime as visitscheduledendtime
    ,t_visits.visitbegindatetime as visitactualstartdatetime 
    ,t_visits.visitenddatetime as visitactualenddatetime
	,t_visits.checkinuserguid as visitpatientcheckedinbyuserid
	,t_visits.checkoutuserguid as visitpatientcheckedoutbyuserid
	,t_facility.name as facilityname
	,t_visits.doctorsignoffdatetime as visitsignoffrecordcreateddatetime
	,t_visits.userguid as VisitSignedoffByUserId
	,t_visits.doctorsignoffdatetime as visitsignedoffdatetime
	,(
		case 
			when t_visits.doctorsignoffdatetime is null
				then '0'
			else '1'
			end
		) as visitsignoffstatus
	,t_patients_schedule.description as visitreasonforeventdescription
	,(	case 
			when t_patients_schedule.parentguid is null and t_patients_schedule.canceluserguid is not null
				then t_patients_schedule.canceltype
			else 
				''
			end) as visitcancelledappointmentreasontext
	,t_visits.patientguid as patientid
	,t_facility.communityguid as practiceid
    ,t_community.license as practicename
	,'IC-EHR' as datasourcesystemid
	,t_visits.facilityguid as facilityid
	,t_patients_schedule.canceldate as visitcancelleddatetime
	,t_patients_schedule.cancelreason as VisitCancelledAppointmentReasonNoteText
	,t_patients_schedule.canceluserguid as VisitCancelledByUserId
from ICEHR.t_visits
inner join ICEHR.t_facility on (t_facility.facilityguid = t_visits.facilityguid) 
inner join ICEHR.t_patients on( t_patients.patientguid = t_visits.patientguid) 
inner join ICEHR.t_member on (t_member.memberguid = t_patients.memberguid) 
inner join ICEHR.t_community t_community on (t_community.communityguid = t_member.homecommunityguid) 
inner join ICEHR.t_patients_schedule on (t_patients_schedule.patientscheduleguid = t_visits.patientscheduleguid) 
inner join ICEHR.t_facility_schedule_type on (t_facility_schedule_type.facilityscheduletypeguid = t_patients_schedule.facilityscheduletypeguid)
left join ICEHR.t_facility_personalization on (t_visits.facilityguid = t_facility_personalization.facilityguid)
and (t_facility_personalization.name = 'timezone') and (t_facility_personalization.active = TRUE) 


union all

-- virtual encounters
select  t_visits.visitguid as visitid
	,t_visits.createdate as VisitRecordCreatedDatetime
	,t_visits.userguid as VisitRecordCreatedByUserId
	,(
		case 
			when t_visits.billingstatus in (
					'deleted'
					,'void'
					)
				then '0'
			else '1'
			end
		) as visitisactiveindicator
	,t_patients_schedule.schedulebegintime as visitdate
	,'virtualvisit' as visittypedescription
	,'1' as visitvirtualeventindicator
	,t_visits.billingstatus as VisitStatusDescription
	,t_patients_schedule.schedulebegintime as visitscheduledstarttime
	,t_patients_schedule.scheduleendtime as visitscheduledendtime
    ,t_visits.visitbegindatetime as visitactualstartdatetime 
    ,t_visits.visitenddatetime as visitactualenddatetime
	,t_visits.checkinuserguid as visitpatientcheckedinbyuserid
	,t_visits.checkoutuserguid as visitpatientcheckedoutbyuserid
	,t_facility.name as facilityname
	,t_visits.doctorsignoffdatetime as visitsignoffrecordcreateddatetime
	,t_visits.userguid as VisitSignedoffByUserId
	,t_visits.doctorsignoffdatetime as visitsignedoffdatetime
	,(
		case 
			when t_visits.doctorsignoffdatetime is null
				then '0'
			else '1'
			end
		) as visitsignoffstatus
	,t_patients_schedule.description as visitreasonforeventdescription
	,(	case 
			when t_patients_schedule.parentguid is null and t_patients_schedule.canceluserguid is not null
				then t_patients_schedule.canceltype
			else 
				''
			end) as visitcancelledappointmentreasontext
	,t_visits.patientguid as patientid
	,t_facility.communityguid as practiceid
    ,t_community.license as practicename
	,'IC-EHR' as datasourcesystemid
	,t_visits.facilityguid as facilityid
	,t_patients_schedule.canceldate as visitcancelleddatetime
	,t_patients_schedule.cancelreason as VisitCancelledAppointmentReasonNoteText
	,t_patients_schedule.canceluserguid as VisitCancelledByUserId
from ICEHR.t_visits
inner join ICEHR.t_facility on (t_facility.facilityguid = t_visits.facilityguid) 
inner join ICEHR.t_patients on (t_patients.patientguid = t_visits.patientguid) 
inner join ICEHR.t_member on (t_member.memberguid = t_patients.memberguid) 
inner join ICEHR.t_community t_community on (t_community.communityguid = t_member.homecommunityguid) 
inner join ICEHR.t_patients_schedule on (t_patients_schedule.patientscheduleguid = t_visits.virtualpatientscheduleguid) 
inner join ICEHR.t_facility_schedule_type on (t_facility_schedule_type.facilityscheduletypeguid = t_patients_schedule.facilityscheduletypeguid) 
left join ICEHR.t_facility_personalization on (t_facility_personalization.facilityguid=  t_visits.facilityguid)
and (t_facility_personalization.name = 'timezone') and (t_facility_personalization.active = TRUE) 


union all

-- appointment
select t_patients_schedule.patientscheduleguid as visitid
	,t_visits.createdate as VisitRecordCreatedDatetime
	,t_patients_schedule.userguid as VisitRecordCreatedByUserId
	,Case When t_patients_schedule.active = TRUE then '1' else '0' end as visitisactiveindicator
	,t_patients_schedule.schedulebegintime as visitdate
	,t_facility_schedule_type.name as visittypedescription
	,-- if it not visit or virtualvisit then it would be appointment
	'0' as visitvirtualeventindicator
	,t_community_status.name as VisitStatusDescription
	,t_patients_schedule.schedulebegintime as visitscheduledstarttime
	,t_patients_schedule.scheduleendtime as visitscheduledendtime
	,null as visitactualstartdatetime
	,null as visitactualenddatetime
	,t_visits.checkinuserguid as visitpatientcheckedinbyuserid
	,t_visits.checkoutuserguid as visitpatientcheckedoutbyuserid
	,t_facility.name as facilityname
	,t_visits.doctorsignoffdatetime as visitsignoffrecordcreateddatetime
	,t_visits.userguid as VisitSignedoffByUserId
	,t_visits.doctorsignoffdatetime as visitsignedoffdatetime
	,(
		case 
			when t_visits.doctorsignoffdatetime is null
				then '0'
			else '1'
			end
		) as visitsignoffstatus
	,t_patients_schedule.description as visitreasonforeventdescription
	,(	case 
			when t_patients_schedule.parentguid is null and t_patients_schedule.canceluserguid is not null
				then t_patients_schedule.canceltype
			else 
				''
			end) as visitcancelledappointmentreasontext
	,t_patients_schedule.patientguid as patientid
	,t_facility.communityguid as practiceid
	,t_community.license as practicename
	,'IC-EHR' as datasourcesystemid
	,t_patients_schedule.facilityguid as facilityid
	,t_patients_schedule.canceldate as visitcancelleddatetime
	,t_patients_schedule.cancelreason as VisitCancelledAppointmentReasonNoteText
	,t_patients_schedule.canceluserguid as VisitCancelledByUserId
from  ICEHR.t_patients_schedule
inner join  ICEHR.t_facility on (t_facility.facilityguid = t_patients_schedule.facilityguid ) 
inner join  ICEHR. t_patients on( t_patients.patientguid = t_patients_schedule.patientguid)  
inner join ICEHR.t_member on ( t_member.memberguid = t_patients.memberguid) 
inner join ICEHR.t_community t_community on ( t_community.communityguid = t_member.homecommunityguid ) 
left outer join  ICEHR. t_visits on (t_visits.patientscheduleguid = t_patients_schedule.patientscheduleguid)  
left outer join  ICEHR.t_community_status on (t_community_status.communitystatusguid = t_patients_schedule.communitystatusguid ) 
inner join ICEHR.t_facility_schedule_type on (t_facility_schedule_type.facilityscheduletypeguid = t_patients_schedule.facilityscheduletypeguid) 

)
select * from cte where visitisactiveindicator = '1'
  );