create or replace view IC1_VIEW.VW_PATIENTADDRESS(
	ADDRESSID,
	PRACTICEID,
	PRACTICENAME,
	DATASOURCESYSTEMID,
	PATIENTID
) as (
    /* 
********************************************  NOTES START  ********************************************
Table: Patients Address
Comments: Reads Patient Address


********************************************  NOTES END    ********************************************
*/



-- Patient Address
select 
	t_address.addressguid as addressid
	,t_member.homecommunityguid as practiceid
	,t_community.license as practicename
	,'IC-EHR' as datasourcesystemid
	,t_patients.patientguid as patientid

from ICEHR.t_patients
inner join ICEHR.t_address on (t_patients.patientguid = t_address.foreignkeyguid) 
inner join ICEHR.t_member on (t_member.memberguid = t_patients.memberguid) 
inner join ICEHR.t_community t_community on (t_community.communityguid = t_member.homecommunityguid) 

  );