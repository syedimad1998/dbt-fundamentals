create or replace view IC1_VIEW.VW_DIAGNOSIS(
	DIAGNOSISID,
	DIAGNOSISRECORDCREATEDDATETIME,
	DIAGNOSISENTRYISDELETEDINDICATOR,
	DIAGNOSISTYPECODE,
	DIAGNOSISONSETDATE,
	DIAGNOSISDISEASESTATUSDESCRIPTION,
	DIAGNOSISCODE,
	DIAGNOSISSHORTDESCRIPTION,
	DIAGNOSISCHRONICCONDITIONINDICATOR,
	DIAGNOSISENCOUNTERDATE,
	SERVICEPROVIDERID,
	PATIENTID,
	PRACTICEID,
	PRACTICENAME,
	DATASOURCESYSTEMID,
	VISITID,
	ORDERID
) as (
    /*
******************************************** NOTES START ********************************************
Table: Diagnosis
Comments: Read Patient diagnosis of patient

Note: 
	If the VisitGuid is NULL then it would be Patient Level Diagnosis (t_patients_chronic_disorder) or else it is visit level diagnosis
	If OrderId is not null then it is Visit Order Diagnosis

******************************************** NOTES END ********************************************
*/



with cte as (


with indicator as (
	select 
	(
	case 
		when t_patients_chronic_disorder_audit.status in ('Deleted', 'InActive', 'Resolved')
			then '1'
		else '0'
		end
	) as status
	, patientchronicdisorderguid
	,row_number() over(partition by t_patients_chronic_disorder_audit.patientchronicdisorderguid
                                         order by t_patients_chronic_disorder_audit.createdate Desc) as rn

	FROM ICEHR.t_patients_chronic_disorder_audit t_patients_chronic_disorder_audit
)

select t_patients_chronic_disorder.patientchronicdisorderguid as diagnosisid
,t_patients_chronic_disorder.createdate as diagnosisrecordcreateddatetime 
,indicator.status as diagnosisentryisdeletedindicator
,t_patients_chronic_disorder.type as diagnosistypecode
,t_patients_chronic_disorder.diagnosisdate as diagnosisonsetdate
,t_patients_chronic_disorder.status as diagnosisdiseasestatusdescription
,t_diagnosis_icd.code as diagnosiscode
,t_diagnosis_icd.ShortDescription AS diagnosisshortdescription 
,(
	case 
		when t_patients_chronic_disorder.status = 'Chronic'
			then '1'
		else '0'
		end
	) as diagnosischronicconditionindicator
,null as diagnosisencounterdate
,null as serviceproviderid
,t_patients_chronic_disorder.patientguid as patientid
,t_member.homecommunityguid as practiceid
,t_community.license as practicename
,'IC-EHR' as datasourcesystemid
,null as visitid
,null as orderid

from   ICEHR.t_patients t_patients
inner join   ICEHR.t_patients_chronic_disorder t_patients_chronic_disorder on (t_patients_chronic_disorder.patientguid = t_patients.patientguid) 
inner join   ICEHR.t_diagnosis_icd t_diagnosis_icd on (t_diagnosis_icd.diagnosisicdguid = t_patients_chronic_disorder.diagnosisicdguid) 
inner join   ICEHR.t_member t_member on (t_member.memberguid = t_patients.memberguid) 
inner join   ICEHR.t_community t_community on (t_member.homecommunityguid = t_community.communityguid)
left outer join indicator on  indicator.patientchronicdisorderguid = t_patients_chronic_disorder.patientchronicdisorderguid and indicator.rn = 1 

union all

select t_visits_todays_assessment.visittodaysassessmentguid as diagnosisid
,t_visits_todays_assessment.createdate as diagnosisrecordcreateddatetime
,(
	case 
		when t_visits_todays_assessment.deletedate is null
			then '0'
		else '1'
		end
	) as diagnosisentryisdeletedindicator
,t_patients_chronic_disorder.type as diagnosistypecode
,t_visits_todays_assessment.createdate as diagnosisonsetdate
,t_visits_todays_assessment.status as diagnosisdiseasestatusdescription
,t_diagnosis_icd.code as diagnosiscode
,t_diagnosis_icd.shortdescription as diagnosisshortdescription
,(
	case 
		when t_visits_todays_assessment.status = 'Chronic'
			then '1'
		else '0'
		end
	) as diagnosischronicconditionindicator
,ifnull(t_visits.visitbegindatetime, t_visits.createdate) as diagnosisencounterdate
,t_visits.userguid as serviceproviderid
,t_patients.patientguid as patientid
,t_member.homecommunityguid as practiceid
,t_community.license as practicename
,'IC-EHR' as datasourcesystemid
,t_visits.visitguid as visitid
,null as orderid
from   ICEHR.t_visits_todays_assessment t_visits_todays_assessment
inner join   ICEHR.t_visits t_visits on (t_visits.visitguid = t_visits_todays_assessment.visitguid) 
inner join   ICEHR.t_patients  t_patients on (t_visits.patientguid = t_patients.patientguid) 
inner join   ICEHR.t_diagnosis_icd t_diagnosis_icd on (t_diagnosis_icd.diagnosisicdguid = t_visits_todays_assessment.diagnosisicdguid) 
left outer join   ICEHR.t_patients_chronic_disorder t_patients_chronic_disorder on (t_patients_chronic_disorder.patientchronicdisorderguid = t_visits_todays_assessment.patientschronicdisorderguid) 
inner join   ICEHR.t_member  t_member on (t_member.memberguid = t_patients.memberguid)
inner join   ICEHR.t_community t_community on (t_member.homecommunityguid = t_community.communityguid)

union all

select t_visits_order_patient_diagnosis.patientchronicdisorderguid as diagnosisid
,t_visits_order.createdate as diagnosisrecordcreateddatetime
,(case when t_visits_order.deletedate is null then '0' else '1' end) as diagnosisentryisdeletedindicator
,t_patients_chronic_disorder.type as diagnosistypecode
,t_patients_chronic_disorder.diagnosisdate as diagnosisonsetdate
,t_patients_chronic_disorder.status as diagnosisdiseasestatusdescription
,t_diagnosis_icd.code as diagnosiscode
,t_diagnosis_icd.shortdescription as diagnosisshortdescription
,(
	case 
		when t_visits_order.status = 'Chronic'
			then '1'
		else '0'
		end
	) as diagnosischronicconditionindicator
,ifnull(t_visits.visitbegindatetime, t_visits.createdate) as diagnosisencounterdate
,t_visits.userguid as serviceproviderid
,t_patients.patientguid as patientid
,t_member.homecommunityguid as practiceid
,t_community.license as practicename
,'IC-EHR' as datasourcesystemid
,t_visits.visitguid as visitid
,t_visits_order.visitlaborderguid as orderid

from   ICEHR.t_visits_order_patient_diagnosis t_visits_order_patient_diagnosis
inner join   ICEHR.t_visits_order t_visits_order on t_visits_order.visitlaborderguid = t_visits_order_patient_diagnosis.visitlaborderguid 
inner join   ICEHR.t_visits  t_visits on t_visits.visitguid = t_visits_order.visitguid  
inner join   ICEHR.t_patients  t_patients on t_visits.patientguid = t_patients.patientguid 
inner join   ICEHR.t_patients_chronic_disorder  t_patients_chronic_disorder on t_patients_chronic_disorder.patientchronicdisorderguid = t_visits_order_patient_diagnosis.patientchronicdisorderguid  
inner join   ICEHR.t_diagnosis_icd t_diagnosis_icd on t_diagnosis_icd.diagnosisicdguid = t_patients_chronic_disorder.diagnosisicdguid  
inner join   ICEHR.t_member t_member on t_member.memberguid = t_patients.memberguid  
inner join ICEHR.t_community  t_community on t_member.homecommunityguid = t_community.communityguid  
)
select * from cte where  diagnosisentryisdeletedindicator = '0'
  );