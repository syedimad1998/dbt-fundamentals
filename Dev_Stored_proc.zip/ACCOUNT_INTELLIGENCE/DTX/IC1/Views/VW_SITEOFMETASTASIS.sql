create or replace view IC1_VIEW.VW_SITEOFMETASTASIS(
	STAGINGID,
	METASTATICNAME,
	PATIENTID,
	PRACTICEID,
	PRACTICENAME,
	DATASOURCESYSTEMID
) as (
    /*
******************************************** NOTES START ********************************************
Table: SiteOfMetastasis
Comments: 

t_Patients******************************************** NOTES END ********************************************
*/



select
	t_onc_patient_staging.patientstagingid as stagingid
	,t_onc_oncology_stage_lookup.title as metastaticname
	,t_patients.patientguid as patientid
	,t_member.homecommunityguid as practiceid
    ,t_community.license as practicename
	,'IC-EHR' as datasourcesystemid
from ICEHR.t_onc_oncology_stage_metastaticsites t_onc_oncology_stage_metastaticsites 
	inner join ICEHR.t_onc_patient_staging t_onc_patient_staging on( t_onc_patient_staging.patientstagingid = t_onc_oncology_stage_metastaticsites.patientstagingid) 
	inner join ICEHR.t_patients_chronic_disorder t_patients_chronic_disorder on (t_onc_patient_staging.patientchronicdisorderguid = t_patients_chronic_disorder.patientchronicdisorderguid) 
	inner join ICEHR.t_patients t_patients on t_patients.patientguid = t_patients_chronic_disorder.patientguid 
	inner join ICEHR.t_member t_member on (t_member.memberguid = t_patients.memberguid) 
	inner join ICEHR.t_onc_oncology_stage_lookup t_onc_oncology_stage_lookup  on (t_onc_oncology_stage_metastaticsites.metastaticlookupid = t_onc_oncology_stage_lookup.stagelookupid) 
    inner join ICEHR.t_community t_community on (t_community.communityguid = t_member.homecommunityguid ) 

  );