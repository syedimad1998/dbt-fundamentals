create or replace view IC1_VIEW.VW_BIOMARKER(
	BIOMARKERID,
	BIOMARKERRECORDMODIFIEDDATETIME,
	BIOMARKERDIAGNOSISCODE,
	BIOMARKERTESTRESULTSPOSTEDDATE,
	BIOMARKERTESTNAMEDESCRIPTION,
	BIOMARKERVALUEDESCRIPTION,
	PATIENTID,
	PRACTICEID,
	PRACTICENAME,
	DATASOURCESYSTEMID
) as (
    /*
******************************************** NOTES START ********************************************
Table: Biomarker
Comments: This query extracts data from It_patients_chronic_disorder, t_onc_Patient_Staging,
t_diagnosis_icd, t_diagnosis_icd, t_patients, t_member, t_onc_oncology_Stage_Parameter_Values,
t_onc_oncology_Stage_Parameters
******************************************** NOTES END ********************************************
*/



SELECT t_onc_oncology_stage_parameter_values.stageparametervalueid AS biomarkerid
	,t_onc_oncology_stage_parameter_values.modifiedddate AS biomarkerrecordmodifieddatetime
	,t_diagnosis_icd.code AS biomarkerdiagnosiscode
	,t_onc_oncology_stage_parameter_values.createddate AS biomarkertestresultsposteddate
	,t_onc_oncology_stage_parameters.fieldname AS biomarkertestnamedescription
	,t_onc_oncology_stage_parameter_values.fieldvalue AS biomarkervaluedescription
	,t_patients.patientguid AS patientid
	,t_member.homecommunityguid AS practiceid
    ,t_community.license as practicename
	,'IC-EHR' as datasourcesystemid

FROM ICEHR.t_onc_patient_staging t_onc_patient_staging
inner join ICEHR.t_patients_chronic_disorder t_patients_chronic_disorder ON (t_onc_patient_staging.patientchronicdisorderguid = t_patients_chronic_disorder.patientchronicdisorderguid) 
inner join ICEHR.t_diagnosis_icd t_diagnosis_icd ON (t_diagnosis_icd.diagnosisicdguid = t_patients_chronic_disorder.diagnosisicdguid) 
inner join ICEHR.t_patients t_patients ON (t_patients.patientguid = t_patients_chronic_disorder.patientguid) 
inner join ICEHR.t_member t_member ON (t_member.memberguid = t_patients.memberguid) 
inner join ICEHR.t_onc_oncology_stage_parameter_values t_onc_oncology_stage_parameter_values ON (t_onc_patient_staging.patientstagingid = t_onc_oncology_stage_parameter_values.patientstagingid)
inner join ICEHR.t_onc_oncology_stage_parameters t_onc_oncology_stage_parameters ON (t_onc_oncology_stage_parameter_values.stageparameterid = t_onc_oncology_stage_parameters.stageparameterid) 
inner join ICEHR.t_community t_community  ON (t_member.homecommunityguid = t_community.communityguid) 
WHERE t_onc_oncology_stage_parameters.ismarker = TRUE
and t_onc_oncology_stage_parameter_values.fieldvalue is not null
and t_onc_oncology_stage_parameter_values.fieldvalue <> ''
  );