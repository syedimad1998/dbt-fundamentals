create or replace view IC1_VIEW.VW_USER(
	USERID,
	USERPROFILECREATEDDATETIME,
	USERPROFILECREATEDBYUSERID,
	USERACTIVESTATUSINDICATOR,
	USERLASTNAME,
	USERMIDDLENAME,
	USERFIRSTNAME,
	USEREMRLOGINNAME,
	USEREMRDISPLAYNAME,
	USERNICKNAMETEXT,
	USERPREFIXNAME,
	USERSUFFIXNAME,
	USERGENDERDESCRIPTION,
	USERSOCIALSECURITYNUMBER,
	USERRACEDESCRIPTION,
	USERBIRTHDATE,
	USEREMAILADDRESS,
	PRACTICEID,
	PRACTICENAME,
	DATASOURCESYSTEMID
) as (
    

with cte as (


select  
	t_users.userguid as userid
	,t_users.createdate as UserProfileCreatedDatetime
	,t_users.createuserguid as UserProfileCreatedByUserId
	,(case when t_member.active = TRUE then 'active' else 'inactive' end) as UserActiveStatusIndicator
	,t_member.lastname as userlastname
	,t_member.middlename as usermiddlename
	,t_member.firstname as userfirstname
	,t_member.loginname as useremrloginname
	,CONCAT(t_member.firstname, ' ' , t_member.MiddleName, ' ', t_member.lastname) as useremrdisplayname
	,t_member.nickname as UserNicknameText
	,t_member.prefix as UserPrefixName
	,t_member.suffix as UserSuffixName
	,t_member.sex as usergenderdescription
	,t_member.ssn as usersocialsecuritynumber
	,t_member.race as userracedescription
	,t_member.dateofbirth as UserBirthDate
	,t_member.email as useremailaddress
	,t_member.homecommunityguid as practiceid
	,t_community.license as practicename
	,'IC-EHR' as datasourcesystemid
from  ICEHR.t_users t_users
inner join  ICEHR.t_member t_member on (t_users.memberguid = t_member.memberguid) 
inner join ICEHR.t_community t_community on t_community.communityguid = t_member.homecommunityguid 

)
select * from cte where
UserActiveStatusIndicator = 'active'
  );