create or replace view IC1_VIEW.VW_PAYER(
	PAYERID,
	INSURANCEID,
	PAYERRECORDCREATEDDATETIME,
	INSUARNCEADDRESSID,
	PATIENTPAYERADDRESSID,
	PAYERRECORDDELETEDINDICATOR,
	PAYERMEMBERID,
	PAYERCLEARINGHOUSEID,
	PAYERCATEGORYNAME,
	PAYERTYPENAME,
	PAYERNAME,
	PAYERMEDICAIDINDICATOR,
	PAYERMEDICAIDPATIENTENROLLMENTDATE,
	PAYERPATIENTPOLICYNUMBER,
	PAYERCLASSGROUPDESCRIPTION,
	PAYERELECTRONICENABLEDINDICATOR,
	PAYERCODESETREQUIREMENTINDICATOR,
	PAYERRECORDACTIVEINDICATOR,
	PAYERELIGIBILITYVERIFICATIONDAYSNUMBER,
	PAYERPATIENTINSURANCEPLANEFFECTIVEDATE,
	PAYERPATIENTINSURANCEPLANEXPIRATIONDATE,
	PATIENTASSIGNEDPAYERGROUPIDNUMBER,
	SUBSCRIBERMEMBERNUMBER,
	PAYERGROUPNAME,
	PAYERMEMBERPERSONCODE,
	PAYERPATIENTBENEFITSASSIGNEDINDICATOR,
	PAYERPATIENTRESPONSIBLEINSURANCEPERCENTAGEVALUE,
	PAYEREMPLOYMENTSTATUSCODE,
	PRACTICEID,
	PRACTICENAME,
	PATIENTID,
	DATASOURCESYSTEMID
) as (
    /*
******************************************** NOTES START ********************************************
Table: Payer
Comments: Payer data needs to be retrieved from t_patients, t_members, t_Patients_payer, t_community_payer,
t_patients_additional_data, t_onc_chemoadmin_PatientRegimenPriorAuthExpiration

******************************************** NOTES END ********************************************
*/



with cte as (

select t_community_payer.communitypayerguid as payerid
	,t_patients_payer.patientpayerguid as insuranceid
	,t_community_payer.createdate as payerrecordcreateddatetime
	,t_community_payer.addressguid as insuarnceaddressid
	,t_address.addressguid as patientpayeraddressid
	,not t_patients_payer.active as payerrecorddeletedindicator
	,t_patients.memberguid as payermemberid
	,t_community_payer.payerclearinghousepayerguid as payerclearinghouseid
	,t_community_payer.class as payercategoryname
	,t_community_payer.defaultinsurancetype as payertypename
	,t_community_payer.shortname as payername
	,t_patients_additional_data.medicaid as payermedicaidindicator
	,t_patients_additional_data.medicaiddate as payermedicaidpatientenrollmentdate
	,t_patients_payer.policynumber as payerpatientpolicynumber
	,t_patients_payer.insurancetype as payerclassgroupdescription
	,t_community_payer.electronicpayerenabled as payerelectronicenabledindicator
	,t_community_payer.codeset as payercodesetrequirementindicator
	,(case when  t_community_payer.active = TRUE and t_patients_payer.active =TRUE then 1 else 0 end) as payerrecordactiveindicator
	,t_community_payer.eligibilityservicetype as payereligibilityverificationdaysnumber
	,t_patients_payer.coveragestartdate as payerpatientinsuranceplaneffectivedate
	,t_patients_payer.coverageenddate as payerpatientinsuranceplanexpirationdate
	,t_patients_payer.groupnumber as patientassignedpayergroupidnumber
	,t_patients_payer.subscribermemberid as subscribermembernumber
	,t_patients_payer.groupname as payergroupname
	,t_patients_payer.relationship as payermemberpersoncode
	,t_patients_payer.assignbenefits as payerpatientbenefitsassignedindicator
	,t_patients_payer.copay as payerpatientresponsibleinsurancepercentagevalue
	,t_patients_additional_data.employmentstatus as payeremploymentstatuscode
	,t_member.homecommunityguid as practiceid
	,t_community.license as practicename
	,t_patients.patientguid as patientid
	,'IC-EHR' as datasourcesystemid
from ICEHR.t_patients_payer
inner join  ICEHR.t_patients on (t_patients.patientguid = t_patients_payer.patientguid) 
inner join ICEHR.t_member on (t_patients.memberguid = t_member.memberguid) 
inner join ICEHR.t_community_payer on (t_patients_payer.communitypayerguid = t_community_payer.communitypayerguid) 
left outer join ICEHR.t_patients_additional_data on (t_patients.patientguid = t_patients_additional_data.patientguid) 
inner join ICEHR.t_community t_community on (t_community.communityguid = t_member.homecommunityguid) 
left outer join ICEHR.t_address on (t_patients_payer.patientpayerguid = t_address.foreignkeyguid) 

)
select * from cte where payerrecorddeletedindicator = FALSE
  );