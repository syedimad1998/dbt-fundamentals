create or replace view IC1_VIEW.VW_DIRECTIVE(
	DIRECTIVEID,
	DIRECTIVEINDICATOR,
	DIRECTIVEDNRINSTRUCTIONSTOPATIENTINDICATOR,
	DIRECTIVEPRACTICERECEIVEDLIVINGWILLINDICATOR,
	DIRECTIVEPRACTICERECEIVEDDPOAINDICATOR,
	DIRECTIVEDETAILREVIEWEDDATE,
	PATIENTID,
	PRACTICEID,
	PRACTICENAME,
	DATASOURCESYSTEMID
) as (
    /*
******************************************** NOTES START ********************************************
Table: Directive
Comments: Main extract from t_patients_additional_data. The Practice ID retrieved by joining it to
t_patients and t_members.



The PatientGUID is used for the DirectiveID as well as the PatientID

******************************************** NOTES END ********************************************
*/



select t_patients_additional_data.patientguid as directiveid
,case 
	when t_patients_additional_data.advanceddirectivesinfogiven is not null
		then 'yes'
	else 'no'
	end as directiveindicator
,case 
	when  t_patients_additional_data.receiveddnr is not null
		then 'yes'
	else 'no'
	end as directivednrinstructionstopatientindicator
,case 
	when  t_patients_additional_data.receivedlivingwill is not null
		then 'yes'
	else 'no'
	end as directivepracticereceivedlivingwillindicator
,case 
	when t_patients_additional_data.receiveddurablepowerofattorney is not null
	then 'yes'
	else 'no'
end as directivepracticereceiveddpoaindicator
,t_patients_additional_data.advanceddirectivesrevieweddate as directivedetailrevieweddate
,t_patients_additional_data.patientguid as patientid
,t_member.homecommunityguid as practiceid
,t_community.license as practicename
,'IC-EHR' as datasourcesystemid

from ICEHR.t_patients_additional_data
inner join ICEHR.t_patients on (t_patients_additional_data.patientguid = t_patients.patientguid) 
inner join ICEHR.t_member on (t_patients.memberguid = t_member.memberguid) 
inner join ICEHR.t_community on (t_community.communityguid = t_member.homecommunityguid) 
where ((
(t_patients_additional_data.advanceddirectivesinfogiven <> '')
and (t_patients_additional_data.advanceddirectivesinfogiven is not null)
)
or (
t_patients_additional_data.receiveddnr is not null
)
or (
t_patients_additional_data.receivedlivingwill is not null
)
or (
t_patients_additional_data.receiveddurablepowerofattorney is not null
))
  );