create or replace view IC1_VIEW.VW_LAB(
	LABTESTID,
	LABTESTNAME,
	ORDERID,
	LABSPECIMENCOLLECTIONDATETIME,
	LABRESULTSTATUSDESCRIPTION,
	LABRESULTENTEREDDATE,
	LABABNORMALRESULTINDICATOR,
	LABRESULTVALUE,
	LABRESULTUNITOFMEASURE,
	LABRANGEVALUE,
	LABFACILITYID,
	ORDERINGPROVIDERID,
	LABSIGNOFFDATE,
	LABDETAILDELETEDATE,
	LABDETAILDELETEDBYUSERID,
	PATIENTID,
	PRACTICEID,
	PRACTICENAME,
	DATASOURCESYSTEMID,
	FACILITYID,
	ISMANUALINDICATORFROM
) as (
    /*
******************************************** NOTES START ********************************************
Table: Lab
Comments: Read Lab Results
******************************************** NOTES END ********************************************
*/



with cte as (

select
     t_visits_order_results.visitcptorderresultguid as labtestid
    ,t_visits_order_results.testname  as labtestname
    ,t_visits_order.visitlaborderguid as orderid
    ,t_visits_order_results.collectiondatetime as labspecimencollectiondatetime
    ,(case when t_visits_order_results.deletedate is null then '1' else '0' end) as labresultstatusdescription
    ,t_visits_order_results.resultdate as labresultentereddate
    ,t_visits_order_results.abnormalflag as lababnormalresultindicator
    ,t_visits_order_results.testresult as labresultvalue
    ,t_visits_order_results.testunit as labresultunitofmeasure
    ,t_visits_order_results.range as labrangevalue
    ,t_visits.facilityguid as labfacilityid
    ,t_visits_order.provideruserguid as orderingproviderid
    ,t_visits_order_results.signoffdatetime as labsignoffdate
    ,t_visits_order_results.deletedate as labdetaildeletedate
    ,t_visits_order_results.deleteuserguid as labdetaildeletedbyuserid
    ,t_visits.patientguid as patientid
    ,t_member.homecommunityguid as practiceid
    ,t_community.license as practicename
    ,'IC-EHR' as datasourcesystemid
    ,t_visits.facilityguid as facilityid
    ,t_visits_order_results.ismanualresult as ismanualindicatorfrom 

from ICEHR.t_visits_order_results
inner join ICEHR.t_visits_order on (t_visits_order_results.visitlaborderguid = t_visits_order.visitlaborderguid ) 
inner join ICEHR.t_visits on (t_visits_order.visitguid = t_visits.visitguid) 
inner join ICEHR.t_patients on (t_patients.patientguid = t_visits.patientguid ) 
inner join ICEHR.t_member on (t_member.memberguid = t_patients.memberguid) 
inner join ICEHR.t_facility_billing_item on( t_facility_billing_item.facilitybillingitemguid = t_visits_order.facilitybillingitemguid) 
inner join ICEHR.t_facility_billing on (t_facility_billing.facilitybillingguid = t_facility_billing_item.facilitybillingguid) 
inner join ICEHR.t_community t_community on t_member.homecommunityguid = t_community.communityguid 

union all

select 
    t_visits_order_results.visitcptorderresultguid as labtestid
    ,t_visits_order_results.testname  as labtestname
    ,null as orderid
    ,t_visits_order_results.collectiondatetime as labspecimencollectiondatetime
    ,(case when t_visits_order_results.deletedate is null then '1' else '0' end) as labresultstatusdescription
    ,t_visits_order_results.resultdate as labresultentereddate
    ,t_visits_order_results.abnormalflag as lababnormalresultindicator
    ,t_visits_order_results.testresult as labresultvalue
    ,t_visits_order_results.testunit as labresultunitofmeasure
    ,t_visits_order_results.range as labrangevalue
    ,null as labfacilityid
    ,null as orderingproviderid
    ,t_visits_order_results.signoffdatetime as labsignoffdate
    ,t_visits_order_results.deletedate as labdetaildeletedate
    ,t_visits_order_results.deleteuserguid as labdetaildeletedbyuserid
    ,t_visits_order_results.patientguid as patientid
    ,t_member.homecommunityguid as practiceid
    ,t_community.license as practicename
    ,'IC-EHR' as datasourcesystemid
    ,null as facilityid
    ,t_visits_order_results.ismanualresult as ismanualindicator

from ICEHR.t_visits_order_results t_visits_order_results
inner join ICEHR.t_patients t_patients on (t_patients.patientguid = t_visits_order_results.patientguid) 
inner join ICEHR.t_member t_member on (t_member.memberguid = t_patients.memberguid )
inner join ICEHR.t_community t_community on t_member.homecommunityguid = t_community.communityguid 
where (t_visits_order_results.visitlaborderguid is null) 
)
select * from cte where labresultstatusdescription = '1'
  );