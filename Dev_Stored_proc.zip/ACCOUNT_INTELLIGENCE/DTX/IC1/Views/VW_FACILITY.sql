create or replace view IC1_VIEW.VW_FACILITY(
	FACILITYID,
	FACILITYRECORDCREATEDDATETIME,
	FACILITYRECORDCREATEDBYUSERID,
	FACILITYNAME,
	FACILITYNPINUMBER,
	FACILITYPRIMARYCONTACTNAME,
	DATASOURCESYSTEMID,
	PRACTICEID,
	PRACTICENAME,
	FACILITYPROFILEDELETEDINDICATOR
) as (
    /* 
********************************************  NOTES START  ********************************************
Table: Facility
Comments: To read Facility master data


********************************************  NOTES END    ********************************************
*/



with cte as (


select 
   	 t_facility.facilityguid as facilityid
   	,t_facility.createdate as facilityrecordcreateddatetime
	,t_facility.createuserguid as facilityrecordcreatedbyuserid
	,t_facility.name as facilityname
	,t_facility.npi as facilitynpinumber
	,t_facility.primarycontact as facilityprimarycontactname
	,'IC-EHR' as datasourcesystemid
	,t_facility.communityguid as practiceid
	,t_community.license as practicename
	,(case when t_facility.active = TRUE then 0 else 1 end) as facilityprofiledeletedindicator
	
from ICEHR.t_facility t_facility
inner join ICEHR.t_community t_community on (t_facility.communityguid = t_community.communityguid)  

)
select * from cte where facilityprofiledeletedindicator = FALSE
  );