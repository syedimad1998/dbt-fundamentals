create or replace view IC1_VIEW.VW_STAGING(
	STAGINGID,
	STAGINGRECORDCREATEDDATETIME,
	STAGINGRECORDCREATEDBYUSERID,
	STAGINGRECORDMODIFIEDDATETIME,
	STAGINGRECORDMODIFIEDBYUSERID,
	STAGINGPATIENTCHRONICDISORDERID,
	DIAGNOSISID,
	STAGINGSYSTEMNAME,
	STAGINGANATOMICCANCERSITEDESCRIPTION,
	STAGINGANATOMICCANCERSITELATERALITYDESCRIPTION,
	STAGINGDIAGNOSISDATE,
	STAGINGBROADCATEGORYOFDISEASEDESCRIPTION,
	STAGINGCLINICALDATE,
	STAGINGPATHOLOGICDATE,
	STAGINGDATE,
	STAGETYPEDESCRIPTION,
	STAGINGCANCERGRADEVALUE,
	STAGINGCANCERGRADEDESCRIPTION,
	STAGEGROUPSTATUSVALUE,
	STAGINGTNMGELEMENTSVALUE,
	STAGINGHISTOLOGYVALUE,
	STAGINGTVALUE,
	STAGINGNVALUE,
	STAGINGMVALUE,
	STAGINGRELAPSEDATE,
	STAGINGRELAPSEINDICATOR,
	PATIENTID,
	PRACTICEID,
	PRACTICENAME,
	DATASOURCESYSTEMID
) as (
    /*
******************************************** NOTES START ********************************************
Table: Staging
Comments: Messy table - gets data from the following tables:
t_onc_Patient_Staging
t_patients_chronic_disorder
t_diagnosis_icd
t_onc_oncology_CancerSiteDxCode
t_onc_oncology_CancerSite
t_onc_oncology_StageGroup
t_onc_oncology_Stage_Lookup
t_onc_oncology_Stage_Lookup
t_onc_oncology_Stage_Lookup
t_onc_oncology_Stage_Lookup
t_onc_oncology_Stage_Lookup
t_onc_oncology_Stage_Lookup
t_member
t_Patients******************************************** NOTES END ********************************************
*/



select  t_onc_patient_staging.patientstagingid as stagingid
	,t_onc_patient_staging.createddate as stagingrecordcreateddatetime
	,t_onc_patient_staging.createdby as stagingrecordcreatedbyuserid
	,t_onc_patient_staging.modifiedddate as stagingrecordmodifieddatetime
	,t_onc_patient_staging.modifiedby as stagingrecordmodifiedbyuserid
	,t_onc_patient_staging.patientchronicdisorderguid as stagingpatientchronicdisorderid
	,t_patients_chronic_disorder.patientchronicdisorderguid as diagnosisid
	,ifnull(t_onc_patient_staging.stagesource, 'ajcc, 7th edition') as stagingsystemname
	,t_onc_oncology_cancersite.name as staginganatomiccancersitedescription
	,lat_lu.description as staginganatomiccancersitelateralitydescription
	,t_patients_chronic_disorder.diagnosisdate as stagingdiagnosisdate
	,t_onc_oncology_cancersite.name as stagingbroadcategoryofdiseasedescription
	,case 
		when t_onc_patient_staging.stagingtype = 'Clinical'
			then t_patients_chronic_disorder.diagnosisdate
		end as stagingclinicaldate
	,case 
		when t_onc_patient_staging.stagingtype = 'Pathologic'
			then t_patients_chronic_disorder.diagnosisdate
		end as stagingpathologicdate
	,t_onc_patient_staging.dateofdiagnosis as stagingdate
	,t_onc_patient_staging.stagingtype as stagetypedescription
	,g_lu.title as stagingcancergradevalue
	,g_lu.description as stagingcancergradedescription
	,t_onc_oncology_stagegroup.title as stagegroupstatusvalue
	,concat(ifnull (t_lu.title,'') , ifnull(n_lu.title,'') , ifnull(m_lu.title,'') , ifnull(g_lu.title,'')) as stagingtnmgelementsvalue
	,his_lu.title as staginghistologyvalue
	,t_lu.title as stagingtvalue
	,n_lu.title as stagingnvalue
	,m_lu.title as stagingmvalue
	,t_onc_patient_staging.relapsedate as stagingrelapsedate
	,t_onc_patient_staging.relapse as stagingrelapseindicator
	,t_patients_chronic_disorder.patientguid as patientid
	,t_member.homecommunityguid as practiceid
	,t_community.license as practicename
	,'IC-EHR' as datasourcesystemid

from ICEHR.t_onc_patient_staging
inner join ICEHR.t_patients_chronic_disorder on (t_onc_patient_staging.patientchronicdisorderguid = t_patients_chronic_disorder.patientchronicdisorderguid) 
inner join ICEHR.t_diagnosis_icd on (t_diagnosis_icd.diagnosisicdguid = t_patients_chronic_disorder.diagnosisicdguid) 
inner join ICEHR.t_onc_oncology_cancersitedxcode on (t_onc_oncology_cancersitedxcode.icdcodeid = t_diagnosis_icd.id)  
and (t_onc_oncology_cancersitedxcode.enabled = TRUE)
and (t_onc_oncology_cancersitedxcode.stage_source = ifnull(t_onc_patient_staging.stagesource, 'ajcc, 7th edition') )
and (t_onc_oncology_CancerSiteDxCode.CancerSiteId = t_onc_Patient_Staging.cancerSiteID)
inner join ICEHR.t_onc_oncology_cancersite on( t_onc_oncology_cancersitedxcode.cancersiteid = t_onc_oncology_cancersite.id)
inner join ICEHR.t_patients on (t_patients.patientguid = t_patients_chronic_disorder.patientguid) 
inner join ICEHR.t_member on (t_member.memberguid = t_patients.memberguid)  
inner join ICEHR.t_community t_community on (t_community.communityguid = t_member.homecommunityguid) 
left outer join ICEHR.t_onc_oncology_stagegroup on (t_onc_oncology_stagegroup.id = t_onc_patient_staging.stagegroupid)  
left outer join ICEHR.t_onc_oncology_stage_lookup t_lu on (t_onc_patient_staging.t_primary_tumor = t_lu.stagelookupid)  
left outer join ICEHR.t_onc_oncology_stage_lookup n_lu on (t_onc_patient_staging.n_lumph_nodes = n_lu.stagelookupid)  
left outer join ICEHR.t_onc_oncology_stage_lookup m_lu on (t_onc_patient_staging.m_distant_metastasis = m_lu.stagelookupid)  
left outer join ICEHR.t_onc_oncology_stage_lookup g_lu on (t_onc_patient_staging.g_grade = g_lu.stagelookupid)  
left outer join ICEHR.t_onc_oncology_stage_lookup his_lu on (t_onc_patient_staging.histopathologyid = his_lu.stagelookupid)  
left outer join ICEHR.t_onc_oncology_stage_lookup lat_lu on (t_onc_patient_staging.lateralityid = lat_lu.stagelookupid) 

order by t_patients_chronic_disorder.patientguid
	,t_onc_oncology_cancersite.name
	,t_onc_patient_staging.createddate
  );