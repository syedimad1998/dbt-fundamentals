create or replace view IC1_VIEW.VW_ORDER(
	ORDERID,
	LABORDERID,
	ORDERDATESELECTEDINDICATOR,
	ORDERRECORDDELETEDINDICATOR,
	ORDERRECORDDELETEDDATETIME,
	ORDERABNREQUIREDINDICATOR,
	ORDERDETAILENCOUNTERDATE,
	ORDERLOINCCODE,
	ORDERTYPEDESCRIPTION,
	ORDERDESCRIPTION,
	ORDERLABTESTNAME,
	ORDERDATE,
	ORDERSIGNEDDATE,
	ORDERNOTETEXT,
	ORDERINGPROVIDERID,
	APPROVINGPROVIDERID,
	FACILITYID,
	PATIENTID,
	PRACTICEID,
	PRACTICENAME,
	DATASOURCESYSTEMID,
	VISITID
) as (
    /* 
********************************************  NOTES START  ********************************************
Table: Order
Comments: Read orders


********************************************  NOTES END    ********************************************
*/


with cte as (

select
 	t_visits_order.visitlaborderguid as orderid
	,(
		case 
			when t_visits_order.orderexternalid is not null
				or t_facility_billing_item.laborderguid is not null
				then t_visits_order.visitlaborderguid
			else null
			end
		) as laborderid
	,'1' as orderdateselectedindicator
	,(
		case 
			when t_visits_order.deletedate is not null
				then '1'
			else '0'
			end
		) as orderrecorddeletedindicator
	,t_visits_order.deletedate as orderrecorddeleteddatetime
	,t_visits_order.abnrequired as orderabnrequiredindicator
	,t_visits.createdate as orderdetailencounterdate
	,t_visits_order.loinc as orderloinccode
	,t_facility_billing.description as ordertypedescription
	,t_facility_billing_item.description as orderdescription
	,t_lab_order.batteryname as orderlabtestname
	,t_visits_order.orderdate as orderdate
	,(
		case when cds.verbalorderby is not null
		then IFNULL(cds.MDApprovalDate, cds.PharmacyApprovalDate)
		when t_visits_order.isdefaultsigned is not null and t_visits_order.isdefaultsigned = TRUE
		then t_visits_order.CreateDate
		else null
		end
	) as ordersigneddate
	,t_visits_order.comments as ordernotetext
	,t_visits_order.provideruserguid as orderingproviderid
	,(case
		when cds.verbalorderby is not null 
			then usrop.userguid
		when t_visits_order.isdefaultsigned is not null and t_visits_order.isdefaultsigned = TRUE
			then t_visits_order.orderuserguid
		else null
		end
) as approvingproviderid
	,t_visits.facilityguid as facilityid
	,t_visits.patientguid as patientid
	,t_member.homecommunityguid as practiceid
	,t_community.license as practicename
	,'IC-EHR' as datasourcesystemid
	,t_visits.visitguid as visitid

from  ICEHR.t_visits_order t_visits_order
inner join   ICEHR.t_visits on (t_visits_order.visitguid = t_visits.visitguid) 
inner join ICEHR.t_patients t_patients on (t_patients.patientguid = t_visits.patientguid) 
inner join ICEHR.t_member  t_member on (t_member.memberguid = t_patients.memberguid) 
inner join ICEHR.t_facility_billing_item t_facility_billing_item on (t_facility_billing_item.facilitybillingitemguid = t_visits_order.facilitybillingitemguid) 
left outer join ICEHR.t_lab_order  t_lab_order on (t_lab_order.laborderguid = t_facility_billing_item.laborderguid) 
inner join ICEHR.t_facility_billing  t_facility_billing on (t_facility_billing.facilitybillingguid = t_facility_billing_item.facilitybillingguid)
inner join ICEHR.t_community t_community  on (t_member.homecommunityguid = t_community.communityguid) 
left join ICEHR.t_onc_chemoadmin_patientchemoregimencycledayservice cds on t_visits_order.visitlaborderguid = cds.visitlaborderguid
left join ICEHR.t_member morderprovider on morderprovider.id= cds.verbalorderby
left join ICEHR.t_users usrop on t_visits_order.orderuserguid = usrop.userguid and ifnull(t_visits_order.isdefaultsigned,FALSE)=TRUE

)
select * from cte where OrderRecordDeletedIndicator = '0'
  );