create or replace view IC1_VIEW.VW_FLOWSHEET(
	PATIENTID,
	FLOWSHEETFIELD,
	FLOWSHEETCATEGORY,
	FLOWSHEETDATE,
	FLOWSHEETVALUE,
	DATASOURCESYSTEMID,
	PRACTICEID,
	PRACTICENAME
) as (
    /*
******************************************** NOTES START ********************************************
Table: FlowSheet
Comments: 
******************************************** NOTES END ********************************************
*/



select
	t_patient_flowsheet.PatientGuid as PatientID
	, t_patient_flowsheet.Field as flowsheetfield
	, t_patient_flowsheet.Category as flowsheetcategory
	, t_patient_flowsheet.Date as flowsheetdate
	, t_patient_flowsheet.Value as flowsheetvalue
	, 'IC-EHR' as datasourcesystemid
	, t_member.homecommunityguid as practiceid
	, t_community.license as practicename
from ICEHR.t_patient_flowsheet t_patient_flowsheet
inner join ICEHR.t_patients t_patients on t_patients.patientguid = t_patient_flowsheet.patientguid 
inner join ICEHR.t_member t_member on t_member.memberguid = t_patients.memberguid 
inner join ICEHR.t_community t_community on t_member.homecommunityguid = t_community.communityguid 
where  t_patient_flowsheet.Field IN ('PerineuralInvasion'
, 'BCG'
, 'BCGInterferon'
, 'Comment'
, 'AUAScore'
, 'Cores'
, 'PathStage'
, 'GleasonScore'
, 'PSAFree'
, 'Fish'
, 'PSALevel'
, 'PrCaTx'
, 'Meds'
, 'PercentageFree'
, 'Continence'
, 'BxPath'
, 'PHI'
, 'TumorSite'
, 'PotencySHIM'
, 'LHRH'
, 'Dexa'
, 'Imaging'
, 'Mitomycin'
, 'Cytol'
, 'TURPath'
, 'ClinicalStage'
, 'Biopsy'
, 'Margins'
, 'Valstar'
, 'NumberOfTumors'
, 'ProstateVolume'
, 'Cysto'
, 'RenalImaging')
  );