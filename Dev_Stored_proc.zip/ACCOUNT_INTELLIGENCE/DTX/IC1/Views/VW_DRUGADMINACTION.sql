create or replace view IC1_VIEW.VW_DRUGADMINACTION(
	DRUGADMINID,
	ACTIONSTARTTIME,
	ACTIONENDTIME,
	PATIENTID,
	PRACTICEID,
	PRACTICENAME,
	DATASOURCESYSTEMID
) as (
    /*
******************************************** NOTES START ********************************************
Table:DrugAdminAction
Comments: 

******************************************** NOTES END ********************************************
*/



select t_onc_chemoadmin_patientchemoregimencycledayagent_infusionaction.patientchemoregimencycledayagentid as drugadminid
,(case when t_onc_chemoadmin_patientchemoregimencycledayagent_infusionaction.action = 0 then  t_onc_chemoadmin_patientchemoregimencycledayagent_infusionaction.mardate else null end) as actionstarttime
,(case when t_onc_chemoadmin_patientchemoregimencycledayagent_infusionaction.action = 1 then  t_onc_chemoadmin_patientchemoregimencycledayagent_infusionaction.mardate else null end) as actionendtime
,ifnull(p1.patientguid, p2.patientguid) as patientid
,ifnull(m1.homecommunityguid, m2.homecommunityguid) as practiceid
,t_community.license as practicename
,'IC-EHR' as datasourcesystemid

FROM ICEHR.t_onc_chemoadmin_PatientChemoRegimenCycleDayAgent_InfusionAction t_onc_chemoadmin_PatientChemoRegimenCycleDayAgent_InfusionAction
Inner Join ICEHR.t_onc_chemoadmin_PatientChemoRegimenCycleDayAgent t_onc_chemoadmin_PatientChemoRegimenCycleDayAgent ON (t_onc_chemoadmin_PatientChemoRegimenCycleDayAgent.Id = t_onc_chemoadmin_PatientChemoRegimenCycleDayAgent_InfusionAction.PatientChemoRegimenCycleDayAgentId) 
Left Outer JOIN ICEHR.t_onc_chemoadmin_PatientChemoRegimen t_onc_chemoadmin_PatientChemoRegimen ON (t_onc_chemoadmin_PatientChemoRegimenCycleDayAgent.PatientChemoRegimenId = t_onc_chemoadmin_PatientChemoRegimen.Id) 
Left Outer JOIN ICEHR.t_patients p1 ON (p1.Id = t_onc_chemoadmin_PatientChemoRegimen.PatientId) 
Left Outer JOIN ICEHR.t_member m1 ON (m1.MemberGuid = p1.MemberGuid) 
Left Outer Join  ICEHR.t_patients p2 ON (p2.Id = t_onc_chemoadmin_PatientChemoRegimenCycleDayAgent.PatientId) 
Left Outer Join ICEHR.t_member m2 ON (m2.MemberGuid = p2.MemberGuid) 
inner join ICEHR.t_community t_community on ((t_community.communityguid = m1.homecommunityguid) OR (t_community.communityguid = m2.homecommunityguid)) 
  );