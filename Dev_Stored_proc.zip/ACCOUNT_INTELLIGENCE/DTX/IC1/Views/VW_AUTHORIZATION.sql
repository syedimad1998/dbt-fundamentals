create or replace view IC1_VIEW.VW_AUTHORIZATION(
	AUTHORIZATIONID,
	AUTHORIZATIONRECORDMODIFIEDDATETIME,
	PAYERID,
	AUTHORIZATIONRECORDCREATEDDATETIME,
	AUTHORIZATIONRECORDDELETEDINDICATOR,
	AUTHORIZATIONAPPROVEDDATETIME,
	AUTHORIZATIONAPPROVEDBYUSERID,
	AUTHORIZATIONSTATUSDESCRIPTION,
	AUTHORIZATIONNUMBER,
	AUTHORIZATIONEFFECTIVEDATE,
	AUTHORIZATIONEXPIRATIONDATE,
	AUTHORIZATIONAPPROVEDTREATMENTDESCRIPTION,
	AUTHORIZATIONAPPROVEDVISITCOUNT,
	AUTHORIZATIONFORINDIVIDUALCHEMOAGENTINDICATOR,
	AUTHORIZATIONCOINSURANCEAMOUNT,
	AUTHORIZATIONPATIENTCOPAYCOMMITMENTAMOUNT,
	AUTHORIZATIONPATIENTDEDUCTIBLEAMOUNT,
	AUTHORIZATIONPAYERCONTACTPERSONNAME,
	AUTHORIZATIONCOMMENTSREGARDINGINSURANCEDESCRIPTION,
	AUTHORIZATIONFORPATIENTCHEMOTHERAPYAGENTID,
	AUTHORIZATIONFORCHEMOTHERAPYREGIMENID,
	PATIENTID,
	PRACTICEID,
	PRACTICENAME,
	DATASOURCESYSTEMID
) as (
    /*
******************************************** notes start ********************************************
table: authorizations
comments: the authorizations table requires the following tables:
t_onc_chemoadmin_patientregimenpriorauthexpiration
t_onc_chemoadmin_patientchemoregimen
t_onc_chemoadmin_patientchemoregimencycledayagent
t_community
t_patients
t_member
t_facility******************************************** notes end ********************************************
*/



with cte as (
--** this query extracts the authorizations for the chemotherapy
select t_onc_chemoadmin_patientregimenpriorauthexpiration.id as authorizationid 
	, t_onc_chemoadmin_patientregimenpriorauthexpiration.adt_lastmodifieddate as authorizationrecordmodifieddatetime 
	, t_onc_chemoadmin_patientregimenpriorauthexpiration.patientpayerguid as payerid 
	, t_onc_chemoadmin_patientregimenpriorauthexpiration.adt_createddate as authorizationrecordcreateddatetime 
	, t_onc_chemoadmin_patientregimenpriorauthexpiration.isdeleted as authorizationrecorddeletedindicator 
	, t_onc_chemoadmin_patientregimenpriorauthexpiration.approveddate as authorizationapproveddatetime
	, t_users.userguid as authorizationapprovedbyuserid 
	, t_onc_chemoadmin_patientregimenpriorauthexpiration.status as authorizationstatusdescription 
	, t_onc_chemoadmin_patientregimenpriorauthexpiration.authorizationnumber 
	, t_onc_chemoadmin_patientregimenpriorauthexpiration.effectivedate as authorizationeffectivedate 
	, t_onc_chemoadmin_patientregimenpriorauthexpiration.expirationdate as authorizationexpirationdate 
	, t_onc_chemoadmin_patientregimenpriorauthexpiration.title as authorizationapprovedtreatmentdescription 
	, t_onc_chemoadmin_patientregimenpriorauthexpiration.numberofvisits as authorizationapprovedvisitcount 
	, t_onc_chemoadmin_patientregimenpriorauthexpiration.allregimenagentsauthorized as authorizationforindividualchemoagentindicator 
	, t_onc_chemoadmin_patientregimenpriorauthexpiration.coinsurance as authorizationcoinsuranceamount 
	, t_onc_chemoadmin_patientregimenpriorauthexpiration.copay as authorizationpatientcopaycommitmentamount
	, t_onc_chemoadmin_patientregimenpriorauthexpiration.deductible as authorizationpatientdeductibleamount
	, t_onc_chemoadmin_patientregimenpriorauthexpiration.contactperson as authorizationpayercontactpersonname 
	, t_onc_chemoadmin_patientregimenpriorauthexpiration.notes as authorizationcommentsregardinginsurancedescription 
	, t_onc_chemoadmin_patientregimenpriorauthexpiration.patientchemodayagentid as authorizationforpatientchemotherapyagentid 
	, t_onc_chemoadmin_patientregimenpriorauthexpiration.patientchemoregimenid as authorizationforchemotherapyregimenid 
	, t_patients.patientguid as patientid 
	, t_community.communityguid as practiceid 
    ,t_community.license as practicename 
	,'IC-EHR' as datasourcesystemid 

from ICEHR.t_onc_chemoadmin_patientregimenpriorauthexpiration
inner join ICEHR.t_onc_chemoadmin_patientchemoregimen on ( t_onc_chemoadmin_patientregimenpriorauthexpiration.patientchemoregimenid =  t_onc_chemoadmin_patientchemoregimen.id) 
inner join ICEHR.t_community on  (t_community.id =  t_onc_chemoadmin_patientchemoregimen.practiceid) 
inner join ICEHR.t_patients on  (t_patients.id =  t_onc_chemoadmin_patientchemoregimen.patientid) 
inner join ICEHR.t_member on ( t_patients.memberguid =  t_member.memberguid) 
left outer join ICEHR.t_member m on( m.memberguid = t_onc_chemoadmin_patientregimenpriorauthexpiration.approvedby) 
left outer join ICEHR.t_users on (t_users.memberguid = m.memberguid) 

union all

--** this query extracts the authorizations for the individual drugs of regimen
		--  at this point there are no records for regiment agent authorization.
select  t_onc_chemoadmin_patientregimenpriorauthexpiration.id as authorizationid
	, t_onc_chemoadmin_patientregimenpriorauthexpiration.adt_lastmodifieddate as authorizationrecordmodifieddatetime
	, t_onc_chemoadmin_patientregimenpriorauthexpiration.patientpayerguid as payerid
	, t_onc_chemoadmin_patientregimenpriorauthexpiration.adt_createddate as authorizationrecordcreateddatetime
	,case 
		when  t_onc_chemoadmin_patientregimenpriorauthexpiration.isdeleted = TRUE
			then TRUE
		else FALSE
		end as authorizationrecorddeletedindicator
	, t_onc_chemoadmin_patientregimenpriorauthexpiration.approveddate as authorizationapproveddatetime
	, t_users.userguid as authorizationapprovedbyuserid
	, t_onc_chemoadmin_patientregimenpriorauthexpiration.status as authorizationstatusdescription
	, t_onc_chemoadmin_patientregimenpriorauthexpiration.authorizationnumber
	, t_onc_chemoadmin_patientregimenpriorauthexpiration.effectivedate as authorizationeffectivedate
	, t_onc_chemoadmin_patientregimenpriorauthexpiration.expirationdate as authorizationexpirationdate
	, t_onc_chemoadmin_patientregimenpriorauthexpiration.title as authorizationapprovedtreatmentdescription
	, t_onc_chemoadmin_patientregimenpriorauthexpiration.numberofvisits as authorizationapprovedvisitcount
	, t_onc_chemoadmin_patientregimenpriorauthexpiration.allregimenagentsauthorized as authorizationforindividualchemoagentindicator
	, t_onc_chemoadmin_patientregimenpriorauthexpiration.coinsurance as authorizationcoinsuranceamount
	, t_onc_chemoadmin_patientregimenpriorauthexpiration.copay as authorizationpatientcopaycommitmentamount
	, t_onc_chemoadmin_patientregimenpriorauthexpiration.deductible as authorizationpatientdeductibleamount
	, t_onc_chemoadmin_patientregimenpriorauthexpiration.contactperson as authorizationpayercontactpersonname
	, t_onc_chemoadmin_patientregimenpriorauthexpiration.notes as authorizationcommentsregardinginsurancedescription
	, t_onc_chemoadmin_patientregimenpriorauthexpiration.patientchemodayagentid as authorizationforpatientchemotherapyagentid
	, t_onc_chemoadmin_patientregimenpriorauthexpiration.patientchemoregimenid as authorizationforchemotherapyregimenid
	, t_patients.patientguid as patientid
	, t_community.communityguid as practiceid
    , t_community.license as practicename
	,'IC-EHR' as datasourcesystemid

from ICEHR.t_onc_chemoadmin_patientregimenpriorauthexpiration
inner join ICEHR.t_onc_chemoadmin_patientchemoregimencycledayagent on  (t_onc_chemoadmin_patientchemoregimencycledayagent.id =  t_onc_chemoadmin_patientregimenpriorauthexpiration.patientchemodayagentid) 
inner join ICEHR.t_onc_chemoadmin_patientchemoregimen on  (t_onc_chemoadmin_patientchemoregimencycledayagent.patientchemoregimenid =  t_onc_chemoadmin_patientchemoregimen.id) 
inner join ICEHR.t_community on ( t_community.id =  t_onc_chemoadmin_patientchemoregimen.practiceid) 
inner join ICEHR.t_patients on  (t_patients.id =  t_onc_chemoadmin_patientchemoregimen.patientid) 
inner join ICEHR.t_member on  (t_patients.memberguid =  t_member.memberguid) 
left outer join ICEHR.t_member m on( m.memberguid = t_onc_chemoadmin_patientregimenpriorauthexpiration.approvedby) 
left outer join ICEHR.t_users on (t_users.memberguid = m.memberguid) 
where (t_onc_chemoadmin_patientchemoregimencycledayagent.isadditionalmedication = FALSE) 

union all 

--** this query extracts the authorizations for the individual drugs 
select  t_onc_chemoadmin_patientregimenpriorauthexpiration.id as authorizationid
	, t_onc_chemoadmin_patientregimenpriorauthexpiration.adt_lastmodifieddate as authorizationrecordmodifieddatetime
	, t_onc_chemoadmin_patientregimenpriorauthexpiration.patientpayerguid as payerid
	, t_onc_chemoadmin_patientregimenpriorauthexpiration.adt_createddate as authorizationrecordcreateddatetime
	,case 
		when  t_onc_chemoadmin_patientregimenpriorauthexpiration.isdeleted = TRUE
			then TRUE
		else FALSE
		end as authorizationrecorddeletedindicator
	, t_onc_chemoadmin_patientregimenpriorauthexpiration.approveddate as authorizationapproveddatetime
	, t_users.userguid as authorizationapprovedbyuserid
	, t_onc_chemoadmin_patientregimenpriorauthexpiration.status as authorizationstatusdescription
	, t_onc_chemoadmin_patientregimenpriorauthexpiration.authorizationnumber
	, t_onc_chemoadmin_patientregimenpriorauthexpiration.effectivedate as authorizationeffectivedate
	, t_onc_chemoadmin_patientregimenpriorauthexpiration.expirationdate as authorizationexpirationdate
	, t_onc_chemoadmin_patientregimenpriorauthexpiration.title as authorizationapprovedtreatmentdescription
	, t_onc_chemoadmin_patientregimenpriorauthexpiration.numberofvisits as authorizationapprovedvisitcount
	, t_onc_chemoadmin_patientregimenpriorauthexpiration.allregimenagentsauthorized as authorizationforindividualchemoagentindicator
	, t_onc_chemoadmin_patientregimenpriorauthexpiration.coinsurance as authorizationcoinsuranceamount
	, t_onc_chemoadmin_patientregimenpriorauthexpiration.copay as authorizationpatientcopaycommitmentamount
	, t_onc_chemoadmin_patientregimenpriorauthexpiration.deductible as authorizationpatientdeductibleamount
	, t_onc_chemoadmin_patientregimenpriorauthexpiration.contactperson as authorizationpayercontactpersonname
	, t_onc_chemoadmin_patientregimenpriorauthexpiration.notes as authorizationcommentsregardinginsurancedescription
	, t_onc_chemoadmin_patientregimenpriorauthexpiration.patientchemodayagentid as authorizationforpatientchemotherapyagentid
	, t_onc_chemoadmin_patientregimenpriorauthexpiration.patientchemoregimenid as authorizationforchemotherapyregimenid
	, t_patients.patientguid as patientid
	,t_member.homecommunityguid as practiceid
    ,t_community.license as practicename
	,'IC-EHR' as datasourcesystemid
	
from ICEHR.t_onc_chemoadmin_patientregimenpriorauthexpiration
inner join ICEHR.t_onc_chemoadmin_patientchemoregimencycledayagent on  (t_onc_chemoadmin_patientchemoregimencycledayagent.id =  t_onc_chemoadmin_patientregimenpriorauthexpiration.patientchemodayagentid) 
inner join ICEHR.t_patients on (t_patients.id = t_onc_chemoadmin_patientchemoregimencycledayagent.patientid) 
inner join ICEHR.t_member on ( t_patients.memberguid =  t_member.memberguid)
inner join ICEHR.t_community on  (t_community.communityguid =  t_member.homecommunityguid )
left outer join ICEHR.t_member m on (m.memberguid = t_onc_chemoadmin_patientregimenpriorauthexpiration.approvedby) 
left outer join ICEHR.t_users on( t_users.memberguid = m.memberguid) 
where (t_onc_chemoadmin_patientchemoregimencycledayagent.isadditionalmedication = TRUE) 
)
select * from cte where authorizationrecorddeletedindicator = FALSE
  );