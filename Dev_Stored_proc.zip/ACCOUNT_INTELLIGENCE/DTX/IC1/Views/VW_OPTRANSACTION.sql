create or replace view IC1_VIEW.VW_OPTRANSACTION(
	OPTRANSACTIONID,
	OPTRANSPATIENTHIPAAREVIEWINDICATOR,
	OPTRANSPATIENTHIPAASIGNATURENAME,
	OPTRANSWITNESSTOPATIENTHIPAASIGNATURENAME,
	OPTRANSPATIENTRECORDDETAILMODIFIEDDATETIME,
	PATIENTID,
	PRACTICEID,
	PRACTICENAME,
	DATASOURCESYSTEMID
) as (
    /*
******************************************** notes start ********************************************
table: op transaction
comments:  this is incomplete due to missing table t_signatures
******************************************** notes end ********************************************
*/



select 
     t_patients_hipaa.patienthipaaguid as optransactionid
    ,t_patients_hipaa.patientreviewedhippaprivacystatement as optranspatienthipaareviewindicator
    ,patsig.signatureimage as optranspatienthipaasignaturename
    ,witsig.signatureimage as optranswitnesstopatienthipaasignaturename
    ,t_patients_hipaa.createdate as optranspatientrecorddetailmodifieddatetime
    ,t_patients_hipaa.patientguid as patientid
    ,t_member.homecommunityguid as practiceid
    ,t_community.license as practicename
    ,'IC-EHR' as datasourcesystemid

from  ICEHR.t_patients_hipaa
left outer join ICEHR.t_signatures patsig on (patsig.signatureguid = t_patients_hipaa.patientsignatureguid )
left outer join ICEHR.t_signatures witsig on (witsig.signatureguid = t_patients_hipaa.witnesssignatureguid) 
inner join ICEHR.t_patients on (t_patients.patientguid = t_patients_hipaa.patientguid) 
inner join ICEHR.t_member on (t_member.memberguid = t_patients.memberguid) 
inner join ICEHR.t_community t_community  on (t_member.homecommunityguid = t_community.communityguid) 
  );