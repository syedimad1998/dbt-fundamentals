create or replace view IC1_VIEW.VW_PRACTICE(
	PRACTICEID,
	PRACTICENAME,
	DATASOURCESYSTEMID
) as (
    /* 
********************************************  NOTES START  ********************************************
Table: Practice
Comments: Practice Master Data
********************************************  NOTES END    ********************************************
*/



select  
	t_community.communityguid As practiceid,
	t_community.license As practicename,
	'IC-EHR' as datasourcesystemid
from ICEHR.t_community t_community
  );