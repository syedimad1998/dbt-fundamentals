create or replace view IC1_VIEW.VW_DOCUMENT(
	DOCUMENTID,
	PATIENTDOCUMENTGUIDVALUE,
	DOCUMENTNAME,
	DOCUMENTTYPEDESCRIPTION,
	DOCUMENTDATETIME,
	DOCUMENTCREATEDBYUSERID,
	DOCUMENTCREATEDDATETIME,
	PATIENTVISITDATE,
	DOCUMENTFILESIZEVALUE,
	PATIENTID,
	PRACTICEID,
	PRACTICENAME,
	VISITID,
	DOCUMENTDELETEDINDICATOR,
	DATASOURCESYSTEMID,
	ORDERID,
	DOCUMENTAPPROVEDDATETIME,
	DOCUMENTAPPROVEDORSIGNEDOFFUSER
) as (
    /*
******************************************** notes start ********************************************
table: documents
comments: this query extracts two sets of data - one from the patients documents and the second from the
documents in the document orders. it requires data from:
t_patients_document
t_patients
t_doc
t_doc_types
t_doc_class_patient
t_member
t_visits
t_visits_order_document
t_visits_order
******************************************** notes end ********************************************
*/



with cte as (

--** query to retrieve information from the patients documents
select t_patients_document.dmsdocid as documentid
,t_patients_document.patientdocumentguid as patientdocumentguidvalue
,t_docs.doc_name as documentname
,t_doc_types.doc_type_name as documenttypedescription
,t_docs.doc_created_datetime as documentdatetime
,t_patients_document.userguid as documentcreatedbyuserid
,t_patients_document.createdate as documentcreateddatetime
,t_visits.visitbegindatetime as patientvisitdate
,t_docs.doc_filesize as documentfilesizevalue
,t_patients.patientguid as patientid
,t_member.homecommunityguid as practiceid
,t_community.license as practicename
,t_visits.visitguid as visitid
,(Case When t_doc_class_patient.visible = TRUE Then 0 Else 1 end) as documentdeletedindicator
,'IC-EHR' as datasourcesystemid
,null as orderid
,t_patients_document.signoffdate as documentapproveddatetime
,t_patients_document.signoffuserguid as documentapprovedorsignedoffuser

from ICEHR.t_doc_class_patient t_doc_class_patient

left outer join ICEHR.t_patients_document t_patients_document on
(t_doc_class_patient.patientguid = t_patients_document.patientguid)
and (t_doc_class_patient.doc_id = t_patients_document.dmsdocid) 
inner join ICEHR.t_patients t_patients on (t_patients_document.patientguid = t_patients.patientguid) 
inner join ICEHR.t_docs t_docs on (t_doc_class_patient.doc_id = t_docs.doc_id) 
inner join ICEHR.t_doc_types t_doc_types on (t_docs.doc_type_id = t_doc_types.doc_type_id) 
inner join ICEHR.t_member t_member on (t_patients.memberguid = t_member.memberguid) 
inner join ICEHR.t_community t_community on (t_community.communityguid = t_member.homecommunityguid) 
left outer join ICEHR.t_visits t_visits on (t_doc_class_patient.visitguid = t_visits.visitguid) 

union all

--** query to retrieve data from the patient's order documents
select  t_visits_order_document.dmsdocid as documentid
,t_visits_order_document.visitorderdocumentsguid as patientdocumentguidvalue
,t_docs.doc_name as documentname
,t_doc_types.doc_type_name as documenttypedescription
,t_docs.doc_created_datetime as documentdatetime
,null as documentcreatedbyuserid
,null as documentcreateddatetime
,t_visits.visitbegindatetime as patientvisitdate
,t_docs.doc_filesize as documentfilesizevalue
,t_patients.patientguid as patientid
,t_member.homecommunityguid as practiceid
,t_community.license as practicename
,t_visits.visitguid as visitid
,(case when t_visits_order_document.isdeleted = TRUE or t_doc_class_patient.visible = FALSE then 0 else 1 end) as documentdeletedindicator
,'IC-EHR' as datasourcesystemid
,t_visits_order.visitlaborderguid as orderid
,t_visits_order.signoffdate as documentapproveddatetime
,t_visits_order.signoffuserguid as documentapprovedorsignedoffuser

from ICEHR.t_docs
inner join ICEHR.t_visits_order_document on (t_docs.doc_id = t_visits_order_document.dmsdocid) 
inner join ICEHR.t_visits_order on (t_visits_order.visitlaborderguid = t_visits_order_document.visitlaborderguid) 
inner join ICEHR.t_visits on( t_visits_order.visitguid = t_visits.visitguid) 
inner join ICEHR.t_patients on (t_visits.patientguid = t_patients.patientguid) 
inner join ICEHR.t_doc_types on (t_doc_types.doc_type_id = t_docs.doc_type_id) 
left outer join ICEHR.t_doc_class_patient on (t_docs.doc_id = t_doc_class_patient.doc_id) 
inner join  ICEHR.t_member on  (t_member.memberguid = t_patients.memberguid) 
inner join ICEHR.t_community on (t_community.communityguid = t_member.homecommunityguid) 

)

select * from cte where documentdeletedindicator = 0
  );