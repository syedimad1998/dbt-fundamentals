create or replace view IC1_VIEW.VW_CHARGE(
	CHARGEID,
	CHARGERECORDCREATEDDATETIME,
	CHARGEADMISSIONSTATUSDESCRIPTION,
	CHARGECODE,
	CHARGECODETYPEDESCRIPTION,
	CHARGEDESCRIPTION,
	CHARGEHOSPITALVISITSTARTDATE,
	CHARGEHOSPITALVISITENDDATE,
	CHARGELOCATIONID,
	CHARGEPOSTEDDATE,
	CHARGESTATUSDESCRIPTION,
	CHARGEUNITBILLEDQUANTITY,
	PATIENTID,
	PRACTICEID,
	PRACTICENAME,
	DATASOURCESYSTEMID,
	VISITID,
	FACILITYID,
	ORDERID,
	CHARGESUPERBILLRECORDACTIVEINDICATOR,
	CHARGESUPERBILLPROVIDERSIGNOFFID,
	CHARGESUPERBILLDATE
) as (
    /* 
********************************************  NOTES START  ********************************************
Table: Charges
Comments: Read Charges
********************************************  NOTES END    ********************************************
*/



select
t_visits_order_cpt.visitordercptguid  as chargeid
,t_visits_order_cpt.createdate  as chargerecordcreateddatetime
,t_visits_order_cpt.senttopms as chargeadmissionstatusdescription
,t_billing_cpt.code  as chargecode
,t_billing_cpt.type  as chargecodetypedescription
,t_billing_cpt.longdescription  as chargedescription
,t_visits.visitbegindatetime  as chargehospitalvisitstartdate
,t_visits.visitenddatetime  as chargehospitalvisitenddate
,t_visits.facilityguid  as chargelocationid
,t_visits_order_cpt.sentdatetime  as chargeposteddate
,(case
    when t_visits_order_cpt.senttopms is null
    then ''
    when t_visits_order_cpt.signoffuserguid is null
    then 'Not Approved'
    else 'Approved'
end) as  chargestatusdescription
,t_visits_order_cpt.unit  as chargeunitbilledquantity
,t_visits.patientguid  as patientid
,t_member.homecommunityguid  as practiceid
,t_community.license as practicename
,'IC-EHR' as datasourcesystemid
,t_visits.visitguid  as visitid
,t_visits.facilityguid  as facilityid
,t_visits_order_cpt.visitlaborderguid as orderid
,t_onc_superbill_signoff.active as chargesuperbillrecordactiveindicator
,t_onc_superbill_signoff.providersignoffguid as chargesuperbillprovidersignoffid
,t_onc_superbill_signoff.superbilldate as chargesuperbilldate

from ICEHR.t_visits_order t_visits_order
inner join ICEHR.t_visits_order_cpt t_visits_order_cpt on (t_visits_order_cpt.visitlaborderguid = t_visits_order.visitlaborderguid) 
inner join ICEHR.t_facility_billing_item_cpt t_facility_billing_item_cpt on (t_facility_billing_item_cpt.facilitybillingitemcptguid = t_visits_order_cpt.facilitybillingitemcptguid) 
inner join ICEHR.t_billing_cpt t_billing_cpt on t_billing_cpt.billingcptguid = t_facility_billing_item_cpt.billingcptguid 
inner join ICEHR.t_visits t_visits on t_visits_order.visitguid = t_visits.visitguid 
inner join ICEHR.t_patients t_patients on t_patients.patientguid = t_visits.patientguid 
inner join ICEHR.t_member t_member on t_member.memberguid = t_patients.memberguid
inner join ICEHR.t_community  t_community on t_member.homecommunityguid = t_community.communityguid
inner join ICEHR.t_onc_superbill_signoff t_onc_superbill_signoff  on t_onc_superbill_signoff.patientguid = t_patients.patientguid
			and superbilldate = to_date(ifnull(t_visits.visitbegindatetime, t_visits.createdate))

  );