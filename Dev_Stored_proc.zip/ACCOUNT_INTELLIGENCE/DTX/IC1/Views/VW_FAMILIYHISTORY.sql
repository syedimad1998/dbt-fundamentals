create or replace view IC1_VIEW.VW_FAMILIYHISTORY(
	FAMILYHISTORYID,
	FAMILYHISTORYRECORDDATE,
	FAMILYHISTORYDIAGNOSISCATEGORYDESCRIPTION,
	FAMILYHISTORYSNOMEDPROBLEMDESCRIPTION,
	FAMILYHISTORYFAMILYMEMBERAGEATCONDITIONONSETVALUE,
	FAMILYHISTORYFAMILYRELATIONTOPATIENTDESCRIPTION,
	PATIENTID,
	PRACTICEID,
	PRACTICENAME,
	DATASOURCESYSTEMID
) as (
    /*
******************************************** NOTES START ********************************************
Table: FamilyHistory
Comments: Requires t_patients_health_condition, t_facility, t_patients and t_member
******************************************** NOTES END ********************************************
*/



select 
	 t_patients_health_condition.patienthealthconditionguid as familyhistoryid
	,t_patients_health_condition.createdate as familyhistoryrecorddate
	,t_patients_health_condition.description as familyhistorydiagnosiscategorydescription
	,(Case 
			When t_patients_health_condition.familymembersnomed IS NULL 
				Then t_patients_health_condition.SNOMED
			Else t_patients_health_condition.familymembersnomed End)
		as familyhistorysnomedproblemdescription
	,t_patients_health_condition.familymembersageonset as familyhistoryfamilymemberageatconditiononsetvalue
	,t_patients_health_condition.familymembers as familyhistoryfamilyrelationtopatientdescription
	,t_patients_health_condition.patientguid as patientid
	,t_member.homecommunityguid as practiceid
    ,t_community.license as practicename
	,'IC-EHR' as datasourcesystemid 

from ICEHR.t_patients_health_condition t_patients_health_condition
inner join ICEHR.t_patients t_patients on (t_patients_health_condition.patientguid = t_patients.patientguid) 
inner join ICEHR.t_member t_member on (t_patients.memberguid = t_member.memberguid) 
inner join ICEHR.t_community t_community on (t_community.communityguid = t_member.homecommunityguid) 
where (t_patients_health_condition.patientaffected = FALSE) 
  );