create or replace view IC1_VIEW.VW_ADDRESS(
	PRACTICEID,
	PRACTICENAME,
	DATASOURCESYSTEMID,
	ADDRESSID,
	ADDRESSACTIVEINDICATOR,
	ADDRESSEFFECTIVEDATE,
	ADDRESSTYPECODE,
	ADDRESSLINE1NAME,
	ADDRESSLINE2NAME,
	ADDRESSCITYNAME,
	ADDRESSSTATENAME,
	ADDRESSPOSTALCODE,
	ADDRESSCOUNTYNAME
) as (

with cte as(

-- Facility Address
select t_facility.communityguid as practiceid
	,t_community.license as practicename
	,'IC-EHR' as datasourcesystemid
	,t_address.addressguid as addressid
	,(case when t_address.inactive = TRUE then 'inactive' else 'active' end) as addressactiveindicator
	,t_address.startdate as addresseffectivedate
	,t_address.addresstype as addresstypecode
	,t_address.address1 as addressline1name
	,t_address.address2 as addressline2name
	,t_address.city as addresscityname
	,t_address.state as addressstatename
	,t_address.zip as addresspostalcode
	,t_address.county as addresscountyname

from ICEHR.t_facility t_facility
inner join ICEHR.t_address t_address on (t_facility.facilityguid = t_address.foreignkeyguid) 
inner join ICEHR.t_community t_community on (t_community.communityguid = t_facility.communityguid) 

union all

-- patient payer address
select  t_member.homecommunityguid as practiceid
	,t_community.license as practicename
	,'IC-EHR' as datasourcesystemid
	,t_address.addressguid as addressid
	,(case when t_address.inactive = TRUE then 'inactive' else 'active' end) as addressactiveindicator
	,t_address.startdate as addresseffectivedate
	,t_address.addresstype as addresstypecode
	,t_address.address1 as addressline1name
	,t_address.address2 as addressline2name
	,t_address.city as addresscityname
	,t_address.state as addressstatename
	,t_address.zip as addresspostalcode
	,t_address.county as addresscountyname

from ICEHR.t_patients_payer t_patients_payer
inner join ICEHR.t_address t_address on (t_patients_payer.patientpayerguid = t_address.foreignkeyguid) 
inner join ICEHR.t_patients t_patients on (t_patients.patientguid = t_patients_payer.patientguid )
inner join ICEHR.t_member  t_member on( t_member.memberguid = t_patients.memberguid) 
inner join ICEHR.t_community t_community on (t_community.communityguid = t_member.homecommunityguid) 

union all

-- community payer address
select t_community_payer.communityguid as practiceid
	,t_community.license as practicename
	,'IC-EHR' as datasourcesystemid
	,t_address.addressguid as addressid
	,(case when t_address.inactive = TRUE then 'inactive' else 'active' end) as addressactiveindicator
	,t_address.startdate as addresseffectivedate
	,t_address.addresstype as addresstypecode
	,t_address.address1 as addressline1name
	,t_address.address2 as addressline2name
	,t_address.city as addresscityname
	,t_address.state as addressstatename
	,t_address.zip as addresspostalcode
	,t_address.county as addresscountyname

from  ICEHR.t_community_payer t_community_payer
inner join  ICEHR.t_address  t_address on (t_community_payer.addressguid = t_address.addressguid )
inner join ICEHR.t_community  t_community on (t_community.communityguid = t_community_payer.communityguid) 

union all

-- Patients Address
select t_member.homecommunityguid as practiceid
	,t_community.license as practicename
	,'IC-EHR' as datasourcesystemid
	,t_address.addressguid as addressid
	,(case when t_address.inactive = TRUE then 'inactive' else 'active' end) as addressactiveindicator
	,t_address.startdate as addresseffectivedate
	,t_address.addresstype as addresstypecode
	,t_address.address1 as addressline1name
	,t_address.address2 as addressline2name
	,t_address.city as addresscityname
	,t_address.state as addressstatename
	,t_address.zip as addresspostalcode
	,t_address.county as addresscountyname
	
from   ICEHR.t_patients t_patients
inner join  ICEHR.t_address  t_address on (t_patients.patientguid = t_address.foreignkeyguid) 
inner join  ICEHR.t_member  t_member on (t_member.memberguid = t_patients.memberguid) 
inner join ICEHR.t_community  t_community on (t_member.homecommunityguid = t_community.communityguid) 

)

select * from cte where addressactiveindicator = 'active'
  );