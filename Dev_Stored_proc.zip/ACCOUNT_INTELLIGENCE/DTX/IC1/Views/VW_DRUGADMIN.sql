create or replace view IC1_VIEW.VW_DRUGADMIN(
	DRUGADMINID,
	CHEMOREGIMENID,
	DRUGADMINMAINCHEMOAGENTID,
	DRUGADMINORDERPROVIDERID,
	ADMINISTERINGPROVIDERID,
	DRUGADMINACTIVERECORDINDICATOR,
	DRUGADMINISTRATIONDATE,
	DRUGADMINADDITIONALMEDICATIONINDICATOR,
	DRUGADMINDRUGNAME,
	DRUGADMINGENERICDRUGNAME,
	DRUGADMINALLORDERSMEDICATIONADJUSTMENTINDICATOR,
	DRUGADMINAPPROVEDBYUSERID,
	DRUGADMINAPPROVEDDATETIME,
	DRUGADMINCHEMOAGENTBILLABLEINDICATOR,
	DRUGADMINCHEMOAGENTINDICATOR,
	DRUGADMINCHEMOAGENTREFERENCEDOSAGEVALUE,
	DRUGADMINCHEMOORDERAPPROVEDINDICATOR,
	DRUGADMINCYCLEDAYNUMBER,
	DRUGADMINCYCLENUMBER,
	DRUGADMINDOSEAMOUNTVALUE,
	DRUGADMINDOSEBASISVALUE,
	DRUGADMINDOSEUNITOFMEASURE,
	DRUGADMINDRUGCATEGORYDESCRIPTION,
	DRUGADMINDRUGMIXREADYINDICATOR,
	DRUGADMINEXTERNALTREATMENTINDICATOR,
	DRUGADMINEXTERNALTREATMENTNOTETEXT,
	DRUGADMININFUSIONBAGASSIGNEDNUMBER,
	DRUGADMINNURSENEEDEDFORPRNORDERINDICATOR,
	DRUGADMINNURSEPRNREASONTEXT,
	DRUGADMINONHOLDINDICATOR,
	DRUGADMINORDERDATETIME,
	DRUGADMINORDERDOSEAMOUNTVALUE,
	DRUGADMINORDERSIGNEDBYUSERID,
	DRUGADMINORDERSIGNEDDATETIME,
	DRUGADMINPREMEDICATIONINDICATOR,
	DRUGADMINDOSEQUANTITY,
	DRUGADMINDOSEQUANTITYUNITOFMEASURE,
	DRUGADMINROUTEDESCRIPTIONTEXT,
	DRUGADMINTHERAPYINTENTDESCRIPTION,
	DRUGADMINTREATMENTREGIMENNAME,
	DRUGADMINVIALAMOUNTWASTEDVALUE,
	DRUGADMINMARENTRYEDITEDBYUSERID,
	DRUGADMINMARENTRYEDITEDDATETIME,
	DRUGADMINMARENTRYPROVIDERSIGNOFFDATETIME,
	DRUGADMINMARENTRYSIGNOFFPROVIDERID,
	DRUGADMINMARSCREENINGPERFORMEDBYUSERID,
	DRUGADMINCOMMENTTEXT,
	DRUGADMINRECORDDELETEDINDICATOR,
	PATIENTID,
	PRACTICEID,
	PRACTICENAME,
	DATASOURCESYSTEMID,
	VISITID,
	ORDERID,
	FACILITYID,
	DRUGADMINSTATUSDESCRIPTION,
	DRUGADMINJCODEVALUE
) as (
    /*
******************************************** NOTES START ********************************************
Table: Drug Drug
Comments: Drug administration details

Note:  If ChemoRegimenId IS NOt null then it is Regimen agent. Or else additional medication. Also "DrugAdminAdditionalMedicationIndicator" field can be used for additional medication indicator.
	

	t_onc_MAR_SignOff table is joining with DayAgent by Date. this may not 100% reliable information. This table is joined with t_visits table

******************************************** NOTES END ********************************************
*/




with cte1 as (
Select t_visits.VisitGuid, 
       t_visits.UserGuid,
       t_visits.patientguid,
       t_visits.createdate,
       row_number() over(partition by t_visits.patientguid order by t_visits.createdate asc
       ) as rn
       From
        ICEHR.t_visits  
),
cte2 as (
Select  t_onc_MAR_SignOff.* ,
        row_number() over(partition by t_onc_MAR_SignOff.patientguid 
                          order by t_onc_MAR_SignOff.SignOffDate asc
        ) as rn
        from ICEHR.t_onc_MAR_SignOff 
)


-- Regimen Agents Administration
select distinct
	t_onc_chemoadmin_patientchemoregimencycledayagent.id as drugadminid
	,t_onc_chemoadmin_patientchemoregimen.id as chemoregimenid
	,t_onc_chemoadmin_patientchemoregimencycledayagent.id as drugadminmainchemoagentid
	,cte2.providersignoffguid as drugadminorderproviderid
	,cte1.userguid as administeringproviderid
	,t_onc_chemoadmin_patientchemoregimencycleday.isactive as drugadminactiverecordindicator
	,t_onc_chemoadmin_patientchemoregimencycledayagent.actualstartdate as drugadministrationdate
	,'0' as drugadminadditionalmedicationindicator
	,t_onc_agt_agent.agentname as drugadmindrugname
	,t_onc_agt_agent.genericname as drugadmingenericdrugname
	,t_onc_chemoadmin_patientchemoregimencycledayagent.isdoseadjustedforallorders as drugadminallordersmedicationadjustmentindicator
	,u.userguid as drugadminapprovedbyuserid
	,t_onc_chemoadmin_patientchemoregimencycledayagent.mdapprovaldate as drugadminapproveddatetime
	,(
		case 
			when t_onc_chemoadmin_patientchemoregimencycledayagent.isnotbillable = FALSE
				then 1
			else 0
			end
		) as drugadminchemoagentbillableindicator
	,t_onc_chemoadmin_patientchemoregimencycledayagent.ischemoagent as drugadminchemoagentindicator
	,t_onc_chemoadmin_patientchemoregimencycledayagent.referencedose as drugadminchemoagentreferencedosagevalue
	,t_onc_chemoadmin_patientchemoregimencycledayagent.ischemoorderapproved as drugadminchemoorderapprovedindicator
	,t_onc_chemoadmin_patientchemoregimencycleday.daynumber as drugadmincycledaynumber
	,t_onc_chemoadmin_patientchemoregimencycleday.cyclenumber as drugadmincyclenumber
	,t_onc_chemoadmin_patientchemoregimencycledayagent.actualadmindose as drugadmindoseamountvalue
	,t_onc_chemoadmin_patientchemoregimencycledayagent.dosebasistitle as drugadmindosebasisvalue
	,t_onc_chemoadmin_patientchemoregimencycledayagent.uom as drugadmindoseunitofmeasure
	,t_onc_agt_agenttype.title as drugadmindrugcategorydescription
	,t_onc_chemoadmin_patientchemoregimencycledayagent.readytomix as drugadmindrugmixreadyindicator
	--,endaction.createdate as drugadminenddate
	,t_onc_chemoadmin_patientchemoregimencycleday.externaladministration as drugadminexternaltreatmentindicator
	,t_onc_chemoadmin_patientchemoregimencycleday.externaladministrationnotes as drugadminexternaltreatmentnotetext
	,t_onc_chemoadmin_patientchemoregimencycledayagent.bagid as drugadmininfusionbagassignednumber
	,t_onc_chemoadmin_patientchemoregimencycledayagent.isprn as drugadminnurseneededforprnorderindicator
	,t_onc_chemoadmin_patientchemoregimencycledayagent.prnreason as drugadminnurseprnreasontext
	,(
		case 
			when t_onc_chemoadmin_patientchemoregimencycleday.isonhold = TRUE
				or t_onc_chemoadmin_patientchemoregimencycledayagent.ishold = TRUE
				then TRUE
			else FALSE
			end
		) as drugadminonholdindicator
	,t_onc_chemoadmin_patientchemoregimencycledayagent.adt_createddate as drugadminorderdatetime
	,t_onc_chemoadmin_patientchemoregimencycledayagent.actualadmindose as drugadminorderdoseamountvalue
	,cte2.signoffuserguid as drugadminordersignedbyuserid
	,cte2.signoffdate as drugadminordersigneddatetime
	,t_onc_chemoadmin_patientchemoregimencycledayagent.premedication as drugadminpremedicationindicator
	,t_onc_chemoadmin_patientchemoregimencycledayagent.actualadmindose as drugadmindosequantity
	,t_onc_chemoadmin_patientchemoregimencycledayagent.uom as drugadmindosequantityunitofmeasure
	,t_onc_agt_drugroute.title as drugadminroutedescriptiontext
	--,startaction.createdate as drugadminstartdate
	,t_onc_chemotherapy_intent.title as drugadmintherapyintentdescription
	,t_onc_chemotherapy_treatmentplan.title as drugadmintreatmentregimenname
	,t_onc_chemoadmin_patientchemoregimencycledayagent.waste as drugadminvialamountwastedvalue
	,cte2.edituserguid as drugadminmarentryeditedbyuserid
	,cte2.editdate as drugadminmarentryediteddatetime
	,cte2.providersignoffdate as drugadminmarentryprovidersignoffdatetime
	,cte2.providersignoffguid as drugadminmarentrysignoffproviderid
	,cte2.signoffuserguid as drugadminmarscreeningperformedbyuserid
	,t_onc_chemoadmin_patientchemoregimencycledayagent.comments as drugadmincommenttext
	,(case when t_onc_chemoadmin_patientchemoregimencycledayagent.isactive = TRUE then 0 else 1 end) as drugadminrecorddeletedindicator
	,t_patients.patientguid as patientid
	,t_member.homecommunityguid as practiceid
    ,t_community.license as practicename
	,'IC-EHR' as datasourcesystemid
	,cte1.visitguid as visitid
	,t_onc_chemoadmin_patientchemoregimencycledayagent.visitlaborderguid as orderid
	,t_facility.FacilityGuid as facilityid
    ,(case
        when t_onc_chemoadmin_patientchemoregimencycledayagent.regimencycledayagentdiscontinueid is not null
            then 'discontinue'
        when t_onc_chemoadmin_patientchemoregimencycledayagent.isactive = FALSE 
            then 'inactive'
        else 'active'
        end) as drugadminstatusdescription
	,t_onc_agt_agent.hcspcscode as drugadminjcodevalue

from  ICEHR.t_onc_chemoadmin_patientchemoregimencycledayagent t_onc_chemoadmin_patientchemoregimencycledayagent
left outer join  ICEHR.t_member m on (m.id = t_onc_chemoadmin_patientchemoregimencycledayagent.mdapprovedby) 
left outer join  ICEHR.t_users u on (u.memberguid = m.memberguid) 
left outer join ICEHR.t_regimencycledayagent_discontinue on (t_regimencycledayagent_discontinue.regimencycledayagentdiscontinueid = t_onc_chemoadmin_patientchemoregimencycledayagent.regimencycledayagentdiscontinueid) 
inner join ICEHR.t_onc_agt_agent on (t_onc_agt_agent.id = t_onc_chemoadmin_patientchemoregimencycledayagent.agentid) 
inner join ICEHR.t_onc_agt_agenttype on (t_onc_agt_agent.agenttypeid = t_onc_agt_agenttype.id)
inner join ICEHR.t_onc_rx_drugfrequency on (t_onc_rx_drugfrequency.id = t_onc_chemoadmin_patientchemoregimencycledayagent.drugfrequency) 
inner join ICEHR.t_onc_agt_drugroute on (t_onc_agt_drugroute.id = t_onc_chemoadmin_patientchemoregimencycledayagent.routeid) 
inner join ICEHR.t_onc_agt_fluid on (t_onc_agt_fluid.id = t_onc_chemoadmin_patientchemoregimencycledayagent.fluidid)
inner join ICEHR.t_onc_chemoadmin_patientchemoregimencycleday on (t_onc_chemoadmin_patientchemoregimencycleday.id = t_onc_chemoadmin_patientchemoregimencycledayagent.PatientChemoRegimenCycleDayId) 
inner join ICEHR.t_onc_chemoadmin_patientchemoregimencycle on (t_onc_chemoadmin_patientchemoregimencycle.id = t_onc_chemoadmin_patientchemoregimencycleday.patientchemoregimencycleid) 
inner join ICEHR.t_onc_chemoadmin_patientchemoregimen on (t_onc_chemoadmin_patientchemoregimencycleday.patientchemoregimenid = t_onc_chemoadmin_patientchemoregimen.id)
inner join ICEHR.t_patients on (t_patients.id = t_onc_chemoadmin_patientchemoregimen.patientid) 
inner join ICEHR.t_member on (t_member.memberguid = t_patients.memberguid) 
inner join  ICEHR.t_community on (t_member.homecommunityguid = t_community.communityguid)

inner join ICEHR.t_onc_chemotherapy_treatmentplan on (t_onc_chemotherapy_treatmentplan.id = t_onc_chemoadmin_patientchemoregimen.regimenid) 
left outer join ICEHR.t_onc_chemotherapy_intent on (t_onc_chemotherapy_intent.id = t_onc_chemoadmin_patientchemoregimen.intentid) 
left outer join ICEHR.t_onc_chemotherapy_regimentreatmentline on (t_onc_chemotherapy_regimentreatmentline.regimenid = t_onc_chemotherapy_treatmentplan.id) 
left outer join ICEHR.t_onc_oncology_treatmentline on (t_onc_oncology_treatmentline.id = t_onc_chemotherapy_regimentreatmentline.treatmentlineid) 
left outer join  cte1 on (t_patients.patientguid = cte1.patientguid) 
	and cast(cte1.createdate as DATE) = cast(t_onc_chemoadmin_patientchemoregimencycledayagent.adt_createddate as DATE) and cte1.rn = 1
left outer join cte2 on (cte2.patientguid = t_patients.patientguid)
	and cte2.mardate = cast(t_onc_chemoadmin_patientchemoregimencycleday.actualstartdate as DATE) and cte2.rn = 1
left outer join  ICEHR.t_onc_superbill_signoff on (t_onc_superbill_signoff.patientguid = t_patients.patientguid) 
	and t_onc_superbill_signoff.superbilldate = cast(t_onc_chemoadmin_patientchemoregimencycleday.actualstartdate as DATE)
left outer join  ICEHR.t_onc_verbal_order_mapping on (t_onc_verbal_order_mapping.dayagentid = t_onc_chemoadmin_patientchemoregimencycledayagent.id) 
	and t_onc_verbal_order_mapping.active = TRUE
left outer join  ICEHR.t_onc_verbal_order on (t_onc_verbal_order.verbalorderid = t_onc_verbal_order_mapping.verbalorderid) 
Left Outer Join ICEHR.t_facility ON t_facility.Id = t_onc_chemoadmin_PatientChemoRegimenCycleDayAgent.ServiceFacilityId 
where (t_onc_chemoadmin_PatientChemoRegimenCycleDayAgent.IsAdditionalMedication = FALSE)


union all 

-- additional medication administration
select distinct
	t_onc_chemoadmin_patientchemoregimencycledayagent.id as drugadminid
	,null as chemoregimenid
	,t_onc_chemoadmin_patientchemoregimencycledayagent.id as drugadminmainchemoagentid
	,cte2.providersignoffguid as drugadminorderproviderid
	,cte1.userguid as administeringproviderid
	,t_onc_chemoadmin_patientchemoregimencycledayagent.isactive as drugadminactiverecordindicator
    ,t_onc_chemoadmin_patientchemoregimencycledayagent.actualstartdate as drugadministrationdate
	,'1' as drugadminadditionalmedicationindicator
	,t_onc_agt_agent.agentname as drugadmindrugname
	,t_onc_agt_agent.genericname as drugadmingenericdrugname
	,t_onc_chemoadmin_patientchemoregimencycledayagent.isdoseadjustedforallorders as drugadminallordersmedicationadjustmentindicator
	,u.userguid as drugadminapprovedbyuserid
	,t_onc_chemoadmin_patientchemoregimencycledayagent.mdapprovaldate as drugadminapproveddatetime
	,(
		case 
			when t_onc_chemoadmin_patientchemoregimencycledayagent.isnotbillable = FALSE
				then 1
			else 0
			end
		) as drugadminchemoagentbillableindicator
	,t_onc_chemoadmin_patientchemoregimencycledayagent.ischemoagent as drugadminchemoagentindicator
	,t_onc_chemoadmin_patientchemoregimencycledayagent.referencedose as drugadminchemoagentreferencedosagevalue
	,t_onc_chemoadmin_patientchemoregimencycledayagent.ischemoorderapproved as drugadminchemoorderapprovedindicator
	,null as drugadmincycledaynumber
	,null as drugadmincyclenumber
	,t_onc_chemoadmin_patientchemoregimencycledayagent.actualadmindose as drugadmindoseamountvalue
	,t_onc_chemoadmin_patientchemoregimencycledayagent.dosebasistitle as drugadmindosebasisvalue
	,t_onc_chemoadmin_patientchemoregimencycledayagent.uom as drugadmindoseunitofmeasure
	,t_onc_agt_agenttype.title as drugadmindrugcategorydescription
	,t_onc_chemoadmin_patientchemoregimencycledayagent.readytomix as drugadmindrugmixreadyindicator
	-- ,endaction.createdate as drugadminenddate
	,t_onc_chemoadmin_patientchemoregimencycledayagent.externaladministration as drugadminexternaltreatmentindicator
	,t_onc_chemoadmin_patientchemoregimencycledayagent.externaladministrationnotes as drugadminexternaltreatmentnotetext
	,t_onc_chemoadmin_patientchemoregimencycledayagent.bagid as drugadmininfusionbagassignednumber
	,t_onc_chemoadmin_patientchemoregimencycledayagent.isprn as drugadminnurseneededforprnorderindicator
	,t_onc_chemoadmin_patientchemoregimencycledayagent.prnreason as drugadminnurseprnreasontext
	,t_onc_chemoadmin_patientchemoregimencycledayagent.ishold as drugadminonholdindicator
	,t_onc_chemoadmin_patientchemoregimencycledayagent.adt_createddate as drugadminorderdatetime
	,t_onc_chemoadmin_patientchemoregimencycledayagent.actualadmindose as drugadminorderdoseamountvalue
	,cte2.signoffuserguid as drugadminordersignedbyuserid
	,cte2.signoffdate as drugadminordersigneddatetime
	,t_onc_chemoadmin_patientchemoregimencycledayagent.premedication as drugadminpremedicationindicator
	,t_onc_chemoadmin_patientchemoregimencycledayagent.actualadmindose as drugadmindosequantity
	,t_onc_chemoadmin_patientchemoregimencycledayagent.uom as drugadmindosequantityunitofmeasure
	,t_onc_agt_drugroute.title as drugadminroutedescriptiontext
	-- ,startaction.createdate as drugadminstartdate
	,null as drugadmintherapyintentdescription
	,null as drugadmintreatmentregimenname
	,t_onc_chemoadmin_patientchemoregimencycledayagent.waste as drugadminvialamountwastedvalue
	,cte2.edituserguid as drugadminmarentryeditedbyuserid
	,cte2.editdate as drugadminmarentryediteddatetime
	,cte2.providersignoffdate as drugadminmarentryprovidersignoffdatetime
	,cte2.providersignoffguid as drugadminmarentrysignoffproviderid
	,cte2.signoffuserguid as drugadminmarscreeningperformedbyuserid
	,t_onc_chemoadmin_patientchemoregimencycledayagent.comments as drugadmincommenttext
	,(case when t_onc_chemoadmin_patientchemoregimencycledayagent.isactive = TRUE then 0 else 1 end) as drugadminrecorddeletedindicator
	,t_patients.patientguid as patientid
	,t_member.homecommunityguid as practiceid
    ,t_community.license as practicename
	,'IC-EHR' as datasourcesystemid
	,cte1.visitguid as visitid
	,t_onc_chemoadmin_patientchemoregimencycledayagent.visitlaborderguid as orderid
	,t_facility.FacilityGuid as facilityid
    ,(case
        when t_onc_chemoadmin_patientchemoregimencycledayagent.regimencycledayagentdiscontinueid is not null
            then 'discontinue'
        when t_onc_chemoadmin_patientchemoregimencycledayagent.isactive = FALSE 
            then 'inactive'
        else 'active'
        end) as drugadminstatusdescription
	,t_onc_agt_agent.hcspcscode as drugadminjcodevalue
from ICEHR.t_onc_chemoadmin_patientchemoregimencycledayagent
left outer join  ICEHR.t_member m on m.id = (t_onc_chemoadmin_patientchemoregimencycledayagent.mdapprovedby) 
left outer join  ICEHR.t_users u on (u.memberguid = m.memberguid) 
left outer join  ICEHR.t_regimencycledayagent_discontinue on (t_regimencycledayagent_discontinue.regimencycledayagentdiscontinueid = t_onc_chemoadmin_patientchemoregimencycledayagent.regimencycledayagentdiscontinueid) 
inner join  ICEHR.t_onc_agt_agent on (t_onc_agt_agent.id = t_onc_chemoadmin_patientchemoregimencycledayagent.agentid) 
inner join  ICEHR.t_onc_agt_agenttype on (t_onc_agt_agent.agenttypeid = t_onc_agt_agenttype.id) 
inner join  ICEHR.t_onc_rx_drugfrequency on (t_onc_rx_drugfrequency.id = t_onc_chemoadmin_patientchemoregimencycledayagent.drugfrequency) 
inner join  ICEHR.t_onc_agt_drugroute on (t_onc_agt_drugroute.id = t_onc_chemoadmin_patientchemoregimencycledayagent.routeid) 
inner join  ICEHR.t_onc_agt_fluid on (t_onc_agt_fluid.id = t_onc_chemoadmin_patientchemoregimencycledayagent.fluidid) 
inner join  ICEHR.t_patients on (t_patients.id = t_onc_chemoadmin_patientchemoregimencycledayagent.patientid) 
inner join  ICEHR.t_member on (t_member.memberguid = t_patients.memberguid)
inner join  ICEHR.t_community on (t_member.homecommunityguid = t_community.communityguid) 
left outer join  cte1 on (t_patients.patientguid = cte1.patientguid) 
	and cast(cte1.createdate as date) = cast(t_onc_chemoadmin_patientchemoregimencycledayagent.adt_createddate as date) and cte1.rn = 1
left outer join cte2 on (cte2.patientguid = t_patients.patientguid)
	and cte2.mardate = cast(t_onc_chemoadmin_patientchemoregimencycledayagent.actualstartdate as DATE) and cte2.rn = 1
left outer join  ICEHR.t_onc_superbill_signoff on (t_onc_superbill_signoff.patientguid = t_patients.patientguid) 
	and t_onc_superbill_signoff.superbilldate = cast(t_onc_chemoadmin_patientchemoregimencycledayagent.actualstartdate as date)
left outer join  ICEHR.t_onc_verbal_order_mapping on (t_onc_verbal_order_mapping.dayagentid = t_onc_chemoadmin_patientchemoregimencycledayagent.id) 
	and (t_onc_verbal_order_mapping.active = TRUE)
left outer join  ICEHR.t_onc_verbal_order on (t_onc_verbal_order.verbalorderid = t_onc_verbal_order_mapping.verbalorderid)
Left Outer Join ICEHR.t_facility ON t_facility.Id = t_onc_chemoadmin_PatientChemoRegimenCycleDayAgent.ServiceFacilityId 
where (t_onc_chemoadmin_patientchemoregimencycledayagent.isadditionalmedication = TRUE)
  );