create or replace view IC1_VIEW.VW_NOTE(
	NOTEID,
	PATIENTID,
	NOTETEXT,
	NOTECREATEDDATE,
	NOTECREATEDBYUSERGUID,
	PRACTICEID,
	PRACTICENAME,
	DATASOURCESYSTEMID,
	VISITID
) as (
    /* 
********************************************  NOTES START  ********************************************
Table: Note
Comments: Reads Provider Notes


********************************************  NOTES END    ********************************************
*/



-- Provider Notes
select 
	t_visits_provider_note.VisitProviderNoteGuid as NoteId    
    ,t_visits_provider_note.PatientGuid as PatientId
    ,t_visits_provider_note.Description as NoteText
    ,t_visits_provider_note.CreateDate As NoteCreatedDate
	,t_visits_provider_note.UserGuid as NoteCreatedByUserGuid
	,t_community.communityguid as practiceid 
    ,t_community.license as practicename
	,'IC-EHR' as datasourcesystemid
    ,t_visits_provider_note.VisitGuid as visitid

from ICEHR.t_patients
inner join ICEHR.t_visits_provider_note on (t_patients.patientguid = t_visits_provider_note.patientguid) 
inner join ICEHR.t_member on (t_member.memberguid = t_patients.memberguid) 
inner join ICEHR.t_community t_community on (t_community.communityguid = t_member.homecommunityguid) 

  );