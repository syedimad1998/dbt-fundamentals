create or replace view IC1_VIEW.VW_REFERRAL(
	REFERRALID,
	REFERRALRECORDACTIVEINDICATOR,
	REFERRALRECORDCREATEDDATETIME,
	REFERRALRECORDCREATEDBYUSERID,
	REFERRALREASONDESCRIPTION,
	REFERRINGPROVIDERID,
	REFERRINGPROVIDERNAME,
	REFERRINGPROVIDERFIRSTNAME,
	REFERRINGPROVIDERLASTNAME,
	REFERRINGPROVIDERMIDDLENAME,
	REFERRINGPROVIDERSPECIALTYDESCRIPTION,
	REFERRINGPROVIDERTAXONOMYCODE,
	REFERRINGPROVIDERFAXNUMBER,
	REFERRINGPROVIDERTELEPHONENUMBER,
	REFERRINGPROVIDERDIRECTEMAILADDRESS,
	REFERRINGPROVIDERPREFERREDCONTACTMETHODDESCRIPTION,
	PATIENTID,
	PRACTICEID,
	PRACTICENAME,
	DATASOURCESYSTEMID,
	VISITID
) as (
    /* 
********************************************  NOTES START  ********************************************
Table: Referral
Comments: Reads Referral Physician data

	This table can be referred to Provider table for other details
********************************************  NOTES END    ********************************************
*/



select t_community_referral.communityreferralguid as referralid
	,t_community_referral.active as referralrecordactiveindicator
	,t_community_referral.createdate as referralrecordcreateddatetime
	,t_users.userguid as referralrecordcreatedbyuserid
	,'referral' as referralreasondescription
	,t_community_referral.communityreferralguid as referringproviderid
	,concat(t_community_referral.firstname,' ', t_community_referral.lastname) as referringprovidername
	,t_community_referral.firstname as referringproviderfirstname
	,t_community_referral.lastname as referringproviderlastname
	,t_community_referral.middlename as referringprovidermiddlename
	,t_community_referral.speciality as referringproviderspecialtydescription
	,t_community_referral.taxonomycode as referringprovidertaxonomycode
	,t_community_referral.fax as referringproviderfaxnumber
	,t_community_referral.phone as referringprovidertelephonenumber
	,t_community_referral.directemail as referringproviderdirectemailaddress
	,t_community_referral.preferredcontactmethod as referringproviderpreferredcontactmethoddescription
	,t_patients_additional_data.patientguid as patientid
	,t_community_referral.communityguid as practiceid
    ,t_community.license as practicename
	,'IC-EHR' as datasourcesystemid
	,null as visitid
from ICEHR.t_community_referral t_community_referral
left outer join ICEHR.t_users t_users on t_users.memberguid = t_community_referral.memberguid 
inner join ICEHR.t_patients_additional_data t_patients_additional_data on t_community_referral.communityreferralguid = t_patients_additional_data.communityreferralguid 
inner join ICEHR.t_community t_community on t_community.communityguid = t_community_referral.communityguid 


union all

-- to get pcp community rerral all patient level
select t_community_referral.communityreferralguid as referralid
	,t_community_referral.active as referralrecordactiveindicator
	,t_community_referral.createdate as referralrecordcreateddatetime
	,t_users.userguid as referralrecordcreatedbyuserid
	,'pcpreferral' as referralreasondescription
	,t_community_referral.communityreferralguid as referringproviderid
	,concat(t_community_referral.firstname,' ', t_community_referral.lastname) as referringprovidername
	,t_community_referral.firstname as referringproviderfirstname
	,t_community_referral.lastname as referringproviderlastname
	,t_community_referral.middlename as referringprovidermiddlename
	,t_community_referral.speciality as referringproviderspecialtydescription
	,t_community_referral.taxonomycode as referringprovidertaxonomycode
	,t_community_referral.fax as referringproviderfaxnumber
	,t_community_referral.phone as referringprovidertelephonenumber
	,t_community_referral.directemail as referringproviderdirectemailaddress
	,t_community_referral.preferredcontactmethod as referringproviderpreferredcontactmethoddescription
	,t_patients_additional_data.patientguid as patientid
	,t_community_referral.communityguid as practiceid
    ,t_community.license as practicename
	,'IC-EHR' as datasourcesystemid
	,null as visitid
from ICEHR.t_community_referral t_community_referral
left outer join ICEHR.t_users t_users on t_users.memberguid = t_community_referral.memberguid 
inner join ICEHR.t_patients_additional_data t_patients_additional_data on t_community_referral.communityreferralguid = t_patients_additional_data.pcpcommunityreferralguid  
inner join ICEHR.t_community t_community on t_community.communityguid = t_community_referral.communityguid 

union all

-- to read additional referring physicians
select t_community_referral.communityreferralguid as referralid
	,t_community_referral.active as referralrecordactiveindicator
	,t_community_referral.createdate as referralrecordcreateddatetime
	,t_users.userguid as referralrecordcreatedbyuserid
	,'addtionalreferral' as referralreasondescription
	,t_community_referral.communityreferralguid as referringproviderid
	,concat(t_community_referral.firstname,' ', t_community_referral.lastname) as referringprovidername
	,t_community_referral.firstname as referringproviderfirstname
	,t_community_referral.lastname as referringproviderlastname
	,t_community_referral.middlename as referringprovidermiddlename
	,t_community_referral.speciality as referringproviderspecialtydescription
	,t_community_referral.taxonomycode as referringprovidertaxonomycode
	,t_community_referral.fax as referringproviderfaxnumber
	,t_community_referral.phone as referringprovidertelephonenumber
	,t_community_referral.directemail as referringproviderdirectemailaddress
	,t_community_referral.preferredcontactmethod as referringproviderpreferredcontactmethoddescription
	,t_patients_additional_careteam_member.patientguid as patientid
	,t_community_referral.communityguid as practiceid
    ,t_community.license as practicename
	,'IC-EHR' as datasourcesystemid
	,null as visitid
from ICEHR.t_community_referral t_community_referral
left outer join ICEHR.t_users t_users on t_users.memberguid = t_community_referral.memberguid 
inner join ICEHR.t_patients_additional_careteam_member t_patients_additional_careteam_member on t_community_referral.communityreferralguid = t_patients_additional_careteam_member.communityreferralguid 
inner join ICEHR.t_community t_community on t_community.communityguid = t_community_referral.communityguid 


union all

-- to reach visits level referring physicians
select t_community_referral.communityreferralguid as referralid
	,t_community_referral.active as referralrecordactiveindicator
	,t_community_referral.createdate as referralrecordcreateddatetime
	,t_users.userguid as referralrecordcreatedbyuserid
	,'visitreferral' as referralreasondescription
	,t_community_referral.communityreferralguid as referringproviderid
	,concat(t_community_referral.firstname,' ', t_community_referral.lastname) as referringprovidername
	,t_community_referral.firstname as referringproviderfirstname
	,t_community_referral.lastname as referringproviderlastname
	,t_community_referral.middlename as referringprovidermiddlename
	,t_community_referral.speciality as referringproviderspecialtydescription
	,t_community_referral.taxonomycode as referringprovidertaxonomycode
	,t_community_referral.fax as referringproviderfaxnumber
	,t_community_referral.phone as referringprovidertelephonenumber
	,t_community_referral.directemail as referringproviderdirectemailaddress
	,t_community_referral.preferredcontactmethod as referringproviderpreferredcontactmethoddescription
	,t_visits.patientguid as patientid
	,t_community_referral.communityguid as practiceid
    ,t_community.license as practicename
	,'IC-EHR' as datasourcesystemid
	,t_visits.visitguid as visitid
from ICEHR.t_community_referral t_community_referral
left outer join ICEHR.t_users t_users on t_users.memberguid = t_community_referral.memberguid 
inner join ICEHR.t_visits_referring_physician t_visits_referring_physician on t_community_referral.communityreferralguid = t_visits_referring_physician.communityreferralguid 
inner join ICEHR.t_visits t_visits on t_visits.visitguid = t_visits_referring_physician.visitguid 
inner join ICEHR.t_community t_community on t_community.communityguid = t_community_referral.communityguid 

  );