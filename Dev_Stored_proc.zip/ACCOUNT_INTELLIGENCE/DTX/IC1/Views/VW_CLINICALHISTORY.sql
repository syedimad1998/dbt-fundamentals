create or replace view IC1_VIEW.VW_CLINICALHISTORY(
	CLINICALHISTORYID,
	CLINICALHISTORYRECORDCREATEDBYUSERID,
	CLINICALHISTORYRECORDCREATEDDATETIME,
	CLINICALHISTORYRECORDDELETEDDATETIME,
	CLINICALHISTORYITEMDESCRIPTION,
	CLINICALHISTORYTREATMENTTYPEDESCRIPTION,
	CLINICALHISTORYTREATMENTEFFECTIVESTARTDATE,
	CLINICALHISTORYTREATMENTEFFECTIVEENDDATE,
	CLINICALHISTORYFACILITYNAME,
	CLINICALHISTORYSNOMEDCODE,
	CLINICALHISTORYPATIENTAGEATPROCEDUREVALUE,
	CLINICALHISTORYMENSTRUALPERIODDATE,
	CLINICALHISTORYPELVICEXAMPERFORMEDDATE,
	CLINICALHISTORYCONTRACEPTIVETYPEUSEDDESCRIPTION,
	CLINICALHISTORYLASTBREASTEXAMDATE,
	CLINICALHISTORYPERFORMSSELFBREASTEXAMSINDICATOR,
	CLINICALHISTORYLASTMAMMOGRAMDATE,
	CLINICALHISTORYPATIENTCOLONOSCOPYDATE,
	CLINICALHISTORYFLUVACCINEDATE,
	CLINICALHISTORYPNEUMONIAVACCINEADMINDATE,
	CLINICALHISTORYLASTPSARESULTDATE,
	CLINICALHISTORYLASTPSAVALUE,
	CLINICALHISTORYSIGMOIDOSCOPYPERFORMEDDATE,
	CLINICALHISTORYPROVIDERCOMMENTTEXT,
	PATIENTID,
	PRACTICEID,
	PRACTICENAME,
	DATASOURCESYSTEMID
) as (
    /*
******************************************** NOTES START ********************************************
Table: ClinicalHistory - contains Hospitalizations, Surgeries, Medical History, Immunization and Female Health
Comments: A little tricky table. Requires a few queries to populate. Data is accessed from
t_patients_hospitalization, t_patients_surgical_history, t_patients_health_condition,
t_patients_immunization, t_patients_injections, t_patients_medical_history,
t_patients and t_member
******************************************** NOTES END ********************************************
*/



with cte as (


-- Hospitalizations
select t_patients_hospitalization.patienthospitalizationguid as clinicalhistoryid
,t_patients_hospitalization.userguid as clinicalhistoryrecordcreatedbyuserid 
,t_patients_hospitalization.createdate as clinicalhistoryrecordcreateddatetime
,t_patients_hospitalization.deletedate as clinicalhistoryrecorddeleteddatetime
,t_patients_hospitalization.reason as clinicalhistoryitemdescription
,'Hospitalizations' as clinicalhistorytreatmenttypedescription
,t_patients_hospitalization.checkin as clinicalhistorytreatmenteffectivestartdate
,t_patients_hospitalization.checkout as clinicalhistorytreatmenteffectiveenddate
,t_patients_hospitalization.hospital as clinicalhistoryfacilityname
,null as clinicalhistorysnomedcode
,null as clinicalhistorypatientageatprocedurevalue 
,null as clinicalhistorymenstrualperioddate
,null as clinicalhistorypelvicexamperformeddate
,null as clinicalhistorycontraceptivetypeuseddescription
,null as clinicalhistorylastbreastexamdate
,null as clinicalhistoryperformsselfbreastexamsindicator
,null as clinicalhistorylastmammogramdate
,null as clinicalhistorypatientcolonoscopydate
,null as clinicalhistoryfluvaccinedate
,null as clinicalhistorypneumoniavaccineadmindate
,null as clinicalhistorylastpsaresultdate
,null as clinicalhistorylastpsavalue
,null as clinicalhistorysigmoidoscopyperformeddate
,null as clinicalhistoryprovidercommenttext 
,t_patients_hospitalization.patientguid as patientid
,t_member.homecommunityguid as practiceid
,t_community.license as practicename
,'IC-EHR' as datasourcesystemid

from ICEHR.t_patients_hospitalization t_patients_hospitalization
inner join ICEHR.t_patients t_patients on (t_patients_hospitalization.patientguid = t_patients.patientguid) 
inner join ICEHR.t_member t_member on (t_patients.memberguid = t_member.memberguid) 
inner join ICEHR.t_community t_community on (t_community.communityguid = t_member.homecommunityguid) 

union all

-- Medical History
select t_patients_health_condition.patienthealthconditionguid as clinicalhistoryid
,t_patients_health_condition.userguid as clinicalhistoryrecordcreatedbyuserid
,t_patients_health_condition.createdate as clinicalhistoryrecordcreateddatetime
,t_patients_health_condition.deletedate as clinicalhistoryrecorddeleteddatetime
,t_patients_health_condition.description as clinicalhistoryitemdescription
,'Medical History' AS ClinicalHistoryTreatmentTypeDescription
,null as clinicalhistorytreatmenteffectivestartdate
,null as clinicalhistorytreatmenteffectiveenddate
,null as clinicalhistoryfacilityname
,t_patients_health_condition.snomed as clinicalhistorysnomedcode
,t_patients_health_condition.patientageonset as clinicalhistorypatientageatprocedurevalue
,null as clinicalhistorymenstrualperioddate
,null as clinicalhistorypelvicexamperformeddate
,null as clinicalhistorycontraceptivetypeuseddescription
,null as clinicalhistorylastbreastexamdate
,null as clinicalhistoryperformsselfbreastexamsindicator
,null as clinicalhistorylastmammogramdate
,null as clinicalhistorypatientcolonoscopydate
,null as clinicalhistoryfluvaccinedate
,null as clinicalhistorypneumoniavaccineadmindate
,null as clinicalhistorylastpsaresultdate
,null as clinicalhistorylastpsavalue
,null as clinicalhistorysigmoidoscopyperformeddate
,null as clinicalhistoryprovidercommenttext
,t_patients_health_condition.patientguid as patientid
,t_member.homecommunityguid as practiceid
,t_community.license as practicename
,'IC-EHR' as datasourcesystemid

from ICEHR.t_patients_health_condition t_patients_health_condition
inner join ICEHR.t_patients t_patients on (t_patients_health_condition.patientguid = t_patients.patientguid) 
inner join ICEHR.t_member t_member on (t_patients.memberguid = t_member.memberguid) 
inner join ICEHR.t_community t_community on (t_community.communityguid = t_member.homecommunityguid) 
where( t_patients_health_condition.patientaffected = FALSE) 

union all

--female health
select t_patients_medical_history.patientmedicalhistoryguid as clinicalhistoryid
,t_patients_medical_history.userguid as clinicalhistoryrecordcreatedbyuserid
,t_patients_medical_history.createdate as clinicalhistoryrecordcreateddatetime
,t_patients_medical_history.deletedate as clinicalhistoryrecorddeleteddatetime
,null as clinicalhistoryitemdescription
,'Female Health' as clinicalhistorytreatmenttypedescription
,null as clinicalhistorytreatmenteffectivestartdate
,null as clinicalhistorytreatmenteffectiveenddate
,null as clinicalhistoryfacilityname
,null as clinicalhistorysnomedcode
,null as clinicalhistorypatientageatprocedurevalue
,t_patients_medical_history.femalelastmenstrualperiod as clinicalhistorymenstrualperioddate
,t_patients_medical_history.femalepelvicexam as clinicalhistorypelvicexamperformeddate
,t_patients_medical_history.femalecontraceptives as clinicalhistorycontraceptivetypeuseddescription
,t_patients_medical_history.femalelastbreastexam as clinicalhistorylastbreastexamdate
,t_patients_medical_history.femaleperformselfbreastexams as clinicalhistoryperformsselfbreastexamsindicator
,t_patients_medical_history.femalelastmammogram as clinicalhistorylastmammogramdate
,t_patients_medical_history.femalecolonoscopy as clinicalhistorypatientcolonoscopydate
,t_patients_medical_history.femalefluvaccine as clinicalhistoryfluvaccinedate
,t_patients_medical_history.femalepneumoniavaccine as clinicalhistorypneumoniavaccineadmindate
,t_patients_medical_history.lastpsa as clinicalhistorylastpsaresultdate
,t_patients_medical_history.psavalue as clinicalhistorylastpsavalue
,t_patients_medical_history.femalesigmoidoscopy as clinicalhistorysigmoidoscopyperformeddate
,t_patients_medical_history.comment as clinicalhistoryprovidercommenttext
,t_patients_medical_history.patientguid as patientid
,t_member.homecommunityguid as practiceid
,t_community.license as practicename
,'IC-EHR' as datasourcesystemid

from ICEHR.t_patients_medical_history t_patients_medical_history
inner join ICEHR.t_patients t_patients on (t_patients_medical_history.patientguid = t_patients.patientguid) 
inner join ICEHR.t_member t_member on (t_patients.memberguid = t_member.memberguid) 
inner join ICEHR.t_community t_community on (t_community.communityguid = t_member.homecommunityguid) 
where (
		t_patients_medical_history.femalelastmenstrualperiod is not null
		or
		t_patients_medical_history.femalepelvicexam is not null
		or
		t_patients_medical_history.femalecontraceptives is not null
		or 
		t_patients_medical_history.femalelastbreastexam is not null
		or 
		t_patients_medical_history.femaleperformselfbreastexams is not null
		or
		t_patients_medical_history.femalelastmammogram is not null
		or
		t_patients_medical_history.femalecolonoscopy is not null
		or
		t_patients_medical_history.femalefluvaccine is not null
		or
		t_patients_medical_history.femalepneumoniavaccine is not null
		or
		t_patients_medical_history.lastpsa is not null
		or
		t_patients_medical_history.psavalue is not null 
		or
		t_patients_medical_history.femalesigmoidoscopy is not null 
		or 
		t_patients_medical_history.comment is not null
		)
   
union all

select t_patients_health_condition.patienthealthconditionguid as clinicalhistoryid
,t_patients_health_condition.userguid as clinicalhistoryrecordcreatedby
,t_patients_health_condition.createdate as clinicalhistoryrecordcreateddatetime
,t_patients_health_condition.deletedate as clinicalhistoryrecorddeleteddatetime
,t_patients_health_condition.description as clinicalhistoryitemdescription
,'Past Medical History' as clinicalhistorytreatmenttypedescription
 ,null as clinicalhistorytreatmenteffectivestartdate
,null as clinicalhistorytreatmenteffectiveenddate
 ,null as clinicalhistoryfacilityname
 ,t_patients_health_condition.snomed as clinicalhistorysnomedcode
,t_patients_health_condition.patientageonset as clinicalhistorypatientageatprocedure
,null as clinicalhistorymenstrualperioddate
,null as clinicalhistorypelvicexamperformeddate
,null as clinicalhistorycontraceptivetypeused
,null as clinicalhistorylastbreastexamdate
,null as clinicalhistoryperformsselfbreastexamsindicator
,null as clinicalhistorylastmammogramdate
,null as clinicalhistorypatientcolonoscopydate
,null as clinicalhistoryfluvaccinedate
,null as clinicalhistorypneumoniavaccineadmindate
,null as clinicalhistorylastpsaresultdate
,null as clinicalhistorylastpsavalue
,null as clinicalhistorysigmoidoscopyperformeddate
,null as clinicalhistoryprovidercomment
,t_patients_health_condition.patientguid as patientid
,t_member.homecommunityguid as practiceid
,t_community.license as practicename
,'IC-EHR' as datasourcesystemid

from ICEHR.t_patients_health_condition t_patients_health_condition
inner join ICEHR.t_patients t_patients on (t_patients_health_condition.patientguid = t_patients.patientguid) 
inner join ICEHR.t_member t_member on (t_patients.memberguid = t_member.memberguid) 
inner join ICEHR.t_community t_community on (t_community.communityguid = t_member.homecommunityguid) 
where (t_patients_health_condition.patientaffected = TRUE) 
)
select * from cte where clinicalhistoryrecorddeleteddatetime IS NULL
  );