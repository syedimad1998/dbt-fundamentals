create or replace view IC1_VIEW.VW_FACILITYADDRESS(
	ADDRESSID,
	PRACTICEID,
	PRACTICENAME,
	DATASOURCESYSTEMID,
	FACILITYID
) as (
    /* 
********************************************  NOTES START  ********************************************
Table: Facility Address
Comments: Stores Facility Address


********************************************  NOTES END    ********************************************
*/



select 
	 t_address.addressguid  as addressid
	,t_facility.communityguid  as practiceid
	,t_community.license as practicename
	,'IC-EHR' as datasourcesystemid
	,t_facility.facilityguid  as facilityid 

from ICEHR.t_facility t_facility
inner join  ICEHR.t_address t_address on (t_facility.facilityguid = t_address.foreignkeyguid) 
inner join ICEHR.t_community  t_community on (t_facility.communityguid = t_community.communityguid) 
  );