create or replace view IC1_VIEW.VW_VITALSIGN(
	VITALSIGNID,
	PROVIDERID,
	VITALSIGNTAKENANDRECORDEDDATE,
	VITALSIGNTAKENANDRECORDEDDATETIME,
	VITALSIGNTAKENANDRECORDEDBYUSERID,
	LOINCCODE,
	VITALSIGNPULSERATEVALUE,
	VITALSIGNRESPIRATIONSVALUE,
	VITALSIGNTEMPERATUREVALUE,
	VITALSIGNTEMPERATUREMETHODOFMEASUREMENTDESCRIPTION,
	VITALSIGNHEIGHTVALUE,
	VITALSIGNWEIGHTINPOUNDSVALUE,
	VITALSIGNBPCUFFSIZEDESCRIPTION,
	VITALSIGNBPDIASTOLICLEFTARMSEATEDVALUE,
	VITALSIGNBPDIASTOLICRIGHTARMSEATEDVALUE,
	VITALSIGNBPSYSTOLICLEFTARMSEATEDVALUE,
	VITALSIGNBPSYSTOLICRIGHTARMSEATEDVALUE,
	VITALSIGNBPDIASTOLICLEFTARMSTANDINGVALUE,
	VITALSIGNBPDIASTOLICRIGHTARMSTANDINGVALUE,
	VITALSIGNBPSYSTOLICLEFTARMSTANDINGVALUE,
	VITALSIGNBPSYSTOLICRIGHTARMSTANDINGVALUE,
	VITALSIGNBPDIASTOLICLEFTARMSUPINEVALUE,
	VITALSIGNBPDIASTOLICRIGHTARMSUPINEVALUE,
	VITALSIGNBPSYSTOLICLEFTARMSUPINEVALUE,
	VITALSIGNBPSYSTOLICRIGHTARMSUPINEVALUE,
	VITALSIGNBMIVALUE,
	VITALSIGNBSAVALUE,
	VITALSIGNOXYGENSATURATIONVALUE,
	VITALSIGNOXYGENFLOWRATEVALUE,
	VITALSIGNHEADCIRCUMFERENCEVALUE,
	VITALSIGNWAISTCIRCUMFERENCEVALUE,
	PATIENTID,
	PRACTICEID,
	PRACTICENAME,
	DATASOURCESYSTEMID,
	VISITID,
	FACILITYID
) as (
    /*
******************************************** NOTES START ********************************************
Table: VitalSigns
Comments: Requires t_visits_vital, t_patients and t_member
******************************************** NOTES END ********************************************
*/



select
	t_visits_vital.visitvitalguid as vitalsignid
	,t_visits.userguid as providerid
	,t_visits_vital.createdate as vitalsigntakenandrecordeddate
	,t_visits_vital.vitaltakentime as vitalsigntakenandrecordeddatetime
	,t_visits_vital.userguid as vitalsigntakenandrecordedbyuserid
	,t_visits_vital.loinc as loinccode
	,t_visits_vital.pulse as vitalsignpulseratevalue
	,t_visits_vital.respiratoryrate as vitalsignrespirationsvalue
	,t_visits_vital.temperature as vitalsigntemperaturevalue
	,t_visits_vital.temperaturemethod as vitalsigntemperaturemethodofmeasurementdescription
	,t_visits_vital.height as vitalsignheightvalue
	,t_visits_vital.weight as VitalSignWeightInPoundsValue
	,t_visits_vital.bloodpressurecupsize as VitalSignBpCuffSizeDescription
	,(case when t_visits_vital.bpcufflocation != 'la' then null else t_visits_vital.bloodpressuresittingdiastolicleft end ) as vitalsignbpdiastolicleftarmseatedvalue
	,(case when t_visits_vital.bpcufflocation != 'ra' then null else t_visits_vital.bloodpressuresittingdiastolicright end) as vitalsignbpdiastolicrightarmseatedvalue
	,(case when t_visits_vital.bpcufflocation != 'la' then null else t_visits_vital.bloodpressuresittingsystolicleft end) as vitalsignbpsystolicleftarmseatedvalue
	,(case when t_visits_vital.bpcufflocation != 'ra' then null else t_visits_vital.bloodpressuresittingsystolicright end) as vitalsignbpsystolicrightarmseatedvalue
	,(case when t_visits_vital.bpcufflocation != 'la' then null else t_visits_vital.bloodpressurestandingdiastolicleft end) as vitalsignbpdiastolicleftarmstandingvalue
	,(case when t_visits_vital.bpcufflocation != 'ra' then null else t_visits_vital.bloodpressurestandingdiastolicright end) as vitalsignbpdiastolicrightarmstandingvalue
	,(case when t_visits_vital.bpcufflocation != 'la' then null else t_visits_vital.bloodpressurestandingsystolicleft end) as vitalsignbpsystolicleftarmstandingvalue
	,(case when t_visits_vital.bpcufflocation != 'ra' then null else t_visits_vital.bloodpressurestandingsystolicright end) as vitalsignbpsystolicrightarmstandingvalue
	,(case when t_visits_vital.bpcufflocation != 'la' then null else t_visits_vital.bloodpressuresupinediastolicleft end) as vitalsignbpdiastolicleftarmsupinevalue
	,(case when t_visits_vital.bpcufflocation != 'ra' then null else t_visits_vital.bloodpressuresupinediastolicright end) as vitalsignbpdiastolicrightarmsupinevalue
	,(case when t_visits_vital.bpcufflocation != 'la' then null else t_visits_vital.bloodpressuresupinesystolicleft end) as vitalsignbpsystolicleftarmsupinevalue
	,(case when t_visits_vital.bpcufflocation != 'ra' then null else t_visits_vital.bloodpressuresupinesystolicright end) as vitalsignbpsystolicrightarmsupinevalue
	,t_visits_vital.bodymassindex as vitalsignbmivalue
	,t_visits_vital.bsa as vitalsignbsavalue
	,t_visits_vital.o2sat as vitalsignoxygensaturationvalue
	,t_visits_vital.o2flowrate  as vitalsignoxygenflowratevalue
	,t_visits_vital.headcircumference as vitalsignheadcircumferencevalue
	,t_visits_vital.waistcircumference as vitalsignwaistcircumferencevalue
	,t_visits.patientguid as patientid
	,t_member.homecommunityguid as practiceid
	,t_community.license as practicename
	,'IC-EHR' as datasourcesystemid
	,t_visits.visitguid as visitid
	,t_visits.facilityguid as facilityid
from  ICEHR.t_visits_vital  t_visits_vital
inner join  ICEHR.t_visits  t_visits on (t_visits_vital.visitguid = t_visits.visitguid) 
inner join  ICEHR.t_patients  t_patients on (t_visits.patientguid = t_patients.patientguid) 
inner join  ICEHR.t_member  t_member on (t_patients.memberguid = t_member.memberguid) 
inner join  ICEHR.t_community  t_community on t_community.communityguid = t_member.homecommunityguid 

  );