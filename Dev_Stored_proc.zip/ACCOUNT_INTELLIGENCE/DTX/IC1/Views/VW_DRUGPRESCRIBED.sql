create or replace view IC1_VIEW.VW_DRUGPRESCRIBED(
	DRUGORDERID,
	DRUGPRESCRIBEDORDERID,
	PRESCRIBINGPROVIDERID,
	DRUGPRESCRIBEDMEDICATIONNAME,
	DRUGPRESCRIBEDFDBMEDICATIONID,
	DRUGPRESCRIBEDDRFIRSTPRESCRIPTIONID,
	DRUGPRESCRIBEDMEDICATIONNDCID,
	DRUGPRESCRIBEDRXNORMCODE,
	DRUGPRESCRIBEDMEDICATIONDOSEDESCRIPTION,
	DRUGPRESCRIBEDMEDICATIONDOSEUNITOFMEASURE,
	DRUGPRESCRIBEDMEDICATIONDOSESTRENGTHVALUE,
	DRUGPRESCRIBEDMEDICATIONDOSEFREQUENCYVALUE,
	DRUGPRESCRIBEDMEDICATIONREFILLNUMBER,
	DRUGPRESCRIBEDMEDICATIONSTARTDATE,
	DRUGPRESCRIBEDMEDICATIONENDDATE,
	DRUGPRESCRIBEDMEDICATIONVERIFIEDDATE,
	PATIENTID,
	PRACTICEID,
	DATASOURCESYSTEMID,
	PRACTICENAME
) as (
    /*
******************************************** NOTES START ********************************************
Table: DrugPrescribed
Comments: Prescription drugs

Note:  

******************************************** NOTES END ********************************************
*/




with review as (
select 
		 t_visits.patientguid
        ,t_visits_additional_data.medicationreviewdate
		,t_visits_additional_data.medicationreviewstatus
		,t_visits_additional_data.medicationuserguid
		,row_number() over(partition by t_visits.patientguid
                                         order by t_visits.createdate) as rn
	from ICEHR.t_visits 
	inner join ICEHR.t_visits_additional_data t_visits_additional_data on (t_visits_additional_data.visitguid = t_visits.visitguid) 
	where (t_visits_additional_data.medicationreviewdate is not null) 
	order by t_visits.createdate desc
),
meds as
(
	select p.id as patientid
	, pm.*
	,row_number() over ( partition by p.id, regimenagentid
									 order by pm.createdate desc) as rn 
	from  ICEHR.t_patients_medication pm
	inner join  ICEHR.t_patients p on pm.patientguid=p.patientguid
	where (regimenagentid is not null) and (regimenagentid != 0) 
)
-- medications
select
	null  as drugorderid,
	t_patients_medication.patientmedicationguid as  drugprescribedorderid,
	t_patients_medication.prescriberuserguid as prescribingproviderid,
	t_patients_medication.name as drugprescribedmedicationname,
	t_patients_medication.firstdatabankmedicationid as drugprescribedfdbmedicationid,
	t_patients_medication.rcopiaprescriptionid as drugprescribeddrfirstprescriptionid,
	t_patients_medication.ndcode as drugprescribedmedicationndcid,
	t_patients_medication.rxnorm as drugprescribedrxnormcode,
	t_patients_medication.doseform as drugprescribedmedicationdosedescription,
	t_patients_medication.unit as drugprescribedmedicationdoseunitofmeasure,
	t_patients_medication.strength as drugprescribedmedicationdosestrengthvalue,
	t_patients_medication.packagequantityunit as drugprescribedmedicationdosefrequencyvalue,
	t_patients_medication.refills as drugprescribedmedicationrefillnumber,
	t_patients_medication.scriptbegindatetime as drugprescribedmedicationstartdate,
	t_patients_medication.scriptenddatetime as drugprescribedmedicationenddate,
	review.medicationreviewdate as drugprescribedmedicationverifieddate,
	t_patients_medication.patientguid as patientid,
	t_member.homecommunityguid as practiceid,
	'IC-EHR' as datasourcesystemid,
	t_community.license as practicename

from   ICEHR.t_patients_medication t_patients_medication
inner join ICEHR.t_patients  t_patients on (t_patients.patientguid = t_patients_medication.patientguid )
inner join ICEHR.t_member t_member   on (t_member.memberguid = t_patients.memberguid) 
inner join ICEHR.t_community t_community on (t_member.homecommunityguid = t_community.communityguid)
left outer join review on t_patients.patientguid = review.patientguid and review.rn = TRUE 
left outer join  ICEHR.t_onc_chemoadmin_patientchemoregimencycledayagent 
	on t_patients.id =  t_onc_chemoadmin_patientchemoregimencycledayagent.patientid and
		t_onc_chemoadmin_patientchemoregimencycledayagent.agentid = t_patients_medication.regimenagentid 
	where  t_patients_medication.prescribed = TRUE
		and t_onc_chemoadmin_patientchemoregimencycledayagent.id is null -- medications without agents link
		and t_patients_medication.isflowsheetagent = FALSE
		

union all

-- regimen  medications
select
	t_onc_chemoadmin_patientchemoregimencycledayagent.id  as drugorderid,
	meds.patientmedicationguid as  drugprescribedorderid,
	meds.prescriberuserguid as prescribingproviderid,
	meds.name as drugprescribedmedicationname,
	meds.firstdatabankmedicationid as drugprescribedfdbmedicationid,
	meds.rcopiaprescriptionid as drugprescribeddrfirstprescriptionid,
	meds.ndcode as drugprescribedmedicationndcid,
	meds.rxnorm as drugprescribedrxnormcode,
	meds.doseform as drugprescribedmedicationdosedescription,
	meds.unit as drugprescribedmedicationdoseunitofmeasure,
	meds.strength as drugprescribedmedicationdosestrengthvalue,
	meds.packagequantityunit as drugprescribedmedicationdosefrequencyvalue,
	meds.refills as drugprescribedmedicationrefillnumber,
	meds.scriptbegindatetime as drugprescribedmedicationstartdate,
	meds.scriptenddatetime as drugprescribedmedicationenddate,
	review.medicationreviewdate as drugprescribedmedicationverifieddate,
	meds.patientguid as patientid,
	t_member.homecommunityguid as practiceid,
	'IC-EHR' as datasourcesystemid,
	t_community.license as practicename

from ICEHR.t_onc_chemoadmin_patientchemoregimencycledayagent t_onc_chemoadmin_patientchemoregimencycledayagent
inner join ICEHR.t_onc_chemoadmin_patientchemoregimen t_onc_chemoadmin_patientchemoregimen
	on (t_onc_chemoadmin_patientchemoregimen.id = t_onc_chemoadmin_patientchemoregimencycledayagent.patientchemoregimenid)
inner join meds 
	on  (meds.patientid = t_onc_chemoadmin_patientchemoregimen.patientid)
		and (t_onc_chemoadmin_patientchemoregimencycledayagent.agentid = meds.regimenagentid)
		and (meds.rn = TRUE)
inner join ICEHR.t_patients t_patients  on (t_patients.id = t_onc_chemoadmin_patientchemoregimen.patientid) 
inner join ICEHR.t_member t_member on (t_member.memberguid = t_patients.memberguid) 
inner join ICEHR.t_community on( t_member.homecommunityguid = t_community.communityguid) 
left outer join review on t_patients.patientguid = review.patientguid and review.rn = TRUE 
where    (t_onc_chemoadmin_patientchemoregimencycledayagent.isprescribed = TRUE
		or meds.isflowsheetagent = TRUE)
		and t_onc_chemoadmin_patientchemoregimencycledayagent.isadditionalmedication = FALSE
		

union all

-- additional regimen  medications
select
	t_onc_chemoadmin_patientchemoregimencycledayagent.id  as drugorderid,
	meds.patientmedicationguid as  drugprescribedorderid,
	meds.prescriberuserguid as prescribingproviderid,
	meds.name as drugprescribedmedicationname,
	meds.firstdatabankmedicationid as drugprescribedfdbmedicationid,
	meds.rcopiaprescriptionid as drugprescribeddrfirstprescriptionid,
	meds.ndcode as drugprescribedmedicationndcid,
	meds.rxnorm as drugprescribedrxnormcode,
	meds.doseform as drugprescribedmedicationdosedescription,
	meds.unit as drugprescribedmedicationdoseunitofmeasure,
	meds.strength as drugprescribedmedicationdosestrengthvalue,
	meds.packagequantityunit as drugprescribedmedicationdosefrequencyvalue,
	meds.refills as drugprescribedmedicationrefillnumber,
	meds.scriptbegindatetime as drugprescribedmedicationstartdate,
	meds.scriptenddatetime as drugprescribedmedicationenddate,
	review.medicationreviewdate as drugprescribedmedicationverifieddate,
	meds.patientguid as patientid,
	t_member.homecommunityguid as practiceid,
	'IC-EHR' as datasourcesystemid,
	t_community.license as practicename

from ICEHR.t_onc_chemoadmin_patientchemoregimencycledayagent  t_onc_chemoadmin_patientchemoregimencycledayagent 
inner join meds 
	on  meds.patientid = t_onc_chemoadmin_patientchemoregimencycledayagent.patientid
		and t_onc_chemoadmin_patientchemoregimencycledayagent.agentid = meds.regimenagentid
		and meds.rn = TRUE

inner join ICEHR.t_patients t_patients on (t_patients.id = t_onc_chemoadmin_patientchemoregimencycledayagent.patientid )
inner join ICEHR.t_member  t_member on (t_member.memberguid = t_patients.memberguid )
inner join ICEHR.t_community t_community on( t_member.homecommunityguid = t_community.communityguid) 
left outer join review on t_patients.patientguid = review.patientguid and review.rn = TRUE 
where   ( t_onc_chemoadmin_patientchemoregimencycledayagent.isprescribed = TRUE
		or meds.isflowsheetagent = TRUE)
		and (t_onc_chemoadmin_patientchemoregimencycledayagent.isadditionalmedication = TRUE)
		
  );