create or replace view IC1_VIEW.VW_MEDICATION(
	MEDICATIONID,
	DRUGID,
	MEDICATIONCHEMOTHERAPYIDENTIFIER,
	MEDICATIONRECORDCREATEDDATETIME,
	MEDICATIONRECORDCREATEDBYUSERID,
	MEDICATIONORDEREDDATE,
	MEDICATIONISPRESCRIBEDINDICATOR,
	MEDICATIONPRESCRIPTIONNUMBER,
	MEDICATIONNAME,
	MEDICATIONNDCCODE,
	FIRSTPRESCRIPTIONID,
	MEDICATIONFDBID,
	MEDICATIONFDBMEDICATIONTYPEID,
	MEDICATIONROUTEOFADMINCODE,
	MEDICATIONDOSEQUANTITYUNITTEXT,
	MEDICATIONSTRENGTHVALUE,
	MEDICATIONREFILLSQUANTITY,
	MEDICATIONPRESCRIPTIONSTATUS,
	MEDICATIONSTARTDATE,
	MEDICATIONSTOPDATE,
	MEDICATIONDISCONTINUEDINDICATOR,
	MEDICATIONNOTETEXT,
	MEDICATIONREVIEWCOMPLETEINDICATOR,
	MEDICATIONREVIEWCOMPLETEDBYUSERID,
	MEDICATIONREVIEWCOMPLETEDATE,
	MEDICATIONRECONCILIATIONCOMPLETEDINDICATOR,
	MEDICATIONRECONCILIATIONCOMPLETEDDATE,
	MEDICATIONRECONCILIATIONCOMPLETEDBYUSERID,
	PATIENTID,
	PRACTICEID,
	PRACTICENAME,
	DATASOURCESYSTEMID,
	VISITID
) as (
    /* 
********************************************  NOTES START  ********************************************
Table: Medications
Comments: Reads data from Patients Medications

********************************************  NOTES END    ********************************************

*/



with review as (
select   t_visits.patientguid
        ,t_visits_additional_data.medicationreviewdate
		,t_visits_additional_data.medicationreviewstatus
		,t_visits_additional_data.medicationuserguid
        ,t_visits.createdate
        ,row_number() over(partition by t_visits.patientguid
                                         order by t_visits.createdate) as rn
from ICEHR.t_visits
inner join ICEHR.t_visits_additional_data 
on t_visits_additional_data.visitguid = t_visits.visitguid 
where (t_visits_additional_data.medicationreviewdate is not null) 
)

select 
	t_patients_medication.patientmedicationguid as medicationid
	,t_onc_chemoadmin_patientchemoregimencycledayagent.id as drugid
	,t_patients_medication.patientchemoregimenid as medicationchemotherapyidentifier
	,t_patients_medication.createdate as medicationrecordcreateddatetime
	,t_patients_medication.userguid as medicationrecordcreatedbyuserid
	,t_patients_medication.createdate as medicationordereddate
	,t_patients_medication.prescribed as medicationisprescribedindicator
	,t_patients_medication.prescription as medicationprescriptionnumber
	,t_patients_medication.name as medicationname
	,t_patients_medication.ndcode as medicationndccode
	,t_patients_medication.rcopiaprescriptionid as firstprescriptionid
	,t_patients_medication.firstdatabankmedicationid as medicationfdbid
	,t_patients_medication.firstdatabankmedicationtypeid as medicationfdbmedicationtypeid
	,t_patients_medication.route as medicationrouteofadmincode
	,t_patients_medication.unit as medicationdosequantityunittext
	,t_patients_medication.strength as medicationstrengthvalue
	,t_patients_medication.refills as medicationrefillsquantity
	,(
		CASE
		WHEN t_patients_medication.STATUS = 1
		THEN 'Active'
		WHEN t_patients_medication.STATUS = 2
		THEN 'Inactive'
		WHEN t_patients_medication.STATUS = 3
		THEN 'Errorneous'
		WHEN t_patients_medication.STATUS = 4
		THEN 'Completed'
		WHEN t_patients_medication.STATUS = 5
		THEN 'Discontinued'
		WHEN t_patients_medication.STATUS = 6
		THEN 'ChangeRx'
		WHEN t_patients_medication.STATUS = 7
		THEN 'CancelRx'
		WHEN t_patients_medication.STATUS = 8
		THEN 'Pending'
		WHEN t_patients_medication.STATUS = 1
		THEN 'Active'
		ELSE 'None'
		END
		) AS MedicationPrescriptionStatus
	,t_patients_medication.scriptbegindatetime as medicationstartdate
	,t_patients_medication.scriptenddatetime as medicationstopdate
	,(
		case 
			when t_patients_medication.status = 5
				then 1
			else 0
			end
		) as medicationdiscontinuedindicator
	,t_patients_medication.comments as medicationnotetext
	,(
		case
		when t_patients_medication.status = 4
		then 1
		else 0
		end
	 ) as medicationreviewcompleteindicator
	,review.medicationuserguid as medicationreviewcompletedbyuserid
	,review.medicationreviewdate as medicationreviewcompletedate
	,t_patients_medication.reconciled as medicationreconciliationcompletedindicator
	,t_patients_medication.reconcileddatetime as medicationreconciliationcompleteddate
	,t_patients_medication.reconcileduserguid as medicationreconciliationcompletedbyuserid
	,t_patients_medication.patientguid as patientid
	,t_member.homecommunityguid as practiceid
	,t_community.license as practicename
	,'IC-EHR' as datasourcesystemid
	,t_patients_medication.visitguid as visitid

from ICEHR.t_patients_medication t_patients_medication
inner join ICEHR.t_patients t_patients on t_patients.patientguid = t_patients_medication.patientguid 
inner join ICEHR.t_member t_member on t_member.memberguid = t_patients.memberguid 
inner join ICEHR.t_community t_community on t_member.homecommunityguid = t_community.communityguid 
left join review on review.medicationuserguid = t_patients_medication.userguid
left outer join ICEHR.t_onc_chemoadmin_patientchemoregimencycledayagent t_onc_chemoadmin_patientchemoregimencycledayagent on t_onc_chemoadmin_patientchemoregimencycledayagent.id = t_patients_medication.regimenagentid 
  );