create or replace view IC1_VIEW.VW_TREATMENTPLAN(
	TREATMENTPLANID,
	TREATMENTPLANCHEMOTHERAPYREGIMENID,
	TREATMENTPLANREGIMENCYCLEDAYID,
	TREATMENTPLANCYCLEDAYNUMBER,
	TREATMENTPLANCYCLENUMBER,
	TREATMENTPLANDISCONTINUEREASONDESCRIPTION,
	TREATMENTPLANDISCONTINUEDINDICATOR,
	TREATMENTPLANDISEASECATEGORYDESCRIPTION,
	TREATMENTPLANORDERAPPROVEDINDICATOR,
	TREATMENTPLANORDEREDDATETIME,
	TREATMENTPLANREGIMENNAME,
	TREATMENTPLANREGIMENCODE,
	TREATMENTPLANSTATUSDESCRIPTION,
	TREATMENTPLANTREATMENTINSTRUCTIONTEXT,
	TREATMENTPLANTREATMENTINTENTDESCRIPTION,
	TREATMENTPLANVERBALORDERSTATUSDESCRIPTION,
	PATIENTID,
	PRACTICEID,
	PRACTICENAME,
	DATASOURCESYSTEMID,
	TREATMENTPLANORDERINGPROVIDERID,
	TREATMENTPLANSTARTDATE,
	TREATMENTPLANPLANNEDSTARTDATE,
	DIAGNOSISID
) as (
    /*
******************************************** NOTES START ********************************************
Table: Treatment Plan Plan
Comments: Data at treatment plan day level

Note: 
******************************************** NOTES END ********************************************
*/



select t_onc_chemoadmin_patientchemoregimencycleday.patientchemoregimenid as treatmentplanid
	,t_onc_chemoadmin_patientchemoregimencycleday.patientchemoregimenid as treatmentplanchemotherapyregimenid
	,t_onc_chemoadmin_patientchemoregimencycleday.id as treatmentplanregimencycledayid
	,t_onc_chemoadmin_patientchemoregimencycleday.daynumber as treatmentplancycledaynumber
	,t_onc_chemoadmin_patientchemoregimencycleday.cyclenumber as treatmentplancyclenumber
	,t_regimen_discontinue.discontinuereason as treatmentplandiscontinuereasondescription
	,(
		case 
			when t_onc_chemoadmin_patientchemoregimen.regimendiscontinueid is not null
				then '1'
			else '0'
			end
		) as treatmentplandiscontinuedindicator
	,t_onc_chemoadmin_patientchemoregimen.regimendiscontinuecomments as treatmentplandiseasecategorydescription
	,t_onc_chemoadmin_patientchemoregimen.approved as treatmentplanorderapprovedindicator
	,t_onc_chemoadmin_patientchemoregimen.adt_createddate as treatmentplanordereddatetime
	,t_onc_chemotherapy_treatmentplan.title as treatmentplanregimenname
	,t_onc_chemotherapy_treatmentplan.regimencode as treatmentplanregimencode
	,(
		case 
			when t_onc_chemoadmin_patientchemoregimen.statusid = 1
				then 'assigned'
			when t_onc_chemoadmin_patientchemoregimen.statusid = 5
				then 'discontinued'
			when t_onc_chemoadmin_patientchemoregimen.statusid = 6
				then 'suspended'
			else 'unknown'
			end
		) as treatmentplanstatusdescription
	,t_onc_chemotherapy_treatmentplan.description as treatmentplantreatmentinstructiontext
	,t_onc_chemotherapy_intent.title as treatmentplantreatmentintentdescription
	,t_onc_chemoadmin_patientchemoregimen.verbalorderstatus as treatmentplanverbalorderstatusdescription
	,t_patients.patientguid as patientid
	,t_member.homecommunityguid as practiceid
    ,t_community.license as practicename
	,'IC-EHR' as datasourcesystemid
	,t_users.userguid as  treatmentplanorderingproviderid
	,t_onc_chemoadmin_patientchemoregimencycleday.actualstartdate as treatmentplanstartdate
	,t_onc_chemoadmin_patientchemoregimencycleday.plannedstartdate as treatmentplanplannedstartdate
	,t_patients_chronic_disorder.patientchronicdisorderguid as diagnosisid
from ICEHR.t_onc_chemoadmin_patientchemoregimencycleday t_onc_chemoadmin_patientchemoregimencycleday
inner join ICEHR.t_onc_chemoadmin_patientchemoregimencycle t_onc_chemoadmin_patientchemoregimencycle on (t_onc_chemoadmin_patientchemoregimencycle.id = t_onc_chemoadmin_patientchemoregimencycleday.patientchemoregimencycleid) 
inner join ICEHR.t_onc_chemoadmin_patientchemoregimen t_onc_chemoadmin_patientchemoregimen on (t_onc_chemoadmin_patientchemoregimencycleday.patientchemoregimenid = t_onc_chemoadmin_patientchemoregimen.id) 
left outer join ICEHR.t_member  m on (m.id = t_onc_chemoadmin_patientchemoregimen.providerid) 
left outer join ICEHR.t_users t_users on (t_users.memberguid = m.memberguid) 
inner join ICEHR.t_patients t_patients on (t_patients.id = t_onc_chemoadmin_patientchemoregimen.patientid) 
inner join ICEHR.t_member t_member on (t_member.memberguid = t_patients.memberguid) 
inner join ICEHR.t_community t_community on (t_community.communityguid = t_member.homecommunityguid) 
inner join ICEHR.t_onc_chemotherapy_treatmentplan t_onc_chemotherapy_treatmentplan on (t_onc_chemotherapy_treatmentplan.id = t_onc_chemoadmin_patientchemoregimen.regimenid) 
left outer join ICEHR.t_onc_chemotherapy_intent t_onc_chemotherapy_intent on (t_onc_chemotherapy_intent.id = t_onc_chemoadmin_patientchemoregimen.intentid) 
left outer join ICEHR.t_regimen_discontinue t_regimen_discontinue on (t_regimen_discontinue.regimendiscontinueid = t_onc_chemoadmin_patientchemoregimen.regimendiscontinueid) 
inner join ICEHR.t_patients_chronic_disorder on t_patients_chronic_disorder.patientchronicdisorderguid = t_onc_chemoadmin_patientchemoregimen.patientchronicdisorderguid 

  );