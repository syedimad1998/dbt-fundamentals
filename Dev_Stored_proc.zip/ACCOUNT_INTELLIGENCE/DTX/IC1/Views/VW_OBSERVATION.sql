create or replace view IC1_VIEW.VW_OBSERVATION(
	OBSERVATIONID,
	OBSERVATIONDATETIME,
	OBSERVATIONNAME,
	OBSERVATIONDESCRIPTION,
	OBSERVATIONPERFORMANCESCALEDESCRIPTION,
	OBSERVATIONECOGPERFORMANCESTATUSNUMBER,
	OBSERVATIONPAINASSESSMENTLOCATIONDESCRIPTION,
	OBSERVATIONPAINASSESSMENTSCALEVALUE,
	OBSERVATIONPAINASSESSMENTTREATMENTPLANDESCRIPTION,
	OBSERVATIONPATIENTQUESTIONNAIREID,
	OBSERVATIONPATIENTDEPRESSIONQUESTIONNAIRESCORINGVALUE,
	OBSERVATIONPATIENTDEPRESSIONQUESTIONNAIRESCORINGFEELINGBADVALUE,
	OBSERVATIONPATIENTDEPRESSIONQUESTIONNAIRESCORINGFEELINGDOWNVALUE,
	OBSERVATIONPATIENTDEPRESSIONQUESTIONNAIRESCORINGFEELINGTIREDVALUE,
	OBSERVATIONPATIENTDEPRESSIONQUESTIONNAIRESCORINGLITTLEINTERESTVALUE,
	OBSERVATIONPATIENTDEPRESSIONQUESTIONNAIRESCORINGMOVINGSLOWLYVALUE,
	OBSERVATIONPATIENTDEPRESSIONQUESTIONNAIRESCORINGPOORAPPETITEVALUE,
	OBSERVATIONPATIENTDEPRESSIONQUESTIONNAIRESCORINGTHOUGHTSBETTEROFFDEADVALUE,
	OBSERVATIONPATIENTDEPRESSIONQUESTIONNAIRESCORINGTROUBLECONCENTRATINGVALUE,
	OBSERVATIONPATIENTDEPRESSIONQUESTIONNAIRESCORINGTROUBLESLEEPVALUE,
	OBSERVATIONDEPRESSIONSEVERITYDESCRIPTION,
	OBSERVATIONPATIENTQUESTIONNAIREASSESSEDBYUSERID,
	OBSERVATIONASSESSMENTDELETEDINDICATOR,
	OBSERVATIONQUESTIONNAIREDELETEDINDICATOR,
	PATIENTID,
	PRACTICEID,
	PRACTICENAME,
	DATASOURCESYSTEMID,
	VISITID
) as (
    /*
******************************************** NOTES START ********************************************
Table: Observation
Comments:  This has Patient Health Questionaire, Performance Status and Pain 

******************************************** NOTES END ********************************************
*/



with cte as (

--patient health questionaire
select  t_onc_patient_health_questionnaire.patienthealthquestionnaireid as observationid
	,t_onc_patient_health_questionnaire.dateofservice as observationdatetime
	,'patient health questionaire' as observationname
	,null as observationdescription
	,null as observationperformancescaledescription
	,null as observationecogperformancestatusnumber
	,null as observationpainassessmentlocationdescription
	,null as observationpainassessmentscalevalue
	,null as observationpainassessmenttreatmentplandescription
	,t_onc_patient_health_questionnaire.patienthealthquestionnaireid as observationpatientquestionnaireid
	,t_onc_patient_health_questionnaire.phq_grandtotal as observationpatientdepressionquestionnairescoringvalue
	,t_onc_patient_health_questionnaire.phq9_feelingbad as observationpatientdepressionquestionnairescoringfeelingbadvalue
	,t_onc_patient_health_questionnaire.phq9_feelingdown as observationpatientdepressionquestionnairescoringfeelingdownvalue
	,t_onc_patient_health_questionnaire.phq9_feelingtired as observationpatientdepressionquestionnairescoringfeelingtiredvalue
	,t_onc_patient_health_questionnaire.phq9_littleinterest as observationpatientdepressionquestionnairescoringlittleinterestvalue
	,t_onc_patient_health_questionnaire.phq9_movingslowly as observationpatientdepressionquestionnairescoringmovingslowlyvalue
	,t_onc_patient_health_questionnaire.phq9_poorappetite as observationpatientdepressionquestionnairescoringpoorappetitevalue
	,t_onc_patient_health_questionnaire.phq9_thoughtsbetterofdead as observationpatientdepressionquestionnairescoringthoughtsbetteroffdeadvalue
	,t_onc_patient_health_questionnaire.phq9_troubleconcentrating as observationpatientdepressionquestionnairescoringtroubleconcentratingvalue
	,t_onc_patient_health_questionnaire.phq9_troublesleep as observationpatientdepressionquestionnairescoringtroublesleepvalue
	,t_onc_patient_health_questionnaire.severity as observationdepressionseveritydescription
	,t_onc_patient_health_questionnaire.userguid as observationpatientquestionnaireassessedbyuserid
	,False as observationassessmentdeletedindicator
	,t_onc_patient_health_questionnaire.isdeleted as observationquestionnairedeletedindicator
	,t_onc_patient_health_questionnaire.patientguid as patientid
	,t_member.homecommunityguid as practiceid
	,t_community.license as practicename
	,'IC-EHR' as datasourcesystemid
	,null as visitid

from ICEHR.t_onc_patient_health_questionnaire t_onc_patient_health_questionnaire
inner join ICEHR.t_patients t_patients on (t_patients.patientguid = t_onc_patient_health_questionnaire.patientguid) 
inner join ICEHR.t_member t_member on (t_member.memberguid = t_patients.memberguid) 
inner join ICEHR.t_community t_community on (t_community.communityguid = t_member.homecommunityguid) 


union all

-- pain
select
	t_onc_nursenotes_pain.id as observationid
	,t_onc_nursenotes_pain.chartdate as observationdatetime
	,'pain' as observationname
	,null as observationdescription
	,null as observationperformancescaledescription
	,null as observationecogperformancestatusnumber
	,t_onc_nursenotes_pain.painlocation as observationpainassessmentlocationdescription
	,t_onc_nursenotes_pain.painscale as observationpainassessmentscalevalue
	,t_onc_nursenotes_pain.painplan as observationpainassessmenttreatmentplandescription
	,null as observationpatientquestionnaireid
	,null as observationpatientdepressionquestionnairescoringvalue
	,null as observationpatientdepressionquestionnairescoringfeelingbadvalue
	,null as observationpatientdepressionquestionnairescoringfeelingdownvalue
	,null as observationpatientdepressionquestionnairescoringfeelingtiredvalue
	,null as observationpatientdepressionquestionnairescoringlittleinterestvalue
	,null as observationpatientdepressionquestionnairescoringmovingslowlyvalue
	,null as observationpatientdepressionquestionnairescoringpoorappetitevalue
	,null as observationpatientdepressionquestionnairescoringthoughtsbetteroffdeadvalue
	,null as observationpatientdepressionquestionnairescoringtroubleconcentratingvalue
	,null as observationpatientdepressionquestionnairescoringtroublesleepvalue
	,null as observationdepressionseveritydescription
	,null as observationpatientquestionnaireassessedbyuserid
	,t_onc_nursenotes_pain.isdeleted as observationassessmentdeletedindicator
	,null as observationquestionnairedeletedindicator
	,t_patients.patientguid as patientid
	,t_member.homecommunityguid as practiceid
	,t_community.license as practicename
	,'IC-EHR' as datasourcesystemid
	,t_onc_nursenotes_pain.visitguid as visitid
from ICEHR.t_onc_nursenotes_pain t_onc_nursenotes_pain
inner join ICEHR.t_patients t_patients on (t_patients.id = t_onc_nursenotes_pain.patientid) 
inner join ICEHR.t_member t_member on (t_member.memberguid = t_patients.memberguid) 
inner join ICEHR.t_community t_community on (t_community.communityguid = t_member.homecommunityguid) 


union all

-- performance status
select t_onc_oncology_patientperformance.id as observationid
	,t_onc_oncology_patientperformance.recorddate as observationdatetime
	,'performance status' as observationname
	,t_onc_oncology_performancestatus.definition as observationdescription
	,t_onc_oncology_performancestatus.scale as observationperformancescaledescription
	,t_onc_oncology_performancestatus.score as observationecogperformancestatusnumber
	,null as observationpainassessmentlocationdescription
	,null as observationpainassessmentscalevalue
	,null as observationpainassessmenttreatmentplandescription
	,null as observationpatientquestionnaireid
	,null as observationpatientdepressionquestionnairescoringvalue
	,null as observationpatientdepressionquestionnairescoringfeelingbadvalue
	,null as observationpatientdepressionquestionnairescoringfeelingdownvalue
	,null as observationpatientdepressionquestionnairescoringfeelingtiredvalue
	,null as observationpatientdepressionquestionnairescoringlittleinterestvalue
	,null as observationpatientdepressionquestionnairescoringmovingslowlyvalue
	,null as observationpatientdepressionquestionnairescoringpoorappetitevalue
	,null as observationpatientdepressionquestionnairescoringthoughtsbetteroffdeadvalue
	,null as observationpatientdepressionquestionnairescoringtroubleconcentratingvalue
	,null as observationpatientdepressionquestionnairescoringtroublesleepvalue
	,null as observationdepressionseveritydescription
	,null as observationpatientquestionnaireassessedbyuserid
	,t_onc_oncology_patientperformance.isdeleted as observationassessmentdeletedindicator
	,null as observationquestionnairedeletedindicator
	,t_patients.patientguid as patientid
	,t_member.homecommunityguid as practiceid
	,t_community.license as practicename
	,'IC-EHR' as datasourcesystemid
	,t_onc_oncology_patientperformance.visitguid as visitid

from ICEHR.t_onc_oncology_patientperformance t_onc_oncology_patientperformance
inner join ICEHR.t_onc_oncology_performancestatus t_onc_oncology_performancestatus on (t_onc_oncology_performancestatus.id = t_onc_oncology_patientperformance.performancestatusid) 
inner join ICEHR.t_patients t_patients on (t_patients.patientguid = t_onc_oncology_patientperformance.patientguid) 
inner join ICEHR.t_member t_member on (t_member.memberguid = t_patients.memberguid) 
inner join ICEHR.t_community t_community on (t_community.communityguid = t_member.homecommunityguid) 


)
select * from cte where (observationquestionnairedeletedindicator IS NULL or  observationquestionnairedeletedindicator = FALSE )
  );