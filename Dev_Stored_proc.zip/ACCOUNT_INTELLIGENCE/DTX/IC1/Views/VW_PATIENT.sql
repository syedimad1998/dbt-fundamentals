create or replace view IC1_VIEW.VW_PATIENT(
	PATIENTID,
	PATIENTRECORDCREATEDDATETIME,
	MEMBERID,
	PATIENTPREFIXNAME,
	PATIENTFIRSTNAME,
	PATIENTMIDDLENAME,
	PATIENTLASTNAME,
	PATIENTFULLNAME,
	PATIENTSUFFIXNAME,
	PATIENTNICKNAMENAME,
	PATIENTSTATUSDESCRIPTION,
	MEDICALRECORDNUMBER,
	PATIENTSECONDARYIDNUMBER,
	PATIENTSOCIALSECURITYNUMBER,
	PATIENTPREFERREDCONTACTMETHODDESCRIPTION,
	PATIENTEMAILDESCRIPTION,
	PATIENTACCEPTSTEXTMESSAGESINDICATOR,
	PATIENTACCEPTSEMAILMESSAGESINDICATOR,
	PATIENTHOMETELEPHONENUMBER,
	PATIENTMOBILETELEPHONENUMBER,
	PATIENTWORKTELEPHONENUMBER,
	PATIENTWORKTELEPHONEEXTENSIONNUMBER,
	PATIENTETHNICITYCODE,
	PATIENTETHNICITYDESCRIPTION,
	PATIENTGENDERDESCRIPTION,
	PATIENTSEXUALORIENTATIONDESCRIPTION,
	PATIENTMARITALSTATUSDESCRIPTION,
	PATIENTRELIGIONDESCRIPTION,
	PATIENTRACECODE,
	PATIENTRACEDESCRIPTION,
	PATIENTBIRTHDATE,
	PATIENTDEATHINDICATOR,
	PATIENTDEATHDATETIME,
	PATIENTPREFERREDLANGUAGEDESCRIPTION,
	LOCATIONID,
	PRIMARYPROVIDERID,
	PATIENTPRIMARYCAREPROVIDERID,
	PATIENTPRIMARYTREATMENTFACILITYID,
	EMERGENCYCONTACTRELATIONSHIPTOPATIENTDESCRIPTION,
	EMERGENCYCONTACTFULLNAME,
	EMERGENCYCONTACTTELEPHONENUMBER,
	EMERGENCYCONTACTCELLPHONENUMBER,
	EMERGENCYCONTACTWORKPHONENUMBER,
	PATIENTSPOUSEFIRSTNAME,
	PATIENTSPOUSEMIDDLENAME,
	PATIENTSPOUSELASTNAME,
	PATIENTSPOUSEPHONENUMBER,
	ICEMRPATIENTHID,
	PROVIDERID,
	PROVIDERNPINUMBER,
	PROVIDERFIRSTNAME,
	PROVIDERLASTNAME,
	PATIENTUSCITIZENINDICATOR,
	PATIENTPORTALACCESSINDICATOR,
	PATIENTINHOSPICEINDICATOR,
	PATIENTINHOSPICEDATE,
	PRACTICEID,
	PRACTICENAME,
	DATASOURCESYSTEMID,
	PATIENTACCEPTSCELLPHONEVOICEMAILAPPOINTMENTMESSAGESINDICATOR,
	PATIENTACCEPTSHOMEPHONEVOICEMAILAPPOINTMENTMESSAGESINDICATOR,
	PATIENTACCEPTSWORKPHONEVOICEMAILAPPOINTMENTMESSAGESINDICATOR,
	PATIENTACCEPTSAPPOINTMENTEMAILINDICATOR,
	PATIENTREQUIRESAPPOINTMENTCOMMUNICATIONVIAMAILINDICATOR,
	PATIENTALLOWSCELLPHONEVOICEMAILMEDICALMESSAGESINDICATOR,
	PATIENTALLOWSHOMEPHONEVOICEMAILMEDICALMESSAGESINDICATOR,
	PATIENTALLOWSWORKPHONEVOICEMAILMEDICALMESSAGESINDICATOR,
	PATIENTMEDICALMESSAGECANBEEMAILCOMMUNICATEDINDICATOR,
	PATIENTDISABLEDINDICATOR
) as (
    /* 
********************************************  NOTES START  ********************************************
Table: Patients
Comments: Gets patients master details


********************************************  NOTES END    ********************************************
*/


with cte as (

with service_provider as (
	select 
		 t_users_personalization.value
		,t_users_personalization.userguid
		,t_member.firstname
		,t_member.lastname
	from ICEHR.t_users_personalization 
	inner join ICEHR.t_users on (t_users.userguid = t_users_personalization.userguid)  
	inner join ICEHR.t_member on (t_member.memberguid = t_users.memberguid) 
    where (t_users_personalization.name = 'NPI')  
)

select 
     t_patients.patientguid as patientid
	,t_patients.createdate as patientrecordcreateddatetime
	,t_patients.memberguid as memberid
	,t_member.prefix as patientprefixname
	,t_member.firstname as patientfirstname
	,t_member.middlename as patientmiddlename
	,t_member.lastname as patientlastname
	,concat(ifnull(t_member.firstname, '') , ' ' , ifnull(t_member.middlename, '') , ' ' , ifnull(t_member.lastname, '')) as patientfullname
	,t_member.suffix as patientsuffixname
	,t_member.nickname as patientnicknamename
	,(case when t_patients.active = TRUE then 'active' else 'inactive' end)  as patientstatusdescription
	,t_patients.hid as medicalrecordnumber
	,t_patients.hid2 as patientsecondaryidnumber
	,t_member.ssn as patientsocialsecuritynumber
	,t_patients_additional_data.preferredcontactmethod as patientpreferredcontactmethoddescription
	,t_member.email as patientemaildescription
	,t_patients_demographics.cellphoneenabletextmessageing as patientacceptstextmessagesindicator
	,t_patients_demographics.emailenablesend as patientacceptsemailmessagesindicator
	,t_member.homephone as patienthometelephonenumber
	,t_member.cellphone as patientmobiletelephonenumber
	,t_member.workphone as patientworktelephonenumber
	,t_member.workphoneextension as patientworktelephoneextensionnumber
	,t_member.ethnicitycode as patientethnicitycode
	,t_member.ethnicity as patientethnicitydescription
	,t_member.sex as patientgenderdescription
	,t_patients_additional_data.sexualorientation as patientsexualorientationdescription
	,t_patients_medical_history_use.value as patientmaritalstatusdescription
	,t_patients.religion as patientreligiondescription
	,t_member.racecode as patientracecode
	,t_member.race as patientracedescription
	,t_member.dateofbirth as patientbirthdate
	,t_patients.isdeceased as patientdeathindicator
	,t_patients.deathdate as patientdeathdatetime
	,t_patients_additional_data.preferredlanguage as patientpreferredlanguagedescription
	,t_patients_additional_data.defaultfacilityguid as locationid
	,t_patients_additional_data.primaryuserguid as primaryproviderid
	,t_patients_additional_data.pcpcommunityreferralguid as patientprimarycareproviderid
	,t_patients_additional_data.defaultfacilityguid as patientprimarytreatmentfacilityid
	,t_patients_emergency_contact.relationship as emergencycontactrelationshiptopatientdescription
	,t_patients_emergency_contact.name as emergencycontactfullname
	,t_patients_emergency_contact.homephone as emergencycontacttelephonenumber
	,t_patients_emergency_contact.cellphone as emergencycontactcellphonenumber
	,t_patients_emergency_contact.workphone as emergencycontactworkphonenumber
	,t_patients.spousefirstname as patientspousefirstname
	,t_patients.spousemiddlename as patientspousemiddlename
	,t_patients.spouselastname as patientspouselastname
	,t_patients.spousephone as patientspousephonenumber
	,t_patients.hid as icemrpatienthid--
	,t_patients_additional_data.primaryuserguid as providerid
	,service_provider.value as providernpinumber
	,service_provider.firstname as providerfirstname
	,service_provider.lastname as providerlastname
	,t_patients.uscitizen as patientuscitizenindicator
	,t_patients.patientportalactive as patientportalaccessindicator
	,t_patients_additional_data.inhospice as patientinhospiceindicator
	,t_patients_additional_data.inhospicedate as patientinhospicedate
	,t_member.homecommunityguid as practiceid
	,t_community.license as practicename
	,'IC-EHR' as datasourcesystemid
	,t_patients_hipaa.appointmentvoicemail as patientacceptscellphonevoicemailappointmentmessagesindicator
	,t_patients_hipaa.leaveapptmsgonhomevoicemail as patientacceptshomephonevoicemailappointmentmessagesindicator
	,t_patients_hipaa.leaveapptmsgonofficevoicemail as patientacceptsworkphonevoicemailappointmentmessagesindicator
	,t_patients_hipaa.leaveapptmsgthroughemail as patientacceptsappointmentemailindicator
	,t_patients_hipaa.leaveapptmsgthroughmail as patientrequiresappointmentcommunicationviamailindicator
	,t_patients_hipaa.leavemedicalmsgoncellvoicemail as patientallowscellphonevoicemailmedicalmessagesindicator
	,t_patients_hipaa.leavemedicalmsgonhomevoicemail as patientallowshomephonevoicemailmedicalmessagesindicator
	,t_patients_hipaa.leavemedicalmsgonofficevoicemail as patientallowsworkphonevoicemailmedicalmessagesindicator
	,t_patients_hipaa.leavemedicalmsgthroughemail as patientmedicalmessagecanbeemailcommunicatedindicator
	,case when t_patients.active =FALSE or t_member.active =FALSE then 1 else 0 end as patientdisabledindicator

from ICEHR.t_patients
left outer join ICEHR.t_patients_hipaa on t_patients_hipaa.patientguid = t_patients.patientguid 
left outer join ICEHR.t_patients_additional_data on t_patients_additional_data.patientguid = t_patients.patientguid 
left outer join ICEHR.t_patients_demographics on t_patients_demographics.patientguid = t_patients.patientguid 
inner join ICEHR.t_member on t_patients.memberguid = t_member.memberguid 
inner join ICEHR.t_community t_community on t_community.communityguid = t_member.homecommunityguid 
left outer join service_provider on  service_provider.userguid = t_patients_additional_data.primaryuserguid 
left outer join ICEHR.t_patients_emergency_contact on t_patients_emergency_contact.patientguid = t_patients.patientguid 
left outer join ICEHR.t_patients_medical_history_use 
        on  t_patients.patientguid = t_patients_medical_history_use.patientguid
		and t_patients_medical_history_use.type = 'MaritalStatus'
		and t_patients_medical_history_use.name = 'MaritalStatus'
where (t_patients.testpatient is null or t_patients.testpatient = FALSE)
)
select * from cte where 
patientstatusdescription = 'active'
  );