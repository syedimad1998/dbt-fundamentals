create or replace view IC1_VIEW.VW_ADVERSEEVENT(
	PRACTICEID,
	TEMPLATENAME,
	PATIENTID,
	CREATEDDATE,
	USERID,
	ACTIVE,
	MEDICATION,
	REACTION,
	STOPDRUGINFUSION,
	ONSET,
	EMSNOTIFIED,
	OUTCOME,
	OXYGEN,
	RECHALLENGE,
	COMMENTVALUE,
	EMERGENCY_ASSISTANCE,
	PRACTICENAME,
	DATASOURCESYSTEMID
) as (
    /*
******************************************** NOTES START ********************************************
Table: Adverse Events
Comments: Adverse Events are stored in Dynamic Templates. So this needs bit more effort to get to the actual data.

******************************************** NOTES END ********************************************
*/


with masterdatacte as
(
select m.homecommunityguid
      ,t.templatename
      ,pd.patientguid
      ,pd.createddate
      ,pd.userguid
      ,pd.active

from ICEHR.t_onc_template_patient_data as pd
inner join ICEHR.t_patients p on (pd.patientguid = p.patientguid) 
inner join ICEHR.t_member m on (m.memberguid = p.memberguid) 
inner join ICEHR.t_onc_template_control as c on (pd.templatecontrolid = c.templatecontrolid) 
inner join ICEHR.t_onc_template_section as s on (c.templatesectionid = s.templatesectionid) 
inner join ICEHR.t_onc_template as t on (s.templateid = t.templateid) 
inner join ICEHR.t_onc_template_control_type as ct on (c.templatecontroltypeid = ct.templatecontroltypeid) 
inner join ICEHR.t_community as tc on   (m.homecommunityguid = tc.communityguid) 
where t.templatename = 'Adverse Event' 
group by m.homecommunityguid
,t.templatename
,pd.patientguid
,pd.createddate
,pd.userguid
,pd.active
order by pd.patientguid
,pd.createddate
)
,combinedcte as (
select pd.patientguid
      ,pd.createddate
      ,pd.fieldvalue
      ,t.templatename
      ,c.displayname
      ,s.sectiontitle

from ICEHR.t_onc_template_patient_data as pd
inner join ICEHR.t_patients p on pd.patientguid = p.patientguid 
inner join ICEHR.t_member m on m.memberguid = p.memberguid 
inner join ICEHR.t_onc_template_control as c on pd.templatecontrolid = c.templatecontrolid 
inner join ICEHR.t_onc_template_section as s on c.templatesectionid = s.templatesectionid 
inner join ICEHR.t_onc_template as t on s.templateid = t.templateid 
inner join ICEHR.t_onc_template_control_type as ct on c.templatecontroltypeid = ct.templatecontroltypeid 
inner join ICEHR.t_community as tc on   (m.homecommunityguid = tc.communityguid) 
)
,medicationcte as
(
select combinedcte.patientguid
      ,combinedcte.createddate
      ,combinedcte.fieldvalue

from combinedcte
where combinedcte.templatename = 'Adverse Event'
and combinedcte.displayname = 'Medication'
and combinedcte.sectiontitle = 'Adverse Event'
)
,reactioncte as
(
select combinedcte.patientguid
      ,combinedcte.createddate
      ,combinedcte.fieldvalue

from combinedcte 
where combinedcte.templatename = 'Adverse Event'
and combinedcte.displayname like  '%Reaction%'
and combinedcte.sectiontitle = 'Adverse Event'
)
,stopdruginfusionCTE As (
select combinedcte.patientguid
      ,combinedcte.createddate
      ,combinedcte.fieldvalue

from combinedcte
where combinedcte.templatename = 'Adverse Event'
and combinedcte.displayname like '%Stop%'
and combinedcte.sectiontitle = 'Adverse Event'
)
,onsetcte as (
select combinedcte.patientguid
      ,combinedcte.createddate
      ,combinedcte.fieldvalue

from combinedcte
where combinedcte.templatename = 'Adverse Event'
and combinedcte.displayname like  '%Onset%'
and combinedcte.sectiontitle = 'Adverse Event'
)
,emsnotifiedcte as (
select combinedcte.patientguid
      ,combinedcte.createddate
      ,combinedcte.fieldvalue

from combinedcte
where combinedcte.templatename = 'Adverse Event'
and combinedcte.displayname like  '%EMS Notified%'
and combinedcte.sectiontitle = 'Plan'
)
,outcomecte as (
select combinedcte.patientguid
      ,combinedcte.createddate
      ,combinedcte.fieldvalue

from combinedcte
where combinedcte.templatename = 'Adverse Event'
and combinedcte.displayname like  '%Outcome%'
and combinedcte.sectiontitle = 'Plan'
)
,oxygencte as (
select combinedcte.patientguid
      ,combinedcte.createddate
      ,combinedcte.fieldvalue

from combinedcte
where combinedcte.templatename = 'Adverse Event'
and combinedcte.displayname like  '%Oxygen%'
)
,rechallengecte as (
select combinedcte.patientguid
      ,combinedcte.createddate
      ,combinedcte.fieldvalue

from combinedcte
where combinedcte.templatename = 'Adverse Event'
and combinedcte.displayname like  '%Rechallenge%'
and combinedcte.sectiontitle = 'Plan'
)
,commentcte as (
select combinedcte.patientguid
      ,combinedcte.createddate
      ,combinedcte.fieldvalue

from combinedcte
where combinedcte.templatename = 'Adverse Event'
and combinedcte.displayname like  '%Comment%'
and combinedcte.sectiontitle = 'Plan'
)
,emergencycte as (
 select combinedcte.patientguid
      , combinedcte.createddate
      , arrayagg(object_construct(combinedcte.displayname, combinedcte.fieldvalue)) as emergency_assistance

from  combinedcte
where combinedcte.templatename = 'Adverse Event'
and combinedcte.sectiontitle like '%Emergency Assistance%'
 group by combinedcte.patientguid, combinedcte.createddate
)

select m.homecommunityguid as practiceid
      ,m.templatename
      ,m.patientguid as patientid
      ,m.createddate 
      ,m.userguid as userid
      ,m.active
      ,med.fieldvalue as medication
      ,rea.fieldvalue as reaction
      ,sdf.fieldvalue as stopdruginfusion
      ,os.fieldvalue as onset
      ,ems.fieldvalue as emsnotified
      ,oc.fieldvalue as outcome
      ,ox.fieldvalue as oxygen
      ,rc.fieldvalue as rechallenge
      ,cc.fieldvalue as commentvalue
      ,ec.emergency_assistance as emergency_assistance
      ,t_community.license as practicename
      ,'IC-EHR' as datasourcesystemid
      
from masterdatacte m
left outer join medicationcte med on m.patientguid = med.patientguid and m.createddate = med.createddate
left outer join reactioncte rea on m.patientguid = rea.patientguid and m.createddate = rea.createddate
left outer join stopdruginfusioncte sdf on m.patientguid = sdf.patientguid and m.createddate = sdf.createddate
left outer join onsetcte os on m.patientguid = os.patientguid and m.createddate = os.createddate
left outer join emsnotifiedcte ems on m.patientguid = ems.patientguid and m.createddate = ems.createddate
left outer join outcomecte oc on m.patientguid = oc.patientguid and m.createddate = oc.createddate
left outer join oxygencte ox  on m.patientguid = ox.patientguid and m.createddate = ox.createddate
left outer join rechallengecte rc on m.patientguid = rc.patientguid and m.createddate = rc.createddate
left outer join commentcte cc on m.patientguid =cc.patientguid and m.createddate = cc.createddate
left outer join emergencycte ec on m.patientguid =ec.patientguid and m.createddate = ec.createddate 
inner join ICEHR.t_community t_community on (t_community.communityguid = m.homecommunityguid) 
  );