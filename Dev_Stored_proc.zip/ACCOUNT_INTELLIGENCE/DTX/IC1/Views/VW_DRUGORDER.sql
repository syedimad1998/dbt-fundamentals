create or replace view IC1_VIEW.VW_DRUGORDER(
	DRUGORDERID,
	TREATMENTPLANID,
	CHEMOREGIMENID,
	ORDERINGPROVIDERID,
	DRUGORDERSIGNOFFBYUSERID,
	DRUGORDERSIGNOFFDATETIME,
	DRUGORDERAPPROVEDINDICATOR,
	DRUGORDEREDDATE,
	DRUGORDERTYPEDESCRIPTION,
	DRUGORDERDELETEDINDICATOR,
	DRUGORDERACTIVETREATMENTPLANINDICATOR,
	DRUGORDERASSIGNEDDATE,
	DRUGORDEREXPECTEDSTARTDATE,
	DRUGORDERCHEMOTHERAPYAPPROVEDINDICATOR,
	DRUGORDERCYCLEDAYTREATMENTHELDREASONTEXT,
	DRUGORDERCYCLEDAYONHOLDINDICATOR,
	DRUGORDERVERBALORDERAPPROVEDDATETIME,
	DRUGORDERVERBALORDERISSUEDBYUSERID,
	DRUGORDERVERBALORDERENTEREDBYUSERID,
	DRUGORDERVERBALORDERSTATUSDESCRIPTION,
	DRUGORDERDISCONTINUEDREASONTEXT,
	DRUGORDERTHERAPYINTENTDESCRIPTION,
	DRUGORDERLINEOFTREATMENTDESCRIPTION,
	DRUGORDERCYCLENUMBER,
	DRUGORDERREGIMENDAYNUMBER,
	DRUGORDERADMINISTRATIONROUTEDESCRIPTION,
	DRUGORDERDRUGLABELNAME,
	DRUGORDERGENERICNAME,
	DRUGORDERDOSEUNITNAME,
	DRUGORDERRELATIVEDOSEAMOUNT,
	DRUGORDERDOSEUNITDESCRIPTION,
	DRUGORDERDOSEAMOUNTVALUE,
	DRUGORDERDOSEFREQUENCYVALUE,
	PATIENTID,
	PRACTICEID,
	PRACTICENAME,
	DATASOURCESYSTEMID,
	VISITID
) as (
    /*
******************************************** NOTES START ********************************************
Table: Drug Order
Comments: Holds Drug order information

			This query has both Regimen Agents and Additional Medications

Note:  If ChemoRegimenId IS NOt null then it is Regimen agent. Or else additional medication
	

******************************************** NOTES END ********************************************
*/



with cte as (


with cte1 as (

select t_visits.visitguid
	   ,t_visits.userguid
	   ,t_visits.patientguid
	   ,t_visits.createdate
	   ,row_number() over(partition by t_visits.patientguid order by t_visits.createdate asc
	   ) as rn
from
	    ICEHR.t_visits  
		
),

cte2 as (
Select  t_onc_mar_signOff.* 
	    ,row_number() over(partition by t_onc_mar_signoff.patientguid 
						  order by t_onc_mar_signoff.signoffdate asc
		) as rn
		from ICEHR.t_onc_mar_signOff
		
)

-- Regimen Agents
select distinct
	 t_onc_chemoadmin_patientchemoregimencycledayagent.id as drugorderid
	,t_onc_chemoadmin_patientchemoregimen.id as treatmentplanid
	,t_onc_chemoadmin_patientchemoregimen.id as chemoregimenid
	,cte1.userguid as orderingproviderid
	,cte2.signoffuserguid as drugordersignoffbyuserid
	,cte2.signoffdate as drugordersignoffdatetime
	,(
		case 
			when t_onc_chemoadmin_patientchemoregimencycledayagent.ischemoorderapproved = TRUE
				then '1'
			else '0'
			end
		) as drugorderapprovedindicator
	,t_onc_chemoadmin_patientchemoregimencycledayagent.adt_createddate as drugordereddate
	,t_onc_agt_agenttype.title as drugordertypedescription
	,(
		case 
			when t_onc_chemoadmin_patientchemoregimencycledayagent.isdeleted = TRUE
				then '1'
			else '0'
			end
		) as drugorderdeletedindicator
	,(
		case 
			when t_onc_chemoadmin_patientchemoregimencycledayagent.isactive = TRUE
				then '1'
			else '0'
			end
		) as drugorderactivetreatmentplanindicator
	,t_onc_chemoadmin_patientchemoregimencycledayagent.adt_createddate as drugorderassigneddate
	,t_onc_chemoadmin_patientchemoregimencycledayagent.plannedstartdate as drugorderexpectedstartdate
	,(
		case 
			when t_onc_chemoadmin_patientchemoregimencycledayagent.ischemoorderapproved = TRUE
				then '1'
			else '0'
			end
		) as drugorderchemotherapyapprovedindicator
	
	,t_onc_chemoadmin_chemoholdingreason.title as drugordercycledaytreatmentheldreasontext
	,(
		case 
			when t_onc_chemoadmin_patientchemoregimencycledayagent.ishold = TRUE
				then '1'
			else '0'
			end
		) as drugordercycledayonholdindicator
	,t_onc_verbal_order.approvedate as drugorderverbalorderapproveddatetime
	,t_onc_verbal_order.approveruserguid as drugorderverbalorderissuedbyuserid
	,t_onc_verbal_order.requestoruserguid as drugorderverbalorderenteredbyuserid
	,t_onc_verbal_order.status as drugorderverbalorderstatusdescription
	,t_regimencycledayagent_discontinue.discontinuereason as drugorderdiscontinuedreasontext
	,t_onc_chemotherapy_intent.title as drugordertherapyintentdescription
	,t_onc_oncology_treatmentline.title as drugorderlineoftreatmentdescription
	,t_onc_chemoadmin_patientchemoregimencycleday.cyclenumber as drugordercyclenumber
	,t_onc_chemoadmin_patientchemoregimencycledayagent.daynumber as drugorderregimendaynumber
	,t_onc_agt_drugroute.description as drugorderadministrationroutedescription
	,t_onc_agt_agent.agentname as drugorderdruglabelname
	,t_onc_agt_agent.genericname as drugordergenericname
	,t_onc_chemoadmin_patientchemoregimencycledayagent.uom as drugorderdoseunitname
	,t_onc_chemoadmin_patientchemoregimencycledayagent.dispenseddose as drugorderrelativedoseamount
	,t_onc_chemoadmin_patientchemoregimencycledayagent.dosebasistitle as drugorderdoseunitdescription
	,t_onc_chemoadmin_patientchemoregimencycledayagent.plannedadmindose as drugorderdoseamountvalue
	,t_onc_rx_drugfrequency.description as drugorderdosefrequencyvalue
	,t_patients.patientguid as patientid
	,t_member.homecommunityguid as practiceid
	,t_community.license as practicename
	,'IC-EHR' as datasourcesystemid
	,cte1.visitguid as visitid

from  ICEHR.t_onc_chemoadmin_patientchemoregimencycledayagent
left outer join ICEHR.t_onc_chemoadmin_patientchemoholdingreason on t_onc_chemoadmin_patientchemoholdingreason.patientchemoregimencycledayagentid = t_onc_chemoadmin_patientchemoregimencycledayagent.id  
left outer join ICEHR.t_onc_chemoadmin_chemoholdingreason on (t_onc_chemoadmin_chemoholdingreason.id = t_onc_chemoadmin_patientchemoholdingreason.reasonid) 
left outer join ICEHR.t_regimencycledayagent_discontinue on t_regimencycledayagent_discontinue.regimencycledayagentdiscontinueid = t_onc_chemoadmin_patientchemoregimencycledayagent.regimencycledayagentdiscontinueid  
inner join ICEHR.t_onc_agt_agent on t_onc_agt_agent.id = t_onc_chemoadmin_patientchemoregimencycledayagent.agentid  
inner join ICEHR.t_onc_agt_agenttype on t_onc_agt_agent.agenttypeid = t_onc_agt_agenttype.id  
inner join ICEHR.t_onc_rx_drugfrequency on t_onc_rx_drugfrequency.id = t_onc_chemoadmin_patientchemoregimencycledayagent.drugfrequency  
inner join ICEHR.t_onc_agt_drugroute on t_onc_agt_drugroute.id = t_onc_chemoadmin_patientchemoregimencycledayagent.routeid 
inner join ICEHR.t_onc_agt_fluid on t_onc_agt_fluid.id = t_onc_chemoadmin_patientchemoregimencycledayagent.fluidid 
inner join ICEHR.t_onc_chemoadmin_patientchemoregimencycleday on t_onc_chemoadmin_patientchemoregimencycleday.id = t_onc_chemoadmin_patientchemoregimencycledayagent.PatientChemoRegimenCycleDayId 
inner join ICEHR.t_onc_chemoadmin_patientchemoregimencycle on t_onc_chemoadmin_patientchemoregimencycle.id = t_onc_chemoadmin_patientchemoregimencycleday.patientchemoregimencycleid  
inner join ICEHR.t_onc_chemoadmin_patientchemoregimen on t_onc_chemoadmin_patientchemoregimencycleday.patientchemoregimenid = t_onc_chemoadmin_patientchemoregimen.id  
inner join ICEHR.t_patients on t_patients.id = t_onc_chemoadmin_patientchemoregimen.patientid 
inner join ICEHR.t_member on t_member.memberguid = t_patients.memberguid 
inner join ICEHR.t_onc_chemotherapy_treatmentplan on t_onc_chemotherapy_treatmentplan.id = t_onc_chemoadmin_patientchemoregimen.regimenid  
left outer join ICEHR.t_onc_chemotherapy_intent on t_onc_chemotherapy_intent.id = t_onc_chemoadmin_patientchemoregimen.intentid  
left outer join ICEHR.t_onc_chemotherapy_regimentreatmentline on t_onc_chemotherapy_regimentreatmentline.regimenid = t_onc_chemotherapy_treatmentplan.id 
left outer join ICEHR.t_onc_oncology_treatmentline on t_onc_oncology_treatmentline.id = t_onc_chemotherapy_regimentreatmentline.treatmentlineid  
inner join ICEHR.t_community t_community on (t_community.communityguid = t_member.homecommunityguid) 
left outer join  cte1 on (t_patients.patientguid = cte1.patientguid) 
	and cast(cte1.createdate as date) = cast(t_onc_chemoadmin_patientchemoregimencycledayagent.adt_createddate as date) and (cte1.rn = 1)
left outer join  cte2 on (cte2.patientguid = t_patients.patientguid) 
	and cte2.mardate = cast(t_onc_chemoadmin_patientchemoregimencycledayagent.actualstartdate as date) and (cte2.rn = 1)
left outer join ICEHR.t_onc_verbal_order_mapping on t_onc_verbal_order_mapping.dayagentid = t_onc_chemoadmin_patientchemoregimencycledayagent.id
	and t_onc_verbal_order_mapping.active = TRUE 
left outer join ICEHR.t_onc_verbal_order on (t_onc_verbal_order.verbalorderid = t_onc_verbal_order_mapping.verbalorderid) 
where (t_onc_chemoadmin_patientchemoregimencycledayagent.isadditionalmedication = FALSE) 

union all

-- additional medications
select distinct
	t_onc_chemoadmin_patientchemoregimencycledayagent.id as drugorderid
	,null as treatmentplanid
	,null as chemoregimenid
	,cte1.userguid as orderingproviderid
	,cte2.signoffuserguid as drugordersignoffbyuserid
	,cte2.signoffdate as drugordersignoffdatetime
	,(
		case 
			when t_onc_chemoadmin_patientchemoregimencycledayagent.ischemoorderapproved = TRUE
				then '1'
			else '0'
			end
		) as drugorderapprovedindicator
	,t_onc_chemoadmin_patientchemoregimencycledayagent.adt_createddate as drugordereddate
	,t_onc_agt_agenttype.title as drugordertypedescription
	,(
		case 
			when t_onc_chemoadmin_patientchemoregimencycledayagent.isdeleted = TRUE
				then '1'
			else '0'
			end
		) as drugorderdeletedindicator
	,(
		case 
			when t_onc_chemoadmin_patientchemoregimencycledayagent.isactive = TRUE
				then '1'
			else '0'
			end
		) as drugorderactivetreatmentplanindicator
	,t_onc_chemoadmin_patientchemoregimencycledayagent.adt_createddate as drugorderassigneddate
	,t_onc_chemoadmin_patientchemoregimencycledayagent.plannedstartdate as drugorderexpectedstartdate
	,(
		case 
			when t_onc_chemoadmin_patientchemoregimencycledayagent.ischemoorderapproved = TRUE
				then '1'
			else '0'
			end
		) as drugorderchemotherapyapprovedindicator
	,t_onc_chemoadmin_chemoholdingreason.title as drugordercycledaytreatmentheldreasontext
	,(
		case 
			when t_onc_chemoadmin_patientchemoregimencycledayagent.ishold = TRUE
				then '1'
			else '0'
			end
		) as drugordercycledayonholdindicator
	,t_onc_verbal_order.approvedate as drugorderverbalorderapproveddatetime
	,t_onc_verbal_order.approveruserguid as drugorderverbalorderissuedbyuserid
	,t_onc_verbal_order.requestoruserguid as drugorderverbalorderenteredbyuserid
	,t_onc_verbal_order.status as drugorderverbalorderstatusdescription
	,t_regimencycledayagent_discontinue.discontinuereason as drugorderdiscontinuedreasontext
	,null as drugordertherapyintentdescription
	,null as drugorderlineoftreatmentdescription
	,null as drugordercyclenumber
	,t_onc_chemoadmin_patientchemoregimencycledayagent.daynumber as drugorderregimendaynumber
	,t_onc_agt_drugroute.description as drugorderadministrationroutedescription
	,t_onc_agt_agent.agentname as drugorderdruglabelname
	,t_onc_agt_agent.genericname as drugordergenericname
	,t_onc_chemoadmin_patientchemoregimencycledayagent.uom as drugorderdoseunitname
	,t_onc_chemoadmin_patientchemoregimencycledayagent.dispenseddose as drugorderrelativedoseamount
	,t_onc_chemoadmin_patientchemoregimencycledayagent.dosebasistitle as drugorderdoseunitdescription
	,t_onc_chemoadmin_patientchemoregimencycledayagent.plannedadmindose as drugorderdoseamountvalue
	,t_onc_rx_drugfrequency.description as drugorderdosefrequencyvalue
	,t_patients.patientguid as patientid
	,t_member.homecommunityguid as practiceid
	,t_community.license as practicename
	,'IC-EHR' as datasourcesystemid
	,cte1.visitguid as visitid

from ICEHR.t_onc_chemoadmin_patientchemoregimencycledayagent
left outer join ICEHR.t_onc_chemoadmin_patientchemoholdingreason on t_onc_chemoadmin_patientchemoholdingreason.patientchemoregimencycledayagentid = t_onc_chemoadmin_patientchemoregimencycledayagent.id  
left outer join ICEHR.t_onc_chemoadmin_chemoholdingreason on t_onc_chemoadmin_chemoholdingreason.id = t_onc_chemoadmin_patientchemoholdingreason.reasonid  
left outer join ICEHR.t_regimencycledayagent_discontinue on t_regimencycledayagent_discontinue.regimencycledayagentdiscontinueid = t_onc_chemoadmin_patientchemoregimencycledayagent.regimencycledayagentdiscontinueid  
inner join ICEHR.t_onc_agt_agent on t_onc_agt_agent.id = t_onc_chemoadmin_patientchemoregimencycledayagent.agentid  
inner join ICEHR.t_onc_agt_agenttype on t_onc_agt_agent.agenttypeid = t_onc_agt_agenttype.id  
inner join ICEHR.t_onc_rx_drugfrequency on t_onc_rx_drugfrequency.id = t_onc_chemoadmin_patientchemoregimencycledayagent.drugfrequency  
inner join ICEHR.t_onc_agt_drugroute on t_onc_agt_drugroute.id = t_onc_chemoadmin_patientchemoregimencycledayagent.routeid  
inner join ICEHR.t_onc_agt_fluid on t_onc_agt_fluid.id = t_onc_chemoadmin_patientchemoregimencycledayagent.fluidid 
inner join ICEHR.t_patients on t_patients.id = t_onc_chemoadmin_patientchemoregimencycledayagent.patientid  
inner join ICEHR.t_member on t_member.memberguid = t_patients.memberguid  
inner join ICEHR.t_community t_community on (t_community.communityguid = t_member.homecommunityguid) 
left outer join  cte1 on (t_patients.patientguid = cte1.patientguid) 
	and cast(cte1.createdate as date) = cast(t_onc_chemoadmin_patientchemoregimencycledayagent.adt_createddate as date) and (cte1.rn = 1)
left outer join  cte2 on (cte2.patientguid = t_patients.patientguid) 
	and cte2.mardate = cast(t_onc_chemoadmin_patientchemoregimencycledayagent.actualstartdate as date) and (cte2.rn = 1)
left outer join ICEHR.t_onc_verbal_order_mapping on t_onc_verbal_order_mapping.dayagentid = t_onc_chemoadmin_patientchemoregimencycledayagent.id
	and t_onc_verbal_order_mapping.active = TRUE  
left outer join ICEHR.t_onc_verbal_order on t_onc_verbal_order.verbalorderid = t_onc_verbal_order_mapping.verbalorderid 
where (t_onc_chemoadmin_patientchemoregimencycledayagent.isadditionalmedication = TRUE) 
)
select * from cte where drugorderdeletedindicator = '0'
  );