CREATE TABLE IF NOT EXISTS IC1.AnthemFinancialTransaction
(
	TransactionRefreshPeriodDate VARCHAR(10) NOT NULL  COMMENT 'Transaction Refresh Period Date is the year/month (YYYYMM) that corresponds with the refresh period.',
	EpisodeId VARCHAR(300) NOT NULL  COMMENT 'Episode Id is the unique episode identifier (will be consistent across all Integra deliverables); format:[EpisodeAcronym]_[EpisodeStartOn]_[MemberID].',
	EpisodeLineOfBusinessDescription VARCHAR(300) NOT NULL  COMMENT 'Episode Line of Business Description is the line of business associated with the episode.',
	ContractPayoutStatusDescription VARCHAR(300) NULL  COMMENT 'Contract Payout Status Description is the payout status of the contract; will be left blank.',
	ContractEpisodeTypeId VARCHAR(300) NOT NULL  COMMENT 'Contract Episode Type Id is the identifier for each unique contract ID and episode type combination (source: Anthem''s PIMS UI "CNTRCT" data); format: [ContractID]_[EpisodeTypeCode].',
	ContractName VARCHAR(300) NOT NULL  COMMENT 'Contract Name is the name of the contract (source: Anthem''s PIMS UI "CNTRCT" data).',
	EpisodeTypeName VARCHAR(300) NOT NULL  COMMENT 'Episode Type Name is the full name for the episode type.',
	ContractKeyId VARCHAR(300) NOT NULL  COMMENT 'Contract Key Id is the concatenation of the [ContractName] and [EpisodeName].',
	TrendFactorValue DECIMAL(20,4) NOT NULL  COMMENT 'Trend Factor Value is the trend factor applied to the Baseline Episode Cost for the contract/episode type to derive the Episode Target Price; assumed to be 1% for all contracts/episode types for purposes of the quasi-real test financial inbounds.',
	EpisodeActualTargetDifferentialValue DECIMAL(20,4) NOT NULL  COMMENT 'Episode Actual Target Differential Value is the difference between the Episode Target and the actual episode allowed cost (i.e., gross episode savings/(losses)).',
	SharedSavingsPercentValue DECIMAL(20,4) NOT NULL  COMMENT 'Shared Savings Percent Value is the shared savings percent for the contract (source: Anthem''s PIMS UI "CNTRCT" data).',
	SharedLossPercentValue DECIMAL(20,4) NOT NULL  COMMENT 'Shared Loss Percent Value is the shared loss percent for the contract (source: Anthem''s PIMS UI "CNTRCT" data).',
	EpisodePaidToAllowedRatioValue DECIMAL(20,4) NOT NULL  COMMENT 'Episode Paid to Allowed Ratio Value is the paid-to-allowed ratio for the episode.',
	EpisodePayoutAmount DECIMAL(20,4) NOT NULL  COMMENT 'Episode Payout Amount is the payout amount for the episode.',
	SytemEntryRecordDate TIMESTAMP NULL  COMMENT 'Sytem Entry Record Date is the date the record was loaded into Anthem''s systems; will be left blank.',
	ItsAccessFeePercentValue DECIMAL(20,4) NULL  COMMENT 'ITS Access Fee Percent Value is the percentage used to recalculate the ITS Access Fee for EBP/BDF settlements (source: Anthem''s "CLM" data).',
	ItsAccessFeeAmount DECIMAL(20,4) NULL  COMMENT 'ITS Access Fee Amount is the recalculated ITS Access Fee amount.',
	FinancialTransactionRunId VARCHAR(300) NOT NULL  COMMENT 'Financial Transaction Run Id is the unique identifier for the run (YYYYMMDD_LOB).',
	DataTemplateVersionNumber VARCHAR(25) NOT NULL  COMMENT 'Data Template Version Number is the Integra template version used to transform the source data to IC CDM format.',
	ICSiteId VARCHAR(300) NOT NULL  COMMENT 'IC Site Id is an IC generated ID to uniquely identify the combination of Data Source System ID, Data Source System Name & Data Site ID. This will permit us to track and identiy all the data coming in to IC1 from multiple clients and sources.',
	ProviderGroupingIdentifier VARCHAR(300) NULL  COMMENT 'Provider Grouping Identifier is a unique identifier for a grouping of providers. For example, this identifier is currently being sourced from Payment Innovation Systems (PIS).',
	ProgramID VARCHAR(300) NULL  COMMENT 'Program ID is the unique id that identifies the program (source: Anthem''s PIMS UI "CNTRCT" data).',
	BatchNumber VARCHAR(300) NULL  COMMENT 'Batch Number is a unique number used to identify each batch of financial transactions; EXAMPLE: ContractID + Rfrsh_Nbr + CurentDate as YYYYMMDD + Sequence Number.',
	FileProcessedDateTime DATE NOT NULL  COMMENT 'File Processed DateTime is the timestamp associated with the date and time a file is ingested and transformed into the Integra infrastructure.'
);

ALTER TABLE IC1.AnthemFinancialTransaction
	ADD CONSTRAINT XPKAnthemFinancialTransaction PRIMARY KEY (EpisodeId, TransactionRefreshPeriodDate, FinancialTransactionRunId, ICSiteId);

ALTER TABLE IC1.AnthemFinancialTransaction
	ADD CONSTRAINT AnthemEpisodeToFinTransaction FOREIGN KEY (EpisodeId, FinancialTransactionRunId, ICSiteId) REFERENCES IC1.AnthemEpisode (EpisodeId, RunId, ICSiteId);