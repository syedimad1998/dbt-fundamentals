CREATE TABLE IF NOT EXISTS IC1.AnthemLOBProductPIMSPSL
(
	DataTemplateVersionNumber VARCHAR(25) NULL  COMMENT 'Data Template Version Number is the Integra template version used to transform the source data to IC CDM format.',
	FileProcessedDatetime TIMESTAMP NULL  COMMENT 'File Processed DateTime is the timestamp associated with the date and time a file is ingested and transformed into the Integra infrastructure.',
	PimsLineOfBusinessId VARCHAR(300) NOT NULL  COMMENT 'PIMS Line of Business ID',
	PimsLineOfBusinessName VARCHAR(300) NULL  COMMENT 'PIMS Line of Business Name is used to define which LOBs are related to a specific contract, i.e. Commercial, Medicare, and Medicaid lines of business.',
	PimsLineOfBusinessDescription VARCHAR(300) NULL  COMMENT 'PIMS Line of Business Description is defined as Commercial, Medicare, and Medicaid lines of business.',
	PimsBrandStateCode VARCHAR(300) NULL  COMMENT 'PIMS Brand State Code defines if a company is associated with a single blue plan, Unicare or Other Brand States.',
	PimsMarketingBusinessUnitChartfieldCode VARCHAR(300) NULL  COMMENT 'PIMS Marketing Business Unit Chartfield Code that represents how products are marketed.',
	PimsBusinessUnitReportingDescription VARCHAR(300) NULL  COMMENT 'PIMS Business Unit Reporting Description Reporting business unit categories under each line of business.',
	PimsProductSwimLaneName VARCHAR(300) NULL  COMMENT 'PIMS Product Swim Lane Name represents the high level product definitions such as, HMO, PPO, POS, etc.',
	PimsProductReportingDescription VARCHAR(300) NULL  COMMENT 'PIMS Product Reporting Description is the description of the Product; a business description of the product in the context of the Program, LOB and PSL.',
	PimsProductChartfieldCode VARCHAR(300) NULL  COMMENT 'PIMS Product Chartfield Code is a code which represents how a Product is defined.',
	PimsLineOfBusinessEffectiveDate DATE NULL  COMMENT 'PIMS Line of Business Effective Date',
	PimsLineOfBusinessTerminationDate DATE NULL  COMMENT 'PIMS Line of Business Termination Date',
	ICSiteId VARCHAR(300) NOT NULL  COMMENT 'IC Site Id is an IC generated ID to uniquely identify the combination of Data Source System ID, Data Source System Name & Data Site ID. This will permit us to track and identiy all the data coming in to IC1 from multiple clients and sources.'
);

ALTER TABLE IC1.AnthemLOBProductPIMSPSL
	ADD CONSTRAINT XPKAnthemLOBProductPIMSPSL PRIMARY KEY (ICSiteId, PimsLineOfBusinessId);

ALTER TABLE IC1.AnthemLOBProductPIMSPSL
	ADD CONSTRAINT R337 FOREIGN KEY (ICSiteId) REFERENCES PROD_DTX.IC_REF.ICSite (ICSiteId);