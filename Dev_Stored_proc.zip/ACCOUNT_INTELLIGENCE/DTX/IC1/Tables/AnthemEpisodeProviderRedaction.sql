CREATE TABLE IF NOT EXISTS IC1.AnthemEpisodeProviderRedaction
(
	ICSiteId VARCHAR(300) NOT NULL  COMMENT 'IC Site Id is an IC generated ID to uniquely identify the combination of Data Source System ID, Data Source System Name & Data Site ID. This will permit us to track and identiy all the data coming in to IC1 from multiple clients and sources.',
	ClaimRedactionRenderingProviderId VARCHAR(300) NOT NULL  COMMENT 'Claim Redaction Rendering Provider Id is the ID number of the rendering provider.',
	ProviderEligibilityStartDate DATE NULL  COMMENT 'Provider Eligibility Start Date is the date the provider or facility becomes eligible to perform services for Anthem members (based on Anthem''s PROV data).',
	ProviderEligibilityEndDate DATE NULL  COMMENT 'Provider Eligibility End Date is the date the provider or facility is no longer eligible to perform services for Anthem members (based on Anthem''s PROV data).',
	RenderingProviderNpiId VARCHAR(300) NULL  COMMENT 'Rendering Provider NPI Id is the NPI number of the rendering provider who performed the services.',
	RenderingProviderTinId VARCHAR(300) NULL  COMMENT 'Rendering Provider TIN Id is the billing provider TIN number of the provider who performed the services.',
	RenderingOrganizationNpiId VARCHAR(300) NULL  COMMENT 'Rendering Organization NPI Id is the NPI number of the organization who performed the services.',
	RenderingProviderName VARCHAR(300) NULL  COMMENT 'Rendering Provider Name is the name of the rendering provider who performed the services (assoicated with the rendering NPI of the provider).',
	RenderingProviderTinName VARCHAR(300) NULL  COMMENT 'Rendering Provider TIN Name is the name of the TIN who performed the services.',
	RenderingOrganizationName VARCHAR(300) NULL  COMMENT 'Rendering Organization Name is the name of the organization who performed the services (associated with the billing NPI of the provider).',
	RenderingProviderMarketName VARCHAR(300) NULL  COMMENT 'Rendering Provider Market Name is the market of the rendering provider.',
	RedactedVersionProviderId VARCHAR(300) NOT NULL  COMMENT 'Redacted Version Provider Id is the redacted version of the ProviderID field.',
	RedactedVersionProviderNpiId VARCHAR(300) NULL  COMMENT 'Redacted Version Provider NPI Id is the redacted version of the Provider NPI field.',
	RedactedVersionProviderTinId VARCHAR(300) NULL  COMMENT 'Redacted Version Provider TIN Id is the redacted version of the Provider TIN field.',
	RedactedVersionOrganizationNpiId VARCHAR(300) NULL  COMMENT 'Redacted Version Organization NPI Id is the redacted version of the Organization NPI field.',
	RedactedVersionProviderName VARCHAR(300) NULL  COMMENT 'Redacted Version Provider Name is the redacted version of the Provider Name field.',
	RedactedVersionProviderTinName VARCHAR(300) NULL  COMMENT 'Redacted Version Provider TIN Name is the redacted version of the Provider TIN Name field.',
	RedactedVersionOrganizationName VARCHAR(300) NULL  COMMENT 'Redacted Version Organization Name is the redacted version of the Organization Name field.',
	EpisodeClaimProviderRedactionId VARCHAR(300) NOT NULL  COMMENT 'Episode Claim Provider Redaction Id is a unique key used to join masked values from the EPI - Provider Redaction file to the EPI - Episode Claim Level file.',
	ProviderRedactionRunId VARCHAR(300) NOT NULL  COMMENT 'Provider Redaction Run Id is the unique identifier for the run (YYYYMMDD_LOB).',
	DataTemplateVersionNumber VARCHAR(25) NOT NULL  COMMENT 'Data Template Version Number is the Integra template version used to transform the source data to IC CDM format.',
	ProviderGroupingIdentifier VARCHAR(300) NULL  COMMENT 'Provider Grouping Identifier is a unique identifier for a grouping of providers. For example, this identifier is currently being sourced from Payment Innovation Systems (PIS).',
	ProgramID VARCHAR(300) NULL  COMMENT 'Program ID is the unique id that identifies the program (source: Anthem''s PIMS UI "CNTRCT" data).',
	BatchNumber VARCHAR(300) NULL  COMMENT 'Batch Number is a unique number used to identify each batch of financial transactions; EXAMPLE: ContractID + Rfrsh_Nbr + CurentDate as YYYYMMDD + Sequence Number.',
	FileProcessedDateTime DATE NOT NULL  COMMENT 'File Processed DateTime is the timestamp associated with the date and time a file is ingested and transformed into the Integra infrastructure.'
);

ALTER TABLE IC1.AnthemEpisodeProviderRedaction
	ADD CONSTRAINT XPKAnthemEpisodeProviderRedaction PRIMARY KEY (EpisodeClaimProviderRedactionId, ICSiteId, ClaimRedactionRenderingProviderId);

ALTER TABLE IC1.AnthemEpisodeProviderRedaction
	ADD CONSTRAINT ICSiteToAnthemEpisodeProviderRedaction FOREIGN KEY (ICSiteId) REFERENCES PROD_DTX.IC_REF.ICSite (ICSiteId);