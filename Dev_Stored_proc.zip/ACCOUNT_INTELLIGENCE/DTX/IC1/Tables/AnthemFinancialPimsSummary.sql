CREATE TABLE IF NOT EXISTS IC1.AnthemFinancialPimsSummary
(
	ICSiteId VARCHAR(300) NOT NULL  COMMENT 'IC Site Id is an IC generated ID to uniquely identify the combination of Data Source System ID, Data Source System Name & Data Site ID. This will permit us to track and identiy all the data coming in to IC1 from multiple clients and sources.',
	PimsRunId VARCHAR(300) NOT NULL  COMMENT 'PIMS Run Id unique identifier for the run; format: YYYYMMDD_[LOB].',
	PimsContractId VARCHAR(300) NOT NULL  COMMENT 'Contract Id is the numerical identifier that uniquely identifies each contract.',
	PimsReconciliationPeriodCode VARCHAR(300) NOT NULL  COMMENT 'PIMS Reconciliation Period Code is the short code for the reconciliation period (Q1,Q2).',
	PimsBatchNumber VARCHAR(100) NOT NULL  COMMENT 'PIMS Batch Number is the unique number used to identify each batch of financial transactions; ContractID + Rfrsh_Nbr + CurentDate as YYYYMMDD + Sequence Number.',
	PimsEpisodeLineOfBusinessDescription VARCHAR(300) NOT NULL  COMMENT 'PIMS Episode Line of Business Description is the line of business associated with the episode.',
	PimsTriggerClaimProviderTinId VARCHAR(300) NOT NULL  COMMENT 'PIMS Trigger Claim Provider TIN Id is the tax identification number (TIN) of the provider associated with the trigger claim under the contract''s Administrative Provider (AP) (source: Anthem''s PIMS UI "PROV_RLTN_EXTRCT" data).',
	PimsContractStateCode VARCHAR(300) NOT NULL  COMMENT 'PIMS Contract State Code is the state the contract resides in.',
	PimsPerformancePeriodStartDate DATE NOT NULL  COMMENT 'PIMS Performance Period Start Date is the start date of the performance period.',
	PimsPerformancePeriodEndDate DATE NOT NULL  COMMENT 'PIMS Performance Period End Date is the end date of the performance period.',
	PimsEffectiveContractDate DATE NOT NULL  COMMENT 'PIMS Effective Contract Date is the contract effective date (source: Anthem''s PIMS UI "CNTRCT" data)',
	PimsEndContractDate DATE NOT NULL  COMMENT 'PIMS End Contract Date is the contract end date (source: Anthem''s PIMS UI "CNTRCT" data).',
	PimsEpisodeCount INTEGER NOT NULL  COMMENT 'PIMS Episode Count is the total number of valid episodes under the contract in the performance period attributed to the AP.',
	PimsTotalSharedSavingsAmount DECIMAL(20,4) NOT NULL  COMMENT 'PIMS Total Shared Savings Amount is the aggregate shared savings amount for the AP''s contract, subject to the Minimum Risk Threshold, Quality Threshold, shared savings/losses percentage, upside/downside factors, and paid-to-allowed ratio.',
	PimsQualityThresholdIndicator VARCHAR(300) NOT NULL  COMMENT 'PIMS Quality Threshold Indicator is the flag indicating if the quality threshold has been met.',
	PimsRecordCreationDate DATE NULL  COMMENT 'PIMS Record Creation Date is the date the record was loaded into Anthem''s systems; will be left blank.',
	PimsEpisodeTypeDescription VARCHAR(300) NOT NULL  COMMENT 'Pims Episode Type Description is the short name for the episode type (ex:  KNRPL, PCI, PREGN, etc.).',
	PimsProgramId VARCHAR(300) NOT NULL  COMMENT 'PIMS Program Id is the unique id that identifies the program (source: Anthem''s PIMS UI "CNTRCT" data).',
	DataTemplateVersionNumber VARCHAR(25) NOT NULL  COMMENT 'Data Template Version Number is the Integra template version used to transform the source data to IC CDM format.',
	FileProcessedDateTime DATE NULL  COMMENT 'File Processed DateTime is the timestamp associated with the date and time a file is ingested and transformed into the Integra infrastructure.',
	PIMSContractPeriodStartDate DATE NOT NULL  COMMENT 'PIMS Contract Period Start Date is the Anthem contract effective date (source: Anthem''s PIMS UI "CNTRCT" data).',
	PIMSContractPeriodEndDate DATE NOT NULL  COMMENT 'PIMS Contract Period End Date  is the Anthem  contract end date (source: Anthem''s PIMS UI "CNTRCT" data).',
	PIMSProviderGroupingIdentifier VARCHAR(300) NULL  COMMENT 'PIMS Provider Grouping Identifier is a unique Anthem  identifier for a grouping of providers. For example, this identifier is currently being sourced from Payment Innovation Systems (PIS).',
	PIMSRecordCreationDateTime DATE NULL  COMMENT 'PIMS Record Creation DateTime is the date the record was loaded into Anthem''s systems; will be left blank by Anthem.',
	PIMSTriggerClaimAdminProviderTINID VARCHAR(300) NULL  COMMENT 'PIMS Trigger Claim Admin Provider TIN ID is the tax identification number (TIN) of the provider associated with the trigger claim under the contract''s Administrative Provider (AP) (source: Anthem''s PIMS UI "PROV_RLTN_EXTRCT" data)'
);

ALTER TABLE IC1.AnthemFinancialPimsSummary
	ADD CONSTRAINT XPKAnthemFinancialPimsSummary PRIMARY KEY (PimsRunId, ICSiteId, PimsReconciliationPeriodCode, PimsContractId, PimsBatchNumber);

ALTER TABLE IC1.AnthemFinancialPimsSummary
	ADD CONSTRAINT ICSiteToAnthemFinancialPimsSummary FOREIGN KEY (ICSiteId) REFERENCES PROD_DTX.IC_REF.ICSite (ICSiteId);