CREATE TABLE IF NOT EXISTS IC1.ICSite
(
	ICSiteId VARCHAR(25) NOT NULL  COMMENT 'IC Site Id is an IC generated ID to uniquely identify the combination of Data Source System ID, Data Source System Name & Data Site ID. This will permit us to track and identiy all the data coming in to IC1 from multiple clients and sources.',
	DataSourceSystemId VARCHAR(300) NULL  COMMENT 'Data Source System ID is a unique identifier indicating the data source; includes practice or customer acronym (i.e., Practrice 1 = PRAC1) followed a the numeric value that is sequential for each practice/customer data source. Integra generated identifier. EXAMPLES: PRAC1 or PRAC21',
	DataSourceSystemName VARCHAR(300) NULL  COMMENT 'Data Source System Name is a unique name indicating the data source; includes practice or customer acronym (i.e., Practrice 1 = PRAC1) followed a the numeric value that is sequential for each practice/customer data source. Integra generated identifier. EXAMPLES: PRAC1 or PRAC21',
	DataSiteId VARCHAR(300) NULL  COMMENT 'Data Site ID DF-11 is a unique identifier indicating the data source; includes practice or customer acronym (i.e., Practrice 1 = PRAC1) followed a the numeric value that is sequential for each practice/customer data source. Integra generated identifier. EXAMPLES: PRAC1 or PRAC21'
);

ALTER TABLE IC1.ICSite
	ADD CONSTRAINT PKPractice PRIMARY KEY (ICSiteId);
