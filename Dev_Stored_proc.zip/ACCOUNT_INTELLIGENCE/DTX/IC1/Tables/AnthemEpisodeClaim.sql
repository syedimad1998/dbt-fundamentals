CREATE TABLE IF NOT EXISTS IC1.AnthemEpisodeClaim
(
	EpisodeId VARCHAR(300) NOT NULL  COMMENT 'Episode Id is the Anthem unique episode id generated (will be consistent across all Integra deliverables); format: [EpisodeAcronym]-[EpisodeStartOn]-[MemberID]',
	EpisodeClaimRunId VARCHAR(300) NOT NULL  COMMENT 'Episode Claim Run Id is the Anthem unique identifier for the run (YYYYMMDD_LOB).',
	EpisodeClaimId VARCHAR(300) NOT NULL  COMMENT 'Episode Claim Id is the Anthem Claim ID number.',
	EpisodeClaimLineId VARCHAR(300) NOT NULL  COMMENT 'Episode Claim Line Id is the Anthem Claim line number.',
	EpisodePhaseDescription VARCHAR(300) NOT NULL  COMMENT 'Episode Phase Description is the descriptor of the episode phase.  EXAMPLE: Pre-index, Index, Post-index',
	TriggerClaimIndicator VARCHAR(300) NOT NULL  COMMENT 'Trigger Claim Indicator is a flag indicating whether or not the claim was a trigger claim. EXAMPLE: T = yes, F = no.',
	RenderingProviderId VARCHAR(300) NOT NULL  COMMENT 'Rendering Provider Id is the Anthem ID number of the provider who performed the services.',
	RenderingProviderNpiId VARCHAR(300) NULL  COMMENT 'Rendering Provider NPI Id is the NPI number of the provider who performed the services',
	RenderingProviderName VARCHAR(300) NULL  COMMENT 'Rendering Provider Name is the name of the provider who performed the services.',
	RenderingProviderTinId VARCHAR(300) NULL  COMMENT 'Rendering Provider TIN Id is the TIN number of the provider who performed the services.',
	RenderingProviderTinName VARCHAR(300) NULL  COMMENT 'Rendering Provider TIN Name is the name of the TIN who performed the services.',
	RenderingOrganizationNpiId VARCHAR(300) NULL  COMMENT 'Rendering Organization NPI Id is the NPI number of the organization who performed the services.',
	RenderingOrganizationName VARCHAR(300) NULL  COMMENT 'Rendering Organization Name is the name of the organization who performed the services.',
	RenderingProviderMarketName VARCHAR(300) NULL  COMMENT 'Rendering Provider Market Name is the market of the rendering provider.',
	ClaimTypeDescription VARCHAR(300) NOT NULL  COMMENT 'Claim Type Description is the claim type.  Options: inpatient facility, outpatient facility, professional, other.  The TOS_TYPE is derived from the first two letters of the TYPE_OF_SRVC_CD’. Integra can consider these values to map the claim Type. TOS_TYPE	TOS_LVL_0_CD_VAL_NM NA	 NOT APPLICABLE IN	 FACILITY IP PR 	PROFESSIONAL PF	 PROFESSIONAL AD	 PROFESSIONAL OP  	FACILITY OP PH	 PHARMACY RX	 PHARMACY',
	PlaceOfServiceCode VARCHAR(300) NOT NULL  COMMENT 'Place of Service Code is an identifier for the location where services were provided.',
	PlaceOfServiceName VARCHAR(300) NOT NULL  COMMENT 'Place of Service Name is the location description or name where service was provided.',
	ClaimServiceCategoryName VARCHAR(300) NOT NULL  COMMENT 'Claim Service Category Name is the Integra created service categories for claims. The same service categories will be used in the online reporting tool',
	ClaimStartDate DATE NOT NULL  COMMENT 'Claim Start Date is the date the claim started on.',
	ClaimEndDate DATE NOT NULL  COMMENT 'Claim End Date is the date the claim ended on.',
	MsDrgVersionNumber VARCHAR(10) NULL  COMMENT 'MS DRG Version Number',
	ClaimMsDrgCode VARCHAR(300) NULL  COMMENT 'MS-DRG associated with inpatient facility claim',
	ClaimReadmissionInclusionIndicator VARCHAR(300) NULL  COMMENT 'Claim Readmission Inclusion Indicator indicates if the claim met Anthem''s definition of readmission for inclusion in the numerator of the quality measure calculation. EXAMPLE:  0 = no, 1 = yes, NULL = not applicable.',
	ClaimComplicationInclusionIndicator VARCHAR(300) NULL  COMMENT 'Claim Complication Inclusion Indicator indicates if the claim met Anthem''s definition of complication for inclusion in the numerator of the quality measure calculation. EXAMPLE: 0 = no, 1 = yes, NULL = not applicable.',
	ClaimPrenatalInclusionIndicator VARCHAR(300) NULL  COMMENT 'Claim Prenatal Inclusion Indicator indicates if the claim met Anthem''s definition of prenatal for inclusion in the numerator of the quality measure calculation. EXAMPLE: 0 = no, 1 = yes, NULL = not applicable.',
	ClaimCsectionInclusionIndicator VARCHAR(300) NULL  COMMENT 'Claim CSection Inclusion Indicator indicates if the claim met Anthem''s definition of c-section for inclusion in the numerator of the quality measure calculation; 0 = no, 1 = yes, NULL = not applicable.',
	EpisodeClaimAllowedCostAmount DECIMAL(20,4) NOT NULL  COMMENT 'Episode Claim Allowed Cost Amount is the allowed cost for the claim assigned to the episode.',
	EpisodeClaimPaidCostAmount DECIMAL(20,4) NOT NULL  COMMENT 'Episode Claim Paid Cost Amount is the paid cost for the claim assigned to the episode.',
	EpisodeClaimProviderRedactionId VARCHAR(300) NOT NULL  COMMENT 'Episode Claim Provider Redaction Id is a unique key used to join masked values from the EPI - Provider Redaction file to the EPI - Episode Claim Level file.',
	EpisodeClaimLineOfBusinessDescription VARCHAR(300) NOT NULL  COMMENT 'Episode Claim Line of Business Description is the line of business associated with the episode.',
	DataTemplateVersionNumber VARCHAR(25) NOT NULL  COMMENT 'Data Template Version Number is the Integra template version used to transform the source data to IC CDM format.',
	ICSiteId VARCHAR(300) NOT NULL  COMMENT 'IC Site Id is an IC generated ID to uniquely identify the combination of Data Source System ID, Data Source System Name & Data Site ID. This will permit us to track and identiy all the data coming in to IC1 from multiple clients and sources.',
	ProviderGroupingIdentifier VARCHAR(300) NULL  COMMENT 'Provider Grouping Identifier is a unique identifier for a grouping of providers. For example, this identifier is currently being sourced from Payment Innovation Systems (PIS).',
	ProgramID VARCHAR(300) NULL  COMMENT 'Program ID is the unique id that identifies the program (source: Anthem''s PIMS UI "CNTRCT" data).',
	BatchNumber VARCHAR(300) NULL  COMMENT 'Batch Number is a unique number used to identify each batch of financial transactions; EXAMPLE: ContractID + Rfrsh_Nbr + CurentDate as YYYYMMDD + Sequence Number.',
	FileProcessedDateTime DATE NOT NULL  COMMENT 'File Processed DateTime is the timestamp associated with the date and time a file is ingested and transformed into the Integra infrastructure.'
);

ALTER TABLE IC1.AnthemEpisodeClaim
	ADD CONSTRAINT XPKAnthemEpisodeClaim PRIMARY KEY (EpisodeId, EpisodeClaimRunId, EpisodeClaimId, EpisodeClaimLineId, ICSiteId);

ALTER TABLE IC1.AnthemEpisodeClaim
	ADD CONSTRAINT AnthemEpisodeToClaim FOREIGN KEY (EpisodeId, EpisodeClaimRunId, ICSiteId) REFERENCES IC1.AnthemEpisode (EpisodeId, RunId, ICSiteId);
