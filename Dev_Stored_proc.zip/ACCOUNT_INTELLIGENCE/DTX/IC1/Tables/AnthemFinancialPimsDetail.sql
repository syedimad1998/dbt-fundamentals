CREATE TABLE IF NOT EXISTS IC1.AnthemFinancialPimsDetail
(
	ICSiteId VARCHAR(300) NOT NULL  COMMENT 'IC Site Id is an IC generated ID to uniquely identify the combination of Data Source System ID, Data Source System Name & Data Site ID. This will permit us to track and identiy all the data coming in to IC1 from multiple clients and sources.',
	PimsEpisodeId VARCHAR(300) NOT NULL  COMMENT 'PIMS Episode Id is the unique episode identifier (will be consistent across all Integra deliverables); format: [EpisodeAcronym]_[EpisodeStartOn]_[MemberID]',
	PimsDetailRunId VARCHAR(300) NOT NULL  COMMENT 'PIMS Detail Run Id unique identifier for the run; format: YYYYMMDD_[LOB]',
	PimsLineOfBusinessDescription VARCHAR(300) NOT NULL  COMMENT 'PIMS Line of Business Description is the line of business associated with the episode.',
	PimsContractId VARCHAR(300) NOT NULL  COMMENT 'PIMS Contract Id is the numerical identifier that uniquely identifies each contract.',
	PimsReconciliationPeriodCode VARCHAR(300) NOT NULL  COMMENT 'PIMS Reconciliation Period Code is the short code for the reconciliation period (Q1,Q2).',
	PimsEpisodeBatchNumber VARCHAR(100) NOT NULL  COMMENT 'PIMS Episode Batch Number is the unique number used to identify each batch of financial transactions; ContractID + Rfrsh_Nbr + CurentDate as YYYYMMDD + Sequence Number.',
	PimsMemberId VARCHAR(300) NOT NULL  COMMENT 'PIMS Member Id is the unique member ID; linkable to all datasets (source: Anthem''s "MBR" data).',
	PimsMemberKeyId VARCHAR(300) NULL  COMMENT 'PIMS Member Key Id is a unique id that identifies a member in different source systems. At the Episode Level, the MBR_KEY associated with the Trigger Event (source: Anthem''s "MBRENR" data)',
	PimsTriggerClaimFacilityNpiId VARCHAR(300) NULL  COMMENT 'PIMS Trigger Claim Facility NPI Id is the NPI of the facility who submitted the facility trigger claim and is attributed the episode (only populated for episodes where the provider on the facility trigger claim is attributed to an EBP contract , i.e., [AttributedProviderType]="F").',
	PimsTriggerClaimRenderingProviderNpiId VARCHAR(300) NULL  COMMENT 'PIMS Trigger Claim Rendering Provider NPI Id is the NPI of the rendering provider who submitted the professional trigger claim and is attributed the episode (only populated for episodes where the provider on the professional trigger claim is attributed to an EBP contract, i.e., [AttributedProviderType]="P")',
	PimsEpisodePayoutAmount DECIMAL(20,4) NOT NULL  COMMENT 'PIMS Episode Payout Amount is the payout amount for the episode.',
	PimsTriggerClaimAdminProviderTinId VARCHAR(300) NOT NULL  COMMENT 'PIMS Trigger Claim Admin Provider TIN Id is the tax identification number (TIN) of the provider associated with the trigger claim under the contract''s Administrative Provider (AP) (source: Anthem''s PIMS UI "PROV_RLTN_EXTRCT" data).',
	PimsMembershipSystemOfRecordCode VARCHAR(300) NOT NULL  COMMENT 'PIMS Membership System of Record Code is the membership System of Record (SOR) code as of the claim trigger date from Anthem source tables (source: Anthem''s "MBRENR" data).',
	PimsEpisodeTriggerProcedureDate DATE NOT NULL  COMMENT 'PIMS Episode Trigger Procedure Date is the date of the procedure that triggered the episode.',
	PimsAccesFeePercentValue DECIMAL(20,4) NULL  COMMENT 'PIMS Acces Fee Percent Value is the percentage used to recalculate the ITS Access Fee for EBP/BDF settlements (source: Anthem''s "CLM" data).',
	PimsItsAccessFeeAmount DECIMAL(20,4) NULL  COMMENT 'PIMS ITS Access Fee Amount is the recalculated ITS Access Fee amount.',
	PimsPerformancePeriodStartDate DATE NOT NULL  COMMENT 'PIMS Performance Period Start Date is the start date of the performance period.',
	PimsPerformancePeriodEndDate DATE NOT NULL  COMMENT 'PIMS Performance Period End Date is the end date of the performance period.',
	PimsAdminProviderContractEffectiveDate DATE NOT NULL  COMMENT 'PIMS Admin Provider Contract Effective Date is the AP''s contract effective date (source: Anthem''s PIMS UI "CNTRCT" data).',
	PimsAdminProviderContractEndDate DATE NOT NULL  COMMENT 'PIMS Admin Provider Contract End Date is the AP''s contract end date (source: Anthem''s PIMS UI "CNTRCT" data).',
	PimsEpisodeStartDate DATE NOT NULL  COMMENT 'PIMS Episode Start Date is the episode''s start date in "YYYY-MM-DD".',
	PimsEpisodeEndDate DATE NOT NULL  COMMENT 'PIMS Episode End Date is the episode''s end date in "YYYY-MM-DD".',
	PimsEpisodeFacilityTriggerClaimId VARCHAR(300) NULL  COMMENT 'PIMS Episode Facility Trigger Claim Id is the facility claim id that triggered the episode and is attributed the episode (only populated for episodes where the provider on the facility trigger claim is attributed to an EBP contract, i.e., [AttributedProviderType]="F").',
	PimsEpisodeProfessionalClaimId VARCHAR(300) NULL  COMMENT 'PIMS Episode Professional Claim Id is the professional claim id that triggered the episode and is attributed the episode (only populated for episodes where the provider on the professional trigger claim is attributed to an EBP contract , i.e., [AttributedProviderType]="P")',
	PimsContractStateCode VARCHAR(300) NOT NULL  COMMENT 'PIMS Contract State Code is the state the contract resides in.',
	PimsMemberEnrollmentStatusCode VARCHAR(300) NOT NULL  COMMENT 'PIMS Member Enrollment Status Code in the status of the member enrollment record as of the claim trigger date from Anthem source tables (source: Anthem''s "MBRENR" data).',
	PimsOriginalRecordLoadDateId VARCHAR(300) NOT NULL  COMMENT 'PIMS Original Record Load Date Id is the date ID (YYYYMMDD) for when the record was originally loaded by Integra.',
	PimsUpdateRecordLoadDateId VARCHAR(300) NOT NULL  COMMENT 'PIMS Update Record Load Date Id is the date ID (YYYYMMDD) for when the updated record was loaded by Integra. On the initial load, this will be populated with the date ID of the LOAD_LOG_KEY field. In future refresh periods, this will be populated with the date ID of the refresh.',
	PimsProductDescription VARCHAR(300) NULL  COMMENT 'PIMS Product Description are the high level product definitions (HMO, PPO, POS, etc.).',
	PimsEpisodeTypeDescription VARCHAR(300) NOT NULL  COMMENT 'PIMS Episode Type Description is the short name for the episode type (ex:  KNRPL, PCI, PREGN, etc.).',
	PimsItsSccfNumber VARCHAR(20) NULL  COMMENT 'PIMS ITS SCCF Number is the Inter-Plan Teleprocessing System (ITS) Standard Claims Collection Facility Number on the trigger claim (source: Anthem''s "CLM" data).',
	PimsProgramId VARCHAR(300) NOT NULL  COMMENT 'PIMS Program Id is the unique id that identifies the program.',
	SystemRecordLoadDate TIMESTAMP NULL  COMMENT 'System Record Load Date is the date the record was loaded into Anthem''s systems; will be left blank.',
	DataTemplateVersionNumber VARCHAR(25) NOT NULL  COMMENT 'Data Template Version Number is the Integra template version used to transform the source data to IC CDM format.',
	ProviderGroupingIdentifier VARCHAR(300) NULL  COMMENT 'Provider Grouping Identifier is a unique identifier for a grouping of providers. For example, this identifier is currently being sourced from Payment Innovation Systems (PIS).',
	FileProcessedDateTime DATE NOT NULL  COMMENT 'File Processed DateTime is the timestamp associated with the date and time a file is ingested and transformed into the Integra infrastructure.',
	BatchNumber VARCHAR(300) NULL  COMMENT 'Batch Number is a unique number used to identify each batch of financial transactions; EXAMPLE: ContractID + Rfrsh_Nbr + CurentDate as YYYYMMDD + Sequence Number.'
);

ALTER TABLE IC1.AnthemFinancialPimsDetail
	ADD CONSTRAINT XPKAnthemFinancialPimsDetail PRIMARY KEY (PimsEpisodeId, PimsDetailRunId, ICSiteId);

ALTER TABLE IC1.AnthemFinancialPimsDetail
	ADD CONSTRAINT ICSiteToAnthemFinancialPimsDetail FOREIGN KEY (ICSiteId) REFERENCES PROD_DTX.IC_REF.ICSite (ICSiteId);