CREATE OR REPLACE VIEW PROD_DTX.PUBLIC.MasterProvider
AS
	SELECT   
		d.client_id
		, d.provider_id
		, d.first_name
		, d.last_name
		, d.provider_name
		, d.email_address
		, d.phone_number
		, d.fax_number
		, d.federal_tax_id
		, d.NPI
		, d.DEA
		, d.client_source_value
		, d.system_source_value
		, d.provider_source_value
		, d.provider_mpi_id
		, SHA2(d.client_source_value, 512) AS client_source_value_hash_512
		, SHA2(d.system_source_value, 512) AS system_source_value_hash_512
		, SHA2(d.provider_source_value, 512) AS provider_source_value_hash_512
	FROM
	(
SELECT DISTINCT
				  provider_id
				, LTRIM(RTRIM(COALESCE(first_name, ''))) AS first_name
				, LTRIM(RTRIM(COALESCE(last_name, ''))) AS last_name
				, LTRIM(RTRIM(COALESCE(provider_name, ''))) AS provider_name
				, LTRIM(RTRIM(COALESCE(email_address, ''))) AS email_address
				, LTRIM(RTRIM(COALESCE(phone_number, ''))) AS phone_number
				, LTRIM(RTRIM(COALESCE(fax_number, ''))) AS fax_number
				, LTRIM(RTRIM(COALESCE(federal_tax_id, ''))) AS federal_tax_id
				, LTRIM(RTRIM(COALESCE(npi, ''))) AS npi
				, LTRIM(RTRIM(COALESCE(dea, ''))) AS dea
				, LTRIM(RTRIM(COALESCE(client_source_value, ''))) AS client_source_value
				, LTRIM(RTRIM(COALESCE(system_source_value, ''))) AS system_source_value
				, LTRIM(RTRIM(COALESCE(provider_source_value, ''))) AS provider_source_value
				, provider_mpi_id
				, Division as client_id
			FROM
				PROD_DTX.PUBLIC.Provider) d;