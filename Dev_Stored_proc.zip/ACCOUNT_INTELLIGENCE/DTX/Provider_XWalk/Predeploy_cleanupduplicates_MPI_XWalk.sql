--get duplicate MPI Ids into temp table

drop table if exists duplicateMPIs;
    CREATE TEMPORARY TABLE duplicateMPIs (
        MasterProviderId int not null
    );

insert into duplicateMPIs 
select MasterProviderId from PROD_DTX.PUBLIC.MasterProviderIndex group by MasterProviderId having count(*) > 1;


--get duplicate XWalk Ids into temp table

drop table if exists duplicateXWalks;
    CREATE TEMPORARY TABLE duplicateXWalks(
        Provider_XWalkId int not null
    );

insert into duplicateXWalks 
select Provider_XWalkId from PROD_DTX.PUBLIC.Provider_XWalk group by Provider_XWalkId having count(*) > 1;

--clean up the duplicates

delete from  PROD_DTX.PUBLIC.MasterProviderIndex  where MasterProviderId in (
select MasterProviderId from duplicateMPIs); 

delete from  PROD_DTX.PUBLIC.Provider_XWalk  where MasterProviderId in (
select MasterProviderId from duplicateMPIs); 

delete from  PROD_DTX.PUBLIC.Provider_XWalk  where provider_xwalkid in (
select provider_xwalkid from duplicateXWalks); 

delete from  PROD_DTX.PUBLIC.MasterProviderIndexHistory  where MasterProviderId in (
select MasterProviderId from duplicateMPIs); 

delete from PROD_DTX.PUBLIC.Provider_XWalkHistory  where MasterProviderId in (
select MasterProviderId from duplicateMPIs); 

delete from PROD_DTX.PUBLIC.Provider_XWalkHistory  where provider_xwalkid in (
select provider_xwalkid from duplicateXWalks); 
