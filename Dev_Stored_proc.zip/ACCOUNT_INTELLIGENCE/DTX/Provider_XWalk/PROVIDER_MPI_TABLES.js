CREATE OR REPLACE PROCEDURE PROD_DTX.PUBLIC.PROVIDER_MPI_TABLES()
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
COMMENT='Process records in Staging table to add new patients to system'
EXECUTE AS CALLER
AS 
$$
function executesql(command, sqlrowcountneeded)
    {
        var cmd_dict = {sqlText: command};
        var stmt = snowflake.createStatement(cmd_dict);
        var result = stmt.execute(); 
        var return_rows = [];
        if (sqlrowcountneeded == '1') //This returns SQL RowCounts from a query
        {
            return stmt.getRowCount();
        }
        else //This just executes SQL query
        {
            return result;
        }
    }
try
{
    var division_query = "SELECT DISTINCT DIVISION FROM PROD_DTX.OMOP.PROVIDER;"
    var res = executesql(division_query,"0")

    while(res.next())
    {
        Provider_query = "UPDATE PROD_DF_"+ res.getColumnValue(1) +".OMOP.PROVIDER P SET P.PROVIDER_MPI_ID = X.MASTERPROVIDERID FROM PROD_DTX.PUBLIC.PROVIDER_XWALK X WHERE TRIM(P.CLIENT_SOURCE_VALUE) = TRIM(X.CLIENT_SOURCE_VALUE) AND TRIM(P.SYSTEM_SOURCE_VALUE) = TRIM(X.SYSTEM_SOURCE_VALUE) AND TRIM(P.PROVIDER_SOURCE_VALUE) = TRIM(X.PROVIDER_SOURCE_VALUE);";
        // Updates PROVIDER_MPI_ID in OMOP Provider tables using records from EMPI_XWALK.
        executesql(Provider_query,"0");

    }
  return "Provider MPI Values are updated! Success!";
}
catch(err)
    {
        executesql('rollback;');
        return err;
    }
$$
;