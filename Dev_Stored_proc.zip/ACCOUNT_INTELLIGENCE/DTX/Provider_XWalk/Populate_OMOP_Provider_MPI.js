CREATE OR REPLACE PROCEDURE PROD_UTILITIES.Public.Populate_OMOP_Provider_MPI()
RETURNS  string 
LANGUAGE  JAVASCRIPT
COMMENT='SP will populate OMOP Provider with MPI'
EXECUTE AS caller
  as     
  $$
   function executesql(command, sqlrowcountneeded)
    {
        var cmd_dict = {sqlText: command};
        var stmt = snowflake.createStatement(cmd_dict);
        var result = stmt.execute(); 
        var return_rows = [];
        if (sqlrowcountneeded == '1') //This returns SQL RowCounts from a query
        {
            return stmt.getRowCount();
        }
        else //This just executes SQL query
        {
            return result;
        }
    }
    try
    {
	
	executesql(`USE PROD_DTX;`,'0');

	executesql(`DROP TABLE IF EXISTS TMP_DBLIST`, '0');
	
    executesql(`CREATE TEMPORARY TABLE TMP_DBLIST(OMOP_DB_Name varchar(100) NULL)`,'0');
	
	insert_databases = `INSERT INTO TMP_DBLIST(OMOP_DB_Name) 
                SELECT CONCAT('PROD_', CLIENTSOURCEDATABASENAME) AS DBNAME
                FROM PROD_DTX.REFERENCE.CLIENTDATABASESYSTEMOFRECORD CSR
                JOIN PROD_DF_000.INFORMATION_SCHEMA.DATABASES ISD ON CONCAT('PROD_', CLIENTSOURCEDATABASENAME) = DATABASE_NAME and DATABASE_NAME not in ('PROD_DF_000')`;
				
    executesql(insert_databases, '0');
	
	
	var get_DBNAMES = `SELECT OMOP_DB_Name FROM TMP_DBLIST;`;
    var dbs = executesql(get_DBNAMES,'0'); 
	
	
	//update Person EMPIs
	try
        {
		while(dbs.next())
			{
				  
			 var db_name = dbs.getColumnValue(1);
			 var UpdateMPI = `USE {!__DatabaseName__!};`;
			 UpdateMPI = UpdateMPI.replace("{!__DatabaseName__!}", db_name);
			 executesql(UpdateMPI,'0')
			 
				executesql('begin transaction;','0');
		
				//insert into omop refresh
				insert_omoprefresh = `INSERT INTO  {!__DatabaseName__!}.DBT_ARTIFACTS.OMOP_REFRESH (SOURCE_DATA,START_DATETIME,END_DATETIME,TRUNCATE_TABLES_FLAG,LOAD_STATUS)
								VALUES ('UPDATE_PROVIDER_MPI',current_timestamp(),NULL,1,'start')`

				var regex = new RegExp('{!__DatabaseName__!}', 'g');
				let omoprefresh = insert_omoprefresh.replace(regex, db_name);
				executesql(omoprefresh, '0');
				
				//update Provider MPIs in OMOP Provider table		
				update_ProviderMPI = `UPDATE {!__DatabaseName__!}.OMOP.Provider x
						set x.Provider_MPI_Id = P.MasterProviderId
						FROM {!__DTXDatabaseName__!}.PUBLIC.PROVIDER_XWALK P
						WHERE TRIM(LOWER(x.Provider_Source_Value)) = TRIM(LOWER(P.Provider_Source_Value))
							AND TRIM(LOWER(x.System_Source_Value)) = TRIM(LOWER(P.System_Source_Value))
							AND TRIM(LOWER(x.Client_Source_Value)) = TRIM(LOWER(P.Client_Source_Value));`;

				var regex = new RegExp('{!__DatabaseName__!}', 'g');
				var regex2 = new RegExp('{!__DTXDatabaseName__!}', 'g');
				let ProviderMPI = update_ProviderMPI.replace(regex, db_name);
				if (db_name.substring(0,3) == 'DEV'){
					ProviderMPI = ProviderMPI.replace(regex2,'DEV_DTX');
				}
				else if (db_name.substring(0,2) == 'QA'){
					ProviderMPI = ProviderMPI.replace(regex2,'QA_DTX');
				}
				else {
					ProviderMPI = ProviderMPI.replace(regex2,'PROD_DTX');
				}
				executesql(ProviderMPI, '0');
				
				//update omop refresh
				get_OMOPrefreshid = ` SELECT max(OMOP_refresh_id)
								   FROM {!__DatabaseName__!}.DBT_ARTIFACTS.OMOP_REFRESH WHERE source_data = 'UPDATE_PROVIDER_MPI'`
				
				var regex = new RegExp('{!__DatabaseName__!}', 'g');
				let omoprefreshid = get_OMOPrefreshid.replace(regex, db_name);
				var res = executesql(omoprefreshid, '0');
				res.next();
				var omop_refresh_id = res.getColumnValue(1);
								   
				update_omoprefresh = `UPDATE  {!__DatabaseName__!}.DBT_ARTIFACTS.OMOP_REFRESH R 
								SET R.END_DATETIME = current_timestamp(), LOAD_STATUS = 'complete' 
								WHERE R.OMOP_REFRESH_ID =  {!__omop_refresh_id__!}`

				var regex = new RegExp('{!__DatabaseName__!}', 'g');
				let upd_omoprefresh = update_omoprefresh.replace(regex, db_name);
				upd_omoprefresh = upd_omoprefresh.replace("{!__omop_refresh_id__!}", omop_refresh_id);
				executesql(upd_omoprefresh, '0');
				
				executesql('commit;','0');
			 
			}
        }
    catch(err)
        {
		 return "Error during updating OMOP Provider: " + err;   
        }
    
    
    return "Populate OMOP Provider with MPI is successful for all clients!"
    }   
    catch(err)
    {
        return err;
        
     }
   $$
  ;