CREATE OR REPLACE PROCEDURE PROD_UTILITIES.MDM.LOAD_MASTERPROVIDER_XWALK()
RETURNS  string 
LANGUAGE  JAVASCRIPT
EXECUTE AS caller

as
    $$
    
	  function executesql(command, sqlrowcountneeded)
		{
			var cmd_dict = {sqlText: command};
			var stmt = snowflake.createStatement(cmd_dict);
			var result = stmt.execute(); 
			var return_rows = [];
			
			if (sqlrowcountneeded == '1')
			{
				return stmt.getRowCount();	//This returns SQL RowCounts from a query
			}
			else
			{
				return result;
			}
		}
    
    try
		{	
			executesql(`USE PROD_DTX;`,'0');
			
			//create sequences to store the max identifiers
			
			ident_curr_mpi = `SELECT MAX(MasterProviderId) as IDENT FROM PUBLIC.MasterProviderIndex`;
			var res = executesql(ident_curr_mpi, '0');
			res.next();
			var ident_curr_mpi_val = res.getColumnValue(1);
			
			mpi_seq = `CREATE OR REPLACE SEQUENCE uniqueIDseq1 start = {!__ident_curr_mpi_val__!} increment=1`;
			mpi_seq = mpi_seq.replace('{!__ident_curr_mpi_val__!}', ident_curr_mpi_val);
			executesql(mpi_seq, '0');
			
			ident_curr_xwalk = `SELECT MAX(Provider_XWalkId) as IDENT FROM PUBLIC.Provider_XWalk`;
			var res = executesql(ident_curr_xwalk, '0');
			res.next();
			var ident_curr_xwalk_val = res.getColumnValue(1);
			
			xwalk_seq = `CREATE OR REPLACE SEQUENCE uniqueIDseq2 start = {!__ident_curr_xwalk_val__!} increment=1`;
			xwalk_seq = xwalk_seq.replace('{!__ident_curr_xwalk_val__!}', ident_curr_xwalk_val);
			executesql(xwalk_seq, '0');
			
			//remove rows where MasterProviderId = 0
			
			del_zeroMPI = `DELETE FROM PUBLIC.Provider_XWalk WHERE MasterProviderId = 0 ;`;
			executesql(del_zeroMPI, '0');
			
			del_zeroMPI_xwalk = `DELETE FROM PUBLIC.Provider_XWalkHistory WHERE MasterProviderId = 0 ;`;
			executesql(del_zeroMPI_xwalk, '0');
			
			//update provider_mpi_id for rows in OMOP.provider where provider_mpi_id = 0
			
			executesql(`Drop table if exists tmp_MPIsToUpdate`,'0');
			create_MPIsToUpdate = `CREATE TEMPORARY TABLE tmp_MPIsToUpdate(
				Division VARCHAR(3) NOT NULL
			   ,provider_id INT NULL) ;`;
			executesql(create_MPIsToUpdate, '0');
			
			executesql(`Drop table if exists tmp_ClientsToUpdate`,'0');
			create_ClientsToUpdate = `CREATE TEMPORARY TABLE tmp_ClientsToUpdate(
				Division VARCHAR(3) NOT NULL) ;`;
			executesql(create_ClientsToUpdate, '0');
			
			
			insert_MPIsToUpdate = `INSERT INTO tmp_MPIsToUpdate(Division,provider_id)
			SELECT DISTINCT Division, provider_id FROM PUBLIC.Provider
					WHERE provider_mpi_id = 0;`;
			executesql(insert_MPIsToUpdate, '0');
			
			//All divisions whose OMOP.provider tables will need clean up
			
			insert_ClientsToUpdate = `INSERT INTO tmp_ClientsToUpdate(Division)
			SELECT DISTINCT Division FROM tmp_MPIsToUpdate;`;
			executesql(insert_ClientsToUpdate, '0');
			
			var Count = 1;
			tablecnt1 = `SELECT count(*) as count FROM tmp_ClientsToUpdate`;
			var res = executesql(tablecnt1, '0');
			res.next();
			var TablesCount = res.getColumnValue(1);
			
			if (TablesCount != null)
			{
				while (Count <= TablesCount)
				{
					var div_result = executesql(`SELECT TOP 1 Division from tmp_ClientsToUpdate`,'0');
                    div_result.next();
                    var ClientID = div_result.getColumnValue(1);
					var DB = 'PROD_DF_' + ClientID
					del_ClientsToUpdate = `DELETE FROM tmp_ClientsToUpdate WHERE division = '{!__ClientID__!}';`;
					del_ClientsToUpdate = del_ClientsToUpdate.replace('{!__ClientID__!}', ClientID);
					executesql(del_ClientsToUpdate,'0')
					
					var SQL_SMT = `UPDATE {!__use_db__!}.OMOP.Provider x
						set x.provider_mpi_id = NULL
					from
						{!__use_db__!}.OMOP.Provider mp
						where mp.provider_id in (select provider_id from tmp_MPIsToUpdate) and mp.provider_id = x.provider_id 
						and x.provider_mpi_id = 0 ;`;
					
					var regex = new RegExp('{!__use_db__!}', 'g');
					SQL_SMT = SQL_SMT.replace(regex, DB);
					SQL_SMT = SQL_SMT.replace('{!__ClientID__!}', ClientID);
					executesql(SQL_SMT,'0')
					
					Count = Count + 1
					
				}
			}
            
			executesql(`USE PROD_DTX;`,'0');
			
            //update NPI in MasterProviderIndex and MasterProviderIndexHistory as a catch in case it is overwritten incorrectly
			
			update_mpi = `UPDATE PUBLIC.MasterProviderIndex x
				SET x.NPI = p.NPI
				FROM PUBLIC.MasterProviderIndex mpi
					INNER JOIN PUBLIC.Provider p
						ON mpi.MasterProviderId = p.provider_mpi_id
				WHERE COALESCE(p.NPI,'') <> ''
					AND mpi.NPI <> p.NPI
					AND x.MasterProviderId = p.provider_mpi_id ;`;

			executesql(update_mpi, '0');
			
			
			update_mpih = `UPDATE PUBLIC.MasterProviderIndexHistory x
				SET x.NPI = p.NPI
				FROM PUBLIC.MasterProviderIndexHistory mpi
					INNER JOIN PUBLIC.Provider p
						ON mpi.MasterProviderId = p.provider_mpi_id
				WHERE COALESCE(p.NPI,'') <> ''
					AND mpi.NPI <> p.NPI
					AND x.MasterProviderId = p.provider_mpi_id;`;

			executesql(update_mpih, '0');
			
			
			executesql(`Drop table if exists tmp_NPIsToCleanUp`,'0');
			create_NPIsToCleanUp = `CREATE TEMPORARY TABLE tmp_NPIsToCleanUp(
				Division VARCHAR(3) NOT NULL
			   ,NPI VARCHAR(20) NULL
			   ,MPI INT NOT NULL);`;
			executesql(create_NPIsToCleanUp, '0');
			
			
			executesql(`Drop table if exists tmp_MPIsToCleanUp`,'0');
			create_MPIsToCleanUp = `CREATE TEMPORARY TABLE tmp_MPIsToCleanUp(
				MPI INT NOT NULL);`;
			executesql(create_MPIsToCleanUp, '0');
			
			
			executesql(`Drop table if exists tmp_ClientsToCleanUp`,'0');
			create_ClientsToCleanUp = `CREATE TEMPORARY TABLE tmp_ClientsToCleanUp(
				Division VARCHAR(3) NOT NULL);`;
			executesql(create_ClientsToCleanUp, '0');
			
			//Fetch all occurrences of multiple NPIs linked to the same MPI
			
			insert_NPIsToCleanUp = `INSERT INTO tmp_NPIsToCleanUp(Division,NPI,MPI)
				SELECT DISTINCT b.Division, b.npi, b.provider_MPI_id 
					FROM (SELECT provider_mpi_id
						FROM PUBLIC.Provider
						WHERE COALESCE(npi,'') <> ''
						GROUP BY provider_mpi_id
						HAVING COUNT(DISTINCT NPI) > 1) a
					JOIN PUBLIC.Provider b
						   ON a.provider_MPI_id = b.provider_MPI_id;`;
			executesql(insert_NPIsToCleanUp, '0');
			
			// Fetch all occurrences of multiple MPIs linked to the same NPI in order to remove
			// This is creating issues in the CalculatedSets.dimProvider table
			
			insert_NPIsToCleanUp2 = `INSERT INTO tmp_NPIsToCleanUp(Division,NPI,MPI)
					SELECT DISTINCT b.ClientID, b.npi, b.masterproviderid
						FROM (SELECT NPI, MIN(masterproviderid)mpi
							FROM PUBLIC.MasterProviderIndex
							WHERE COALESCE(npi,'') <> ''
							GROUP BY NPI
							HAVING COUNT(DISTINCT MasterProviderId) > 1) a
					JOIN PUBLIC.MasterProviderIndex b
						ON a.npi = b.npi
							and a.mpi <> b.masterproviderid;`;
			executesql(insert_NPIsToCleanUp2, '0');
			
			// Fetch all the MPIs linked to these NPIs, as there can be several others.
			// Some MPIs that are shown to be 0 might not appear in history tables.
	        // They can be fetched directly from the OMOP tables.
			
			insert_MPIsToCleanUp = `INSERT INTO tmp_MPIsToCleanUp(MPI)
					SELECT DISTINCT MPI FROM tmp_NPIsToCleanUp;`;
			executesql(insert_MPIsToCleanUp, '0');
			
			// All divisions whose OMOP.provider tables will need clean up
			
			insert_ClientsToCleanUp = `INSERT INTO tmp_ClientsToCleanUp(Division)
					SELECT DISTINCT Division FROM tmp_NPIsToCleanUp;`;
			executesql(insert_ClientsToCleanUp, '0');
			
			// Setting MPIs for these providers to NULL, so that we generate separate and new MPIs later
			
			var Count = 1;
			tablecnt2 = `SELECT count(*) as count FROM tmp_ClientsToCleanUp`;
			var res = executesql(tablecnt2, '0');
			res.next();
			var TablesCount = res.getColumnValue(1);
			
			if (TablesCount != null)
			{
				while (Count <= TablesCount)
				{
					var div_result = executesql(`SELECT TOP 1 Division from tmp_ClientsToCleanUp`,'0')
					div_result.next();
					var Div = div_result.getColumnValue(1);
					var DB = 'PROD_DF_' + Div
					del_ClientsToCleanUp = `DELETE FROM tmp_ClientsToCleanUp WHERE division = '{!__Div__!}';`;
					del_ClientsToCleanUp = del_ClientsToCleanUp.replace('{!__Div__!}', Div);
					executesql(del_ClientsToCleanUp,'0')
					
					var SQL_SMT = `UPDATE {!__use_db__!}.OMOP.Provider x
						set x.provider_mpi_id = NULL
					from
						{!__use_db__!}.OMOP.Provider mp
						where mp.provider_mpi_id in (select * from tmp_MPIsToCleanUp) and x.provider_mpi_id = mp.provider_mpi_id ;`;
					
					var regex = new RegExp('{!__use_db__!}', 'g');
					SQL_SMT = SQL_SMT.replace(regex, DB);
					SQL_SMT = SQL_SMT.replace('{!__Div__!}', Div);
					executesql(SQL_SMT,'0')
					
					Count = Count + 1
					
				}
			}
            
            
            // Deleting all records of all old MPIs for these providers.
	        // New and separate MPIs will be generated for them in this procedure.
			
			executesql(`USE PROD_DTX;`,'0');
			
			del_MPIsToCleanUp_MPI = `DELETE FROM PUBLIC.MasterProviderIndex
										WHERE MasterProviderId IN (SELECT * FROM tmp_MPIsToCleanUp);`;
			executesql(del_MPIsToCleanUp_MPI, '0');
			
			del_MPIsToCleanUp_XWALK = `DELETE FROM PUBLIC.Provider_XWalk 
										WHERE MasterProviderId IN (SELECT * FROM tmp_MPIsToCleanUp);`;
			executesql(del_MPIsToCleanUp_XWALK, '0');
			
			del_MPIsToCleanUp_MPIH = `DELETE FROM PUBLIC.MasterProviderIndexHistory 
										WHERE MasterProviderId IN (SELECT * FROM tmp_MPIsToCleanUp);`;
			executesql(del_MPIsToCleanUp_MPIH, '0');
			
			del_MPIsToCleanUp_XWALKH = `DELETE FROM PUBLIC.Provider_XWalkHistory 
										WHERE MasterProviderId IN (SELECT * FROM tmp_MPIsToCleanUp);`;
			executesql(del_MPIsToCleanUp_XWALKH, '0');
			
			// First try to get the omop data looking better:
			
			executesql(`Drop table if exists tmp_provider_to_fix`,'0');
			
			executesql(`Drop table if exists tmp_TrueNpiData`,'0');
			
			executesql(`Drop table if exists tmp_ClientsToPushDataInto`,'0');
            
            
            create_ClientsToPushDataInto = `CREATE TEMPORARY TABLE tmp_ClientsToPushDataInto(
				Division VARCHAR(100) NOT NULL);`;
			executesql(create_ClientsToPushDataInto, '0');
			
			
			create_provider_to_fix = `CREATE TEMPORARY TABLE tmp_provider_to_fix(
				NPI varchar(20) NOT NULL,
				client_id varchar(100) NOT NULL,
				provider_id int NOT NULL,
				last_name varchar(100) NULL,
				first_name varchar(100) NULL,
				provider_name varchar(255) NULL,
				phone_number varchar(50) NULL,
				fax_number varchar(50) NULL,
				fix_last_name varchar(10) not null,
				fix_first_name varchar(10) not null,
				fix_provider_name varchar(10) not null,
				fix_phone_number varchar(10) not null,
				fix_fax_number varchar(10) not null);`;
			executesql(create_provider_to_fix, '0');
			
			
			create_TrueNpiData = `CREATE TEMPORARY TABLE tmp_TrueNpiData(
				NPI varchar(20) NOT NULL,
				last_name varchar(100) NULL,
				first_name varchar(100) NULL,
				provider_name varchar(255) NULL,
				phone_number varchar(50) NULL,
				fax_number varchar(50) NULL);`;
			executesql(create_TrueNpiData, '0');
			
			
			insert_provider_to_fix = `INSERT INTO tmp_provider_to_fix(
					NPI
					,client_id
					,provider_id
					,fix_last_name
					,fix_first_name
					,fix_provider_name
					,fix_phone_number
					,fix_fax_number)
					SELECT 
						m.NPI
						,m.client_id
						,m.provider_id
						,case when len(TRIM(coalesce(Last_Name, ''))) = 0	then 1 else 0 end
						,case when len(TRIM(coalesce(First_Name, ''))) = 0	then 1 else 0 end
						,case when len(TRIM(coalesce(Provider_Name, ''))) = 0	then 1 else 0 end
						,case when len(TRIM(coalesce(phone_number, ''))) = 0	then 1 else 0 end
						,case when len(TRIM(coalesce(fax_number, ''))) = 0	then 1 else 0 end
					FROM PUBLIC.MasterProvider m
					WHERE
						len(TRIM(m.npi)) > 0
						and m.client_id is not null
						and m.provider_id is not null
					and (
						len(TRIM(coalesce(Last_Name, ''))) = 0
						or 
						len(TRIM(coalesce(First_Name, ''))) = 0
						or 
						len(TRIM(coalesce(Provider_Name, ''))) = 0
						or 
						len(TRIM(coalesce(phone_number, ''))) = 0
						or 
						len(TRIM(coalesce(fax_number, ''))) = 0
						);`;
			executesql(insert_provider_to_fix, '0');
            
            
            insert_TrueNpiData = `INSERT INTO tmp_TrueNpiData
						  SELECT 
						  left(TRIM(npi.NPI), 20) as NPI
						, max(left(TRIM(npi.Provider_Last_Name_Legal_Name), 100)) as Last_Name
						, max(left(TRIM(npi.Provider_First_Name), 100)) as First_Name
						, null as FullProviderName
						, MAX(left(TRIM(case
								when len(npi.Provider_Business_Practice_Location_Address_Telephone_Number) > 0 then npi.Provider_Business_Practice_Location_Address_Telephone_Number
								when len(npi.Provider_Business_Mailing_Address_Telephone_Number) > 0 then npi.Provider_Business_Mailing_Address_Telephone_Number
								else NULL
							end), 50)) AS PhoneNumber
						, MAX(left(TRIM(case
								when len(npi.Provider_Business_Mailing_Address_Fax_Number) > 0 then npi.Provider_Business_Mailing_Address_Fax_Number
								when len(npi.Provider_Business_Practice_Location_Address_Fax_Number) > 0 then npi.Provider_Business_Practice_Location_Address_Fax_Number
								else NULL
							end), 50)) AS FaxNumber
					from PUBLIC.NPIDATA npi
					where npi.npi in (
						select n.npi from tmp_provider_to_fix N
					)
					group by left(TRIM(npi.NPI), 20);`;
			executesql(insert_TrueNpiData, '0');
            
            
            // normalize case.
			
			update_TrueNpiData  = `UPDATE tmp_TrueNpiData x
				SET x.last_name = case 
									when len(TRIM(last_name)) > 1 
									then  concat(upper(left(TRIM(last_name) , 1)) , lower(right(TRIM(last_name)  , len(TRIM(last_name)) - 1)))  
									else TRIM(last_name) end 
					, x.first_name = case 
										when len(TRIM(first_name)) > 1 
										then concat(upper(left(TRIM(first_name), 1)) , lower(right(TRIM(first_name) , len(TRIM(first_name)) - 1)))  
										else TRIM(first_name) end ;`;

			executesql(update_TrueNpiData, '0');
            
            // If it has junk data, null it.
			
			update_provider_to_fix  = `UPDATE tmp_provider_to_fix x 
				SET 
					x.last_name		    = case when len(TRIM(tn.last_name)) > 0 then tn.last_name else null end 
					, x.first_name	    = case when len(TRIM(tn.first_name)) > 0 then tn.first_name else null end 
					, x.phone_number	= case when len(TRIM(tn.phone_number)) > 0 then tn.phone_number else null end 
					, x.fax_number	    = case when len(TRIM(tn.fax_number)) > 0 then tn.fax_number else null end 
				from
					tmp_provider_to_fix ptf
					inner join tmp_TrueNpiData tn
						on tn.npi = ptf.NPI
							where tn.npi = x.NPI and x.provider_id = ptf.provider_id and x.client_id = ptf.client_id;`;

			executesql(update_provider_to_fix, '0');
            
            // Combine lastname and firstname, if still present, to become the full provider name.
			
			update_provider_to_fix2  = `UPDATE tmp_provider_to_fix x
			SET x.provider_name = case when len(last_name) > 0 and len(first_name) > 0 then concat(last_name, ', ' , first_name) else null end;`;
			
			executesql(update_provider_to_fix2, '0');
			
			
			insert_ClientsToPushDataInto  = `INSERT INTO tmp_ClientsToPushDataInto
			SELECT DISTINCT cast(client_id as varchar(100)) from tmp_provider_to_fix where try_cast(client_id as int) is not null;`;
			
			executesql(insert_ClientsToPushDataInto, '0');
            
            
            var Count = 1;
			tablecnt3 = `SELECT count(*) as count FROM tmp_ClientsToPushDataInto`;
			var res = executesql(tablecnt3, '0');
			res.next();
			var TablesCount = res.getColumnValue(1);
			
			if (TablesCount != null)
			{
				while (Count <= TablesCount)
				{
					var div_result = executesql(`SELECT TOP 1 Division from tmp_ClientsToPushDataInto`,'0');
					div_result.next();
					var division = div_result.getColumnValue(1);
					var DB = 'PROD_DF_' + division
					del_ClientsToPushDataInto = `DELETE FROM tmp_ClientsToPushDataInto WHERE division = '{!__division__!}';`;
					del_ClientsToPushDataInto = del_ClientsToPushDataInto.replace('{!__division__!}', division);
					executesql(del_ClientsToPushDataInto,'0')
					
					var SQL_SMT = `UPDATE {!__use_db__!}.OMOP.Provider x
						SET
						 x.last_name = case when fix_last_name = 1 and len(ptf.last_name ) > 0 and len(TRIM(coalesce(mp.last_name , ''))) = 0 then ptf.last_name else mp.last_name end 
						 , x.first_name = case when fix_first_name = 1 and len(ptf.first_name ) > 0 and len(TRIM(coalesce(mp.first_name , ''))) = 0 then ptf.first_name else mp.first_name end 
						 , x.provider_name= case when fix_provider_name = 1 and len(ptf.provider_name) > 0 and len(TRIM(coalesce(mp.provider_name , ''))) = 0 then ptf.provider_name else mp.provider_name end 
						 , x.phone_number = case when fix_phone_number = 1 and len(ptf.phone_number) > 0 and len(TRIM(coalesce(mp.phone_number , ''))) = 0 then ptf.phone_number else mp.phone_number end
						 , x.fax_number = case when fix_fax_number = 1 and len(ptf.fax_number ) > 0 and len(TRIM(coalesce(mp.fax_number , ''))) = 0 then ptf.fax_number else mp.fax_number end 
						from
							{!__use_db__!}.OMOP.provider mp
							inner join tmp_provider_to_fix ptf
								on mp.NPI = ptf.NPI
								and ptf.client_id = '{!__division__!}'
								and ptf.provider_id = mp.provider_id
								where x.NPI = ptf.NPI
								and ptf.provider_id = x.provider_id;`;
					
					var regex = new RegExp('{!__use_db__!}', 'g');
					SQL_SMT = SQL_SMT.replace(regex, DB);
					SQL_SMT = SQL_SMT.replace('{!__division__!}', division);
					executesql(SQL_SMT,'0')
					
					Count = Count + 1
					
				}
			}
            
            // End of 'get the provider data looking better by pullin in npi data.'

		    // Copy of the provider master - we will be making our changes to just this table
		    // so blocking on the actual table will be kept in check.
			
			executesql(`USE PROD_DTX;`,'0');
			
            executesql(`Drop table if exists tmp_AllProvidersMaster`,'0');
			create_AllProvidersMaster = `CREATE TEMPORARY TABLE tmp_AllProvidersMaster (
					MasterProviderId NUMBER(38,0) NOT null IDENTITY(1,1)
					, ClientId NUMBER(38,0) not null
					, first_name varchar(100) NOT NULL
					, first_name_mutated varchar(100) NOT NULL
					, last_name varchar(100) NOT NULL
					, last_name_mutated varchar(100) NOT NULL
					, provider_name varchar(255) NOT NULL
					, provider_name_mutated varchar(255) not null
					, email_address varchar(1000) NOT NULL
					, phone_number varchar(50) NOT NULL
					, fax_number varchar(50) NOT NULL
					, federal_tax_id varchar(20) NOT NULL
					, NPI varchar(20) NOT NULL
					, PRIMARY KEY (MasterProviderId));`;
			executesql(create_AllProvidersMaster, '0');
            
            
            // Copy of the provider xwalk - we will be making our changes to just this table
			// so blocking on the actual table will be kept in check.
            
            executesql(`Drop table if exists tmp_ProviderXwalk`,'0');
			create_ProviderXwalk = `CREATE TEMPORARY TABLE tmp_ProviderXwalk (
					Provider_XWalkId NUMBER(38,0) not null IDENTITY(1,1)
					, ClientId NUMBER(38,0) not null
					, client_source_value varchar(50) NOT NULL
					, system_source_value varchar(50) NOT NULL
					, provider_source_value varchar(50) NOT NULL
					, MasterProviderId NUMBER(38,0) not null
					, client_source_value_hash_512 varchar(16777216) not null
					, system_source_value_hash_512 varchar(16777216) not null
					, provider_source_value_hash_512 varchar(16777216) not null
                    , PRIMARY KEY (Provider_XWalkId));`;
			executesql(create_ProviderXwalk, '0');
            
            // This contains the original data we pull from our view and will not be changed during the query.  
			// This is so we can join against it to get data that we want.
			// EXCEPT in the case where we get junk NPI. In those cases, we are directly updating this table
			// so this poison data doesn't go downstream.
			
			executesql(`Drop table if exists tmp_Original_AllProvidersFromAllClients`,'0');
            create_Original_AllProvidersFromAllClients = `CREATE TEMPORARY TABLE tmp_Original_AllProvidersFromAllClients (
					client_id NUMBER(38,0) not null
					, provider_id NUMBER(38,0) NOT NULL
					, first_name varchar(100) NOT NULL
					, last_name varchar(100) NOT NULL
					, provider_name varchar(255) NOT NULL
					, email_address varchar(1000) NOT NULL
					, phone_number varchar(50) NOT NULL
					, fax_number varchar(50) NOT NULL
					, federal_tax_id varchar(20) NOT NULL
					, NPI varchar(20) NOT NULL
					, provider_mpi_id NUMBER(38,0) NULL
					, client_source_value varchar(16777216) NOT NULL
					, system_source_value varchar(16777216) NOT NULL
					, provider_source_value varchar(50) NOT NULL
					, client_source_value_hash_512 varchar(16777216) not null
					, system_source_value_hash_512 varchar(16777216) not null
					, provider_source_value_hash_512 varchar(16777216) not null);`;
			executesql(create_Original_AllProvidersFromAllClients, '0');
            
            
            // Initially, this will equal the data from #Original_AllProvidersFromAllClients but we will delete
			// records from this table as we are going and as we find matches.
			
			executesql(`Drop table if exists tmp_AllProvidersFromAllClients`,'0');

            create_AllProvidersFromAllClients = `CREATE TEMPORARY TABLE tmp_AllProvidersFromAllClients (
					AllProvidersFromAllClientsId NUMBER(38,0) NOT NULL IDENTITY(1,1)
					, client_id NUMBER(38,0) not null
					, provider_id NUMBER(38,0) NOT NULL
					, first_name varchar(100) NOT NULL
					, first_name_mutated varchar(100) NOT NULL
					, last_name varchar(100) NOT NULL
					, last_name_mutated varchar(100) NOT NULL
					, provider_name varchar(255) NOT NULL
					, provider_name_mutated varchar(255) not null
					, email_address varchar(1000) NOT NULL
					, phone_number varchar(50) NOT NULL
					, fax_number varchar(50) NOT NULL
					, federal_tax_id varchar(20) NOT NULL
					, NPI varchar(20) NOT NULL
					, client_source_value varchar(16777216) NOT NULL
					, system_source_value varchar(16777216) NOT NULL
					, provider_source_value varchar(50) NOT NULL
					, client_source_value_hash_512 varchar(16777216) not null
					, system_source_value_hash_512 varchar(16777216) not null
					, provider_source_value_hash_512 varchar(16777216) not null
					, provider_mpi_id NUMBER(38,0) NULL
                    , PRIMARY KEY (AllProvidersFromAllClientsId));`;
			executesql(create_AllProvidersFromAllClients, '0');
            
            
            // Tables to hold the records we match up as well as any attributes we want to get length for (for update purposes)
			
            executesql(`Drop table if exists tmp_NewProviderXwalkRecords`,'0');
            create_NewProviderXwalkRecords = `CREATE TEMPORARY TABLE tmp_NewProviderXwalkRecords (
					client_source_value_hash_512 varchar(16777216) not null
					, system_source_value_hash_512 varchar(16777216) not null
					, provider_source_value_hash_512 varchar(16777216) not null);`;
			executesql(create_NewProviderXwalkRecords, '0');
            
            
            // Tables to hold the records we match up as well as any attributes we want to get length for (for update purposes)
				
			executesql(`Drop table if exists tmp_NewlyMatchedRecordsAndAttributeLengthData`,'0');
            create_NewlyMatchedRecordsAndAttributeLengthData = `CREATE TEMPORARY TABLE tmp_NewlyMatchedRecordsAndAttributeLengthData (
					MasterProviderId NUMBER(38,0) not null
					, client_id NUMBER(38,0) not null
					, provider_id NUMBER(38,0) NOT NULL
					, first_name varchar(100) NOT NULL
					, last_name varchar(100) NOT NULL
					, provider_name varchar(255) NOT NULL
					, email_address varchar(1000) NOT NULL
					, phone_number varchar(50) NOT NULL
					, fax_number varchar(50) NOT NULL
					, federal_tax_id varchar(20) NOT NULL
					, NPI varchar(20) NOT NULL
					, client_source_value varchar(16777216) NOT NULL
					, system_source_value varchar(16777216) NOT NULL
					, provider_source_value varchar(50) NOT NULL
					, client_source_value_hash_512 varchar(16777216) not null
					, system_source_value_hash_512 varchar(16777216) not null
					, provider_source_value_hash_512 varchar(16777216) not null
					, LEN_first_name		  NUMBER(38,0) not null
					, LEN_last_name		  NUMBER(38,0) not null
					, LEN_provider_name	  NUMBER(38,0) not null
					, LEN_email_address	  NUMBER(38,0) not null
					, LEN_phone_number	  NUMBER(38,0) not null
					, LEN_fax_number		  NUMBER(38,0) not null
					, LEN_federal_tax_id	  NUMBER(38,0) not null
					, LEN_NPI				  NUMBER(38,0) not null);`;
			executesql(create_NewlyMatchedRecordsAndAttributeLengthData, '0');
            
            
            // Step 1 - Copy in data for the provider master AND the xwalk.
			// Note - we can't checkident tempdb tables without having dbo or sysadmin
			// so we will handle this using an explicit insert.  Its a kludge, but it works.
			
			
			insert_AllProvidersMaster = `INSERT into tmp_AllProvidersMaster(
					MasterProviderId
					, ClientId
					, first_name
					, first_name_mutated
					, last_name
					, last_name_mutated
					, provider_name
					, provider_name_mutated
					, email_address
					, phone_number
					, fax_number
					, federal_tax_id
					, NPI
				)
				select
					MasterProviderId
					, ClientId
					, first_name
					, first_name_mutated
					, last_name
					, last_name_mutated
					, provider_name
					, provider_name_mutated
					, email_address
					, phone_number
					, fax_number
					, federal_tax_id
					, NPI
				from
					PUBLIC.MasterProviderIndex;`;
			
			executesql(insert_AllProvidersMaster, '0');	
				
			// To get the correct identity values, we add an explicit insert and delete it later.
			
			
			ident_ext = `SELECT count(*) as count FROM tmp_AllProvidersMaster where MasterProviderId = {!__ident_curr_mpi_val__!}`;
			ident_ext = ident_ext.replace('{!__ident_curr_mpi_val__!}', ident_curr_mpi_val);
			var res = executesql(ident_ext, '0');
			res.next();
			var ident_exists = res.getColumnValue(1);
			
			if(ident_exists == 0)
			{
				insert_AllProvidersMaster2 = `INSERT into tmp_AllProvidersMaster(
					MasterProviderId
					, ClientId
					, first_name
					, first_name_mutated
					, last_name
					, last_name_mutated
					, provider_name
					, provider_name_mutated
					, email_address
					, phone_number
					, fax_number
					, federal_tax_id
					, NPI
				)
				select
					uniqueIDseq1.nextval
					, 0
					, ''
					, ''
					, ''
					, ''
					, ''
					, ''
					, ''
					, ''
					, ''
					, ''
					, ''
				;`;
				insert_AllProvidersMaster2 = insert_AllProvidersMaster2.replace('{!__ident_curr_mpi_val__!}', ident_curr_mpi_val);
				executesql(insert_AllProvidersMaster2, '0');	
			
				del_AllProvidersMaster = `DELETE FROM tmp_AllProvidersMaster WHERE MasterProviderId = {!__ident_curr_mpi_val__!}`;
				del_AllProvidersMaster = del_AllProvidersMaster.replace('{!__ident_curr_mpi_val__!}', ident_curr_mpi_val);
				var res = executesql(del_AllProvidersMaster, '0');
			}
			
			else
			{
				mpi_seq = `CREATE OR REPLACE SEQUENCE uniqueIDseq1 start = {!__ident_curr_mpi_val__!} increment=1`;
				mpi_seq = mpi_seq.replace('{!__ident_curr_mpi_val__!}', ident_curr_mpi_val+1);
				executesql(mpi_seq, '0');
			}
			
            
			insert_ProviderXwalk = `INSERT into tmp_ProviderXwalk(
				Provider_XWalkId
				, ClientId
				, client_source_value
				, system_source_value
				, provider_source_value
				, MasterProviderId
				, client_source_value_hash_512
				, system_source_value_hash_512
				, provider_source_value_hash_512
			)
			select
				Provider_XWalkId
				, ClientId
				, client_source_value
				, system_source_value
				, provider_source_value
				, MasterProviderId
				, client_source_value_hash_512
				, system_source_value_hash_512
				, provider_source_value_hash_512
			from
				PUBLIC.Provider_XWalk;`;
				
			executesql(insert_ProviderXwalk,'0');
			
			
			// To get the correct identity values, we add an explicit insert and delete it later.
			
			
			ident_ext = `SELECT count(*) as count FROM tmp_ProviderXwalk where Provider_XWalkId = {!__ident_curr_xwalk_val__!}`;
			ident_ext = ident_ext.replace('{!__ident_curr_xwalk_val__!}', ident_curr_xwalk_val);
			var res = executesql(ident_ext, '0');
			res.next();
			var ident_exists = res.getColumnValue(1);
			
			if(ident_exists == 0)
			{
				insert_ProviderXwalk = `INSERT into tmp_ProviderXwalk(
					Provider_XWalkId
					, ClientId
					, client_source_value
					, system_source_value
					, provider_source_value
					, MasterProviderId
					, client_source_value_hash_512
					, system_source_value_hash_512
					, provider_source_value_hash_512
				)
				select
					uniqueIDseq2.nextval
					, 0
					, ''
					, ''
					, ''
					, 0
					, ''
					, ''
					, ''
				;`;
                insert_ProviderXwalk = insert_ProviderXwalk.replace('{!__ident_curr_xwalk_val__!}', ident_curr_xwalk_val);
				executesql(insert_ProviderXwalk, '0');	
				
				del_ProviderXwalk = `DELETE FROM tmp_ProviderXwalk WHERE Provider_XWalkId = {!__ident_curr_xwalk_val__!}`;
				del_ProviderXwalk = del_ProviderXwalk.replace('{!__ident_curr_xwalk_val__!}', ident_curr_xwalk_val);
				executesql(del_ProviderXwalk, '0');
			}
			
			else
			{
				xwalk_seq = `CREATE OR REPLACE SEQUENCE uniqueIDseq2 start = {!__ident_curr_xwalk_val__!} increment=1`;
				xwalk_seq = xwalk_seq.replace('{!__ident_curr_xwalk_val__!}', ident_curr_xwalk_val+1);
				executesql(xwalk_seq, '0');
			}
			
            
			// End step 1.
            
            insert_Original_AllProvidersFromAllClients = `INSERT INTO tmp_Original_AllProvidersFromAllClients
			select   
				d.client_id
				, d.provider_id
				, d.first_name
				, d.last_name
				, d.provider_name
				, d.email_address
				, d.phone_number
				, d.fax_number
				, d.federal_tax_id
				, d.NPI
				, d.provider_mpi_id
				, d.client_source_value
				, d.system_source_value
				, d.provider_source_value
				, d.client_source_value_hash_512
				, d.system_source_value_hash_512
				, d.provider_source_value_hash_512
			from PUBLIC.MasterProvider d
			WHERE
			LEN(TRIM(COALESCE(d.first_name, ''))) != 0 OR LEN(TRIM(COALESCE(d.last_name, ''))) != 0 OR LEN(TRIM(COALESCE(d.provider_name, ''))) != 0 OR LEN(TRIM(COALESCE(d.NPI, ''))) != 0`;
			
			executesql(insert_Original_AllProvidersFromAllClients,'0')


			update_Original_AllProvidersFromAllClients = `UPDATE tmp_Original_AllProvidersFromAllClients x
			SET x.NPI = ''
			WHERE
				LEN(TRIM(COALESCE(NPI, ''))) = 0 OR
				(
					LEN(TRIM(COALESCE(NPI, ''))) > 0 and 
					(
						try_cast(x.NPI as int) is NULL OR try_cast(x.NPI as int) > 2147483647 OR x.npi ilike '%.%'
						OR len(TRIM(replace(x.NPI, '0', ''))) = 0	
						OR len(TRIM(replace(x.NPI, '1', ''))) = 0	
						OR len(TRIM(replace(x.NPI, '2', ''))) = 0	
						OR len(TRIM(replace(x.NPI, '3', ''))) = 0	
						OR len(TRIM(replace(x.NPI, '4', ''))) = 0	
						OR len(TRIM(replace(x.NPI, '5', ''))) = 0	
						OR len(TRIM(replace(x.NPI, '6', ''))) = 0	
						OR len(TRIM(replace(x.NPI, '7', ''))) = 0	
						OR len(TRIM(replace(x.NPI, '8', ''))) = 0	
						OR len(TRIM(replace(x.NPI, '9', ''))) = 0
					)
				);`
				
			executesql(update_Original_AllProvidersFromAllClients,'0')
            
            insert_AllProvidersFromAllClients = `INSERT INTO tmp_AllProvidersFromAllClients(client_id, provider_id, first_name, first_name_mutated, last_name, last_name_mutated
            , provider_name, provider_name_mutated, email_address, phone_number, fax_number, federal_tax_id, NPI, client_source_value, system_source_value, provider_source_value
            , client_source_value_hash_512, system_source_value_hash_512, provider_source_value_hash_512, provider_mpi_id) 
			select 
				client_id
				, provider_id
				, first_name
				, first_name
				, last_name
				, last_name
				, provider_name
				, provider_name
				, email_address
				, phone_number
				, fax_number
				, federal_tax_id
				, NPI
				, client_source_value
				, system_source_value
				, provider_source_value
				, client_source_value_hash_512
				, system_source_value_hash_512
				, provider_source_value_hash_512
				, provider_mpi_id
			from tmp_Original_AllProvidersFromAllClients;`
			
			executesql(insert_AllProvidersFromAllClients,'0')
            
            
            // Mutate:  Lets update the firstname and lastname to just the first word...
			update_AllProvidersFromAllClients = `UPDATE tmp_AllProvidersFromAllClients x
			SET x.provider_name_mutated = CASE WHEN LEN(x.provider_name_mutated) > 0 
											then x.provider_name_mutated else concat(concat(last_name_mutated , ', ' ), first_name_mutated) end;`;
			
			executesql(update_AllProvidersFromAllClients,'0')
			
			update_AllProvidersFromAllClients2 = `UPDATE tmp_AllProvidersFromAllClients x
			SET
				x.first_name_mutated = 
					REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(UPPER(first_name_mutated)
						, '/', '')
						, 'PORT HURON', '')
						, '(SELECTHEALTH)', '')
						, '(FLATIRON)', '')
						, '(JVH)', '')
						, ' MS,', ',')
						, 'FACEP', '')
						, 'FABHP', '')
						, 'FACP', '')
						, 'FNP-C', '')
						, 'APN-BC', '')
						, 'APN-C', '')
						, 'APN', '')
						, 'JVRMC', '')
						, 'CRNP', '')
						, 'DNP', '')
						, 'DCC', '')
						, ' NPP', '')
						, ' D.O.,', ',')
						, 'D.O.,', ',')
						, ' D.O.', '')
						, 'D.O.', '')
						, '(IHC)', '')
						, ', DOCTOR', ', ')
						, ', DOC', ', ')
						, ' MPAS', ' ')
						, 'MHP', '')
						, 'ARNP-C,', ', ')
						, 'ARNP', '')
						, ', NP,', ', ')
						, ' IV', '')
						, ' III', '')
						, ' II', '')
						, 'MR.', '')
						, 'MRS.', '')
						, 'MS.', '')
						, '(CONS)', ' ')
						, '(MS)', ' ')
						, 'IHC', ' ')
						, ', MISS ', ', ')
						, ' MISS ', ' ')
						, '(', '')
						, ')', '')
						, 'M.D.', ' ')
						, 'M.D', ' ')
						, 'MD.', ' ')
						, 'MD', ' ')
						, 'PA-C,', ', ')
						, 'PA-C', '')
						, 'P.A.', ' ')
						, 'PA.', ' ')
						, 'P.A', ' ')
						, ' PA,', ' ')
						, ', LPN', ', ')
						, 'LPN', ' ')
						, 'ARNP,', ', '), 'ARNP', '')
						, 'ANP,', ', ')
						, 'AOCNP,', ', ')
						, ' OCN,', ', ')
						, 'LPN,', ', ')
						, 'D.R.', ' ') 
						, 'DR.', ' ')
						, ' DO,', ' ')
						, ' APRN ', ' ')
						, ' MSN ', ' ')
						, ' RN ', ' ')
						, ' JR.', ' ')
						, ' JR', ' ')
						, ' NP', ' ')
						, 'BSN', '')
						, 'OCN', '')
						, ' RN', '')
						, 'MPH', '')
						, '-', ' ')
						, '  ', ' ')
						, ',  ,', ', ')
						, ', ,', ', ')
						, ',,', ', ')
						, ' , ', ', ')
						, '  ', ' ')
						, ' ,', ',')
						
				, x.last_name_mutated = 
					REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(UPPER(last_name_mutated)
						, '/', '')
						, 'PORT HURON', '')
						, '(SELECTHEALTH)', '')
						, '(FLATIRON)', '')
						, '(JVH)', '')
						, ' MS,', ',')
						, 'FACEP', '')
						, 'FABHP', '')
						, 'FACP', '')
						, 'FNP-C', '')
						, 'APN-BC', '')
						, 'APN-C', '')
						, 'APN', '')
						, 'JVRMC', '')
						, 'CRNP', '')
						, 'DNP', '')
						, 'DCC', '')
						, ' NPP', '')
						, ' D.O.,', ',')
						, 'D.O.,', ',')
						, ' D.O.', '')
						, 'D.O.', '')
						, '(IHC)', '')
						, ', DOCTOR', ', ')
						, ', DOC', ', ')
						, ' MPAS', ' ')
						, 'MHP', '')
						, 'ARNP-C,', ', ')
						, 'ARNP', '')
						, ', NP,', ', ')
						, ' IV', '')
						, ' III', '')
						, ' II', '')
						, 'MR.', '')
						, 'MRS.', '')
						, 'MS.', '')
						, '(CONS)', ' ')
						, '(MS)', ' ')
						, 'IHC', ' ')
						, ', MISS ', ', ')
						, ' MISS ', ' ')
						, '(', '')
						, ')', '')
						, 'M.D.', ' ')
						, 'M.D', ' ')
						, 'MD.', ' ')
						, 'MD', ' ')
						, 'PA-C,', ', ')
						, 'PA-C', '')
						, 'P.A.', ' ')
						, 'PA.', ' ')
						, 'P.A', ' ')
						, ' PA,', ' ')
						, ', LPN', ', ')
						, 'LPN', ' ')
						, 'ARNP,', ', '), 'ARNP', '')
						, 'ANP,', ', ')
						, 'AOCNP,', ', ')
						, ' OCN,', ', ')
						, 'LPN,', ', ')
						, 'D.R.', ' ') 
						, 'DR.', ' ')
						, ' DO,', ' ')
						, ' APRN ', ' ')
						, ' MSN ', ' ')
						, ' RN ', ' ')
						, ' JR.', ' ')
						, ' JR', ' ')
						, ' NP', ' ')
						, 'BSN', '')
						, 'OCN', '')
						, ' RN', '')
						, 'MPH', '')
						, '-', '')
						, '  ', ' ')
						, ',  ,', ', ')
						, ', ,', ', ')
						, ',,', ', ')
						, ' , ', ', ')
						, '  ', ' ')
						, ' ,', ',')
				, x.provider_name_mutated = 
					REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(UPPER(provider_name_mutated)
						, '/', '')
						, 'PORT HURON', '')
						, '(SELECTHEALTH)', '')
						, '(FLATIRON)', '')
						, '(JVH)', '')
						, ' MS,', ',')
						, 'FACEP', '')
						, 'FABHP', '')
						, 'FACP', '')
						, 'FNP-C', '')
						, 'APN-BC', '')
						, 'APN-C', '')
						, 'APN', '')
						, 'JVRMC', '')
						, 'CRNP', '')
						, 'DNP', '')
						, 'DCC', '')
						, ' NPP', '')
						, ' D.O.,', ',')
						, 'D.O.,', ',')
						, ' D.O.', '')
						, 'D.O.', '')
						, '(IHC)', '')
						, ', DOCTOR', ', ')
						, ', DOC', ', ')
						, ' MPAS', ' ')
						, 'MHP', '')
						, 'ARNP-C,', ', ')
						, 'ARNP', '')
						, ', NP,', ', ')
						, ' IV', '')
						, ' III', '')
						, ' II', '')
						, 'MR.', '')
						, 'MRS.', '')
						, 'MS.', '')
						, '(CONS)', ' ')
						, '(MS)', ' ')
						, 'IHC', ' ')
						, ', MISS ', ', ')
						, ' MISS ', ' ')
						, '(', '')
						, ')', '')
						, 'M.D.', ' ')
						, 'M.D', ' ')
						, 'MD.', ' ')
						, 'MD', ' ')
						, 'PA-C,', ', ')
						, 'PA-C', '')
						, 'P.A.', ' ')
						, 'PA.', ' ')
						, 'P.A', ' ')
						, ' PA,', ' ')
						, ', LPN', ', ')
						, 'LPN', ' ')
						, 'ARNP,', ', '), 'ARNP', '')
						, 'ANP,', ', ')
						, 'AOCNP,', ', ')
						, ' OCN,', ', ')
						, 'LPN,', ', ')
						, 'D.R.', ' ') 
						, 'DR.', ' ')
						, ' DO,', ' ')
						, ' APRN ', ' ')
						, ' MSN ', ' ')
						, ' RN ', ' ')
						, ' JR.', ' ')
						, ' JR', ' ')
						, ' NP', ' ')
						, 'BSN', '')
						, 'OCN', '')
						, ' RN', '')
						, 'MPH', '')
						, '-', ' ')
						, '  ', ' ')
						, ',  ,', ', ')
						, ', ,', ', ')
						, ',,', ', ')
						, ' , ', ', ')
						, '  ', ' ')
						, ' ,', ',');`;
						
			executesql(update_AllProvidersFromAllClients2,'0')
            
            
            // Starts with RN - remove it!
			update_AllProvidersFromAllClients3 = `update tmp_AllProvidersFromAllClients x
				SET x.provider_name_mutated = TRIM(
					case 
							WHEN LEN(provider_name_mutated) < 3 then provider_name_mutated
							when left(TRIM(provider_name_mutated), 2) = 'RN' then right(provider_name_mutated, len(provider_name_mutated)-2)
							else provider_name_mutated
						end)
					, x.last_name_mutated = TRIM(
					case 
							WHEN LEN(last_name_mutated) < 3 then last_name_mutated
							when left(TRIM(last_name_mutated), 2) = 'RN' then right(last_name_mutated, len(last_name_mutated)-2)
							else last_name_mutated
						end)
					, x.first_name_mutated = TRIM(
					case 
							WHEN LEN(first_name_mutated) < 3 then first_name_mutated
							when left(TRIM(first_name_mutated), 2) = 'RN' then right(first_name_mutated, len(first_name_mutated)-2)
							else first_name_mutated
						end);`;
			
			executesql(update_AllProvidersFromAllClients3,'0')
            
            // Double commas are always a mistake.
			update_AllProvidersFromAllClients4 = `UPDATE tmp_AllProvidersFromAllClients x
			SET 
				x.provider_name_mutated = TRIM(REPLACE(provider_name, ',,', ''))
				, x.first_name_mutated =  TRIM(replace(first_name_mutated, ',,', ''))
				, x.last_name_mutated =   TRIM(replace(last_name_mutated, ',,', ''))`;
				
			executesql(update_AllProvidersFromAllClients4,'0')
			
			// starts with comma.
			update_AllProvidersFromAllClients5 = `UPDATE tmp_AllProvidersFromAllClients x
				SET x.provider_name_mutated = TRIM(
					case 
							WHEN LEN(provider_name_mutated) < 3 then provider_name_mutated
							when left(TRIM(provider_name_mutated), 1) = ',' then right(provider_name_mutated, len(provider_name_mutated)-1)
							else provider_name_mutated
						end)
					, last_name_mutated = TRIM(
					case 
							WHEN LEN(last_name_mutated) < 3 then last_name_mutated
							when left(TRIM(last_name_mutated), 1) = ',' then right(last_name_mutated, len(last_name_mutated)-1)
							else last_name_mutated
						end)
					, first_name_mutated = TRIM(
					case 
							WHEN LEN(first_name_mutated) < 3 then first_name_mutated
							when left(TRIM(first_name_mutated), 1) = ',' then right(first_name_mutated, len(first_name_mutated)-1)
							else first_name_mutated
						end);`
			
			executesql(update_AllProvidersFromAllClients5,'0')
			
			// ends with comma.
			update_AllProvidersFromAllClients6 = `UPDATE tmp_AllProvidersFromAllClients x
				SET x.provider_name_mutated = 
					case 
							WHEN LEN(provider_name_mutated) < 3 then provider_name_mutated
							when right(TRIM(provider_name_mutated), 1) = ',' 
							then TRIM(left(TRIM(provider_name_mutated), len(TRIM(provider_name_mutated))-1))
							else provider_name_mutated
						end
					, x.last_name_mutated = 
					case 
							WHEN LEN(last_name_mutated) < 3 then last_name_mutated
							when right(TRIM(last_name_mutated), 1) = ',' 
							then TRIM(left(TRIM(last_name_mutated), len(TRIM(last_name_mutated))-1))
							else last_name_mutated
						end
					, x.first_name_mutated = 
					case 
							WHEN LEN(first_name_mutated) < 3 then first_name_mutated
							when right(TRIM(first_name_mutated), 1) = ',' 
							then TRIM(left(TRIM(first_name_mutated), len(TRIM(first_name_mutated))-1))
							else first_name_mutated
						end`;
						
			executesql(update_AllProvidersFromAllClients6,'0')
            
            // starts with initial - strip it.
			update_AllProvidersFromAllClients7 = `UPDATE tmp_AllProvidersFromAllClients x
				SET x.provider_name_mutated = 
					case 
							WHEN LEN(provider_name_mutated) < 3 then provider_name_mutated
							when SUBSTRING(provider_name_mutated, 3, 1) = ' ' and SUBSTRING(provider_name_mutated, 2, 1) = '.' 
							then TRIM(right(provider_name_mutated, len(provider_name_mutated)-3))
							when SUBSTRING(provider_name_mutated, 2, 1) = ' '  
							then TRIM(right(provider_name_mutated, len(provider_name_mutated)-2))
							else provider_name_mutated
						end
					, x.first_name_mutated = 
					case 
							WHEN LEN(first_name_mutated) < 3 then first_name_mutated
							when SUBSTRING(first_name_mutated, 3, 1) = ' ' and SUBSTRING(first_name_mutated, 2, 1) = '.' 
							then TRIM(right(first_name_mutated, len(first_name_mutated)-3))
							when SUBSTRING(first_name_mutated, 2, 1) = ' '  
							then TRIM(right(first_name_mutated, len(first_name_mutated)-2))
							else first_name_mutated
						end
					, x.last_name_mutated = 
					case 
							WHEN LEN(last_name_mutated) < 3 then last_name_mutated
							when SUBSTRING(last_name_mutated, 3, 1) = ' ' and SUBSTRING(last_name_mutated, 2, 1) = '.' 
							then TRIM(right(last_name_mutated, len(last_name_mutated)-3))
							when SUBSTRING(last_name_mutated, 2, 1) = ' '  
							then TRIM(right(last_name_mutated, len(last_name_mutated)-2))
							else last_name_mutated
						end;`;
			
			executesql(update_AllProvidersFromAllClients7,'0')
			
			// Ends with initial - strip it.
			update_AllProvidersFromAllClients8 = `UPDATE tmp_AllProvidersFromAllClients x
				SET x.provider_name_mutated = 
					case 
							WHEN LEN(provider_name_mutated) < 3 then provider_name_mutated
							when left(right(provider_name_mutated, 3), 1) = ' ' and right(provider_name_mutated, 1) = '.' 
							then TRIM(left(provider_name_mutated, len(provider_name_mutated)-3))
							when left(right(provider_name_mutated, 2), 1) = ' ' 
							then TRIM(left(provider_name_mutated, len(provider_name_mutated)-2))
							else provider_name_mutated
						end
					, x.first_name_mutated = 
					case 
							WHEN LEN(first_name_mutated) < 3 then first_name_mutated
							when left(right(first_name_mutated, 3), 1) = ' ' and right(first_name_mutated, 1) = '.' 
							then TRIM(left(first_name_mutated, len(first_name_mutated)-3))
							when left(right(first_name_mutated, 2), 1) = ' ' 
							then TRIM(left(first_name_mutated, len(first_name_mutated)-2))
							else first_name_mutated
						end
					, x.last_name_mutated = 
					case 
							WHEN LEN(last_name_mutated) < 3 then last_name_mutated
							when left(right(last_name_mutated, 3), 1) = ' ' and right(last_name_mutated, 1) = '.' 
							then TRIM(left(last_name_mutated, len(last_name_mutated)-3))
							when left(right(last_name_mutated, 2), 1) = ' ' 
							then TRIM(left(last_name_mutated, len(last_name_mutated)-2))
							else last_name_mutated
						end;`
						
			executesql(update_AllProvidersFromAllClients8,'0')
			
			// Repeated comma in case it opened up again (it does)
			update_AllProvidersFromAllClients9 = `UPDATE tmp_AllProvidersFromAllClients x
				SET provider_name_mutated = 
					case 
							WHEN LEN(provider_name_mutated) < 3 then provider_name_mutated
							when right(TRIM(provider_name_mutated), 1) = ',' 
							then TRIM(left(TRIM(provider_name_mutated), len(TRIM(provider_name_mutated))-1))
							else provider_name_mutated
						end
					, last_name_mutated = 
					case 
							WHEN LEN(last_name_mutated) < 3 then last_name_mutated
							when right(TRIM(last_name_mutated), 1) = ',' 
							then TRIM(left(TRIM(last_name_mutated), len(TRIM(last_name_mutated))-1))
							else last_name_mutated
						end
					, first_name_mutated = 
					case 
							WHEN LEN(first_name_mutated) < 3 then first_name_mutated
							when right(TRIM(first_name_mutated), 1) = ',' 
							then TRIM(left(TRIM(first_name_mutated), len(TRIM(first_name_mutated))-1))
							else first_name_mutated
						end;`;
			
			executesql(update_AllProvidersFromAllClients9,'0')
			
			// hmm.. for firstname and lastname, remove items after a space if they exist.

			update_AllProvidersFromAllClients10 = `UPDATE tmp_AllProvidersFromAllClients x
			SET
				x.first_name_mutated = TRIM(
					CASE
							when charindex(' ', first_name_mutated, 1) < 1 then first_name_mutated
							else left(first_name_mutated, charindex(' ', first_name_mutated, 1))
						end)
				, x.last_name_mutated = TRIM(
					CASE
							when charindex(' ', last_name_mutated, 1) < 1 then last_name_mutated
							else left(last_name_mutated, charindex(' ', last_name_mutated, 1))
						end);`;
				
			executesql(update_AllProvidersFromAllClients10,'0')

			// Normalize capitalization to make it look prettier.
			
			update_AllProvidersFromAllClients11 = `UPDATE tmp_AllProvidersFromAllClients x
			SET
				first_name_mutated  = CASE WHEN LEN(first_name_mutated) <= 1 then UPPER(first_name_mutated) ELSE concat(UPPER(LEFT(first_name_mutated, 1)) , lower(RIGHT(first_name_mutated, len(first_name_mutated)-1))) end
				, last_name_mutated = CASE WHEN LEN(last_name_mutated) <=  1 then UPPER(last_name_mutated) ELSE concat(UPPER(LEFT(last_name_mutated, 1)) , lower(RIGHT(last_name_mutated, len(last_name_mutated)-1))) end
			;`;
			
			executesql(update_AllProvidersFromAllClients11,'0')

			// Clean Phone_number for special charecters.
			
			update_AllProvidersFromAllClients12 = `UPDATE tmp_AllProvidersFromAllClients x
			SET PHONE_NUMBER = REPLACE(REPLACE(REPLACE(REPLACE(PHONE_NUMBER,'-',''),'(',''),')',''),' ','')
			;`;
			
			executesql(update_AllProvidersFromAllClients12,'0')
			// Clean FAX_NUMBER for special charecters.
			
			update_AllProvidersFromAllClients13 = `UPDATE tmp_AllProvidersFromAllClients x
			SET FAX_NUMBER = REPLACE(REPLACE(REPLACE(REPLACE(FAX_NUMBER,'-',''),'(',''),')',''),' ','')
			;`;
			
			executesql(update_AllProvidersFromAllClients13,'0')
			// Clean FEDERAL_TAX_ID for special charecters.
			
			update_AllProvidersFromAllClients14 = `UPDATE tmp_AllProvidersFromAllClients x
			SET FEDERAL_TAX_ID = REPLACE(REPLACE(REPLACE(REPLACE(FEDERAL_TAX_ID,'-',''),'(',''),')',''),' ','')
			;`;
			
			executesql(update_AllProvidersFromAllClients14,'0')
            
            // JCD - Kludge - This needs to be removed or handled in some other way.
			// We are leaving this in because its a data abnormality that has to be handled by the data team.
			// They have not yet completed this part so leaving this in.  When they fix this, this code will do nothing.
			// Until they fix this, this code will remove the duplicate value.  
			del_AllProvidersFromAllClients = `DELETE FROM tmp_AllProvidersFromAllClients x
			using 
				(
					select *
					, row_number() over (partition by system_source_value, client_source_value, provider_source_value order by system_source_value) as rn
					from tmp_AllProvidersFromAllClients
				) rownum
			where
				rownum.rn > 1 and x.system_source_value = rownum.system_source_value and x.client_source_value = rownum.client_source_value and
				x.provider_source_value = rownum.provider_source_value and x.AllProvidersFromAllClientsId = rownum.AllProvidersFromAllClientsId;`
			
			executesql(del_AllProvidersFromAllClients,'0')
			
			
			// Updates before removing already processed providers to allow them to be pulled into the process to update existing data

			update_AllProvidersMaster1 = `UPDATE tmp_AllProvidersMaster x
			SET x.last_name = ap.last_name
			FROM tmp_AllProvidersMaster T
				INNER JOIN tmp_AllProvidersFromAllClients ap
					ON T.MasterProviderId = ap.provider_mpi_id
			WHERE COALESCE(T.last_name,'') = ''
				AND COALESCE(ap.last_name,'') <> ''
				AND x.MasterProviderId = ap.provider_mpi_id;`
				
			executesql(update_AllProvidersMaster1,'0')
			
			
			update_AllProvidersMaster2 = `UPDATE tmp_AllProvidersMaster x
			SET x.last_name_mutated = ap.last_name_mutated
			FROM tmp_AllProvidersMaster T
				INNER JOIN tmp_AllProvidersFromAllClients ap
					ON T.MasterProviderId = ap.provider_mpi_id
			WHERE COALESCE(T.last_name_mutated,'') = ''
				AND COALESCE(ap.last_name_mutated,'') <> ''
				AND x.MasterProviderId = ap.provider_mpi_id;`
				
			executesql(update_AllProvidersMaster2,'0')
			
			
			update_AllProvidersMaster3 = `UPDATE tmp_AllProvidersMaster x
			SET x.first_name = ap.first_name
			FROM tmp_AllProvidersMaster T
				INNER JOIN tmp_AllProvidersFromAllClients ap
					ON T.MasterProviderId = ap.provider_mpi_id
			WHERE COALESCE(T.first_name,'') = ''
				AND COALESCE(ap.first_name,'') <> ''
				AND x.MasterProviderId = ap.provider_mpi_id;`
				
			executesql(update_AllProvidersMaster3,'0')
			
			
			update_AllProvidersMaster4 = `UPDATE tmp_AllProvidersMaster x
			SET x.first_name_mutated = ap.first_name_mutated
			FROM tmp_AllProvidersMaster T
				INNER JOIN tmp_AllProvidersFromAllClients ap
					ON T.MasterProviderId = ap.provider_mpi_id
			WHERE COALESCE(T.first_name_mutated,'') = ''
				AND COALESCE(ap.first_name_mutated,'') <> ''
				AND x.MasterProviderId = ap.provider_mpi_id;`
				
			executesql(update_AllProvidersMaster4,'0')
			
			
			update_AllProvidersMaster5 = `UPDATE tmp_AllProvidersMaster x
			SET x.NPI = ap.NPI
			FROM tmp_AllProvidersMaster T
				INNER JOIN tmp_AllProvidersFromAllClients ap
					ON T.MasterProviderId = ap.provider_mpi_id
			WHERE COALESCE(T.NPI,'') = ''
				AND COALESCE(ap.NPI,'') <> ''
				AND x.MasterProviderId = ap.provider_mpi_id;`
				
			executesql(update_AllProvidersMaster5,'0')
			
			
			update_AllProvidersMaster6 = `UPDATE tmp_AllProvidersMaster x
			SET x.email_address = ap.email_address
			FROM tmp_AllProvidersMaster T
				INNER JOIN tmp_AllProvidersFromAllClients ap
					ON T.MasterProviderId = ap.provider_mpi_id
			WHERE COALESCE(T.email_address,'') = ''
				AND COALESCE(ap.email_address,'') <> ''
				AND COALESCE(x.email_address,'') = ''
				AND x.MasterProviderId = ap.provider_mpi_id;`
				
			executesql(update_AllProvidersMaster6,'0')
			
			
			update_AllProvidersMaster7 = `UPDATE tmp_AllProvidersMaster x
			SET x.phone_number = ap.phone_number
			FROM tmp_AllProvidersMaster T
				INNER JOIN tmp_AllProvidersFromAllClients ap
					ON T.MasterProviderId = ap.provider_mpi_id
			WHERE COALESCE(T.phone_number,'') = ''
				AND COALESCE(ap.phone_number,'') <> ''
				AND COALESCE(x.phone_number,'') = ''
				AND x.MasterProviderId = ap.provider_mpi_id;`
				
			executesql(update_AllProvidersMaster7,'0')
			
			
			update_AllProvidersMaster8 = `UPDATE tmp_AllProvidersMaster x
			SET x.fax_number = ap.fax_number
			FROM tmp_AllProvidersMaster T
				INNER JOIN tmp_AllProvidersFromAllClients ap
					ON T.MasterProviderId = ap.provider_mpi_id
			WHERE COALESCE(T.fax_number,'') = ''
				AND COALESCE(ap.fax_number,'') <> ''
				AND COALESCE(x.fax_number,'') = ''
				AND x.MasterProviderId = ap.provider_mpi_id;`
				
			executesql(update_AllProvidersMaster8,'0')
			
			
			update_AllProvidersMaster9 = `UPDATE tmp_AllProvidersMaster x
			SET x.federal_tax_id = ap.federal_tax_id
			FROM tmp_AllProvidersMaster T
				INNER JOIN tmp_AllProvidersFromAllClients ap
					ON T.MasterProviderId = ap.provider_mpi_id
			WHERE COALESCE(T.federal_tax_id,'') = ''
				AND COALESCE(ap.federal_tax_id,'') <> ''
				AND COALESCE(x.federal_tax_id,'') = ''
				AND x.MasterProviderId = ap.provider_mpi_id;`
				
			executesql(update_AllProvidersMaster9,'0')
			
			
			// SELECTing the smallest MPI value when more than one is available
			update_ProviderXwalk1 = `UPDATE tmp_ProviderXwalk x
			SET x.MasterProviderId = mm.provider_mpi_id
			from
			tmp_AllProvidersFromAllClients t
			JOIN tmp_ProviderXwalk xw
					ON UPPER(concat('0x',t.client_source_value_hash_512)) = UPPER(xw.client_source_value_hash_512)
					and UPPER(concat('0x',t.system_source_value_hash_512)) = UPPER(xw.system_source_value_hash_512)
					and UPPER(concat('0x',t.provider_source_value_hash_512)) = UPPER(xw.provider_source_value_hash_512)
					and t.npi <> ''
			JOIN(
			WITH MINMPI AS
				(SELECT client_id, NPI, MIN(provider_mpi_id) provider_mpi_id
					FROM tmp_AllProvidersFromAllClients  
					WHERE provider_mpi_id IS NOT NULL 
					GROUP BY client_id,NPI)select * from MINMPI)mm
					ON t.NPI = mm.NPI
					AND t.client_id = mm.client_id
			WHERE x.client_source_value_hash_512 = UPPER(concat('0x',t.client_source_value_hash_512))
			AND x.system_source_value_hash_512 = UPPER(concat('0x',t.system_source_value_hash_512))
			AND x.provider_source_value_hash_512 = UPPER(concat('0x',t.provider_source_value_hash_512));`;
			
			executesql(update_ProviderXwalk1,'0')
			
			
			// Remove any already processed in a past run.
			// IE - before this procedure was called OR in a link we found in our last loop.
			del_AllProvidersFromAllClients2 = `DELETE FROM tmp_AllProvidersFromAllClients x
			using(select t.client_source_value_hash_512, t.system_source_value_hash_512,t.provider_source_value_hash_512 from
				tmp_AllProvidersFromAllClients t
				inner join tmp_ProviderXwalk xw
					on 
						UPPER(concat('0x',t.client_source_value_hash_512))   =    UPPER(xw.client_source_value_hash_512)
						and UPPER(concat('0x',t.system_source_value_hash_512))   = UPPER(xw.system_source_value_hash_512)
						and UPPER(concat('0x',t.provider_source_value_hash_512)) = UPPER(xw.provider_source_value_hash_512))ctes
			where UPPER(ctes.client_source_value_hash_512)   =     UPPER(x.client_source_value_hash_512)
			        and UPPER(ctes.system_source_value_hash_512)   = UPPER(x.system_source_value_hash_512)
					and  UPPER(ctes.provider_source_value_hash_512) = UPPER(x.provider_source_value_hash_512);`;
					
			executesql(del_AllProvidersFromAllClients2,'0')
                  
                  
            // Find new matches based on an absolute complete match (allowing whitespace matching whitespace)
			insert_ProviderXwalk2 = `insert all  
			into tmp_ProviderXwalk(Provider_XWalkId ,ClientId, client_source_value, system_source_value, provider_source_value, MasterProviderId, 
			client_source_value_hash_512, system_source_value_hash_512, provider_source_value_hash_512) 
			values (pxwalkid, client_id,client_source_value,system_source_value,provider_source_value,MasterProviderId,client_source_value_hash_512,system_source_value_hash_512,provider_source_value_hash_512)
			into tmp_NewProviderXwalkRecords(client_source_value_hash_512, system_source_value_hash_512, provider_source_value_hash_512)
			values (client_source_value_hash_512,system_source_value_hash_512,provider_source_value_hash_512)
            SELECT
                uniqueIDseq2.nextval as pxwalkid
				, client_id
				, client_source_value
				, system_source_value
				, provider_source_value
				, MasterProviderId
				, client_source_value_hash_512
				, system_source_value_hash_512
				, provider_source_value_hash_512
			from (SELECT
				  client_id
				, client_source_value
				, system_source_value
				, provider_source_value
				, MasterProviderId
				, UPPER(concat('0x',client_source_value_hash_512)) as client_source_value_hash_512
				, UPPER(concat('0x',system_source_value_hash_512)) as system_source_value_hash_512
				, UPPER(concat('0x',provider_source_value_hash_512)) as provider_source_value_hash_512
			from (
				SELECT 
					ac.client_id
					, ac.client_source_value
					, ac.system_source_value
					, ac.provider_source_value
					, m.MasterProviderId
					, ac.client_source_value_hash_512
					, ac.system_source_value_hash_512
					, ac.provider_source_value_hash_512
					, ROW_NUMBER() OVER (
						partition by 
							ac.client_source_value
							, ac.system_source_value
							, ac.provider_source_value
						order by case when m.NPI = ac.NPI then 1 else 0 end desc, (
							case when UPPER(m.first_name_mutated) = UPPER(ac.first_name_mutated) then 1 else 0 end
							+ case when UPPER(m.last_name_mutated) = UPPER(ac.last_name_mutated) then 1 else 0 end
							+ case when UPPER(m.provider_name_mutated) = UPPER(ac.provider_name_mutated) then 1 else 0 end
							+ case when UPPER(m.email_address) = UPPER(ac.email_address) then 1 else 0 end
							+ case when m.phone_number = ac.phone_number then 1 else 0 end
							+ case when m.fax_number = ac.fax_number then 1 else 0 end
							+ case when m.federal_tax_id = ac.federal_tax_id then 1 else 0 end
							+ case when m.NPI = ac.NPI then 1 else 0 end
							) desc
					) as rownum
				from
					tmp_AllProvidersMaster m
					inner join tmp_AllProvidersFromAllClients ac
						on 
							UPPER(m.first_name_mutated) = UPPER(ac.first_name_mutated)
							and UPPER(m.last_name_mutated) = UPPER(ac.last_name_mutated)
							and m.provider_name = ac.provider_name
							and UPPER(m.provider_name_mutated) = UPPER(ac.provider_name_mutated)
							and UPPER(m.email_address) = UPPER(ac.email_address)
							and m.phone_number = ac.phone_number
							and m.fax_number = ac.fax_number
							and m.federal_tax_id = ac.federal_tax_id
							and m.NPI = ac.NPI
					where
						(
							   (LEN(TRIM(COALESCE(ac.NPI, ''))) > 0)
							or (LEN(TRIM(COALESCE(ac.last_name_mutated, ''))) > 0 AND LEN(TRIM(COALESCE(ac.email_address, ''))) > 0)
							OR (LEN(TRIM(COALESCE(ac.first_name_mutated, ''))) > 0 AND LEN(TRIM(COALESCE(ac.last_name_mutated, ''))) > 0 AND LEN(TRIM(COALESCE(ac.phone_number, ''))) > 0)
							OR (LEN(TRIM(COALESCE(ac.first_name_mutated, ''))) > 0 AND LEN(TRIM(COALESCE(ac.last_name_mutated, ''))) > 0 AND LEN(TRIM(COALESCE(ac.fax_number, ''))) > 0)
							OR (LEN(TRIM(COALESCE(ac.first_name_mutated, ''))) > 0 AND LEN(TRIM(COALESCE(ac.last_name_mutated, ''))) > 0 AND LEN(TRIM(COALESCE(ac.federal_tax_id, ''))) > 0)
						)
				) q
			where
				q.rownum = 1);`;
				
			executesql(insert_ProviderXwalk2,'0')
                  
                  
            del_AllProvidersFromAllClients3 = `DELETE FROM tmp_AllProvidersFromAllClients x
			using
			(select t.client_source_value_hash_512, t.system_source_value_hash_512, t.provider_source_value_hash_512 FROM
				tmp_AllProvidersFromAllClients t
				inner join tmp_ProviderXwalk xw
					on 
						UPPER(concat('0x',t.client_source_value_hash_512))   =     UPPER(xw.client_source_value_hash_512)
						and UPPER(concat('0x',t.system_source_value_hash_512))   = UPPER(xw.system_source_value_hash_512)
						and UPPER(concat('0x',t.provider_source_value_hash_512)) = UPPER(xw.provider_source_value_hash_512))ctes
			where UPPER(ctes.client_source_value_hash_512)   =     UPPER(x.client_source_value_hash_512)
			        and UPPER(ctes.system_source_value_hash_512)   = UPPER(x.system_source_value_hash_512)
					and  UPPER(ctes.provider_source_value_hash_512) = UPPER(x.provider_source_value_hash_512);`;
				
			
			executesql(del_AllProvidersFromAllClients3,'0')
			
			
			// Find new matches on NPI
			ident_curr_xwalk = `SELECT MAX(Provider_XWalkId) as IDENT FROM tmp_ProviderXwalk`;
			var res = executesql(ident_curr_xwalk, '0');
			res.next();
			var ident_curr_xwalk_val = res.getColumnValue(1)+1;
			
			xwalk_seq = `CREATE OR REPLACE SEQUENCE uniqueIDseq2 start = {!__ident_curr_xwalk_val__!} increment=1`;
			xwalk_seq = xwalk_seq.replace('{!__ident_curr_xwalk_val__!}', ident_curr_xwalk_val);
			executesql(xwalk_seq, '0');
			
			insert_ProviderXwalk3 = `INSERT all
			into tmp_ProviderXwalk(Provider_XWalkId,ClientId, client_source_value, system_source_value, provider_source_value, MasterProviderId, 
			client_source_value_hash_512, system_source_value_hash_512, provider_source_value_hash_512) 
			values (pxwalkid,client_id,client_source_value,system_source_value,provider_source_value,MasterProviderId,client_source_value_hash_512,system_source_value_hash_512,provider_source_value_hash_512)
			into tmp_NewProviderXwalkRecords(client_source_value_hash_512, system_source_value_hash_512, provider_source_value_hash_512)
			values (client_source_value_hash_512,system_source_value_hash_512,provider_source_value_hash_512)
            SELECT 
                uniqueIDseq2.nextval as pxwalkid
				, client_id
				, client_source_value
				, system_source_value
				, provider_source_value
				, MasterProviderId
				, client_source_value_hash_512
				, system_source_value_hash_512
				, provider_source_value_hash_512
			from (SELECT 
				  client_id
				, client_source_value
				, system_source_value
				, provider_source_value
				, MasterProviderId
				, UPPER(concat('0x',client_source_value_hash_512)) as client_source_value_hash_512
				, UPPER(concat('0x',system_source_value_hash_512)) as system_source_value_hash_512
				, UPPER(concat('0x',provider_source_value_hash_512)) as provider_source_value_hash_512
			from (
				SELECT 
					ac.client_id
					, ac.client_source_value
					, ac.system_source_value
					, ac.provider_source_value
					, m.MasterProviderId
					, ac.client_source_value_hash_512
					, ac.system_source_value_hash_512
					, ac.provider_source_value_hash_512
					, ROW_NUMBER() OVER (
						partition by 
							ac.client_source_value
							, ac.system_source_value
							, ac.provider_source_value
						order by case when m.NPI = ac.NPI then 1 else 0 end desc, (
							case when UPPER(m.first_name_mutated) = UPPER(ac.first_name_mutated) then 1 else 0 end
							+ case when UPPER(m.last_name_mutated) = UPPER(ac.last_name_mutated) then 1 else 0 end
							+ case when UPPER(m.provider_name_mutated) = UPPER(ac.provider_name_mutated) then 1 else 0 end
							+ case when UPPER(m.email_address) = UPPER(ac.email_address) then 1 else 0 end
							+ case when m.phone_number = ac.phone_number then 1 else 0 end
							+ case when m.fax_number = ac.fax_number then 1 else 0 end
							+ case when m.federal_tax_id = ac.federal_tax_id then 1 else 0 end
							+ case when m.NPI = ac.NPI then 1 else 0 end
							) desc
					) as rownum
				from
					tmp_AllProvidersMaster m
					inner join tmp_AllProvidersFromAllClients ac
						on m.NPI = ac.NPI
				where
					len(ac.npi) > 0
				) q
			where
				q.rownum = 1);`;
				
			executesql(insert_ProviderXwalk3,'0')
			
			
			del_AllProvidersFromAllClients4 = `DELETE FROM tmp_AllProvidersFromAllClients x
			using
			(select t.client_source_value_hash_512, t.system_source_value_hash_512, t.provider_source_value_hash_512 from
				tmp_AllProvidersFromAllClients t
				inner join tmp_ProviderXwalk xw
					on 
						UPPER(concat('0x',t.client_source_value_hash_512))   =     UPPER(xw.client_source_value_hash_512)
						and UPPER(concat('0x',t.system_source_value_hash_512))   = UPPER(xw.system_source_value_hash_512)
						and UPPER(concat('0x',t.provider_source_value_hash_512)) = UPPER(xw.provider_source_value_hash_512))ctes
			where UPPER(ctes.client_source_value_hash_512)   =     UPPER(x.client_source_value_hash_512)
			        and UPPER(ctes.system_source_value_hash_512)   = UPPER(x.system_source_value_hash_512)
					and  UPPER(ctes.provider_source_value_hash_512) = UPPER(x.provider_source_value_hash_512);`;
				
			executesql(del_AllProvidersFromAllClients4,'0')
			
			
			// Find new matches on Lastname, Email
			
			ident_curr_xwalk = `SELECT MAX(Provider_XWalkId) as IDENT FROM tmp_ProviderXwalk`;
			var res = executesql(ident_curr_xwalk, '0');
			res.next();
			var ident_curr_xwalk_val = res.getColumnValue(1)+1;
			
			xwalk_seq = `CREATE OR REPLACE SEQUENCE uniqueIDseq2 start = {!__ident_curr_xwalk_val__!} increment=1`;
			xwalk_seq = xwalk_seq.replace('{!__ident_curr_xwalk_val__!}', ident_curr_xwalk_val);
			executesql(xwalk_seq, '0');
			
			insert_ProviderXwalk4 = `INSERT all
			into tmp_ProviderXwalk(Provider_XWalkId,ClientId, client_source_value, system_source_value, provider_source_value, MasterProviderId, 
			client_source_value_hash_512, system_source_value_hash_512, provider_source_value_hash_512) 
			values (pxwalkid,client_id,client_source_value,system_source_value,provider_source_value,MasterProviderId,client_source_value_hash_512,system_source_value_hash_512,provider_source_value_hash_512)
			into tmp_NewProviderXwalkRecords(client_source_value_hash_512, system_source_value_hash_512, provider_source_value_hash_512)
			values (client_source_value_hash_512,system_source_value_hash_512,provider_source_value_hash_512)
            SELECT 
                uniqueIDseq2.nextval as pxwalkid
				, client_id
				, client_source_value
				, system_source_value
				, provider_source_value
				, MasterProviderId
				, client_source_value_hash_512
				, system_source_value_hash_512
				, provider_source_value_hash_512
			from (SELECT 
				  client_id
				, client_source_value
				, system_source_value
				, provider_source_value
				, MasterProviderId
				, UPPER(concat('0x',client_source_value_hash_512)) as client_source_value_hash_512
				, UPPER(concat('0x',system_source_value_hash_512)) as system_source_value_hash_512
				, UPPER(concat('0x',provider_source_value_hash_512)) as provider_source_value_hash_512
			from (
				SELECT 
					ac.client_id
					, ac.client_source_value
					, ac.system_source_value
					, ac.provider_source_value
					, m.MasterProviderId
					, ac.client_source_value_hash_512
					, ac.system_source_value_hash_512
					, ac.provider_source_value_hash_512
					, ROW_NUMBER() OVER (
						partition by 
							ac.client_source_value
							, ac.system_source_value
							, ac.provider_source_value
						order by case when m.NPI = ac.NPI then 1 else 0 end desc, (
							case when UPPER(m.first_name_mutated) = UPPER(ac.first_name_mutated) then 1 else 0 end
							+ case when UPPER(m.last_name_mutated) = UPPER(ac.last_name_mutated) then 1 else 0 end
							+ case when UPPER(m.provider_name_mutated) = UPPER(ac.provider_name_mutated) then 1 else 0 end
							+ case when UPPER(m.email_address) = UPPER(ac.email_address) then 1 else 0 end
							+ case when m.phone_number = ac.phone_number then 1 else 0 end
							+ case when m.fax_number = ac.fax_number then 1 else 0 end
							+ case when m.federal_tax_id = ac.federal_tax_id then 1 else 0 end
							+ case when m.NPI = ac.NPI then 1 else 0 end
							) desc
					) as rownum
				from
					tmp_AllProvidersMaster m
					inner join tmp_AllProvidersFromAllClients ac
						on m.last_name_mutated = ac.last_name_mutated
						and m.email_address = ac.email_address
				where
						LEN(TRIM(COALESCE(ac.last_name_mutated, ''))) > 0
					and LEN(TRIM(COALESCE(ac.email_address, ''))) > 0
					and (
						LEN(ac.NPI) = 0
						OR
						LEN(M.NPI) = 0
						OR
						AC.NPI = M.NPI
					)
				) q
			where
				q.rownum = 1);`;
				
			executesql(insert_ProviderXwalk4,'0')
			
			
			del_AllProvidersFromAllClients5 = `DELETE FROM tmp_AllProvidersFromAllClients x
			using
			(select t.client_source_value_hash_512, t.system_source_value_hash_512, t.provider_source_value_hash_512 from
				tmp_AllProvidersFromAllClients t
				inner join tmp_ProviderXwalk xw
					on 
						UPPER(concat('0x',t.client_source_value_hash_512))   =     UPPER(xw.client_source_value_hash_512)
						and UPPER(concat('0x',t.system_source_value_hash_512))   = UPPER(xw.system_source_value_hash_512)
						and UPPER(concat('0x',t.provider_source_value_hash_512)) = UPPER(xw.provider_source_value_hash_512))ctes
			where UPPER(ctes.client_source_value_hash_512)   =     UPPER(x.client_source_value_hash_512)
			        and UPPER(ctes.system_source_value_hash_512)   = UPPER(x.system_source_value_hash_512)
					and  UPPER(ctes.provider_source_value_hash_512) = UPPER(x.provider_source_value_hash_512);`;
				
			executesql(del_AllProvidersFromAllClients5,'0')
			
			
			// Find new matches on Firstname, Lastname, Phone
			ident_curr_xwalk = `SELECT MAX(Provider_XWalkId) as IDENT FROM tmp_ProviderXwalk`;
			var res = executesql(ident_curr_xwalk, '0');
			res.next();
			var ident_curr_xwalk_val = res.getColumnValue(1)+1;
			
			xwalk_seq = `CREATE OR REPLACE SEQUENCE uniqueIDseq2 start = {!__ident_curr_xwalk_val__!} increment=1`;
			xwalk_seq = xwalk_seq.replace('{!__ident_curr_xwalk_val__!}', ident_curr_xwalk_val);
			executesql(xwalk_seq, '0');
			
			insert_ProviderXwalk5 = `INSERT all
			into tmp_ProviderXwalk(Provider_XWalkId,ClientId, client_source_value, system_source_value, provider_source_value, MasterProviderId, 
			client_source_value_hash_512, system_source_value_hash_512, provider_source_value_hash_512) 
			values (pxwalkid,client_id,client_source_value,system_source_value,provider_source_value,MasterProviderId,client_source_value_hash_512,system_source_value_hash_512,provider_source_value_hash_512)
			into tmp_NewProviderXwalkRecords(client_source_value_hash_512, system_source_value_hash_512, provider_source_value_hash_512)
			values (client_source_value_hash_512,system_source_value_hash_512,provider_source_value_hash_512)
            SELECT 
                uniqueIDseq2.nextval as pxwalkid
				, client_id
				, client_source_value
				, system_source_value
				, provider_source_value
				, MasterProviderId
				, client_source_value_hash_512
				, system_source_value_hash_512
				, provider_source_value_hash_512
			from (SELECT 
				  client_id
				, client_source_value
				, system_source_value
				, provider_source_value
				, MasterProviderId
				, UPPER(concat('0x',client_source_value_hash_512)) as client_source_value_hash_512
				, UPPER(concat('0x',system_source_value_hash_512)) as system_source_value_hash_512
				, UPPER(concat('0x',provider_source_value_hash_512)) as provider_source_value_hash_512
			from (
				SELECT 
					ac.client_id
					, ac.client_source_value
					, ac.system_source_value
					, ac.provider_source_value
					, m.MasterProviderId
					, ac.client_source_value_hash_512
					, ac.system_source_value_hash_512
					, ac.provider_source_value_hash_512
					, ROW_NUMBER() OVER (
						partition by 
							ac.client_source_value
							, ac.system_source_value
							, ac.provider_source_value
						order by case when m.NPI = ac.NPI then 1 else 0 end desc, (
							case when UPPER(m.first_name_mutated) = UPPER(ac.first_name_mutated) then 1 else 0 end
							+ case when UPPER(m.last_name_mutated) = UPPER(ac.last_name_mutated) then 1 else 0 end
							+ case when UPPER(m.provider_name_mutated) = UPPER(ac.provider_name_mutated) then 1 else 0 end
							+ case when UPPER(m.email_address) = UPPER(ac.email_address) then 1 else 0 end
							+ case when m.phone_number = ac.phone_number then 1 else 0 end
							+ case when m.fax_number = ac.fax_number then 1 else 0 end
							+ case when m.federal_tax_id = ac.federal_tax_id then 1 else 0 end
							+ case when m.NPI = ac.NPI then 1 else 0 end
							) desc
					) as rownum
				from
					tmp_AllProvidersMaster m
					inner join tmp_AllProvidersFromAllClients ac
						on UPPER(m.first_name_mutated) = UPPER(ac.first_name_mutated)
						and UPPER(m.last_name_mutated) = UPPER(ac.last_name_mutated)
						and m.phone_number = ac.phone_number
				where
						LEN(TRIM(COALESCE(ac.first_name_mutated, ''))) > 0
					AND LEN(TRIM(COALESCE(ac.last_name_mutated, ''))) > 0
					AND LEN(TRIM(COALESCE(ac.phone_number, ''))) > 0
					and (
						LEN(ac.NPI) = 0
						OR
						LEN(M.NPI) = 0
						OR
						AC.NPI = M.NPI
					)
				) q
			where
				q.rownum = 1);`;
			
			executesql(insert_ProviderXwalk5,'0')
			
			
			del_AllProvidersFromAllClients6 = `DELETE FROM tmp_AllProvidersFromAllClients x
			using
			(select t.client_source_value_hash_512, t.system_source_value_hash_512, t.provider_source_value_hash_512 from
				tmp_AllProvidersFromAllClients t
				inner join tmp_ProviderXwalk xw
					on 
						UPPER(concat('0x',t.client_source_value_hash_512))   =     UPPER(xw.client_source_value_hash_512)
						and UPPER(concat('0x',t.system_source_value_hash_512))   = UPPER(xw.system_source_value_hash_512)
						and UPPER(concat('0x',t.provider_source_value_hash_512)) = UPPER(xw.provider_source_value_hash_512))ctes
			where UPPER(ctes.client_source_value_hash_512)   =     UPPER(x.client_source_value_hash_512)
			        and UPPER(ctes.system_source_value_hash_512)   = UPPER(x.system_source_value_hash_512)
					and  UPPER(ctes.provider_source_value_hash_512) = UPPER(x.provider_source_value_hash_512);`;
				
			executesql(del_AllProvidersFromAllClients6,'0')
			
			
			// Find new matches on Firstname, Lastname, fax
			ident_curr_xwalk = `SELECT MAX(Provider_XWalkId) as IDENT FROM tmp_ProviderXwalk`;
			var res = executesql(ident_curr_xwalk, '0');
			res.next();
			var ident_curr_xwalk_val = res.getColumnValue(1)+1;
			
			xwalk_seq = `CREATE OR REPLACE SEQUENCE uniqueIDseq2 start = {!__ident_curr_xwalk_val__!} increment=1`;
			xwalk_seq = xwalk_seq.replace('{!__ident_curr_xwalk_val__!}', ident_curr_xwalk_val);
			executesql(xwalk_seq, '0');
			
			insert_ProviderXwalk6 = `INSERT all
			into tmp_ProviderXwalk(Provider_XWalkId,ClientId, client_source_value, system_source_value, provider_source_value, MasterProviderId, 
			client_source_value_hash_512, system_source_value_hash_512, provider_source_value_hash_512) 
			values (pxwalkid,client_id,client_source_value,system_source_value,provider_source_value,MasterProviderId,client_source_value_hash_512,system_source_value_hash_512,provider_source_value_hash_512)
			into tmp_NewProviderXwalkRecords(client_source_value_hash_512, system_source_value_hash_512, provider_source_value_hash_512)
			values (client_source_value_hash_512,system_source_value_hash_512,provider_source_value_hash_512)
            SELECT 
                uniqueIDseq2.nextval as pxwalkid
				, client_id
				, client_source_value
				, system_source_value
				, provider_source_value
				, MasterProviderId
				, client_source_value_hash_512
				, system_source_value_hash_512
				, provider_source_value_hash_512
			from (SELECT 
				  client_id
				, client_source_value
				, system_source_value
				, provider_source_value
				, MasterProviderId
				, UPPER(concat('0x',client_source_value_hash_512)) as client_source_value_hash_512
				, UPPER(concat('0x',system_source_value_hash_512)) as system_source_value_hash_512
				, UPPER(concat('0x',provider_source_value_hash_512)) as provider_source_value_hash_512
			from (
				SELECT 
					ac.client_id
					, ac.client_source_value
					, ac.system_source_value
					, ac.provider_source_value
					, m.MasterProviderId
					, ac.client_source_value_hash_512
					, ac.system_source_value_hash_512
					, ac.provider_source_value_hash_512
					, ROW_NUMBER() OVER (
						partition by 
							ac.client_source_value
							, ac.system_source_value
							, ac.provider_source_value
						order by case when m.NPI = ac.NPI then 1 else 0 end desc,  (
							case when UPPER(m.first_name_mutated) = UPPER(ac.first_name_mutated) then 1 else 0 end
							+ case when UPPER(m.last_name_mutated) = UPPER(ac.last_name_mutated) then 1 else 0 end
							+ case when UPPER(m.provider_name_mutated) = UPPER(ac.provider_name_mutated) then 1 else 0 end
							+ case when UPPER(m.email_address) = UPPER(ac.email_address) then 1 else 0 end
							+ case when m.phone_number = ac.phone_number then 1 else 0 end
							+ case when m.fax_number = ac.fax_number then 1 else 0 end
							+ case when m.federal_tax_id = ac.federal_tax_id then 1 else 0 end
							+ case when m.NPI = ac.NPI then 1 else 0 end
							) desc
					) as rownum
				from
					tmp_AllProvidersMaster m
					inner join tmp_AllProvidersFromAllClients ac
						on UPPER(m.first_name_mutated) = UPPER(ac.first_name_mutated)
						and UPPER(m.last_name_mutated) = UPPER(ac.last_name_mutated)
						and m.fax_number = ac.fax_number
				where
						LEN(TRIM(COALESCE(ac.first_name_mutated, ''))) > 0
					and LEN(TRIM(COALESCE(ac.last_name_mutated, ''))) > 0
					and LEN(TRIM(COALESCE(ac.fax_number, ''))) > 0
					and (
						LEN(ac.NPI) = 0
						OR
						LEN(M.NPI) = 0
						OR
						AC.NPI = M.NPI
					)
				) q
			where
				q.rownum = 1);`;
				
			executesql(insert_ProviderXwalk6,'0')
			
			
			del_AllProvidersFromAllClients7 = `DELETE FROM tmp_AllProvidersFromAllClients x
			using
			(select t.client_source_value_hash_512, t.system_source_value_hash_512, t.provider_source_value_hash_512 from
				tmp_AllProvidersFromAllClients t
				inner join tmp_ProviderXwalk xw
					on 
						UPPER(concat('0x',t.client_source_value_hash_512))   =     UPPER(xw.client_source_value_hash_512)
						and UPPER(concat('0x',t.system_source_value_hash_512))   = UPPER(xw.system_source_value_hash_512)
						and UPPER(concat('0x',t.provider_source_value_hash_512)) = UPPER(xw.provider_source_value_hash_512))ctes
			where UPPER(ctes.client_source_value_hash_512)   =     UPPER(x.client_source_value_hash_512)
			        and UPPER(ctes.system_source_value_hash_512)   = UPPER(x.system_source_value_hash_512)
					and  UPPER(ctes.provider_source_value_hash_512) = UPPER(x.provider_source_value_hash_512);`;
				
			executesql(del_AllProvidersFromAllClients7,'0')
			
			
			// Find new matches on Firstname, Lastname, taxid
			ident_curr_xwalk = `SELECT MAX(Provider_XWalkId) as IDENT FROM tmp_ProviderXwalk`;
			var res = executesql(ident_curr_xwalk, '0');
			res.next();
			var ident_curr_xwalk_val = res.getColumnValue(1)+1;
			
			xwalk_seq = `CREATE OR REPLACE SEQUENCE uniqueIDseq2 start = {!__ident_curr_xwalk_val__!} increment=1`;
			xwalk_seq = xwalk_seq.replace('{!__ident_curr_xwalk_val__!}', ident_curr_xwalk_val);
			executesql(xwalk_seq, '0');
			
			insert_ProviderXwalk7 = `INSERT all
			into tmp_ProviderXwalk(Provider_XWalkId,ClientId, client_source_value, system_source_value, provider_source_value, MasterProviderId, 
			client_source_value_hash_512, system_source_value_hash_512, provider_source_value_hash_512) 
			values (pxwalkid, client_id,client_source_value,system_source_value,provider_source_value,MasterProviderId,client_source_value_hash_512,system_source_value_hash_512,provider_source_value_hash_512)
			into tmp_NewProviderXwalkRecords(client_source_value_hash_512, system_source_value_hash_512, provider_source_value_hash_512)
			values (client_source_value_hash_512,system_source_value_hash_512,provider_source_value_hash_512)
            SELECT 
                uniqueIDseq2.nextval as pxwalkid
				, client_id
				, client_source_value
				, system_source_value
				, provider_source_value
				, MasterProviderId
				, client_source_value_hash_512
				, system_source_value_hash_512
				, provider_source_value_hash_512
			from (SELECT 
				  client_id
				, client_source_value
				, system_source_value
				, provider_source_value
				, MasterProviderId
				, UPPER(concat('0x',client_source_value_hash_512)) as client_source_value_hash_512
				, UPPER(concat('0x',system_source_value_hash_512)) as system_source_value_hash_512
				, UPPER(concat('0x',provider_source_value_hash_512)) as provider_source_value_hash_512
			from (
				SELECT 
					ac.client_id
					, ac.client_source_value
					, ac.system_source_value
					, ac.provider_source_value
					, m.MasterProviderId
					, ac.client_source_value_hash_512
					, ac.system_source_value_hash_512
					, ac.provider_source_value_hash_512
					, ROW_NUMBER() OVER (
						partition by 
							ac.client_source_value
							, ac.system_source_value
							, ac.provider_source_value
						order by case when m.NPI = ac.NPI then 1 else 0 end desc,  (
							case when UPPER(m.first_name_mutated) = UPPER(ac.first_name_mutated) then 1 else 0 end
							+ case when UPPER(m.last_name_mutated) = UPPER(ac.last_name_mutated) then 1 else 0 end
							+ case when UPPER(m.provider_name_mutated) = UPPER(ac.provider_name_mutated) then 1 else 0 end
							+ case when UPPER(m.email_address) = UPPER(ac.email_address) then 1 else 0 end
							+ case when m.phone_number = ac.phone_number then 1 else 0 end
							+ case when m.fax_number = ac.fax_number then 1 else 0 end
							+ case when m.federal_tax_id = ac.federal_tax_id then 1 else 0 end
							+ case when m.NPI = ac.NPI then 1 else 0 end
							) desc
					) as rownum
				from
					tmp_AllProvidersMaster m
					inner join tmp_AllProvidersFromAllClients ac
						on UPPER(m.first_name_mutated) = UPPER(ac.first_name_mutated)
						and UPPER(m.last_name_mutated) = UPPER(ac.last_name_mutated)
						and m.federal_tax_id = ac.federal_tax_id
				where
						LEN(TRIM(COALESCE(ac.first_name_mutated, ''))) > 0
					and LEN(TRIM(COALESCE(ac.last_name_mutated, ''))) > 0
					and LEN(TRIM(COALESCE(ac.federal_tax_id, ''))) > 0
					and (
						LEN(ac.NPI) = 0
						OR
						LEN(M.NPI) = 0
						OR
						AC.NPI = M.NPI
					)
				) q
			where
				q.rownum = 1);`;
			
			executesql(insert_ProviderXwalk7,'0')
			
			
			del_AllProvidersFromAllClients8 = `DELETE FROM tmp_AllProvidersFromAllClients x
			using
			(select t.client_source_value_hash_512, t.system_source_value_hash_512, t.provider_source_value_hash_512 from
				tmp_AllProvidersFromAllClients t
				inner join tmp_ProviderXwalk xw
					on 
						UPPER(concat('0x',t.client_source_value_hash_512))   =     UPPER(xw.client_source_value_hash_512)
						and UPPER(concat('0x',t.system_source_value_hash_512))   = UPPER(xw.system_source_value_hash_512)
						and UPPER(concat('0x',t.provider_source_value_hash_512)) = UPPER(xw.provider_source_value_hash_512))ctes
			where UPPER(ctes.client_source_value_hash_512)   =     UPPER(x.client_source_value_hash_512)
			        and UPPER(ctes.system_source_value_hash_512)   = UPPER(x.system_source_value_hash_512)
					and  UPPER(ctes.provider_source_value_hash_512) = UPPER(x.provider_source_value_hash_512);`;
				
			executesql(del_AllProvidersFromAllClients8,'0')
			
			
			// Find new matches on Firstname, Lastname for a client if they have no data for our other values.
			// Lock it to only be for clients that have already seen this though.. so if we just have firstname lastname then it is just
			// going for people that are on the same client as the one value we are trying to insert.
			// not ideal, but its too hazy otherwise.
			ident_curr_xwalk = `SELECT MAX(Provider_XWalkId) as IDENT FROM tmp_ProviderXwalk`;
			var res = executesql(ident_curr_xwalk, '0');
			res.next();
			var ident_curr_xwalk_val = res.getColumnValue(1)+1;
			
			xwalk_seq = `CREATE OR REPLACE SEQUENCE uniqueIDseq2 start = {!__ident_curr_xwalk_val__!} increment=1`;
			xwalk_seq = xwalk_seq.replace('{!__ident_curr_xwalk_val__!}', ident_curr_xwalk_val);
			executesql(xwalk_seq, '0');
			
			insert_ProviderXwalk8 = `INSERT all 
			into tmp_ProviderXwalk(Provider_XWalkId,ClientId, client_source_value, system_source_value, provider_source_value, MasterProviderId, 
			client_source_value_hash_512, system_source_value_hash_512, provider_source_value_hash_512) 
			values (pxwalkid,client_id,client_source_value,system_source_value,provider_source_value,MasterProviderId,client_source_value_hash_512,system_source_value_hash_512,provider_source_value_hash_512)
			into tmp_NewProviderXwalkRecords(client_source_value_hash_512, system_source_value_hash_512, provider_source_value_hash_512)
			values (client_source_value_hash_512,system_source_value_hash_512,provider_source_value_hash_512)
            SELECT
                 uniqueIDseq2.nextval as pxwalkid
				, client_id
				, client_source_value
				, system_source_value
				, provider_source_value
				, MasterProviderId
				, client_source_value_hash_512
				, system_source_value_hash_512
				, provider_source_value_hash_512
			from (SELECT
				  client_id
				, client_source_value
				, system_source_value
				, provider_source_value
				, MasterProviderId
				, UPPER(concat('0x',client_source_value_hash_512)) as client_source_value_hash_512
				, UPPER(concat('0x',system_source_value_hash_512)) as system_source_value_hash_512
				, UPPER(concat('0x',provider_source_value_hash_512)) as provider_source_value_hash_512
			from (
				SELECT 
					ac.client_id
					, ac.client_source_value
					, ac.system_source_value
					, ac.provider_source_value
					, m.MasterProviderId
					, ac.client_source_value_hash_512
					, ac.system_source_value_hash_512
					, ac.provider_source_value_hash_512
					, ROW_NUMBER() OVER (
						partition by 
							ac.client_source_value
							, ac.system_source_value
							, ac.provider_source_value
						order by case when m.NPI = ac.NPI then 1 else 0 end desc,  (
							case when UPPER(m.first_name_mutated) = UPPER(ac.first_name_mutated) then 1 else 0 end
							+ case when UPPER(m.last_name_mutated) = UPPER(ac.last_name_mutated) then 1 else 0 end
							+ case when UPPER(m.provider_name_mutated) = UPPER(ac.provider_name_mutated) then 1 else 0 end
							+ case when UPPER(m.email_address) = UPPER(ac.email_address) then 1 else 0 end
							+ case when m.phone_number = ac.phone_number then 1 else 0 end
							+ case when m.fax_number = ac.fax_number then 1 else 0 end
							+ case when m.federal_tax_id = ac.federal_tax_id then 1 else 0 end
							+ case when m.NPI = ac.NPI then 1 else 0 end
							) desc
					) as rownum
				from
					tmp_AllProvidersMaster m
					inner join tmp_AllProvidersFromAllClients ac
						on UPPER(m.first_name_mutated) = UPPER(ac.first_name_mutated)
						and UPPER(m.last_name_mutated) = UPPER(ac.last_name_mutated)
				where
						LEN(TRIM(COALESCE(ac.first_name_mutated, ''))) > 0
					and LEN(TRIM(COALESCE(ac.last_name_mutated, ''))) > 0
					and (
						LEN(ac.NPI) = 0
						OR
						LEN(M.NPI) = 0
						OR
						AC.NPI = M.NPI
					)
				) q
			where
				q.rownum = 1);`;
				
			executesql(insert_ProviderXwalk8,'0')
			
			
			del_AllProvidersFromAllClients9 = `DELETE FROM tmp_AllProvidersFromAllClients x
			using
			(select t.client_source_value_hash_512, t.system_source_value_hash_512, t.provider_source_value_hash_512 from
				tmp_AllProvidersFromAllClients t
				inner join tmp_ProviderXwalk xw
					on 
						UPPER(concat('0x',t.client_source_value_hash_512))   =     UPPER(xw.client_source_value_hash_512)
						and UPPER(concat('0x',t.system_source_value_hash_512))   = UPPER(xw.system_source_value_hash_512)
						and UPPER(concat('0x',t.provider_source_value_hash_512)) = UPPER(xw.provider_source_value_hash_512))ctes
			where UPPER(ctes.client_source_value_hash_512)   =     UPPER(x.client_source_value_hash_512)
			        and UPPER(ctes.system_source_value_hash_512)   = UPPER(x.system_source_value_hash_512)
					and  UPPER(ctes.provider_source_value_hash_512) = UPPER(x.provider_source_value_hash_512);`;
				
			executesql(del_AllProvidersFromAllClients9,'0')

					
			// Find new matches on Provider_name for a client if they have no data for our other values.
			// not ideal, but its too hazy otherwise.
			ident_curr_xwalk = `SELECT MAX(Provider_XWalkId) as IDENT FROM tmp_ProviderXwalk`;
			var res = executesql(ident_curr_xwalk, '0');
			res.next();
			var ident_curr_xwalk_val = res.getColumnValue(1)+1;
			
			xwalk_seq = `CREATE OR REPLACE SEQUENCE uniqueIDseq2 start = {!__ident_curr_xwalk_val__!} increment=1`;
			xwalk_seq = xwalk_seq.replace('{!__ident_curr_xwalk_val__!}', ident_curr_xwalk_val);
			executesql(xwalk_seq, '0');
			
			insert_ProviderXwalk9 = `INSERT all 
			into tmp_ProviderXwalk(Provider_XWalkId,ClientId, client_source_value, system_source_value, provider_source_value, MasterProviderId, 
			client_source_value_hash_512, system_source_value_hash_512, provider_source_value_hash_512) 
			values (pxwalkid,client_id,client_source_value,system_source_value,provider_source_value,MasterProviderId,client_source_value_hash_512,system_source_value_hash_512,provider_source_value_hash_512)
			into tmp_NewProviderXwalkRecords(client_source_value_hash_512, system_source_value_hash_512, provider_source_value_hash_512)
			values (client_source_value_hash_512,system_source_value_hash_512,provider_source_value_hash_512)
            SELECT
                 uniqueIDseq2.nextval as pxwalkid
				, client_id
				, client_source_value
				, system_source_value
				, provider_source_value
				, MasterProviderId
				, client_source_value_hash_512
				, system_source_value_hash_512
				, provider_source_value_hash_512
			from (SELECT
				  client_id
				, client_source_value
				, system_source_value
				, provider_source_value
				, MasterProviderId
				, UPPER(concat('0x',client_source_value_hash_512)) as client_source_value_hash_512
				, UPPER(concat('0x',system_source_value_hash_512)) as system_source_value_hash_512
				, UPPER(concat('0x',provider_source_value_hash_512)) as provider_source_value_hash_512
			from (
				SELECT 
					ac.client_id
					, ac.client_source_value
					, ac.system_source_value
					, ac.provider_source_value
					, m.MasterProviderId
					, ac.client_source_value_hash_512
					, ac.system_source_value_hash_512
					, ac.provider_source_value_hash_512
					, ROW_NUMBER() OVER (
						partition by 
							ac.client_source_value
							, ac.system_source_value
							, ac.provider_source_value
						order by case when m.NPI = ac.NPI then 1 else 0 end desc,  (
							case when UPPER(m.first_name_mutated) = UPPER(ac.first_name_mutated) then 1 else 0 end
							+ case when UPPER(m.last_name_mutated) = UPPER(ac.last_name_mutated) then 1 else 0 end
							+ case when UPPER(m.provider_name_mutated) = UPPER(ac.provider_name_mutated) then 1 else 0 end
							+ case when UPPER(m.email_address) = UPPER(ac.email_address) then 1 else 0 end
							+ case when m.phone_number = ac.phone_number then 1 else 0 end
							+ case when m.fax_number = ac.fax_number then 1 else 0 end
							+ case when m.federal_tax_id = ac.federal_tax_id then 1 else 0 end
							+ case when m.NPI = ac.NPI then 1 else 0 end
							) desc
					) as rownum
				from
					tmp_AllProvidersMaster m
					inner join tmp_AllProvidersFromAllClients ac
						on UPPER(m.provider_name_mutated) = UPPER(ac.provider_name_mutated)
						AND LEN(TRIM(COALESCE(m.first_name_mutated, ''))) = 0 AND LEN(TRIM(COALESCE(ac.first_name_mutated, ''))) = 0 
						AND LEN(TRIM(COALESCE(m.last_name_mutated, ''))) = 0 AND LEN(TRIM(COALESCE(ac.last_name_mutated, ''))) = 0
				where
						LEN(TRIM(COALESCE(ac.provider_name_mutated, ''))) > 0
					and (
						LEN(ac.NPI) = 0
						OR
						LEN(M.NPI) = 0
						OR
						AC.NPI = M.NPI
					)
				) q
			where
				q.rownum = 1);`;
				
			executesql(insert_ProviderXwalk9,'0')
			
			
			del_AllProvidersFromAllClients10 = `DELETE FROM tmp_AllProvidersFromAllClients x
			using
			(select t.client_source_value_hash_512, t.system_source_value_hash_512, t.provider_source_value_hash_512 from
				tmp_AllProvidersFromAllClients t
				inner join tmp_ProviderXwalk xw
					on 
						UPPER(concat('0x',t.client_source_value_hash_512))   =     UPPER(xw.client_source_value_hash_512)
						and UPPER(concat('0x',t.system_source_value_hash_512))   = UPPER(xw.system_source_value_hash_512)
						and UPPER(concat('0x',t.provider_source_value_hash_512)) = UPPER(xw.provider_source_value_hash_512))ctes
			where UPPER(ctes.client_source_value_hash_512)   =     UPPER(x.client_source_value_hash_512)
			        and UPPER(ctes.system_source_value_hash_512)   = UPPER(x.system_source_value_hash_512)
					and  UPPER(ctes.provider_source_value_hash_512) = UPPER(x.provider_source_value_hash_512);`;
				
			executesql(del_AllProvidersFromAllClients10,'0')


            
            // Creating Staging table to hold all the  reamining records before instering into tmp_ProviderXwalk and tmp_AllProvidersMaster
			// so blocking on the actual table will be kept in check.			
            executesql(`Drop table if exists tmp_StagingMaster`,'0');
			create_StagingMaster = `CREATE TEMPORARY TABLE tmp_StagingMaster (
					MasterProviderId NUMBER(38,0) NOT null IDENTITY(1,1)
					, Provider_XWalkId NUMBER(38,0) not null IDENTITY(1,1)
					, ClientId NUMBER(38,0) not null
					, first_name varchar(100) NOT NULL
					, first_name_mutated varchar(100) NOT NULL
					, last_name varchar(100) NOT NULL
					, last_name_mutated varchar(100) NOT NULL
					, provider_name varchar(255) NOT NULL
					, provider_name_mutated varchar(255) not null
					, email_address varchar(1000) NOT NULL
					, phone_number varchar(50) NOT NULL
					, fax_number varchar(50) NOT NULL
					, federal_tax_id varchar(20) NOT NULL
					, NPI varchar(20) NOT NULL
					, client_source_value varchar(50) NOT NULL
					, system_source_value varchar(50) NOT NULL
					, provider_source_value varchar(50) NOT NULL
					, client_source_value_hash_512 varchar(16777216) not null
					, system_source_value_hash_512 varchar(16777216) not null
					, provider_source_value_hash_512 varchar(16777216) not null);`;
			executesql(create_StagingMaster, '0');
			
			ident_curr_mpi = `SELECT MAX(MasterProviderId) as IDENT FROM tmp_AllProvidersMaster`;
			var res = executesql(ident_curr_mpi, '0');
			res.next();
			var ident_curr_mpi_val = res.getColumnValue(1);
			
			mpi_seq = `CREATE OR REPLACE SEQUENCE uniqueIDseq1 start = {!__ident_curr_mpi_val__!} increment=1`;
			mpi_seq = mpi_seq.replace('{!__ident_curr_mpi_val__!}', ident_curr_mpi_val+1);
			executesql(mpi_seq, '0');
			
			ident_curr_xwalk = `SELECT MAX(Provider_XWalkId) as IDENT FROM tmp_ProviderXwalk`;
			var res = executesql(ident_curr_xwalk, '0');
			res.next();
			var ident_curr_xwalk_val = res.getColumnValue(1)+1;
			
			xwalk_seq = `CREATE OR REPLACE SEQUENCE uniqueIDseq2 start = {!__ident_curr_xwalk_val__!} increment=1`;
			xwalk_seq = xwalk_seq.replace('{!__ident_curr_xwalk_val__!}', ident_curr_xwalk_val);
			executesql(xwalk_seq, '0');
			
            // Now that we have matched up as many as we can, lets insert new records.
			
			// Inserting new records(which are coming with existing NPI) with old MPI values from MasterProviderIndex  
			insert_tmp_StagingMaster1 = `INSERT INTO tmp_StagingMaster(Provider_XWalkId, MasterProviderId, ClientId, first_name, last_name, first_name_mutated, last_name_mutated, 
			provider_name, provider_name_mutated, email_address, phone_number, fax_number, federal_tax_id, NPI, client_source_value, system_source_value, provider_source_value,
			client_source_value_hash_512, system_source_value_hash_512, provider_source_value_hash_512 )
            select
                uniqueIDseq2.nextval as Provider_XWalkId
				, MasterProviderId
				, client_id
				, first_name
				, last_name
				, first_name_mutated
				, last_name_mutated
				, provider_name
				, provider_name_mutated
				, email_address
				, phone_number
				, fax_number
				, federal_tax_id
				, NPI
				, client_source_value
				, system_source_value
				, provider_source_value
				, UPPER(concat('0x',client_source_value_hash_512)) as client_source_value_hash_512
				, UPPER(concat('0x',system_source_value_hash_512)) as system_source_value_hash_512
				, UPPER(concat('0x',provider_source_value_hash_512)) as provider_source_value_hash_512
			from (select
				DISTINCT
				m.MasterProviderId
				, q.client_id
				, q.first_name
				, q.last_name
				, q.first_name_mutated
				, q.last_name_mutated
				, q.provider_name
				, q.provider_name_mutated
				, q.email_address
				, q.phone_number
				, q.fax_number
				, q.federal_tax_id
				, q.NPI
				, q.client_source_value
				, q.system_source_value
				, q.provider_source_value
				, q.client_source_value_hash_512
				, q.system_source_value_hash_512
				, q.provider_source_value_hash_512
				FROM 
					tmp_AllProvidersFromAllClients q
				INNER JOIN tmp_AllProvidersMaster m
					on q.NPI = m.NPI 
                WHERE LEN(TRIM(COALESCE(q.NPI, ''))) > 0
			) Q ;`;
			
			executesql(insert_tmp_StagingMaster1,'0')
			
			del_AllProvidersFromAllClients11 = `DELETE FROM tmp_AllProvidersFromAllClients x
			using
			(select t.client_source_value_hash_512, t.system_source_value_hash_512, t.provider_source_value_hash_512 from
				tmp_AllProvidersFromAllClients t
				inner join tmp_StagingMaster xw
					on 
						UPPER(concat('0x',t.client_source_value_hash_512))   =     UPPER(xw.client_source_value_hash_512)
						and UPPER(concat('0x',t.system_source_value_hash_512))   = UPPER(xw.system_source_value_hash_512)
						and UPPER(concat('0x',t.provider_source_value_hash_512)) = UPPER(xw.provider_source_value_hash_512))ctes
			where UPPER(ctes.client_source_value_hash_512)   =     UPPER(x.client_source_value_hash_512)
			        and UPPER(ctes.system_source_value_hash_512)   = UPPER(x.system_source_value_hash_512)
					and  UPPER(ctes.provider_source_value_hash_512) = UPPER(x.provider_source_value_hash_512);`;
				
			executesql(del_AllProvidersFromAllClients11,'0')

			// People with different NPI are different people.  Insert all the NPI that is remaining. (Max on a single insert per npi... it will match up next time.)
			insert_tmp_StagingMaster2 = `INSERT INTO tmp_StagingMaster(MasterProviderId, Provider_XWalkId, ClientId, first_name, last_name, first_name_mutated, last_name_mutated, 
			provider_name, provider_name_mutated, email_address, phone_number, fax_number, federal_tax_id, NPI, client_source_value, system_source_value, provider_source_value,
			client_source_value_hash_512, system_source_value_hash_512, provider_source_value_hash_512 )
            select
                uniqueIDseq1.nextval as MasterProviderId
				, uniqueIDseq2.nextval as Provider_XWalkId
				, client_id
				, first_name
				, last_name
				, first_name_mutated
				, last_name_mutated
				, provider_name
				, provider_name_mutated
				, email_address
				, phone_number
				, fax_number
				, federal_tax_id
				, NPI
				, client_source_value
				, system_source_value
				, provider_source_value
				, UPPER(concat('0x',client_source_value_hash_512)) as client_source_value_hash_512
				, UPPER(concat('0x',system_source_value_hash_512)) as system_source_value_hash_512
				, UPPER(concat('0x',provider_source_value_hash_512)) as provider_source_value_hash_512
			from (select
				  q.client_id
				, q.first_name
				, q.last_name
				, q.first_name_mutated
				, q.last_name_mutated
				, q.provider_name
				, q.provider_name_mutated
				, q.email_address
				, q.phone_number
				, q.fax_number
				, q.federal_tax_id
				, q.NPI
				, q.client_source_value
				, q.system_source_value
				, q.provider_source_value
				, q.client_source_value_hash_512
				, q.system_source_value_hash_512
				, q.provider_source_value_hash_512
			from (
				SELECT
					T.client_id
					, t.first_name
					, t.last_name
					, T.first_name_mutated
					, T.last_name_mutated
					, T.provider_name
					, T.provider_name_mutated
					, T.email_address
					, T.phone_number
					, T.fax_number
					, T.federal_tax_id
					, T.NPI
					, T.client_source_value
					, T.system_source_value
					, T.provider_source_value
					, T.client_source_value_hash_512
					, T.system_source_value_hash_512
					, T.provider_source_value_hash_512
					, ROW_NUMBER() OVER (PARTITION BY NPI ORDER BY 
					(
					  CASE WHEN LEN(TRIM(COALESCE(first_name_mutated, ''))) > 0 then 1 else 0 end
					+ CASE WHEN LEN(TRIM(COALESCE(last_name_mutated, ''))) > 0 then 1 else 0 end
					+ CASE WHEN LEN(TRIM(COALESCE(provider_name, ''))) > 0 then 1 else 0 end
					+ CASE WHEN LEN(TRIM(COALESCE(email_address, ''))) > 0 then 1 else 0 end
					+ CASE WHEN LEN(TRIM(COALESCE(phone_number, ''))) > 0 then 1 else 0 end
					+ CASE WHEN LEN(TRIM(COALESCE(fax_number, ''))) > 0 then 1 else 0 end
					+ CASE WHEN LEN(TRIM(COALESCE(federal_tax_id, ''))) > 0 then 1 else 0 end
					+ CASE WHEN LEN(TRIM(COALESCE(NPI, ''))) > 0 then 1 else 0 end)
					desc) as RN
				FROM 
					tmp_AllProvidersFromAllClients T
				WHERE
					LEN(TRIM(COALESCE(T.NPI, ''))) > 0
			) Q where q.rn = 1);`;
			
			executesql(insert_tmp_StagingMaster2,'0')
			
			del_AllProvidersFromAllClients12 = `DELETE FROM tmp_AllProvidersFromAllClients x
			using
			(select t.client_source_value_hash_512, t.system_source_value_hash_512, t.provider_source_value_hash_512 from
				tmp_AllProvidersFromAllClients t
				inner join tmp_StagingMaster xw
					on 
						UPPER(concat('0x',t.client_source_value_hash_512))   =     UPPER(xw.client_source_value_hash_512)
						and UPPER(concat('0x',t.system_source_value_hash_512))   = UPPER(xw.system_source_value_hash_512)
						and UPPER(concat('0x',t.provider_source_value_hash_512)) = UPPER(xw.provider_source_value_hash_512))ctes
			where UPPER(ctes.client_source_value_hash_512)   =     UPPER(x.client_source_value_hash_512)
			        and UPPER(ctes.system_source_value_hash_512)   = UPPER(x.system_source_value_hash_512)
					and  UPPER(ctes.provider_source_value_hash_512) = UPPER(x.provider_source_value_hash_512);`;
				
			executesql(del_AllProvidersFromAllClients12,'0')
			
			
			// Assigining same MPI values for the records with same NPI
			
			insert_tmp_StagingMaster3 = `INSERT INTO tmp_StagingMaster(Provider_XWalkId, MasterProviderId, ClientId, first_name, last_name, first_name_mutated, last_name_mutated, 
			provider_name, provider_name_mutated, email_address, phone_number, fax_number, federal_tax_id, NPI, client_source_value, system_source_value, provider_source_value,
			client_source_value_hash_512, system_source_value_hash_512, provider_source_value_hash_512 )
            select
                uniqueIDseq2.nextval as Provider_XWalkId
				, MasterProviderId
				, client_id
				, first_name
				, last_name
				, first_name_mutated
				, last_name_mutated
				, provider_name
				, provider_name_mutated
				, email_address
				, phone_number
				, fax_number
				, federal_tax_id
				, NPI
				, client_source_value
				, system_source_value
				, provider_source_value
				, UPPER(concat('0x',client_source_value_hash_512)) as client_source_value_hash_512
				, UPPER(concat('0x',system_source_value_hash_512)) as system_source_value_hash_512
				, UPPER(concat('0x',provider_source_value_hash_512)) as provider_source_value_hash_512
			from (select
				DISTINCT
				tmp.MasterProviderId
				, q.client_id
				, q.first_name
				, q.last_name
				, q.first_name_mutated
				, q.last_name_mutated
				, q.provider_name
				, q.provider_name_mutated
				, q.email_address
				, q.phone_number
				, q.fax_number
				, q.federal_tax_id
				, q.NPI
				, q.client_source_value
				, q.system_source_value
				, q.provider_source_value
				, q.client_source_value_hash_512
				, q.system_source_value_hash_512
				, q.provider_source_value_hash_512
				FROM 
					tmp_AllProvidersFromAllClients q
				INNER JOIN tmp_StagingMaster tmp
					on q.NPI = tmp.NPI
                WHERE LEN(TRIM(COALESCE(q.NPI, ''))) > 0
			) Q ;`;
			
			executesql(insert_tmp_StagingMaster3,'0')
			
			del_AllProvidersFromAllClients13 = `DELETE FROM tmp_AllProvidersFromAllClients x
			using
			(select t.client_source_value_hash_512, t.system_source_value_hash_512, t.provider_source_value_hash_512 from
				tmp_AllProvidersFromAllClients t
				inner join tmp_StagingMaster xw
					on 
						UPPER(concat('0x',t.client_source_value_hash_512))   =     UPPER(xw.client_source_value_hash_512)
						and UPPER(concat('0x',t.system_source_value_hash_512))   = UPPER(xw.system_source_value_hash_512)
						and UPPER(concat('0x',t.provider_source_value_hash_512)) = UPPER(xw.provider_source_value_hash_512))ctes
			where UPPER(ctes.client_source_value_hash_512)   =     UPPER(x.client_source_value_hash_512)
			        and UPPER(ctes.system_source_value_hash_512)   = UPPER(x.system_source_value_hash_512)
					and  UPPER(ctes.provider_source_value_hash_512) = UPPER(x.provider_source_value_hash_512);`;
				
			executesql(del_AllProvidersFromAllClients13,'0')
		
			

			ident_curr_mpi = `SELECT MAX(MasterProviderId) as IDENT FROM tmp_StagingMaster`;
			var res = executesql(ident_curr_mpi, '0');
			res.next();
			var ident_curr_mpi_val = res.getColumnValue(1)+1;
			
			
			ident_curr_mpi_Orig = `SELECT MAX(MasterProviderId) as IDENT FROM tmp_AllProvidersMaster`;
			var res_2 = executesql(ident_curr_mpi_Orig, '0');
			res_2.next();
			var ident_curr_mpi_val_Orig = res_2.getColumnValue(1)+1;
			
			mpi_seq = `CREATE OR REPLACE SEQUENCE uniqueIDseq1 start = {!__ident_curr_mpi_val__!} increment=1`;
			if (ident_curr_mpi_val_Orig > ident_curr_mpi_val)
			{
				mpi_seq = mpi_seq.replace('{!__ident_curr_mpi_val__!}', ident_curr_mpi_val_Orig);
			}
			else
			{
				mpi_seq = mpi_seq.replace('{!__ident_curr_mpi_val__!}', ident_curr_mpi_val);
			}
				executesql(mpi_seq, '0');
			
			
			ident_curr_xwalk = `SELECT MAX(Provider_XWalkId) as IDENT FROM tmp_StagingMaster`;
			var res = executesql(ident_curr_xwalk, '0');
			res.next();
			var ident_curr_xwalk_val = res.getColumnValue(1)+1;
			
			
			ident_curr_xwalk_Orig = `SELECT MAX(Provider_XWalkId) as IDENT FROM tmp_ProviderXwalk`;
			var res_3 = executesql(ident_curr_xwalk_Orig, '0');
			res_3.next();
			var ident_curr_xwalk_val_Orig = res_3.getColumnValue(1)+1;
			
			xwalk_seq = `CREATE OR REPLACE SEQUENCE uniqueIDseq2 start = {!__ident_curr_xwalk_val__!} increment=1`;
			if (ident_curr_xwalk_val_Orig > ident_curr_xwalk_val)
			{
				xwalk_seq = xwalk_seq.replace('{!__ident_curr_xwalk_val__!}', ident_curr_xwalk_val_Orig);
			}
			else
			{
				xwalk_seq = xwalk_seq.replace('{!__ident_curr_xwalk_val__!}', ident_curr_xwalk_val);
			}
			executesql(xwalk_seq, '0');

			// People with different last_name_mutated,email_address are different people.  Insert all the last_name_mutated,email_address that is remaining. (Max on a single insert per last_name_mutated,email_address... it will match up next time.)
			insert_tmp_StagingMaster4 = `INSERT INTO tmp_StagingMaster(MasterProviderId, Provider_XWalkId, ClientId, first_name, last_name, first_name_mutated, last_name_mutated, 
				provider_name, provider_name_mutated, email_address, phone_number, fax_number, federal_tax_id, NPI, client_source_value, system_source_value, provider_source_value,
				client_source_value_hash_512, system_source_value_hash_512, provider_source_value_hash_512 )
				select
					uniqueIDseq1.nextval as MasterProviderId
					, uniqueIDseq2.nextval as Provider_XWalkId
					, client_id
					, first_name
					, last_name
					, first_name_mutated
					, last_name_mutated
					, provider_name
					, provider_name_mutated
					, email_address
					, phone_number
					, fax_number
					, federal_tax_id
					, NPI
					, client_source_value
					, system_source_value
					, provider_source_value
					, UPPER(concat('0x',client_source_value_hash_512)) as client_source_value_hash_512
					, UPPER(concat('0x',system_source_value_hash_512)) as system_source_value_hash_512
					, UPPER(concat('0x',provider_source_value_hash_512)) as provider_source_value_hash_512
				from (select
					  q.client_id
					, q.first_name
					, q.last_name
					, q.first_name_mutated
					, q.last_name_mutated
					, q.provider_name
					, q.provider_name_mutated
					, q.email_address
					, q.phone_number
					, q.fax_number
					, q.federal_tax_id
					, q.NPI
					, q.client_source_value
					, q.system_source_value
					, q.provider_source_value
					, q.client_source_value_hash_512
					, q.system_source_value_hash_512
					, q.provider_source_value_hash_512
				from (
					SELECT
						T.client_id
						, t.first_name
						, t.last_name
						, T.first_name_mutated
						, T.last_name_mutated
						, T.provider_name
						, T.provider_name_mutated
						, T.email_address
						, T.phone_number
						, T.fax_number
						, T.federal_tax_id
						, T.NPI
						, T.client_source_value
						, T.system_source_value
						, T.provider_source_value
						, T.client_source_value_hash_512
						, T.system_source_value_hash_512
						, T.provider_source_value_hash_512
						, ROW_NUMBER() OVER (PARTITION BY T.last_name_mutated, T.email_address ORDER BY 
						(
						  CASE WHEN LEN(TRIM(COALESCE(first_name_mutated, ''))) > 0 then 1 else 0 end
						+ CASE WHEN LEN(TRIM(COALESCE(last_name_mutated, ''))) > 0 then 1 else 0 end
						+ CASE WHEN LEN(TRIM(COALESCE(provider_name, ''))) > 0 then 1 else 0 end
						+ CASE WHEN LEN(TRIM(COALESCE(email_address, ''))) > 0 then 1 else 0 end
						+ CASE WHEN LEN(TRIM(COALESCE(phone_number, ''))) > 0 then 1 else 0 end
						+ CASE WHEN LEN(TRIM(COALESCE(fax_number, ''))) > 0 then 1 else 0 end
						+ CASE WHEN LEN(TRIM(COALESCE(federal_tax_id, ''))) > 0 then 1 else 0 end
						+ CASE WHEN LEN(TRIM(COALESCE(NPI, ''))) > 0 then 1 else 0 end)
						desc) as RN
					FROM 
						tmp_AllProvidersFromAllClients T
					WHERE
					LEN(TRIM(COALESCE(T.last_name_mutated, ''))) > 0 AND LEN(TRIM(COALESCE(T.email_address, ''))) > 0 AND (T.last_name_mutated, T.email_address) NOT IN (SELECT DISTINCT last_name_mutated, email_address FROM tmp_StagingMaster)
				) Q where q.rn = 1);`;
				
				executesql(insert_tmp_StagingMaster4,'0')
				
				del_AllProvidersFromAllClients14 = `DELETE FROM tmp_AllProvidersFromAllClients x
				using
				(select t.client_source_value_hash_512, t.system_source_value_hash_512, t.provider_source_value_hash_512 from
					tmp_AllProvidersFromAllClients t
					inner join tmp_StagingMaster xw
						on 
							UPPER(concat('0x',t.client_source_value_hash_512))   =     UPPER(xw.client_source_value_hash_512)
							and UPPER(concat('0x',t.system_source_value_hash_512))   = UPPER(xw.system_source_value_hash_512)
							and UPPER(concat('0x',t.provider_source_value_hash_512)) = UPPER(xw.provider_source_value_hash_512))ctes
				where UPPER(ctes.client_source_value_hash_512)   =     UPPER(x.client_source_value_hash_512)
						and UPPER(ctes.system_source_value_hash_512)   = UPPER(x.system_source_value_hash_512)
						and  UPPER(ctes.provider_source_value_hash_512) = UPPER(x.provider_source_value_hash_512);`;
					
				executesql(del_AllProvidersFromAllClients14,'0')
				
				
				// Assigining same MPI values for the records with same last_name_mutated,email_address
				
				insert_tmp_StagingMaster5 = `INSERT INTO tmp_StagingMaster(Provider_XWalkId, MasterProviderId, ClientId, first_name, last_name, first_name_mutated, last_name_mutated, 
				provider_name, provider_name_mutated, email_address, phone_number, fax_number, federal_tax_id, NPI, client_source_value, system_source_value, provider_source_value,
				client_source_value_hash_512, system_source_value_hash_512, provider_source_value_hash_512 )
				select
					uniqueIDseq2.nextval as Provider_XWalkId
					, MasterProviderId
					, client_id
					, first_name
					, last_name
					, first_name_mutated
					, last_name_mutated
					, provider_name
					, provider_name_mutated
					, email_address
					, phone_number
					, fax_number
					, federal_tax_id
					, NPI
					, client_source_value
					, system_source_value
					, provider_source_value
					, UPPER(concat('0x',client_source_value_hash_512)) as client_source_value_hash_512
					, UPPER(concat('0x',system_source_value_hash_512)) as system_source_value_hash_512
					, UPPER(concat('0x',provider_source_value_hash_512)) as provider_source_value_hash_512
				from (select
					DISTINCT
					tmp.MasterProviderId
					, q.client_id
					, q.first_name
					, q.last_name
					, q.first_name_mutated
					, q.last_name_mutated
					, q.provider_name
					, q.provider_name_mutated
					, q.email_address
					, q.phone_number
					, q.fax_number
					, q.federal_tax_id
					, q.NPI
					, q.client_source_value
					, q.system_source_value
					, q.provider_source_value
					, q.client_source_value_hash_512
					, q.system_source_value_hash_512
					, q.provider_source_value_hash_512
					FROM 
						tmp_AllProvidersFromAllClients q
					INNER JOIN tmp_StagingMaster tmp
						on q.last_name_mutated = tmp.last_name_mutated and q.email_address = tmp.email_address
					WHERE LEN(TRIM(COALESCE(tmp.last_name_mutated, ''))) > 0 AND LEN(TRIM(COALESCE(tmp.email_address, ''))) > 0
				) Q ;`;
				
				executesql(insert_tmp_StagingMaster5,'0')

				del_AllProvidersFromAllClients15 = `DELETE FROM tmp_AllProvidersFromAllClients x
			using
			(select t.client_source_value_hash_512, t.system_source_value_hash_512, t.provider_source_value_hash_512 from
				tmp_AllProvidersFromAllClients t
				inner join tmp_StagingMaster xw
					on 
						UPPER(concat('0x',t.client_source_value_hash_512))   =     UPPER(xw.client_source_value_hash_512)
						and UPPER(concat('0x',t.system_source_value_hash_512))   = UPPER(xw.system_source_value_hash_512)
						and UPPER(concat('0x',t.provider_source_value_hash_512)) = UPPER(xw.provider_source_value_hash_512))ctes
			where UPPER(ctes.client_source_value_hash_512)   =     UPPER(x.client_source_value_hash_512)
			        and UPPER(ctes.system_source_value_hash_512)   = UPPER(x.system_source_value_hash_512)
					and  UPPER(ctes.provider_source_value_hash_512) = UPPER(x.provider_source_value_hash_512);`;
				
			executesql(del_AllProvidersFromAllClients15,'0')

			ident_curr_mpi = `SELECT MAX(MasterProviderId) as IDENT FROM tmp_StagingMaster`;
			var res = executesql(ident_curr_mpi, '0');
			res.next();
			var ident_curr_mpi_val = res.getColumnValue(1)+1;
			
			
			ident_curr_mpi_Orig = `SELECT MAX(MasterProviderId) as IDENT FROM tmp_AllProvidersMaster`;
			var res_2 = executesql(ident_curr_mpi_Orig, '0');
			res_2.next();
			var ident_curr_mpi_val_Orig = res_2.getColumnValue(1)+1;
			
			mpi_seq = `CREATE OR REPLACE SEQUENCE uniqueIDseq1 start = {!__ident_curr_mpi_val__!} increment=1`;
			if (ident_curr_mpi_val_Orig > ident_curr_mpi_val)
			{
				mpi_seq = mpi_seq.replace('{!__ident_curr_mpi_val__!}', ident_curr_mpi_val_Orig);
			}
			else
			{
				mpi_seq = mpi_seq.replace('{!__ident_curr_mpi_val__!}', ident_curr_mpi_val);
			}
				executesql(mpi_seq, '0');
			
			
			ident_curr_xwalk = `SELECT MAX(Provider_XWalkId) as IDENT FROM tmp_StagingMaster`;
			var res = executesql(ident_curr_xwalk, '0');
			res.next();
			var ident_curr_xwalk_val = res.getColumnValue(1)+1;
			
			
			ident_curr_xwalk_Orig = `SELECT MAX(Provider_XWalkId) as IDENT FROM tmp_ProviderXwalk`;
			var res_3 = executesql(ident_curr_xwalk_Orig, '0');
			res_3.next();
			var ident_curr_xwalk_val_Orig = res_3.getColumnValue(1)+1;
			
			xwalk_seq = `CREATE OR REPLACE SEQUENCE uniqueIDseq2 start = {!__ident_curr_xwalk_val__!} increment=1`;
			if (ident_curr_xwalk_val_Orig > ident_curr_xwalk_val)
			{
				xwalk_seq = xwalk_seq.replace('{!__ident_curr_xwalk_val__!}', ident_curr_xwalk_val_Orig);
			}
			else
			{
				xwalk_seq = xwalk_seq.replace('{!__ident_curr_xwalk_val__!}', ident_curr_xwalk_val);
			}
			executesql(xwalk_seq, '0');

			// People with different first_name_mutated,last_name_mutated,phone_number are different people.  Insert all the first_name_mutated,last_name_mutated,phone_number that is remaining. (Max on a single insert per first_name_mutated,last_name_mutated,phone_number... it will match up next time.)
			insert_tmp_StagingMaster6 = `INSERT INTO tmp_StagingMaster(MasterProviderId, Provider_XWalkId, ClientId, first_name, last_name, first_name_mutated, last_name_mutated, 
				provider_name, provider_name_mutated, email_address, phone_number, fax_number, federal_tax_id, NPI, client_source_value, system_source_value, provider_source_value,
				client_source_value_hash_512, system_source_value_hash_512, provider_source_value_hash_512 )
				select
					uniqueIDseq1.nextval as MasterProviderId
					, uniqueIDseq2.nextval as Provider_XWalkId
					, client_id
					, first_name
					, last_name
					, first_name_mutated
					, last_name_mutated
					, provider_name
					, provider_name_mutated
					, email_address
					, phone_number
					, fax_number
					, federal_tax_id
					, NPI
					, client_source_value
					, system_source_value
					, provider_source_value
					, UPPER(concat('0x',client_source_value_hash_512)) as client_source_value_hash_512
					, UPPER(concat('0x',system_source_value_hash_512)) as system_source_value_hash_512
					, UPPER(concat('0x',provider_source_value_hash_512)) as provider_source_value_hash_512
				from (select
					  q.client_id
					, q.first_name
					, q.last_name
					, q.first_name_mutated
					, q.last_name_mutated
					, q.provider_name
					, q.provider_name_mutated
					, q.email_address
					, q.phone_number
					, q.fax_number
					, q.federal_tax_id
					, q.NPI
					, q.client_source_value
					, q.system_source_value
					, q.provider_source_value
					, q.client_source_value_hash_512
					, q.system_source_value_hash_512
					, q.provider_source_value_hash_512
				from (
					SELECT
						T.client_id
						, t.first_name
						, t.last_name
						, T.first_name_mutated
						, T.last_name_mutated
						, T.provider_name
						, T.provider_name_mutated
						, T.email_address
						, T.phone_number
						, T.fax_number
						, T.federal_tax_id
						, T.NPI
						, T.client_source_value
						, T.system_source_value
						, T.provider_source_value
						, T.client_source_value_hash_512
						, T.system_source_value_hash_512
						, T.provider_source_value_hash_512
						, ROW_NUMBER() OVER (PARTITION BY T.first_name_mutated, T.last_name_mutated, T.phone_number ORDER BY 
						(
						  CASE WHEN LEN(TRIM(COALESCE(first_name_mutated, ''))) > 0 then 1 else 0 end
						+ CASE WHEN LEN(TRIM(COALESCE(last_name_mutated, ''))) > 0 then 1 else 0 end
						+ CASE WHEN LEN(TRIM(COALESCE(provider_name, ''))) > 0 then 1 else 0 end
						+ CASE WHEN LEN(TRIM(COALESCE(email_address, ''))) > 0 then 1 else 0 end
						+ CASE WHEN LEN(TRIM(COALESCE(phone_number, ''))) > 0 then 1 else 0 end
						+ CASE WHEN LEN(TRIM(COALESCE(fax_number, ''))) > 0 then 1 else 0 end
						+ CASE WHEN LEN(TRIM(COALESCE(federal_tax_id, ''))) > 0 then 1 else 0 end
						+ CASE WHEN LEN(TRIM(COALESCE(NPI, ''))) > 0 then 1 else 0 end)
						desc) as RN
					FROM 
						tmp_AllProvidersFromAllClients T
					WHERE
					LEN(TRIM(COALESCE(T.first_name_mutated, ''))) > 0 AND LEN(TRIM(COALESCE(T.last_name_mutated, ''))) > 0 AND LEN(TRIM(COALESCE(T.phone_number, ''))) > 0 AND (T.first_name_mutated, T.last_name_mutated, T.phone_number) NOT IN (SELECT DISTINCT first_name_mutated, last_name_mutated, phone_number FROM tmp_StagingMaster)
				) Q where q.rn = 1);`;
				
				executesql(insert_tmp_StagingMaster6,'0')
				
				del_AllProvidersFromAllClients16 = `DELETE FROM tmp_AllProvidersFromAllClients x
				using
				(select t.client_source_value_hash_512, t.system_source_value_hash_512, t.provider_source_value_hash_512 from
					tmp_AllProvidersFromAllClients t
					inner join tmp_StagingMaster xw
						on 
							UPPER(concat('0x',t.client_source_value_hash_512))   =     UPPER(xw.client_source_value_hash_512)
							and UPPER(concat('0x',t.system_source_value_hash_512))   = UPPER(xw.system_source_value_hash_512)
							and UPPER(concat('0x',t.provider_source_value_hash_512)) = UPPER(xw.provider_source_value_hash_512))ctes
				where UPPER(ctes.client_source_value_hash_512)   =     UPPER(x.client_source_value_hash_512)
						and UPPER(ctes.system_source_value_hash_512)   = UPPER(x.system_source_value_hash_512)
						and  UPPER(ctes.provider_source_value_hash_512) = UPPER(x.provider_source_value_hash_512);`;
					
				executesql(del_AllProvidersFromAllClients16,'0')
				
				
				// Assigining same MPI values for the records with same first_name_mutated,last_name_mutated,phone_number
				
				insert_tmp_StagingMaster7 = `INSERT INTO tmp_StagingMaster(Provider_XWalkId, MasterProviderId, ClientId, first_name, last_name, first_name_mutated, last_name_mutated, 
				provider_name, provider_name_mutated, email_address, phone_number, fax_number, federal_tax_id, NPI, client_source_value, system_source_value, provider_source_value,
				client_source_value_hash_512, system_source_value_hash_512, provider_source_value_hash_512 )
				select
					uniqueIDseq2.nextval as Provider_XWalkId
					, MasterProviderId
					, client_id
					, first_name
					, last_name
					, first_name_mutated
					, last_name_mutated
					, provider_name
					, provider_name_mutated
					, email_address
					, phone_number
					, fax_number
					, federal_tax_id
					, NPI
					, client_source_value
					, system_source_value
					, provider_source_value
					, UPPER(concat('0x',client_source_value_hash_512)) as client_source_value_hash_512
					, UPPER(concat('0x',system_source_value_hash_512)) as system_source_value_hash_512
					, UPPER(concat('0x',provider_source_value_hash_512)) as provider_source_value_hash_512
				from (select
					DISTINCT
					tmp.MasterProviderId
					, q.client_id
					, q.first_name
					, q.last_name
					, q.first_name_mutated
					, q.last_name_mutated
					, q.provider_name
					, q.provider_name_mutated
					, q.email_address
					, q.phone_number
					, q.fax_number
					, q.federal_tax_id
					, q.NPI
					, q.client_source_value
					, q.system_source_value
					, q.provider_source_value
					, q.client_source_value_hash_512
					, q.system_source_value_hash_512
					, q.provider_source_value_hash_512
					FROM 
						tmp_AllProvidersFromAllClients q
					INNER JOIN tmp_StagingMaster tmp
						on q.first_name_mutated = tmp.first_name_mutated and q.last_name_mutated = tmp.last_name_mutated and q.phone_number = tmp.phone_number
					WHERE LEN(TRIM(COALESCE(tmp.first_name_mutated, ''))) > 0 AND LEN(TRIM(COALESCE(tmp.last_name_mutated, ''))) > 0 AND LEN(TRIM(COALESCE(tmp.phone_number, ''))) > 0
				) Q ;`;
				
				executesql(insert_tmp_StagingMaster7,'0')

				del_AllProvidersFromAllClients17 = `DELETE FROM tmp_AllProvidersFromAllClients x
			using
			(select t.client_source_value_hash_512, t.system_source_value_hash_512, t.provider_source_value_hash_512 from
				tmp_AllProvidersFromAllClients t
				inner join tmp_StagingMaster xw
					on 
						UPPER(concat('0x',t.client_source_value_hash_512))   =     UPPER(xw.client_source_value_hash_512)
						and UPPER(concat('0x',t.system_source_value_hash_512))   = UPPER(xw.system_source_value_hash_512)
						and UPPER(concat('0x',t.provider_source_value_hash_512)) = UPPER(xw.provider_source_value_hash_512))ctes
			where UPPER(ctes.client_source_value_hash_512)   =     UPPER(x.client_source_value_hash_512)
			        and UPPER(ctes.system_source_value_hash_512)   = UPPER(x.system_source_value_hash_512)
					and  UPPER(ctes.provider_source_value_hash_512) = UPPER(x.provider_source_value_hash_512);`;

				executesql(del_AllProvidersFromAllClients17,'0')

			ident_curr_mpi = `SELECT MAX(MasterProviderId) as IDENT FROM tmp_StagingMaster`;
			var res = executesql(ident_curr_mpi, '0');
			res.next();
			var ident_curr_mpi_val = res.getColumnValue(1)+1;
			
			
			ident_curr_mpi_Orig = `SELECT MAX(MasterProviderId) as IDENT FROM tmp_AllProvidersMaster`;
			var res_2 = executesql(ident_curr_mpi_Orig, '0');
			res_2.next();
			var ident_curr_mpi_val_Orig = res_2.getColumnValue(1)+1;
			
			mpi_seq = `CREATE OR REPLACE SEQUENCE uniqueIDseq1 start = {!__ident_curr_mpi_val__!} increment=1`;
			if (ident_curr_mpi_val_Orig > ident_curr_mpi_val)
			{
				mpi_seq = mpi_seq.replace('{!__ident_curr_mpi_val__!}', ident_curr_mpi_val_Orig);
			}
			else
			{
				mpi_seq = mpi_seq.replace('{!__ident_curr_mpi_val__!}', ident_curr_mpi_val);
			}
				executesql(mpi_seq, '0');
			
			
			ident_curr_xwalk = `SELECT MAX(Provider_XWalkId) as IDENT FROM tmp_StagingMaster`;
			var res = executesql(ident_curr_xwalk, '0');
			res.next();
			var ident_curr_xwalk_val = res.getColumnValue(1)+1;
			
			
			ident_curr_xwalk_Orig = `SELECT MAX(Provider_XWalkId) as IDENT FROM tmp_ProviderXwalk`;
			var res_3 = executesql(ident_curr_xwalk_Orig, '0');
			res_3.next();
			var ident_curr_xwalk_val_Orig = res_3.getColumnValue(1)+1;
			
			xwalk_seq = `CREATE OR REPLACE SEQUENCE uniqueIDseq2 start = {!__ident_curr_xwalk_val__!} increment=1`;
			if (ident_curr_xwalk_val_Orig > ident_curr_xwalk_val)
			{
				xwalk_seq = xwalk_seq.replace('{!__ident_curr_xwalk_val__!}', ident_curr_xwalk_val_Orig);
			}
			else
			{
				xwalk_seq = xwalk_seq.replace('{!__ident_curr_xwalk_val__!}', ident_curr_xwalk_val);
			}
			executesql(xwalk_seq, '0');

			// People with different first_name_mutated,last_name_mutated,fax_number are different people.  Insert all the first_name_mutated,last_name_mutated,fax_number that is remaining. (Max on a single insert per first_name_mutated,last_name_mutated,fax_number... it will match up next time.)
			insert_tmp_StagingMaster8 = `INSERT INTO tmp_StagingMaster(MasterProviderId, Provider_XWalkId, ClientId, first_name, last_name, first_name_mutated, last_name_mutated, 
				provider_name, provider_name_mutated, email_address, phone_number, fax_number, federal_tax_id, NPI, client_source_value, system_source_value, provider_source_value,
				client_source_value_hash_512, system_source_value_hash_512, provider_source_value_hash_512 )
				select
					uniqueIDseq1.nextval as MasterProviderId
					, uniqueIDseq2.nextval as Provider_XWalkId
					, client_id
					, first_name
					, last_name
					, first_name_mutated
					, last_name_mutated
					, provider_name
					, provider_name_mutated
					, email_address
					, phone_number
					, fax_number
					, federal_tax_id
					, NPI
					, client_source_value
					, system_source_value
					, provider_source_value
					, UPPER(concat('0x',client_source_value_hash_512)) as client_source_value_hash_512
					, UPPER(concat('0x',system_source_value_hash_512)) as system_source_value_hash_512
					, UPPER(concat('0x',provider_source_value_hash_512)) as provider_source_value_hash_512
				from (select
					  q.client_id
					, q.first_name
					, q.last_name
					, q.first_name_mutated
					, q.last_name_mutated
					, q.provider_name
					, q.provider_name_mutated
					, q.email_address
					, q.phone_number
					, q.fax_number
					, q.federal_tax_id
					, q.NPI
					, q.client_source_value
					, q.system_source_value
					, q.provider_source_value
					, q.client_source_value_hash_512
					, q.system_source_value_hash_512
					, q.provider_source_value_hash_512
				from (
					SELECT
						T.client_id
						, t.first_name
						, t.last_name
						, T.first_name_mutated
						, T.last_name_mutated
						, T.provider_name
						, T.provider_name_mutated
						, T.email_address
						, T.phone_number
						, T.fax_number
						, T.federal_tax_id
						, T.NPI
						, T.client_source_value
						, T.system_source_value
						, T.provider_source_value
						, T.client_source_value_hash_512
						, T.system_source_value_hash_512
						, T.provider_source_value_hash_512
						, ROW_NUMBER() OVER (PARTITION BY T.first_name_mutated, T.last_name_mutated, T.fax_number ORDER BY 
						(
						  CASE WHEN LEN(TRIM(COALESCE(first_name_mutated, ''))) > 0 then 1 else 0 end
						+ CASE WHEN LEN(TRIM(COALESCE(last_name_mutated, ''))) > 0 then 1 else 0 end
						+ CASE WHEN LEN(TRIM(COALESCE(provider_name, ''))) > 0 then 1 else 0 end
						+ CASE WHEN LEN(TRIM(COALESCE(email_address, ''))) > 0 then 1 else 0 end
						+ CASE WHEN LEN(TRIM(COALESCE(phone_number, ''))) > 0 then 1 else 0 end
						+ CASE WHEN LEN(TRIM(COALESCE(fax_number, ''))) > 0 then 1 else 0 end
						+ CASE WHEN LEN(TRIM(COALESCE(federal_tax_id, ''))) > 0 then 1 else 0 end
						+ CASE WHEN LEN(TRIM(COALESCE(NPI, ''))) > 0 then 1 else 0 end)
						desc) as RN
					FROM 
						tmp_AllProvidersFromAllClients T
					WHERE
					LEN(TRIM(COALESCE(T.first_name_mutated, ''))) > 0 AND LEN(TRIM(COALESCE(T.last_name_mutated, ''))) > 0 AND LEN(TRIM(COALESCE(T.fax_number, ''))) > 0 AND (T.first_name_mutated, T.last_name_mutated, T.fax_number) NOT IN (SELECT DISTINCT first_name_mutated, last_name_mutated, fax_number FROM tmp_StagingMaster)
				) Q where q.rn = 1);`;
				
				executesql(insert_tmp_StagingMaster8,'0')
				
				del_AllProvidersFromAllClients18 = `DELETE FROM tmp_AllProvidersFromAllClients x
				using
				(select t.client_source_value_hash_512, t.system_source_value_hash_512, t.provider_source_value_hash_512 from
					tmp_AllProvidersFromAllClients t
					inner join tmp_StagingMaster xw
						on 
							UPPER(concat('0x',t.client_source_value_hash_512))   =     UPPER(xw.client_source_value_hash_512)
							and UPPER(concat('0x',t.system_source_value_hash_512))   = UPPER(xw.system_source_value_hash_512)
							and UPPER(concat('0x',t.provider_source_value_hash_512)) = UPPER(xw.provider_source_value_hash_512))ctes
				where UPPER(ctes.client_source_value_hash_512)   =     UPPER(x.client_source_value_hash_512)
						and UPPER(ctes.system_source_value_hash_512)   = UPPER(x.system_source_value_hash_512)
						and  UPPER(ctes.provider_source_value_hash_512) = UPPER(x.provider_source_value_hash_512);`;
					
				executesql(del_AllProvidersFromAllClients18,'0')
				
				
				// Assigining same MPI values for the records with same first_name_mutated,last_name_mutated,fax_number
				
				insert_tmp_StagingMaster9 = `INSERT INTO tmp_StagingMaster(Provider_XWalkId, MasterProviderId, ClientId, first_name, last_name, first_name_mutated, last_name_mutated, 
				provider_name, provider_name_mutated, email_address, phone_number, fax_number, federal_tax_id, NPI, client_source_value, system_source_value, provider_source_value,
				client_source_value_hash_512, system_source_value_hash_512, provider_source_value_hash_512 )
				select
					uniqueIDseq2.nextval as Provider_XWalkId
					, MasterProviderId
					, client_id
					, first_name
					, last_name
					, first_name_mutated
					, last_name_mutated
					, provider_name
					, provider_name_mutated
					, email_address
					, phone_number
					, fax_number
					, federal_tax_id
					, NPI
					, client_source_value
					, system_source_value
					, provider_source_value
					, UPPER(concat('0x',client_source_value_hash_512)) as client_source_value_hash_512
					, UPPER(concat('0x',system_source_value_hash_512)) as system_source_value_hash_512
					, UPPER(concat('0x',provider_source_value_hash_512)) as provider_source_value_hash_512
				from (select
					DISTINCT
					tmp.MasterProviderId
					, q.client_id
					, q.first_name
					, q.last_name
					, q.first_name_mutated
					, q.last_name_mutated
					, q.provider_name
					, q.provider_name_mutated
					, q.email_address
					, q.phone_number
					, q.fax_number
					, q.federal_tax_id
					, q.NPI
					, q.client_source_value
					, q.system_source_value
					, q.provider_source_value
					, q.client_source_value_hash_512
					, q.system_source_value_hash_512
					, q.provider_source_value_hash_512
					FROM 
						tmp_AllProvidersFromAllClients q
					INNER JOIN tmp_StagingMaster tmp
						on q.first_name_mutated = tmp.first_name_mutated and q.last_name_mutated = tmp.last_name_mutated and q.fax_number = tmp.fax_number
					WHERE LEN(TRIM(COALESCE(tmp.first_name_mutated, ''))) > 0 AND LEN(TRIM(COALESCE(tmp.last_name_mutated, ''))) > 0 AND LEN(TRIM(COALESCE(tmp.fax_number, ''))) > 0
				) Q ;`;
				
				executesql(insert_tmp_StagingMaster9,'0')

				del_AllProvidersFromAllClients19 = `DELETE FROM tmp_AllProvidersFromAllClients x
			using
			(select t.client_source_value_hash_512, t.system_source_value_hash_512, t.provider_source_value_hash_512 from
				tmp_AllProvidersFromAllClients t
				inner join tmp_StagingMaster xw
					on 
						UPPER(concat('0x',t.client_source_value_hash_512))   =     UPPER(xw.client_source_value_hash_512)
						and UPPER(concat('0x',t.system_source_value_hash_512))   = UPPER(xw.system_source_value_hash_512)
						and UPPER(concat('0x',t.provider_source_value_hash_512)) = UPPER(xw.provider_source_value_hash_512))ctes
			where UPPER(ctes.client_source_value_hash_512)   =     UPPER(x.client_source_value_hash_512)
			        and UPPER(ctes.system_source_value_hash_512)   = UPPER(x.system_source_value_hash_512)
					and  UPPER(ctes.provider_source_value_hash_512) = UPPER(x.provider_source_value_hash_512);`;

				executesql(del_AllProvidersFromAllClients19,'0')
			
				ident_curr_mpi = `SELECT MAX(MasterProviderId) as IDENT FROM tmp_StagingMaster`;
				var res = executesql(ident_curr_mpi, '0');
				res.next();
				var ident_curr_mpi_val = res.getColumnValue(1)+1;
				
				
				ident_curr_mpi_Orig = `SELECT MAX(MasterProviderId) as IDENT FROM tmp_AllProvidersMaster`;
				var res_2 = executesql(ident_curr_mpi_Orig, '0');
				res_2.next();
				var ident_curr_mpi_val_Orig = res_2.getColumnValue(1)+1;
				
				mpi_seq = `CREATE OR REPLACE SEQUENCE uniqueIDseq1 start = {!__ident_curr_mpi_val__!} increment=1`;
				if (ident_curr_mpi_val_Orig > ident_curr_mpi_val)
				{
					mpi_seq = mpi_seq.replace('{!__ident_curr_mpi_val__!}', ident_curr_mpi_val_Orig);
				}
				else
				{
					mpi_seq = mpi_seq.replace('{!__ident_curr_mpi_val__!}', ident_curr_mpi_val);
				}
					executesql(mpi_seq, '0');
				
				
				ident_curr_xwalk = `SELECT MAX(Provider_XWalkId) as IDENT FROM tmp_StagingMaster`;
				var res = executesql(ident_curr_xwalk, '0');
				res.next();
				var ident_curr_xwalk_val = res.getColumnValue(1)+1;
				
				
				ident_curr_xwalk_Orig = `SELECT MAX(Provider_XWalkId) as IDENT FROM tmp_ProviderXwalk`;
				var res_3 = executesql(ident_curr_xwalk_Orig, '0');
				res_3.next();
				var ident_curr_xwalk_val_Orig = res_3.getColumnValue(1)+1;
				
				xwalk_seq = `CREATE OR REPLACE SEQUENCE uniqueIDseq2 start = {!__ident_curr_xwalk_val__!} increment=1`;
				if (ident_curr_xwalk_val_Orig > ident_curr_xwalk_val)
				{
					xwalk_seq = xwalk_seq.replace('{!__ident_curr_xwalk_val__!}', ident_curr_xwalk_val_Orig);
				}
				else
				{
					xwalk_seq = xwalk_seq.replace('{!__ident_curr_xwalk_val__!}', ident_curr_xwalk_val);
				}
				executesql(xwalk_seq, '0');
	
				// People with different first_name_mutated,last_name_mutated,federal_tax_id are different people.  Insert all the first_name_mutated,last_name_mutated,federal_tax_id that is remaining. (Max on a single insert per first_name_mutated,last_name_mutated,federal_tax_id... it will match up next time.)
				insert_tmp_StagingMaster10 = `INSERT INTO tmp_StagingMaster(MasterProviderId, Provider_XWalkId, ClientId, first_name, last_name, first_name_mutated, last_name_mutated, 
					provider_name, provider_name_mutated, email_address, phone_number, fax_number, federal_tax_id, NPI, client_source_value, system_source_value, provider_source_value,
					client_source_value_hash_512, system_source_value_hash_512, provider_source_value_hash_512 )
					select
						uniqueIDseq1.nextval as MasterProviderId
						, uniqueIDseq2.nextval as Provider_XWalkId
						, client_id
						, first_name
						, last_name
						, first_name_mutated
						, last_name_mutated
						, provider_name
						, provider_name_mutated
						, email_address
						, phone_number
						, fax_number
						, federal_tax_id
						, NPI
						, client_source_value
						, system_source_value
						, provider_source_value
						, UPPER(concat('0x',client_source_value_hash_512)) as client_source_value_hash_512
						, UPPER(concat('0x',system_source_value_hash_512)) as system_source_value_hash_512
						, UPPER(concat('0x',provider_source_value_hash_512)) as provider_source_value_hash_512
					from (select
						  q.client_id
						, q.first_name
						, q.last_name
						, q.first_name_mutated
						, q.last_name_mutated
						, q.provider_name
						, q.provider_name_mutated
						, q.email_address
						, q.phone_number
						, q.fax_number
						, q.federal_tax_id
						, q.NPI
						, q.client_source_value
						, q.system_source_value
						, q.provider_source_value
						, q.client_source_value_hash_512
						, q.system_source_value_hash_512
						, q.provider_source_value_hash_512
					from (
						SELECT
							T.client_id
							, t.first_name
							, t.last_name
							, T.first_name_mutated
							, T.last_name_mutated
							, T.provider_name
							, T.provider_name_mutated
							, T.email_address
							, T.phone_number
							, T.fax_number
							, T.federal_tax_id
							, T.NPI
							, T.client_source_value
							, T.system_source_value
							, T.provider_source_value
							, T.client_source_value_hash_512
							, T.system_source_value_hash_512
							, T.provider_source_value_hash_512
							, ROW_NUMBER() OVER (PARTITION BY T.first_name_mutated, T.last_name_mutated, T.federal_tax_id ORDER BY 
							(
							  CASE WHEN LEN(TRIM(COALESCE(first_name_mutated, ''))) > 0 then 1 else 0 end
							+ CASE WHEN LEN(TRIM(COALESCE(last_name_mutated, ''))) > 0 then 1 else 0 end
							+ CASE WHEN LEN(TRIM(COALESCE(provider_name, ''))) > 0 then 1 else 0 end
							+ CASE WHEN LEN(TRIM(COALESCE(email_address, ''))) > 0 then 1 else 0 end
							+ CASE WHEN LEN(TRIM(COALESCE(phone_number, ''))) > 0 then 1 else 0 end
							+ CASE WHEN LEN(TRIM(COALESCE(fax_number, ''))) > 0 then 1 else 0 end
							+ CASE WHEN LEN(TRIM(COALESCE(federal_tax_id, ''))) > 0 then 1 else 0 end
							+ CASE WHEN LEN(TRIM(COALESCE(NPI, ''))) > 0 then 1 else 0 end)
							desc) as RN
						FROM 
							tmp_AllProvidersFromAllClients T
						WHERE
						LEN(TRIM(COALESCE(T.first_name_mutated, ''))) > 0 AND LEN(TRIM(COALESCE(T.last_name_mutated, ''))) > 0 AND LEN(TRIM(COALESCE(T.federal_tax_id, ''))) > 0 AND (T.first_name_mutated, T.last_name_mutated, T.federal_tax_id) NOT IN (SELECT DISTINCT first_name_mutated, last_name_mutated, federal_tax_id FROM tmp_StagingMaster)
					) Q where q.rn = 1);`;
					
					executesql(insert_tmp_StagingMaster10,'0')
					
					del_AllProvidersFromAllClients20 = `DELETE FROM tmp_AllProvidersFromAllClients x
					using
					(select t.client_source_value_hash_512, t.system_source_value_hash_512, t.provider_source_value_hash_512 from
						tmp_AllProvidersFromAllClients t
						inner join tmp_StagingMaster xw
							on 
								UPPER(concat('0x',t.client_source_value_hash_512))   =     UPPER(xw.client_source_value_hash_512)
								and UPPER(concat('0x',t.system_source_value_hash_512))   = UPPER(xw.system_source_value_hash_512)
								and UPPER(concat('0x',t.provider_source_value_hash_512)) = UPPER(xw.provider_source_value_hash_512))ctes
					where UPPER(ctes.client_source_value_hash_512)   =     UPPER(x.client_source_value_hash_512)
							and UPPER(ctes.system_source_value_hash_512)   = UPPER(x.system_source_value_hash_512)
							and  UPPER(ctes.provider_source_value_hash_512) = UPPER(x.provider_source_value_hash_512);`;
						
					executesql(del_AllProvidersFromAllClients20,'0')
					
					
					// Assigining same MPI values for the records with same first_name_mutated,last_name_mutated,federal_tax_id
					
					insert_tmp_StagingMaster11 = `INSERT INTO tmp_StagingMaster(Provider_XWalkId, MasterProviderId, ClientId, first_name, last_name, first_name_mutated, last_name_mutated, 
					provider_name, provider_name_mutated, email_address, phone_number, fax_number, federal_tax_id, NPI, client_source_value, system_source_value, provider_source_value,
					client_source_value_hash_512, system_source_value_hash_512, provider_source_value_hash_512 )
					select
						uniqueIDseq2.nextval as Provider_XWalkId
						, MasterProviderId
						, client_id
						, first_name
						, last_name
						, first_name_mutated
						, last_name_mutated
						, provider_name
						, provider_name_mutated
						, email_address
						, phone_number
						, fax_number
						, federal_tax_id
						, NPI
						, client_source_value
						, system_source_value
						, provider_source_value
						, UPPER(concat('0x',client_source_value_hash_512)) as client_source_value_hash_512
						, UPPER(concat('0x',system_source_value_hash_512)) as system_source_value_hash_512
						, UPPER(concat('0x',provider_source_value_hash_512)) as provider_source_value_hash_512
					from (select
						DISTINCT
						tmp.MasterProviderId
						, q.client_id
						, q.first_name
						, q.last_name
						, q.first_name_mutated
						, q.last_name_mutated
						, q.provider_name
						, q.provider_name_mutated
						, q.email_address
						, q.phone_number
						, q.fax_number
						, q.federal_tax_id
						, q.NPI
						, q.client_source_value
						, q.system_source_value
						, q.provider_source_value
						, q.client_source_value_hash_512
						, q.system_source_value_hash_512
						, q.provider_source_value_hash_512
						FROM 
							tmp_AllProvidersFromAllClients q
						INNER JOIN tmp_StagingMaster tmp
							on q.first_name_mutated = tmp.first_name_mutated and q.last_name_mutated = tmp.last_name_mutated and q.federal_tax_id = tmp.federal_tax_id
						WHERE LEN(TRIM(COALESCE(tmp.first_name_mutated, ''))) > 0 AND LEN(TRIM(COALESCE(tmp.last_name_mutated, ''))) > 0 AND LEN(TRIM(COALESCE(tmp.federal_tax_id, ''))) > 0
					) Q ;`;
					
					executesql(insert_tmp_StagingMaster11,'0')
	
					del_AllProvidersFromAllClients20 = `DELETE FROM tmp_AllProvidersFromAllClients x
				using
				(select t.client_source_value_hash_512, t.system_source_value_hash_512, t.provider_source_value_hash_512 from
					tmp_AllProvidersFromAllClients t
					inner join tmp_StagingMaster xw
						on 
							UPPER(concat('0x',t.client_source_value_hash_512))   =     UPPER(xw.client_source_value_hash_512)
							and UPPER(concat('0x',t.system_source_value_hash_512))   = UPPER(xw.system_source_value_hash_512)
							and UPPER(concat('0x',t.provider_source_value_hash_512)) = UPPER(xw.provider_source_value_hash_512))ctes
				where UPPER(ctes.client_source_value_hash_512)   =     UPPER(x.client_source_value_hash_512)
						and UPPER(ctes.system_source_value_hash_512)   = UPPER(x.system_source_value_hash_512)
						and  UPPER(ctes.provider_source_value_hash_512) = UPPER(x.provider_source_value_hash_512);`;
	
					executesql(del_AllProvidersFromAllClients20,'0')

					ident_curr_mpi = `SELECT MAX(MasterProviderId) as IDENT FROM tmp_StagingMaster`;
					var res = executesql(ident_curr_mpi, '0');
					res.next();
					var ident_curr_mpi_val = res.getColumnValue(1)+1;
					
					
					ident_curr_mpi_Orig = `SELECT MAX(MasterProviderId) as IDENT FROM tmp_AllProvidersMaster`;
					var res_2 = executesql(ident_curr_mpi_Orig, '0');
					res_2.next();
					var ident_curr_mpi_val_Orig = res_2.getColumnValue(1)+1;
					
					mpi_seq = `CREATE OR REPLACE SEQUENCE uniqueIDseq1 start = {!__ident_curr_mpi_val__!} increment=1`;
					if (ident_curr_mpi_val_Orig > ident_curr_mpi_val)
					{
						mpi_seq = mpi_seq.replace('{!__ident_curr_mpi_val__!}', ident_curr_mpi_val_Orig);
					}
					else
					{
						mpi_seq = mpi_seq.replace('{!__ident_curr_mpi_val__!}', ident_curr_mpi_val);
					}
						executesql(mpi_seq, '0');
					
					
					ident_curr_xwalk = `SELECT MAX(Provider_XWalkId) as IDENT FROM tmp_StagingMaster`;
					var res = executesql(ident_curr_xwalk, '0');
					res.next();
					var ident_curr_xwalk_val = res.getColumnValue(1)+1;
					
					
					ident_curr_xwalk_Orig = `SELECT MAX(Provider_XWalkId) as IDENT FROM tmp_ProviderXwalk`;
					var res_3 = executesql(ident_curr_xwalk_Orig, '0');
					res_3.next();
					var ident_curr_xwalk_val_Orig = res_3.getColumnValue(1)+1;
					
					xwalk_seq = `CREATE OR REPLACE SEQUENCE uniqueIDseq2 start = {!__ident_curr_xwalk_val__!} increment=1`;
					if (ident_curr_xwalk_val_Orig > ident_curr_xwalk_val)
					{
						xwalk_seq = xwalk_seq.replace('{!__ident_curr_xwalk_val__!}', ident_curr_xwalk_val_Orig);
					}
					else
					{
						xwalk_seq = xwalk_seq.replace('{!__ident_curr_xwalk_val__!}', ident_curr_xwalk_val);
					}
					executesql(xwalk_seq, '0');
		
					// People with different first_name_mutated,last_name_mutated are different people.  Insert all the  first_name_mutated,last_name_mutated that is remaining. (Max on a single insert per  first_name_mutated,last_name_mutated... it will match up next time.)
					insert_tmp_StagingMaster12 = `INSERT INTO tmp_StagingMaster(MasterProviderId, Provider_XWalkId, ClientId, first_name, last_name, first_name_mutated, last_name_mutated, 
						provider_name, provider_name_mutated, email_address, phone_number, fax_number, federal_tax_id, NPI, client_source_value, system_source_value, provider_source_value,
						client_source_value_hash_512, system_source_value_hash_512, provider_source_value_hash_512 )
						select
							uniqueIDseq1.nextval as MasterProviderId
							, uniqueIDseq2.nextval as Provider_XWalkId
							, client_id
							, first_name
							, last_name
							, first_name_mutated
							, last_name_mutated
							, provider_name
							, provider_name_mutated
							, email_address
							, phone_number
							, fax_number
							, federal_tax_id
							, NPI
							, client_source_value
							, system_source_value
							, provider_source_value
							, UPPER(concat('0x',client_source_value_hash_512)) as client_source_value_hash_512
							, UPPER(concat('0x',system_source_value_hash_512)) as system_source_value_hash_512
							, UPPER(concat('0x',provider_source_value_hash_512)) as provider_source_value_hash_512
						from (select
							  q.client_id
							, q.first_name
							, q.last_name
							, q.first_name_mutated
							, q.last_name_mutated
							, q.provider_name
							, q.provider_name_mutated
							, q.email_address
							, q.phone_number
							, q.fax_number
							, q.federal_tax_id
							, q.NPI
							, q.client_source_value
							, q.system_source_value
							, q.provider_source_value
							, q.client_source_value_hash_512
							, q.system_source_value_hash_512
							, q.provider_source_value_hash_512
						from (
							SELECT
								T.client_id
								, t.first_name
								, t.last_name
								, T.first_name_mutated
								, T.last_name_mutated
								, T.provider_name
								, T.provider_name_mutated
								, T.email_address
								, T.phone_number
								, T.fax_number
								, T.federal_tax_id
								, T.NPI
								, T.client_source_value
								, T.system_source_value
								, T.provider_source_value
								, T.client_source_value_hash_512
								, T.system_source_value_hash_512
								, T.provider_source_value_hash_512
								, ROW_NUMBER() OVER (PARTITION BY T.first_name_mutated, T.last_name_mutated ORDER BY 
								(
								  CASE WHEN LEN(TRIM(COALESCE(first_name_mutated, ''))) > 0 then 1 else 0 end
								+ CASE WHEN LEN(TRIM(COALESCE(last_name_mutated, ''))) > 0 then 1 else 0 end
								+ CASE WHEN LEN(TRIM(COALESCE(provider_name, ''))) > 0 then 1 else 0 end
								+ CASE WHEN LEN(TRIM(COALESCE(email_address, ''))) > 0 then 1 else 0 end
								+ CASE WHEN LEN(TRIM(COALESCE(phone_number, ''))) > 0 then 1 else 0 end
								+ CASE WHEN LEN(TRIM(COALESCE(fax_number, ''))) > 0 then 1 else 0 end
								+ CASE WHEN LEN(TRIM(COALESCE(federal_tax_id, ''))) > 0 then 1 else 0 end
								+ CASE WHEN LEN(TRIM(COALESCE(NPI, ''))) > 0 then 1 else 0 end)
								desc) as RN
							FROM 
								tmp_AllProvidersFromAllClients T
							WHERE
							LEN(TRIM(COALESCE(T.first_name_mutated, ''))) > 0 AND LEN(TRIM(COALESCE(T.last_name_mutated, ''))) > 0 AND (T.first_name_mutated, T.last_name_mutated) NOT IN (SELECT DISTINCT first_name_mutated, last_name_mutated FROM tmp_StagingMaster)
						) Q where q.rn = 1);`;
						
						executesql(insert_tmp_StagingMaster12,'0')
						
						del_AllProvidersFromAllClients20 = `DELETE FROM tmp_AllProvidersFromAllClients x
						using
						(select t.client_source_value_hash_512, t.system_source_value_hash_512, t.provider_source_value_hash_512 from
							tmp_AllProvidersFromAllClients t
							inner join tmp_StagingMaster xw
								on 
									UPPER(concat('0x',t.client_source_value_hash_512))   =     UPPER(xw.client_source_value_hash_512)
									and UPPER(concat('0x',t.system_source_value_hash_512))   = UPPER(xw.system_source_value_hash_512)
									and UPPER(concat('0x',t.provider_source_value_hash_512)) = UPPER(xw.provider_source_value_hash_512))ctes
						where UPPER(ctes.client_source_value_hash_512)   =     UPPER(x.client_source_value_hash_512)
								and UPPER(ctes.system_source_value_hash_512)   = UPPER(x.system_source_value_hash_512)
								and  UPPER(ctes.provider_source_value_hash_512) = UPPER(x.provider_source_value_hash_512);`;
							
						executesql(del_AllProvidersFromAllClients20,'0')
						
						
						// Assigining same MPI values for the records with same  first_name_mutated,last_name_mutated
						
						insert_tmp_StagingMaster13 = `INSERT INTO tmp_StagingMaster(Provider_XWalkId, MasterProviderId, ClientId, first_name, last_name, first_name_mutated, last_name_mutated, 
						provider_name, provider_name_mutated, email_address, phone_number, fax_number, federal_tax_id, NPI, client_source_value, system_source_value, provider_source_value,
						client_source_value_hash_512, system_source_value_hash_512, provider_source_value_hash_512 )
						select
							uniqueIDseq2.nextval as Provider_XWalkId
							, MasterProviderId
							, client_id
							, first_name
							, last_name
							, first_name_mutated
							, last_name_mutated
							, provider_name
							, provider_name_mutated
							, email_address
							, phone_number
							, fax_number
							, federal_tax_id
							, NPI
							, client_source_value
							, system_source_value
							, provider_source_value
							, UPPER(concat('0x',client_source_value_hash_512)) as client_source_value_hash_512
							, UPPER(concat('0x',system_source_value_hash_512)) as system_source_value_hash_512
							, UPPER(concat('0x',provider_source_value_hash_512)) as provider_source_value_hash_512
						from (select
							DISTINCT
							tmp.MasterProviderId
							, q.client_id
							, q.first_name
							, q.last_name
							, q.first_name_mutated
							, q.last_name_mutated
							, q.provider_name
							, q.provider_name_mutated
							, q.email_address
							, q.phone_number
							, q.fax_number
							, q.federal_tax_id
							, q.NPI
							, q.client_source_value
							, q.system_source_value
							, q.provider_source_value
							, q.client_source_value_hash_512
							, q.system_source_value_hash_512
							, q.provider_source_value_hash_512
							FROM 
								tmp_AllProvidersFromAllClients q
							INNER JOIN tmp_StagingMaster tmp
								on q.first_name_mutated = tmp.first_name_mutated and q.last_name_mutated = tmp.last_name_mutated
							WHERE LEN(TRIM(COALESCE(tmp.first_name_mutated, ''))) > 0 AND LEN(TRIM(COALESCE(tmp.last_name_mutated, ''))) > 0
						) Q ;`;
						
						executesql(insert_tmp_StagingMaster13,'0')
		
						del_AllProvidersFromAllClients21 = `DELETE FROM tmp_AllProvidersFromAllClients x
					using
					(select t.client_source_value_hash_512, t.system_source_value_hash_512, t.provider_source_value_hash_512 from
						tmp_AllProvidersFromAllClients t
						inner join tmp_StagingMaster xw
							on 
								UPPER(concat('0x',t.client_source_value_hash_512))   =     UPPER(xw.client_source_value_hash_512)
								and UPPER(concat('0x',t.system_source_value_hash_512))   = UPPER(xw.system_source_value_hash_512)
								and UPPER(concat('0x',t.provider_source_value_hash_512)) = UPPER(xw.provider_source_value_hash_512))ctes
					where UPPER(ctes.client_source_value_hash_512)   =     UPPER(x.client_source_value_hash_512)
							and UPPER(ctes.system_source_value_hash_512)   = UPPER(x.system_source_value_hash_512)
							and  UPPER(ctes.provider_source_value_hash_512) = UPPER(x.provider_source_value_hash_512);`;
		
						executesql(del_AllProvidersFromAllClients21,'0')
			

			// If nothing was added, then we have linked up everyone except people with just a firstname and lastname and none of the allowed combinations that identify someone to
			// a record that exists for a client.  
			
			// People with different provider_name_mutated are different people.  Insert all the  provider_name_mutated that is remaining. (Max on a single insert per  provider_name_mutated... it will match up next time.)
			insert_tmp_StagingMaster14 = `INSERT INTO tmp_StagingMaster(MasterProviderId, Provider_XWalkId, ClientId, first_name, last_name, first_name_mutated, last_name_mutated, 
				provider_name, provider_name_mutated, email_address, phone_number, fax_number, federal_tax_id, NPI, client_source_value, system_source_value, provider_source_value,
				client_source_value_hash_512, system_source_value_hash_512, provider_source_value_hash_512 )
				select
					uniqueIDseq1.nextval as MasterProviderId
					, uniqueIDseq2.nextval as Provider_XWalkId
					, client_id
					, first_name
					, last_name
					, first_name_mutated
					, last_name_mutated
					, provider_name
					, provider_name_mutated
					, email_address
					, phone_number
					, fax_number
					, federal_tax_id
					, NPI
					, client_source_value
					, system_source_value
					, provider_source_value
					, UPPER(concat('0x',client_source_value_hash_512)) as client_source_value_hash_512
					, UPPER(concat('0x',system_source_value_hash_512)) as system_source_value_hash_512
					, UPPER(concat('0x',provider_source_value_hash_512)) as provider_source_value_hash_512
				from (select
					  q.client_id
					, q.first_name
					, q.last_name
					, q.first_name_mutated
					, q.last_name_mutated
					, q.provider_name
					, q.provider_name_mutated
					, q.email_address
					, q.phone_number
					, q.fax_number
					, q.federal_tax_id
					, q.NPI
					, q.client_source_value
					, q.system_source_value
					, q.provider_source_value
					, q.client_source_value_hash_512
					, q.system_source_value_hash_512
					, q.provider_source_value_hash_512
				from (
					SELECT
						T.client_id
						, t.first_name
						, t.last_name
						, T.first_name_mutated
						, T.last_name_mutated
						, T.provider_name
						, T.provider_name_mutated
						, T.email_address
						, T.phone_number
						, T.fax_number
						, T.federal_tax_id
						, T.NPI
						, T.client_source_value
						, T.system_source_value
						, T.provider_source_value
						, T.client_source_value_hash_512
						, T.system_source_value_hash_512
						, T.provider_source_value_hash_512
						, ROW_NUMBER() OVER (PARTITION BY T.provider_name_mutated ORDER BY 
						(
						  CASE WHEN LEN(TRIM(COALESCE(first_name_mutated, ''))) > 0 then 1 else 0 end
						+ CASE WHEN LEN(TRIM(COALESCE(last_name_mutated, ''))) > 0 then 1 else 0 end
						+ CASE WHEN LEN(TRIM(COALESCE(provider_name, ''))) > 0 then 1 else 0 end
						+ CASE WHEN LEN(TRIM(COALESCE(email_address, ''))) > 0 then 1 else 0 end
						+ CASE WHEN LEN(TRIM(COALESCE(phone_number, ''))) > 0 then 1 else 0 end
						+ CASE WHEN LEN(TRIM(COALESCE(fax_number, ''))) > 0 then 1 else 0 end
						+ CASE WHEN LEN(TRIM(COALESCE(federal_tax_id, ''))) > 0 then 1 else 0 end
						+ CASE WHEN LEN(TRIM(COALESCE(NPI, ''))) > 0 then 1 else 0 end)
						desc) as RN
					FROM 
						tmp_AllProvidersFromAllClients T
					WHERE
					LEN(TRIM(COALESCE(T.provider_name_mutated, ''))) > 0 
					AND (T.provider_name_mutated) NOT IN (SELECT DISTINCT provider_name_mutated FROM tmp_StagingMaster)
					AND LEN(TRIM(COALESCE(T.first_name_mutated, ''))) = 0 AND LEN(TRIM(COALESCE(T.last_name_mutated, ''))) = 0
				) Q where q.rn = 1);`;
				
				executesql(insert_tmp_StagingMaster14,'0')
				
				del_AllProvidersFromAllClients22 = `DELETE FROM tmp_AllProvidersFromAllClients x
				using
				(select t.client_source_value_hash_512, t.system_source_value_hash_512, t.provider_source_value_hash_512 from
					tmp_AllProvidersFromAllClients t
					inner join tmp_StagingMaster xw
						on 
							UPPER(concat('0x',t.client_source_value_hash_512))   =     UPPER(xw.client_source_value_hash_512)
							and UPPER(concat('0x',t.system_source_value_hash_512))   = UPPER(xw.system_source_value_hash_512)
							and UPPER(concat('0x',t.provider_source_value_hash_512)) = UPPER(xw.provider_source_value_hash_512))ctes
				where UPPER(ctes.client_source_value_hash_512)   =     UPPER(x.client_source_value_hash_512)
						and UPPER(ctes.system_source_value_hash_512)   = UPPER(x.system_source_value_hash_512)
						and  UPPER(ctes.provider_source_value_hash_512) = UPPER(x.provider_source_value_hash_512);`;
					
				executesql(del_AllProvidersFromAllClients22,'0')
				
				
				// Assigining same MPI values for the records with same provider_name_mutated
				
				insert_tmp_StagingMaster15 = `INSERT INTO tmp_StagingMaster(Provider_XWalkId, MasterProviderId, ClientId, first_name, last_name, first_name_mutated, last_name_mutated, 
				provider_name, provider_name_mutated, email_address, phone_number, fax_number, federal_tax_id, NPI, client_source_value, system_source_value, provider_source_value,
				client_source_value_hash_512, system_source_value_hash_512, provider_source_value_hash_512 )
				select
					uniqueIDseq2.nextval as Provider_XWalkId
					, MasterProviderId
					, client_id
					, first_name
					, last_name
					, first_name_mutated
					, last_name_mutated
					, provider_name
					, provider_name_mutated
					, email_address
					, phone_number
					, fax_number
					, federal_tax_id
					, NPI
					, client_source_value
					, system_source_value
					, provider_source_value
					, UPPER(concat('0x',client_source_value_hash_512)) as client_source_value_hash_512
					, UPPER(concat('0x',system_source_value_hash_512)) as system_source_value_hash_512
					, UPPER(concat('0x',provider_source_value_hash_512)) as provider_source_value_hash_512
				from (select
					DISTINCT
					tmp.MasterProviderId
					, q.client_id
					, q.first_name
					, q.last_name
					, q.first_name_mutated
					, q.last_name_mutated
					, q.provider_name
					, q.provider_name_mutated
					, q.email_address
					, q.phone_number
					, q.fax_number
					, q.federal_tax_id
					, q.NPI
					, q.client_source_value
					, q.system_source_value
					, q.provider_source_value
					, q.client_source_value_hash_512
					, q.system_source_value_hash_512
					, q.provider_source_value_hash_512
					FROM 
						tmp_AllProvidersFromAllClients q
					INNER JOIN tmp_StagingMaster tmp
						on q.provider_name_mutated = tmp.provider_name_mutated
						AND LEN(TRIM(COALESCE(q.first_name_mutated, ''))) = 0 AND LEN(TRIM(COALESCE(tmp.first_name_mutated, ''))) = 0 
						AND LEN(TRIM(COALESCE(q.last_name_mutated, ''))) = 0 AND LEN(TRIM(COALESCE(tmp.last_name_mutated, ''))) = 0
					WHERE LEN(TRIM(COALESCE(tmp.provider_name_mutated, ''))) > 0
				) Q ;`;
				
				executesql(insert_tmp_StagingMaster15,'0')

				del_AllProvidersFromAllClients23 = `DELETE FROM tmp_AllProvidersFromAllClients x
			using
			(select t.client_source_value_hash_512, t.system_source_value_hash_512, t.provider_source_value_hash_512 from
				tmp_AllProvidersFromAllClients t
				inner join tmp_StagingMaster xw
					on 
						UPPER(concat('0x',t.client_source_value_hash_512))   =     UPPER(xw.client_source_value_hash_512)
						and UPPER(concat('0x',t.system_source_value_hash_512))   = UPPER(xw.system_source_value_hash_512)
						and UPPER(concat('0x',t.provider_source_value_hash_512)) = UPPER(xw.provider_source_value_hash_512))ctes
			where UPPER(ctes.client_source_value_hash_512)   =     UPPER(x.client_source_value_hash_512)
					and UPPER(ctes.system_source_value_hash_512)   = UPPER(x.system_source_value_hash_512)
					and  UPPER(ctes.provider_source_value_hash_512) = UPPER(x.provider_source_value_hash_512);`;

				executesql(del_AllProvidersFromAllClients23,'0')

			ident_curr_mpi = `SELECT MAX(MasterProviderId) as IDENT FROM tmp_StagingMaster`;
			var res = executesql(ident_curr_mpi, '0');
			res.next();
			var ident_curr_mpi_val = res.getColumnValue(1)+1;
			
			
			ident_curr_mpi_Orig = `SELECT MAX(MasterProviderId) as IDENT FROM tmp_AllProvidersMaster`;
			var res_2 = executesql(ident_curr_mpi_Orig, '0');
			res_2.next();
			var ident_curr_mpi_val_Orig = res_2.getColumnValue(1)+1;
			
			mpi_seq = `CREATE OR REPLACE SEQUENCE uniqueIDseq1 start = {!__ident_curr_mpi_val__!} increment=1`;
			if (ident_curr_mpi_val_Orig > ident_curr_mpi_val)
			{
				mpi_seq = mpi_seq.replace('{!__ident_curr_mpi_val__!}', ident_curr_mpi_val_Orig);
				
			} else
			{
				mpi_seq = mpi_seq.replace('{!__ident_curr_mpi_val__!}', ident_curr_mpi_val);
			}
			executesql(mpi_seq, '0');
				
			
			
			ident_curr_xwalk = `SELECT MAX(Provider_XWalkId) as IDENT FROM tmp_StagingMaster`;
			var res = executesql(ident_curr_xwalk, '0');
			res.next();
			var ident_curr_xwalk_val = res.getColumnValue(1)+1;
			
			
			ident_curr_xwalk_Orig = `SELECT MAX(Provider_XWalkId) as IDENT FROM tmp_ProviderXwalk`;
			var res_3 = executesql(ident_curr_xwalk_Orig, '0');
			res_3.next();
			var ident_curr_xwalk_val_Orig = res_3.getColumnValue(1)+1;
			
			xwalk_seq = `CREATE OR REPLACE SEQUENCE uniqueIDseq2 start = {!__ident_curr_xwalk_val__!} increment=1`;
			if (ident_curr_xwalk_val_Orig > ident_curr_xwalk_val)
			{
				xwalk_seq = xwalk_seq.replace('{!__ident_curr_xwalk_val__!}', ident_curr_xwalk_val_Orig);
				executesql(xwalk_seq, '0');
			}
			else
			{
				xwalk_seq = xwalk_seq.replace('{!__ident_curr_xwalk_val__!}', ident_curr_xwalk_val);
				executesql(xwalk_seq, '0');
			}
			 
			insert_tmp_StagingMaster16 = `INSERT INTO tmp_StagingMaster(MasterProviderId, Provider_XWalkId, ClientId, first_name, last_name, first_name_mutated, last_name_mutated, 
			provider_name, provider_name_mutated, email_address, phone_number, fax_number, federal_tax_id, NPI, client_source_value, system_source_value, provider_source_value,
			client_source_value_hash_512, system_source_value_hash_512, provider_source_value_hash_512)
            SELECT
				uniqueIDseq1.nextval as MasterProviderId
				, uniqueIDseq2.nextval as Provider_XWalkId
				, client_id
				, first_name
				, last_name
				, first_name_mutated
				, last_name_mutated
				, provider_name
				, provider_name_mutated
				, email_address
				, phone_number
				, fax_number
				, federal_tax_id
				, NPI
				, client_source_value
				, system_source_value
				, provider_source_value
				, UPPER(concat('0x',client_source_value_hash_512)) as client_source_value_hash_512
				, UPPER(concat('0x',system_source_value_hash_512)) as system_source_value_hash_512
				, UPPER(concat('0x',provider_source_value_hash_512)) as provider_source_value_hash_512
            from (SELECT
				  T.client_id
				, t.first_name
				, t.last_name
				, T.first_name_mutated
				, T.last_name_mutated
				, T.provider_name
				, T.provider_name_mutated
				, T.email_address
				, T.phone_number
				, T.fax_number
				, T.federal_tax_id
				, T.NPI
				, T.client_source_value
				, T.system_source_value
				, T.provider_source_value
				, T.client_source_value_hash_512
				, T.system_source_value_hash_512
				, T.provider_source_value_hash_512
			FROM 
				tmp_AllProvidersFromAllClients T
			WHERE t.AllProvidersFromAllClientsId IS NOT NULL);`;
			
			executesql(insert_tmp_StagingMaster16,'0');
			
			
			// Insertung new records from tmp_StagingMaster into tmp_AllProvidersMaster and tmp_ProviderXwalk
			
			
			insert_AllProvidersMaster3 = `INSERT INTO tmp_AllProvidersMaster(MasterProviderId,clientid, first_name, last_name, first_name_mutated, last_name_mutated, provider_name, provider_name_mutated, email_address, phone_number, fax_number, federal_tax_id, NPI)
			SELECT
                MasterProviderId
				, ClientId
				, first_name
				, last_name
				, first_name_mutated
				, last_name_mutated
				, provider_name
				, provider_name_mutated
				, email_address
				, phone_number
				, fax_number
				, federal_tax_id
				, NPI
            from (
				SELECT
                MasterProviderId
				, ClientId
				, first_name
				, last_name
				, first_name_mutated
				, last_name_mutated
				, provider_name
				, provider_name_mutated
				, email_address
				, phone_number
				, fax_number
				, federal_tax_id
				, NPI
				, ROW_NUMBER() OVER (PARTITION BY MasterProviderId  ORDER BY 
					(
					  CASE WHEN LEN(TRIM(COALESCE(first_name_mutated, ''))) > 0 then 1 else 0 end
					+ CASE WHEN LEN(TRIM(COALESCE(last_name_mutated, ''))) > 0 then 1 else 0 end
					+ CASE WHEN LEN(TRIM(COALESCE(provider_name, ''))) > 0 then 1 else 0 end
					+ CASE WHEN LEN(TRIM(COALESCE(email_address, ''))) > 0 then 1 else 0 end
					+ CASE WHEN LEN(TRIM(COALESCE(phone_number, ''))) > 0 then 1 else 0 end
					+ CASE WHEN LEN(TRIM(COALESCE(fax_number, ''))) > 0 then 1 else 0 end
					+ CASE WHEN LEN(TRIM(COALESCE(federal_tax_id, ''))) > 0 then 1 else 0 end
					+ CASE WHEN LEN(TRIM(COALESCE(NPI, ''))) > 0 then 1 else 0 end)
					desc) as RN
            from tmp_StagingMaster
			) Q where q.rn = 1`;
			
			executesql(insert_AllProvidersMaster3,'0');
			
			
			insert_ProviderXwalk9 = `INSERT all
			into tmp_ProviderXwalk(Provider_XWalkId,ClientId, client_source_value, system_source_value, provider_source_value, MasterProviderId, 
			client_source_value_hash_512, system_source_value_hash_512, provider_source_value_hash_512) 
			values (Provider_XWalkId,ClientId,client_source_value,system_source_value,provider_source_value,MasterProviderId,client_source_value_hash_512,system_source_value_hash_512,provider_source_value_hash_512)
			into tmp_NewProviderXwalkRecords(client_source_value_hash_512, system_source_value_hash_512, provider_source_value_hash_512)
			values (client_source_value_hash_512,system_source_value_hash_512,provider_source_value_hash_512)
				SELECT 
                    Provider_XWalkId
					, ClientId
					, client_source_value
					, system_source_value
					, provider_source_value
					, MasterProviderId
					, client_source_value_hash_512
					, system_source_value_hash_512
					, provider_source_value_hash_512
                from tmp_StagingMaster`;
				
			executesql(insert_ProviderXwalk9,'0');
                     
                      
            // Update Master Provider with all of the changes we made to the name / data.  
			truncate_NewlyMatchedRecordsAndAttributeLengthData = `TRUNCATE TABLE tmp_NewlyMatchedRecordsAndAttributeLengthData;`;
			executesql(truncate_NewlyMatchedRecordsAndAttributeLengthData,'0')
			
			insert_NewlyMatchedRecordsAndAttributeLengthData = `INSERT INTO tmp_NewlyMatchedRecordsAndAttributeLengthData
			SELECT 
				m.MasterProviderId
				, orig.client_id
				, orig.provider_id
				, orig.first_name 
				, orig.last_name
				, orig.provider_name
				, orig.email_address
				, orig.phone_number
				, orig.fax_number
				, orig.federal_tax_id
				, orig.NPI
				, orig.client_source_value
				, orig.system_source_value 
				, orig.provider_source_value
				, orig.client_source_value_hash_512
				, orig.system_source_value_hash_512
				, orig.provider_source_value_hash_512
				, len(orig.first_name) as LEN_first_name
				, len(orig.last_name) as LEN_last_name
				, len(orig.provider_name) as LEN_provider_name
				, len(orig.email_address) as LEN_email_address
				, len(orig.phone_number) as LEN_phone_number
				, len(orig.fax_number) as LEN_fax_number
				, len(orig.federal_tax_id) as LEN_federal_tax_id
				, len(orig.NPI) as LEN_NPI

			from
				tmp_ProviderXwalk pw
				inner join tmp_Original_AllProvidersFromAllClients orig
					on UPPER(concat('0x',orig.client_source_value_hash_512)) = UPPER(pw.client_source_value_hash_512)
					and UPPER(concat('0x',orig.provider_source_value_hash_512)) = UPPER(pw.provider_source_value_hash_512)
					and UPPER(concat('0x',orig.system_source_value_hash_512)) = UPPER(pw.system_source_value_hash_512)
				inner join tmp_AllProvidersMaster m
					on m.MasterProviderId = pw.MasterProviderId
				inner join tmp_NewProviderXwalkRecords filter
					on  UPPER(filter.client_source_value_hash_512)		= UPPER(pw.client_source_value_hash_512)
					and UPPER(filter.provider_source_value_hash_512)	= UPPER(pw.provider_source_value_hash_512)
					and UPPER(filter.system_source_value_hash_512)		= UPPER(pw.system_source_value_hash_512);`;
					
			executesql(insert_NewlyMatchedRecordsAndAttributeLengthData,'0')
			
			
			executesql(`Drop table if exists tmp_bar`,'0');
			create_tmpbar = `CREATE TEMPORARY TABLE tmp_bar as
			SELECT nm.MasterProviderId
					, MAX(nm.LEN_first_name) as LEN_first_name
					, MAX(nm.LEN_last_name) as LEN_last_name
					, MAX(nm.LEN_provider_name) as LEN_provider_name
					, MAX(nm.LEN_email_address) as LEN_email_address
					, MAX(nm.LEN_phone_number) as LEN_phone_number
					, MAX(nm.LEN_fax_number) as LEN_fax_number
					, MAX(nm.LEN_federal_tax_id) as LEN_federal_tax_id
					, MAX(nm.LEN_NPI) as LEN_NPI
				from
					tmp_NewlyMatchedRecordsAndAttributeLengthData nm
				group by nm.MasterProviderId`;
				
			executesql(create_tmpbar,'0')
			
			
			executesql(`Drop table if exists tmp_ItemsToUpdate`,'0');
			create_tmpItemsToUpdate = ` CREATE TEMPORARY TABLE tmp_ItemsToUpdate as                   
					select distinct tb.MasterProviderId,first_name,last_name,provider_name,email_address,phone_number,fax_number,federal_tax_id,NPI 
						from tmp_NewlyMatchedRecordsAndAttributeLengthData foo
					 inner join tmp_bar tb 
                      on foo.MasterProviderId = tb.MasterProviderId 
                      and foo.LEN_first_name = tb.LEN_first_name
				      and foo.LEN_last_name = tb.LEN_last_name
                      and foo.LEN_provider_name = tb.LEN_provider_name
                      and foo.LEN_email_address = tb.LEN_email_address
                      and foo.LEN_phone_number = tb.LEN_phone_number
                      and foo.LEN_fax_number = tb.LEN_fax_number
                      and foo.LEN_federal_tax_id = tb.LEN_federal_tax_id
                      and foo.LEN_NPI = tb.LEN_NPI;`;
				
			executesql(create_tmpItemsToUpdate,'0')
			
			
			update_AllProviderMaster = `UPDATE tmp_AllProvidersMaster x
			SET
				x.first_name = case when LEN(x.first_name) = 0 then b.first_name else x.first_name end
				, x.last_name = case when LEN(x.last_name) = 0 then b.last_name else x.last_name end
				, x.provider_name = case when LEN(x.provider_name) = 0 then b.provider_name else x.provider_name end
				, x.email_address = case when LEN(x.email_address) = 0 then b.email_address else x.email_address end
				, x.phone_number = case when LEN(x.phone_number) = 0 then b.phone_number else x.phone_number end
				, x.fax_number = case when LEN(x.fax_number) = 0 then b.fax_number else x.fax_number end
				, x.federal_tax_id = case when LEN(x.federal_tax_id) = 0 then b.federal_tax_id else x.federal_tax_id end
				, x.NPI = case when LEN(x.NPI) = 0 then b.NPI else x.NPI end
			from
				tmp_AllProvidersMaster pm
				INNER JOIN
				tmp_ItemsToUpdate b 
					on b.MasterProviderId = pm.MasterProviderId 
					where b.MasterProviderId = x.MasterProviderId;`;
			
			executesql(update_AllProviderMaster,'0')
			
			
			// delete data from our xwalk temp table.
			del_ProviderXwalk = `DELETE FROM tmp_ProviderXwalk x
			using
			(select t.client_source_value_hash_512, t.system_source_value_hash_512, t.provider_source_value_hash_512 from
				tmp_ProviderXwalk t
				left join tmp_Original_AllProvidersFromAllClients o
					on 
						UPPER(concat('0x',o.client_source_value_hash_512))   =     UPPER(t.client_source_value_hash_512)
						and UPPER(concat('0x',o.system_source_value_hash_512))   = UPPER(t.system_source_value_hash_512)
						and UPPER(concat('0x',o.provider_source_value_hash_512)) = UPPER(t.provider_source_value_hash_512) 
						where UPPER(concat('0x',o.client_source_value_hash_512)) is null)ctes
			where UPPER(ctes.client_source_value_hash_512) =  UPPER(x.client_source_value_hash_512)
				AND UPPER(ctes.system_source_value_hash_512) = UPPER(x.system_source_value_hash_512)
				AND UPPER(ctes.provider_source_value_hash_512) = UPPER(x.provider_source_value_hash_512);`;
				
			executesql(del_ProviderXwalk,'0')
			
			// Delete data from our master temp table.
			// Retain the entries that underwent a change in NPI, as per the update from CalculatedSet.Control_ProviderAllowedList.
			del_AllProvidersMaster2 = `DELETE FROM tmp_AllProvidersMaster x
			using
			(select t.MasterProviderId from
				tmp_AllProvidersMaster t
				inner join PUBLIC.MasterProviderIndex orig
					on t.MasterProviderId = orig.MasterProviderId
				left join tmp_ProviderXwalk px
					on px.MasterProviderId = t.MasterProviderId
			where px.MasterProviderId is null
				and T.NPI = orig.NPI)ctes
			where ctes.MasterProviderId = x.MasterProviderId;`;
			
			executesql(del_AllProvidersMaster2,'0')
			
			try
			{
				executesql('begin transaction;','0');
				
				sys_date = `SELECT  TO_VARCHAR(GETDATE()) as cur_date;`;
				var res = executesql(sys_date, '0');
				res.next();
				var curr_date = res.getColumnValue(1);
				
				// insert new history records - updated data.
				insert_MasterProviderIndexHistory1 = `INSERT into PUBLIC.MasterProviderIndexHistory  
				select
					'{!__curr_date__!}'
					, 'U'
					, new.*
					,''
				from
					PUBLIC.MasterProviderIndex mpi
					inner join tmp_AllProvidersMaster new
						on new.MasterProviderId = mpi.MasterProviderId
				where
					UPPER(trim(mpi.first_name)) <> UPPER(trim(new.first_name))
					or UPPER(trim(mpi.first_name_mutated)) <> UPPER(trim(new.first_name_mutated))
					or UPPER(trim(mpi.last_name)) <> UPPER(trim(new.last_name))
					or UPPER(trim(mpi.last_name_mutated)) <> UPPER(trim(new.last_name_mutated))
					or UPPER(trim(mpi.provider_name)) <> UPPER(trim(new.provider_name))
					or UPPER(trim(mpi.provider_name_mutated)) <> UPPER(trim(new.provider_name_mutated))
					or UPPER(trim(mpi.email_address)) <> UPPER(trim(new.email_address))
					or UPPER(trim(mpi.phone_number))<> UPPER(trim(new.phone_number))
					or UPPER(trim(mpi.fax_number)) <> UPPER(trim(new.fax_number))
					or UPPER(trim(mpi.federal_tax_id)) <> UPPER(trim(new.federal_tax_id))
					or UPPER(trim(mpi.NPI)) <> UPPER(trim(new.NPI));`;
					
				insert_MasterProviderIndexHistory1 = insert_MasterProviderIndexHistory1.replace('{!__curr_date__!}', curr_date);
				executesql(insert_MasterProviderIndexHistory1,'0')
				
				
				insert_Provider_XWalkHistory1 = `INSERT into PUBLIC.Provider_XWalkHistory
				select
					'{!__curr_date__!}'
					, 'U'
					, new.*
				from
					PUBLIC.Provider_XWalk px
					inner join tmp_ProviderXwalk new
						on new.Provider_XWalkId = px.Provider_XWalkId
				where
					px.MasterProviderId <> new.MasterProviderId;`;
				
				insert_Provider_XWalkHistory1 = insert_Provider_XWalkHistory1.replace('{!__curr_date__!}', curr_date);
				executesql(insert_Provider_XWalkHistory1,'0')
				
				
				// Perform updates.
				update_MasterProviderIndex = `UPDATE PUBLIC.MasterProviderIndex x 
				SET 
					x.first_name					 = mpih.first_name
					, x.first_name_mutated			 = mpih.first_name_mutated
					, x.last_name					 = mpih.last_name
					, x.last_name_mutated			 = mpih.last_name_mutated
					, x.provider_name				 = mpih.provider_name
					, x.provider_name_mutated		 = mpih.provider_name_mutated
					, x.email_address				 = mpih.email_address
					, x.phone_number				 = mpih.phone_number
					, x.fax_number					 = mpih.fax_number
					, x.federal_tax_id				 = mpih.federal_tax_id
					, x.NPI							 = mpih.NPI
                from
					PUBLIC.MasterProviderIndex T
					inner join PUBLIC.MasterProviderIndexHistory mpih
						on mpih.MasterProviderId =T.MasterProviderId
				where
					mpih.ChangeDate = '{!__curr_date__!}'
					and mpih.ChangeType = 'U'
					and mpih.MasterProviderId = x.MasterProviderId;`;
					
				update_MasterProviderIndex = update_MasterProviderIndex.replace('{!__curr_date__!}', curr_date);
				executesql(update_MasterProviderIndex,'0')
					
				
				update_Provider_XWalk = `UPDATE PUBLIC.Provider_XWalk x 
				SET 
					x.MasterProviderId = xwh.MasterProviderId
                from
					PUBLIC.Provider_XWalk T
					inner join PUBLIC.Provider_XWalkHistory xwh
						on t.Provider_XWalkId = xwh.Provider_XWalkId
				where
					xwh.ChangeDate = '{!__curr_date__!}'
					and xwh.ChangeType = 'U'
					and x.Provider_XWalkId = xwh.Provider_XWalkId;`;
					
				update_Provider_XWalk = update_Provider_XWalk.replace('{!__curr_date__!}', curr_date);
				executesql(update_Provider_XWalk,'0')
				
				
				// insert new history records - inserted data
				insert_MasterProviderIndexHistory2 = `INSERT into PUBLIC.MasterProviderIndexHistory
				select
					'{!__curr_date__!}'
					, 'I'
					, new.*
					,''
				from
					PUBLIC.MasterProviderIndex mpi
					right join tmp_AllProvidersMaster new
						on new.MasterProviderId = mpi.MasterProviderId
				where
					mpi.MasterProviderId is null;`;
					
				insert_MasterProviderIndexHistory2 = insert_MasterProviderIndexHistory2.replace('{!__curr_date__!}', curr_date);
				executesql(insert_MasterProviderIndexHistory2,'0')
				
				
				insert_Provider_XWalkHistory2 = `INSERT into PUBLIC.Provider_XWalkHistory 
				select
					'{!__curr_date__!}'
					, 'I'
					, new.*
				from
					PUBLIC.Provider_XWalk px
					right join tmp_ProviderXwalk new
						on new.Provider_XWalkId = px.Provider_XWalkId
				where
					px.Provider_XWalkId is null
				QUALIFY ROW_NUMBER() OVER(PARTITION BY new.client_source_value,new.system_source_value,new.provider_source_value ORDER BY new.Provider_XWalkId) = 1;`;
					
				insert_Provider_XWalkHistory2 = insert_Provider_XWalkHistory2.replace('{!__curr_date__!}', curr_date);
				executesql(insert_Provider_XWalkHistory2,'0')
				
				// Perform inserts.

				insert_MasterProviderIndex = `INSERT into PUBLIC.MasterProviderIndex( 
					MasterProviderId
					, ClientId
					, first_name
					, first_name_mutated
					, last_name
					, last_name_mutated
					, provider_name
					, provider_name_mutated
					, email_address
					, phone_number
					, fax_number
					, federal_tax_id
					, NPI
					, DEA
				)
				SELECT 
					MasterProviderId
					, ClientId
					, first_name
					, first_name_mutated
					, last_name
					, last_name_mutated
					, provider_name
					, provider_name_mutated
					, email_address
					, phone_number
					, fax_number
					, federal_tax_id
					, NPI
					,''
				FROM
					PUBLIC.MasterProviderIndexHistory mpih
				where
					mpih.ChangeDate = '{!__curr_date__!}'
					and mpih.ChangeType = 'I';`;
				
				insert_MasterProviderIndex = insert_MasterProviderIndex.replace('{!__curr_date__!}', curr_date);
				executesql(insert_MasterProviderIndex,'0')
				
				
				insert_ProviderXwalk_table = `INSERT into PUBLIC.Provider_XWalk( 
					Provider_XWalkId
					, ClientId
					, client_source_value
					, system_source_value
					, provider_source_value
					, MasterProviderId
					, client_source_value_hash_512
					, system_source_value_hash_512
					, provider_source_value_hash_512
				)
				SELECT 
					Provider_XWalkId
					, ClientId
					, client_source_value
					, system_source_value
					, provider_source_value
					, MasterProviderId
					, client_source_value_hash_512
					, system_source_value_hash_512
					, provider_source_value_hash_512
				FROM
					PUBLIC.Provider_XWalkHistory mpih
				where
					mpih.ChangeDate = '{!__curr_date__!}'
					and mpih.ChangeType = 'I';`;
				
				insert_ProviderXwalk_table = insert_ProviderXwalk_table.replace('{!__curr_date__!}', curr_date);
				executesql(insert_ProviderXwalk_table,'0')
				
				executesql('commit;','0');
			}
			
			catch(err)
			{
				executesql('rollback;','0');
				return "Error During Swap-In of data: " + err;    
			}
			
            
			return "Load MASTERPROVIDER XWALK was successful!";			
		}
		catch(err)
		{
			executesql('rollback', '0');
			return "Error in Load MASTERPROVIDER XWALK: " + err;
		}
    $$
    ;