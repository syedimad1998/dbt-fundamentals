--First clone are prod related data tables
--STEP:1
CREATE OR REPLACE TABLE QA_ADMIN_VERATO.EMPI.EMPI_XWALK CLONE PROD_ADMIN.EMPI.EMPI_XWALK;
CREATE OR REPLACE TABLE QA_ADMIN_VERATO.EMPI.ENTERPRISEMASTERPATIENTINDEX CLONE PROD_ADMIN.EMPI.ENTERPRISEMASTERPATIENTINDEX;

--STEP:1.1
call qa_utilities.public.CREATE_DATABASE('QA_DF_100_VERATO');
USE DATABASE QA_DF_100_VERATO;
CREATE SCHEMA OMOP;

call qa_utilities.public.CREATE_DATABASE('QA_DF_101_VERATO');
USE DATABASE QA_DF_101_VERATO;
CREATE SCHEMA OMOP;

call qa_utilities.public.CREATE_DATABASE('QA_DF_102_VERATO');
USE DATABASE QA_DF_102_VERATO;
CREATE SCHEMA OMOP;

call qa_utilities.public.CREATE_DATABASE('QA_DF_103_VERATO');
USE DATABASE QA_DF_103_VERATO;
CREATE SCHEMA OMOP;

call qa_utilities.public.CREATE_DATABASE('QA_DF_105_VERATO');
USE DATABASE QA_DF_105_VERATO;
CREATE SCHEMA OMOP;

call qa_utilities.public.CREATE_DATABASE('QA_DF_107_VERATO');
USE DATABASE QA_DF_107_VERATO;
CREATE SCHEMA OMOP;

call qa_utilities.public.CREATE_DATABASE('QA_DF_111_VERATO');
USE DATABASE QA_DF_111_VERATO;
CREATE SCHEMA OMOP;

call qa_utilities.public.CREATE_DATABASE('QA_DF_112_VERATO');
USE DATABASE QA_DF_112_VERATO;
CREATE SCHEMA OMOP;

call qa_utilities.public.CREATE_DATABASE('QA_DF_114_VERATO');
USE DATABASE QA_DF_114_VERATO;
CREATE SCHEMA OMOP;

call qa_utilities.public.CREATE_DATABASE('QA_DF_117_VERATO');
USE DATABASE QA_DF_117_VERATO;
CREATE SCHEMA OMOP;

call qa_utilities.public.CREATE_DATABASE('QA_DF_119_VERATO');
USE DATABASE QA_DF_119_VERATO;
CREATE SCHEMA OMOP;

call qa_utilities.public.CREATE_DATABASE('QA_DF_120_VERATO');
USE DATABASE QA_DF_120_VERATO;
CREATE SCHEMA OMOP;

call qa_utilities.public.CREATE_DATABASE('QA_DF_121_VERATO');
USE DATABASE QA_DF_121_VERATO;
CREATE SCHEMA OMOP;

call qa_utilities.public.CREATE_DATABASE('QA_DF_123_VERATO');
USE DATABASE QA_DF_123_VERATO;
CREATE SCHEMA OMOP;

call qa_utilities.public.CREATE_DATABASE('QA_DF_125_VERATO');
USE DATABASE QA_DF_125_VERATO;
CREATE SCHEMA OMOP;

call qa_utilities.public.CREATE_DATABASE('QA_DF_127_VERATO');
USE DATABASE QA_DF_127_VERATO;
CREATE SCHEMA OMOP;

call qa_utilities.public.CREATE_DATABASE('QA_DF_130_VERATO');
USE DATABASE QA_DF_130_VERATO;
CREATE SCHEMA OMOP;

call qa_utilities.public.CREATE_DATABASE('QA_DF_131_VERATO');
USE DATABASE QA_DF_131_VERATO;
CREATE SCHEMA OMOP;

call qa_utilities.public.CREATE_DATABASE('QA_DF_133_VERATO');
USE DATABASE QA_DF_133_VERATO;
CREATE SCHEMA OMOP;

call qa_utilities.public.CREATE_DATABASE('QA_DF_136_VERATO');
USE DATABASE QA_DF_136_VERATO;
CREATE SCHEMA OMOP;

call qa_utilities.public.CREATE_DATABASE('QA_DF_137_VERATO');
USE DATABASE QA_DF_137_VERATO;
CREATE SCHEMA OMOP;

call qa_utilities.public.CREATE_DATABASE('QA_DF_138_VERATO');
USE DATABASE QA_DF_138_VERATO;
CREATE SCHEMA OMOP;

call qa_utilities.public.CREATE_DATABASE('QA_DF_140_VERATO');
USE DATABASE QA_DF_140_VERATO;
CREATE SCHEMA OMOP;


--STEP:2
CREATE OR REPLACE TRANSIENT TABLE QA_DF_100_VERATO.OMOP.PERSON CLONE PROD_DF_100.OMOP.PERSON;
CREATE OR REPLACE TRANSIENT TABLE QA_DF_101_VERATO.OMOP.PERSON CLONE PROD_DF_101.OMOP.PERSON;
CREATE OR REPLACE TRANSIENT TABLE QA_DF_102_VERATO.OMOP.PERSON CLONE PROD_DF_102.OMOP.PERSON;
CREATE OR REPLACE TRANSIENT TABLE QA_DF_103_VERATO.OMOP.PERSON CLONE PROD_DF_103.OMOP.PERSON;
CREATE OR REPLACE TRANSIENT TABLE QA_DF_105_VERATO.OMOP.PERSON CLONE PROD_DF_105.OMOP.PERSON;
CREATE OR REPLACE TRANSIENT TABLE QA_DF_107_VERATO.OMOP.PERSON CLONE PROD_DF_107.OMOP.PERSON;
CREATE OR REPLACE TRANSIENT TABLE QA_DF_111_VERATO.OMOP.PERSON CLONE PROD_DF_111.OMOP.PERSON;
CREATE OR REPLACE TRANSIENT TABLE QA_DF_112_VERATO.OMOP.PERSON CLONE PROD_DF_112.OMOP.PERSON;
CREATE OR REPLACE TRANSIENT TABLE QA_DF_114_VERATO.OMOP.PERSON CLONE PROD_DF_114.OMOP.PERSON;
CREATE OR REPLACE TRANSIENT TABLE QA_DF_117_VERATO.OMOP.PERSON CLONE PROD_DF_117.OMOP.PERSON;
CREATE OR REPLACE TRANSIENT TABLE QA_DF_119_VERATO.OMOP.PERSON CLONE PROD_DF_119.OMOP.PERSON;
CREATE OR REPLACE TRANSIENT TABLE QA_DF_120_VERATO.OMOP.PERSON CLONE PROD_DF_120.OMOP.PERSON;
CREATE OR REPLACE TRANSIENT TABLE QA_DF_121_VERATO.OMOP.PERSON CLONE PROD_DF_121.OMOP.PERSON;
CREATE OR REPLACE TRANSIENT TABLE QA_DF_123_VERATO.OMOP.PERSON CLONE PROD_DF_123.OMOP.PERSON;
CREATE OR REPLACE TRANSIENT TABLE QA_DF_125_VERATO.OMOP.PERSON CLONE PROD_DF_125.OMOP.PERSON;
CREATE OR REPLACE TRANSIENT TABLE QA_DF_127_VERATO.OMOP.PERSON CLONE PROD_DF_127.OMOP.PERSON;
CREATE OR REPLACE TRANSIENT TABLE QA_DF_130_VERATO.OMOP.PERSON CLONE PROD_DF_130.OMOP.PERSON;
CREATE OR REPLACE TRANSIENT TABLE QA_DF_131_VERATO.OMOP.PERSON CLONE PROD_DF_131.OMOP.PERSON;
CREATE OR REPLACE TRANSIENT TABLE QA_DF_133_VERATO.OMOP.PERSON CLONE PROD_DF_133.OMOP.PERSON;
CREATE OR REPLACE TRANSIENT TABLE QA_DF_134_VERATO.OMOP.PERSON CLONE PROD_DF_134.OMOP.PERSON;
CREATE OR REPLACE TRANSIENT TABLE QA_DF_136_VERATO.OMOP.PERSON CLONE PROD_DF_136.OMOP.PERSON;
CREATE OR REPLACE TRANSIENT TABLE QA_DF_137_VERATO.OMOP.PERSON CLONE PROD_DF_137.OMOP.PERSON;
CREATE OR REPLACE TRANSIENT TABLE QA_DF_138_VERATO.OMOP.PERSON CLONE PROD_DF_138.OMOP.PERSON;
CREATE OR REPLACE TRANSIENT TABLE QA_DF_140_VERATO.OMOP.PERSON CLONE PROD_DF_140.OMOP.PERSON;

--STEP:3
CREATE OR REPLACE TRANSIENT TABLE QA_DF_100_VERATO.OMOP.LOCATION CLONE PROD_DF_100.OMOP.LOCATION;
CREATE OR REPLACE TRANSIENT TABLE QA_DF_101_VERATO.OMOP.LOCATION CLONE PROD_DF_101.OMOP.LOCATION;
CREATE OR REPLACE TRANSIENT TABLE QA_DF_102_VERATO.OMOP.LOCATION CLONE PROD_DF_102.OMOP.LOCATION;
CREATE OR REPLACE TRANSIENT TABLE QA_DF_103_VERATO.OMOP.LOCATION CLONE PROD_DF_103.OMOP.LOCATION;
CREATE OR REPLACE TRANSIENT TABLE QA_DF_105_VERATO.OMOP.LOCATION CLONE PROD_DF_105.OMOP.LOCATION;
CREATE OR REPLACE TRANSIENT TABLE QA_DF_107_VERATO.OMOP.LOCATION CLONE PROD_DF_107.OMOP.LOCATION;
CREATE OR REPLACE TRANSIENT TABLE QA_DF_111_VERATO.OMOP.LOCATION CLONE PROD_DF_111.OMOP.LOCATION;
CREATE OR REPLACE TRANSIENT TABLE QA_DF_112_VERATO.OMOP.LOCATION CLONE PROD_DF_112.OMOP.LOCATION;
CREATE OR REPLACE TRANSIENT TABLE QA_DF_114_VERATO.OMOP.LOCATION CLONE PROD_DF_114.OMOP.LOCATION;
CREATE OR REPLACE TRANSIENT TABLE QA_DF_117_VERATO.OMOP.LOCATION CLONE PROD_DF_117.OMOP.LOCATION;
CREATE OR REPLACE TRANSIENT TABLE QA_DF_119_VERATO.OMOP.LOCATION CLONE PROD_DF_119.OMOP.LOCATION;
CREATE OR REPLACE TRANSIENT TABLE QA_DF_120_VERATO.OMOP.LOCATION CLONE PROD_DF_120.OMOP.LOCATION;
CREATE OR REPLACE TRANSIENT TABLE QA_DF_121_VERATO.OMOP.LOCATION CLONE PROD_DF_121.OMOP.LOCATION;
CREATE OR REPLACE TRANSIENT TABLE QA_DF_123_VERATO.OMOP.LOCATION CLONE PROD_DF_123.OMOP.LOCATION;
CREATE OR REPLACE TRANSIENT TABLE QA_DF_125_VERATO.OMOP.LOCATION CLONE PROD_DF_125.OMOP.LOCATION;
CREATE OR REPLACE TRANSIENT TABLE QA_DF_127_VERATO.OMOP.LOCATION CLONE PROD_DF_127.OMOP.LOCATION;
CREATE OR REPLACE TRANSIENT TABLE QA_DF_130_VERATO.OMOP.LOCATION CLONE PROD_DF_130.OMOP.LOCATION;
CREATE OR REPLACE TRANSIENT TABLE QA_DF_131_VERATO.OMOP.LOCATION CLONE PROD_DF_131.OMOP.LOCATION;
CREATE OR REPLACE TRANSIENT TABLE QA_DF_133_VERATO.OMOP.LOCATION CLONE PROD_DF_133.OMOP.LOCATION;
CREATE OR REPLACE TRANSIENT TABLE QA_DF_134_VERATO.OMOP.LOCATION CLONE PROD_DF_134.OMOP.LOCATION;
CREATE OR REPLACE TRANSIENT TABLE QA_DF_136_VERATO.OMOP.LOCATION CLONE PROD_DF_136.OMOP.LOCATION;
CREATE OR REPLACE TRANSIENT TABLE QA_DF_137_VERATO.OMOP.LOCATION CLONE PROD_DF_137.OMOP.LOCATION;
CREATE OR REPLACE TRANSIENT TABLE QA_DF_138_VERATO.OMOP.LOCATION CLONE PROD_DF_138.OMOP.LOCATION;
CREATE OR REPLACE TRANSIENT TABLE QA_DF_140_VERATO.OMOP.LOCATION CLONE PROD_DF_140.OMOP.LOCATION;

--STEP:3
create or replace view QA_DTX_VERATO.OMOP.PERSON(
	CLIENTID,
	PATIENTID,
	PERSON_ID,
	LAST_NAME,
	FIRST_NAME,
	MIDDLE_NAME,
	MRN,
	SSN,
	GENDER_CONCEPT_ID,
	YEAR_OF_BIRTH,
	MONTH_OF_BIRTH,
	DAY_OF_BIRTH,
	BIRTH_DATETIME,
	RACE_CONCEPT_ID,
	ETHNICITY_CONCEPT_ID,
	LOCATION_ID,
	PROVIDER_ID,
	CARE_SITE_ID,
	PERSON_SOURCE_VALUE,
	PERSON_MPI_ID,
	SYSTEM_SOURCE_VALUE,
	CLIENT_SOURCE_VALUE,
	GENDER_SOURCE_VALUE,
	GENDER_SOURCE_CONCEPT_ID,
	RACE_SOURCE_VALUE,
	RACE_SOURCE_CONCEPT_ID,
	ETHNICITY_SOURCE_VALUE,
	ETHNICITY_SOURCE_CONCEPT_ID,
	DIVISION
) as 
SELECT 'Augusta' as ClientID, CONCAT('100' , '-' , cast(person_id as varchar)) as PatientID,person_id,last_name,first_name,middle_name,mrn,ssn,gender_concept_id,year_of_birth,month_of_birth,day_of_birth,birth_datetime,race_concept_id,ethnicity_concept_id,location_id,provider_id,care_site_id,person_source_value,person_MPI_id,system_source_value,client_source_value,gender_source_value,gender_source_concept_id,race_source_value,race_source_concept_id,ethnicity_source_value,ethnicity_source_concept_id,'100' as Division FROM QA_DF_100_VERATO.OMOP.person  
UNION ALL
SELECT 'Utah' as ClientID, CONCAT('101' , '-' , cast(person_id as varchar)) as PatientID,person_id,last_name,first_name,middle_name,mrn,ssn,gender_concept_id,year_of_birth,month_of_birth,day_of_birth,birth_datetime,race_concept_id,ethnicity_concept_id,location_id,provider_id,care_site_id,person_source_value,person_MPI_id,system_source_value,client_source_value,gender_source_value,gender_source_concept_id,race_source_value,race_source_concept_id,ethnicity_source_value,ethnicity_source_concept_id,'101' as Division FROM QA_DF_101_VERATO.OMOP.person  
UNION ALL
SELECT 'RCCA' as ClientID, CONCAT('102' , '-' , cast(person_id as varchar)) as PatientID,person_id,last_name,first_name,middle_name,mrn,ssn,gender_concept_id,year_of_birth,month_of_birth,day_of_birth,birth_datetime,race_concept_id,ethnicity_concept_id,location_id,provider_id,care_site_id,person_source_value,person_MPI_id,system_source_value,client_source_value,gender_source_value,gender_source_concept_id,race_source_value,race_source_concept_id,ethnicity_source_value,ethnicity_source_concept_id,'102' as Division FROM QA_DF_102_VERATO.OMOP.person  
UNION ALL
SELECT 'Virginia Cancer' as ClientID, CONCAT('103' , '-' , cast(person_id as varchar)) as PatientID,person_id,last_name,first_name,middle_name,mrn,ssn,gender_concept_id,year_of_birth,month_of_birth,day_of_birth,birth_datetime,race_concept_id,ethnicity_concept_id,location_id,provider_id,care_site_id,person_source_value,person_MPI_id,system_source_value,client_source_value,gender_source_value,gender_source_concept_id,race_source_value,race_source_concept_id,ethnicity_source_value,ethnicity_source_concept_id,'103' as Division FROM QA_DF_103_VERATO.OMOP.person  
UNION ALL
SELECT 'UPMC' as ClientID, CONCAT('105' , '-' , cast(person_id as varchar)) as PatientID,person_id,last_name,first_name,middle_name,mrn,ssn,gender_concept_id,year_of_birth,month_of_birth,day_of_birth,birth_datetime,race_concept_id,ethnicity_concept_id,location_id,provider_id,care_site_id,person_source_value,person_MPI_id,system_source_value,client_source_value,gender_source_value,gender_source_concept_id,race_source_value,race_source_concept_id,ethnicity_source_value,ethnicity_source_concept_id,'105' as Division FROM QA_DF_105_VERATO.OMOP.person  
UNION ALL
SELECT 'IMP' as ClientID, CONCAT('107' , '-' , cast(person_id as varchar)) as PatientID,person_id,last_name,first_name,middle_name,mrn,ssn,gender_concept_id,year_of_birth,month_of_birth,day_of_birth,birth_datetime,race_concept_id,ethnicity_concept_id,location_id,provider_id,care_site_id,person_source_value,person_MPI_id,system_source_value,client_source_value,gender_source_value,gender_source_concept_id,race_source_value,race_source_concept_id,ethnicity_source_value,ethnicity_source_concept_id,'107' as Division FROM QA_DF_107_VERATO.OMOP.person  
UNION ALL
SELECT 'TUG' as ClientID, CONCAT('114' , '-' , cast(person_id as varchar)) as PatientID,person_id,last_name,first_name,middle_name,mrn,ssn,gender_concept_id,year_of_birth,month_of_birth,day_of_birth,birth_datetime,race_concept_id,ethnicity_concept_id,location_id,provider_id,care_site_id,person_source_value,person_MPI_id,system_source_value,client_source_value,gender_source_value,gender_source_concept_id,race_source_value,race_source_concept_id,ethnicity_source_value,ethnicity_source_concept_id,'114' as Division FROM QA_DF_114_VERATO.OMOP.person  
UNION ALL
SELECT 'Clearview Cancer' as ClientID, CONCAT('117' , '-' , cast(person_id as varchar)) as PatientID,person_id,last_name,first_name,middle_name,mrn,ssn,gender_concept_id,year_of_birth,month_of_birth,day_of_birth,birth_datetime,race_concept_id,ethnicity_concept_id,location_id,provider_id,care_site_id,person_source_value,person_MPI_id,system_source_value,client_source_value,gender_source_value,gender_source_concept_id,race_source_value,race_source_concept_id,ethnicity_source_value,ethnicity_source_concept_id,'117' as Division FROM QA_DF_117_VERATO.OMOP.person  
UNION ALL
SELECT 'AlOnc' as ClientID, CONCAT('120' , '-' , cast(person_id as varchar)) as PatientID,person_id,last_name,first_name,middle_name,mrn,ssn,gender_concept_id,year_of_birth,month_of_birth,day_of_birth,birth_datetime,race_concept_id,ethnicity_concept_id,location_id,provider_id,care_site_id,person_source_value,person_MPI_id,system_source_value,client_source_value,gender_source_value,gender_source_concept_id,race_source_value,race_source_concept_id,ethnicity_source_value,ethnicity_source_concept_id,'120' as Division FROM QA_DF_120_VERATO.OMOP.person  
UNION ALL
SELECT 'NWMS' as ClientID, CONCAT('121' , '-' , cast(person_id as varchar)) as PatientID,person_id,last_name,first_name,middle_name,mrn,ssn,gender_concept_id,year_of_birth,month_of_birth,day_of_birth,birth_datetime,race_concept_id,ethnicity_concept_id,location_id,provider_id,care_site_id,person_source_value,person_MPI_id,system_source_value,client_source_value,gender_source_value,gender_source_concept_id,race_source_value,race_source_concept_id,ethnicity_source_value,ethnicity_source_concept_id,'121' as Division FROM QA_DF_121_VERATO.OMOP.person  
UNION ALL
SELECT 'SCOA' as ClientID, CONCAT('123' , '-' , cast(person_id as varchar)) as PatientID,person_id,last_name,first_name,middle_name,mrn,ssn,gender_concept_id,year_of_birth,month_of_birth,day_of_birth,birth_datetime,race_concept_id,ethnicity_concept_id,location_id,provider_id,care_site_id,person_source_value,person_MPI_id,system_source_value,client_source_value,gender_source_value,gender_source_concept_id,race_source_value,race_source_concept_id,ethnicity_source_value,ethnicity_source_concept_id,'123' as Division FROM QA_DF_123_VERATO.OMOP.person  
UNION ALL
SELECT 'FCS' as ClientID, CONCAT('111' , '-' , cast(person_id as varchar)) as PatientID,person_id,last_name,first_name,middle_name,mrn,ssn,gender_concept_id,year_of_birth,month_of_birth,day_of_birth,birth_datetime,race_concept_id,ethnicity_concept_id,location_id,provider_id,care_site_id,person_source_value,person_MPI_id,system_source_value,client_source_value,gender_source_value,gender_source_concept_id,race_source_value,race_source_concept_id,ethnicity_source_value,ethnicity_source_concept_id,'111' as Division FROM QA_DF_111_VERATO.OMOP.person  
UNION ALL
SELECT 'HVCC' as ClientID, CONCAT('112' , '-' , cast(person_id as varchar)) as PatientID,person_id,last_name,first_name,middle_name,mrn,ssn,gender_concept_id,year_of_birth,month_of_birth,day_of_birth,birth_datetime,race_concept_id,ethnicity_concept_id,location_id,provider_id,care_site_id,person_source_value,person_MPI_id,system_source_value,client_source_value,gender_source_value,gender_source_concept_id,race_source_value,race_source_concept_id,ethnicity_source_value,ethnicity_source_concept_id,'112' as Division FROM QA_DF_112_VERATO.OMOP.person  
UNION ALL
SELECT 'HOAPB' as ClientID, CONCAT('119' , '-' , cast(person_id as varchar)) as PatientID,person_id,last_name,first_name,middle_name,mrn,ssn,gender_concept_id,year_of_birth,month_of_birth,day_of_birth,birth_datetime,race_concept_id,ethnicity_concept_id,location_id,provider_id,care_site_id,person_source_value,person_MPI_id,system_source_value,client_source_value,gender_source_value,gender_source_concept_id,race_source_value,race_source_concept_id,ethnicity_source_value,ethnicity_source_concept_id,'119' as Division FROM QA_DF_119_VERATO.OMOP.person  
UNION ALL
SELECT 'CINJ - Rutgers' as ClientID, CONCAT('125' , '-' , cast(person_id as varchar)) as PatientID,person_id,last_name,first_name,middle_name,mrn,ssn,gender_concept_id,year_of_birth,month_of_birth,day_of_birth,birth_datetime,race_concept_id,ethnicity_concept_id,location_id,provider_id,care_site_id,person_source_value,person_MPI_id,system_source_value,client_source_value,gender_source_value,gender_source_concept_id,race_source_value,race_source_concept_id,ethnicity_source_value,ethnicity_source_concept_id,'125' as Division FROM QA_DF_125_VERATO.OMOP.person  
UNION ALL
SELECT 'NJCC' as ClientID, CONCAT('127' , '-' , cast(person_id as varchar)) as PatientID,person_id,last_name,first_name,middle_name,mrn,ssn,gender_concept_id,year_of_birth,month_of_birth,day_of_birth,birth_datetime,race_concept_id,ethnicity_concept_id,location_id,provider_id,care_site_id,person_source_value,person_MPI_id,system_source_value,client_source_value,gender_source_value,gender_source_concept_id,race_source_value,race_source_concept_id,ethnicity_source_value,ethnicity_source_concept_id,'127' as Division FROM QA_DF_127_VERATO.OMOP.person  
UNION ALL
SELECT 'AON' as ClientID, CONCAT('133' , '-' , cast(person_id as varchar)) as PatientID,person_id,last_name,first_name,middle_name,mrn,ssn,gender_concept_id,year_of_birth,month_of_birth,day_of_birth,birth_datetime,race_concept_id,ethnicity_concept_id,location_id,provider_id,care_site_id,person_source_value,person_MPI_id,system_source_value,client_source_value,gender_source_value,gender_source_concept_id,race_source_value,race_source_concept_id,ethnicity_source_value,ethnicity_source_concept_id,'133' as Division FROM QA_DF_133_VERATO.OMOP.person  
UNION ALL
SELECT 'FWO' as ClientID, CONCAT('130' , '-' , cast(person_id as varchar)) as PatientID,person_id,last_name,first_name,middle_name,mrn,ssn,gender_concept_id,year_of_birth,month_of_birth,day_of_birth,birth_datetime,race_concept_id,ethnicity_concept_id,location_id,provider_id,care_site_id,person_source_value,person_MPI_id,system_source_value,client_source_value,gender_source_value,gender_source_concept_id,race_source_value,race_source_concept_id,ethnicity_source_value,ethnicity_source_concept_id,'130' as Division FROM QA_DF_130_VERATO.OMOP.person  
UNION ALL
SELECT 'Nebraska' as ClientID, CONCAT('131' , '-' , cast(person_id as varchar)) as PatientID,person_id,last_name,first_name,middle_name,mrn,ssn,gender_concept_id,year_of_birth,month_of_birth,day_of_birth,birth_datetime,race_concept_id,ethnicity_concept_id,location_id,provider_id,care_site_id,person_source_value,person_MPI_id,system_source_value,client_source_value,gender_source_value,gender_source_concept_id,race_source_value,race_source_concept_id,ethnicity_source_value,ethnicity_source_concept_id,'131' as Division FROM QA_DF_131_VERATO.OMOP.person  
UNION ALL
SELECT 'Oregon Cancer' as ClientID, CONCAT('134' , '-' , cast(person_id as varchar)) as PatientID,person_id,last_name,first_name,middle_name,mrn,ssn,gender_concept_id,year_of_birth,month_of_birth,day_of_birth,birth_datetime,race_concept_id,ethnicity_concept_id,location_id,provider_id,care_site_id,person_source_value,person_MPI_id,system_source_value,client_source_value,gender_source_value,gender_source_concept_id,race_source_value,race_source_concept_id,ethnicity_source_value,ethnicity_source_concept_id,'134' as Division FROM QA_DF_134_VERATO.OMOP.person  
UNION ALL
SELECT 'COHA' as ClientID, CONCAT('136' , '-' , cast(person_id as varchar)) as PatientID,person_id,last_name,first_name,middle_name,mrn,ssn,gender_concept_id,year_of_birth,month_of_birth,day_of_birth,birth_datetime,race_concept_id,ethnicity_concept_id,location_id,provider_id,care_site_id,person_source_value,person_MPI_id,system_source_value,client_source_value,gender_source_value,gender_source_concept_id,race_source_value,race_source_concept_id,ethnicity_source_value,ethnicity_source_concept_id,'136' as Division FROM QA_DF_136_VERATO.OMOP.person  
UNION ALL
SELECT 'Oklahoma Cancer' as ClientID, CONCAT('137' , '-' , cast(person_id as varchar)) as PatientID,person_id,last_name,first_name,middle_name,mrn,ssn,gender_concept_id,year_of_birth,month_of_birth,day_of_birth,birth_datetime,race_concept_id,ethnicity_concept_id,location_id,provider_id,care_site_id,person_source_value,person_MPI_id,system_source_value,client_source_value,gender_source_value,gender_source_concept_id,race_source_value,race_source_concept_id,ethnicity_source_value,ethnicity_source_concept_id,'137' as Division FROM QA_DF_137_VERATO.OMOP.person  
UNION ALL
SELECT 'GWOA' as ClientID, CONCAT('138' , '-' , cast(person_id as varchar)) as PatientID,person_id,last_name,first_name,middle_name,mrn,ssn,gender_concept_id,year_of_birth,month_of_birth,day_of_birth,birth_datetime,race_concept_id,ethnicity_concept_id,location_id,provider_id,care_site_id,person_source_value,person_MPI_id,system_source_value,client_source_value,gender_source_value,gender_source_concept_id,race_source_value,race_source_concept_id,ethnicity_source_value,ethnicity_source_concept_id,'138' as Division FROM QA_DF_138_VERATO.OMOP.person
UNION ALL
SELECT 'Reno' as ClientID, CONCAT('140' , '-' , cast(person_id as varchar)) as PatientID,person_id,last_name,first_name,middle_name,mrn,ssn,gender_concept_id,year_of_birth,month_of_birth,day_of_birth,birth_datetime,race_concept_id,ethnicity_concept_id,location_id,provider_id,care_site_id,person_source_value,person_MPI_id,system_source_value,client_source_value,gender_source_value,gender_source_concept_id,race_source_value,race_source_concept_id,ethnicity_source_value,ethnicity_source_concept_id,'140' as Division FROM QA_DF_140_VERATO.OMOP.person;

--STEP:4
create or replace view QA_DTX_VERATO.OMOP.LOCATION(
	CLIENTID,
	LOCATION_ID,
	ADDRESS_1,
	ADDRESS_2,
	CITY,
	STATE,
	ZIP,
	COUNTY,
	LOCATION_SOURCE_VALUE,
	SYSTEM_SOURCE_VALUE,
	DIVISION
) as
SELECT 'Augusta' as ClientID,location_id,address_1,address_2,city,state,zip,county,location_source_value, system_source_value, '100' as Division FROM QA_DF_100_VERATO.OMOP.location  
UNION ALL
SELECT 'Utah' as ClientID,location_id,address_1,address_2,city,state,zip,county,location_source_value, system_source_value, '101' as Division FROM QA_DF_101_VERATO.OMOP.location  
UNION ALL
SELECT 'RCCA' as ClientID,location_id,address_1,address_2,city,state,zip,county,location_source_value, system_source_value,'102' as Division FROM QA_DF_102_VERATO.OMOP.location  
UNION ALL
SELECT 'Virginia Cancer' as ClientID,location_id,address_1,address_2,city,state,zip,county,location_source_value,system_source_value, '103' as Division FROM QA_DF_103_VERATO.OMOP.location  
UNION ALL
SELECT 'UPMC' as ClientID,location_id,address_1,address_2,city,state,zip,county,location_source_value, system_source_value ,'105' as Division FROM QA_DF_105_VERATO.OMOP.location  
UNION ALL
SELECT 'IMP' as ClientID,location_id,address_1,address_2,city,state,zip,county,location_source_value, system_source_value ,'107' as Division FROM QA_DF_107_VERATO.OMOP.location  
UNION ALL
SELECT 'TUG' as ClientID,location_id,address_1,address_2,city,state,zip,county,location_source_value, system_source_value ,'114' as Division FROM QA_DF_114_VERATO.OMOP.location  
UNION ALL
SELECT 'Clearview Cancer' as ClientID,location_id,address_1,address_2,city,state,zip,county,location_source_value, system_source_value , '117' as Division FROM QA_DF_117_VERATO.OMOP.location  
UNION ALL
SELECT 'AlOnc' as ClientID,location_id,address_1,address_2,city,state,zip,county,location_source_value, system_source_value , '120' as Division FROM QA_DF_120_VERATO.OMOP.location  
UNION ALL
SELECT 'NWMS' as ClientID,location_id,address_1,address_2,city,state,zip,county,location_source_value, system_source_value , '121' as Division FROM QA_DF_121_VERATO.OMOP.location  
UNION ALL
SELECT 'SCOA' as ClientID,location_id,address_1,address_2,city,state,zip,county,location_source_value, system_source_value ,'123' as Division FROM QA_DF_123_VERATO.OMOP.location  
UNION ALL
SELECT 'FCS' as ClientID,location_id,address_1,address_2,city,state,zip,county,location_source_value, system_source_value ,'111' as Division FROM QA_DF_111_VERATO.OMOP.location  
UNION ALL
SELECT 'HVCC' as ClientID,location_id,address_1,address_2,city,state,zip,county,location_source_value, system_source_value ,'112' as Division FROM QA_DF_112_VERATO.OMOP.location  
UNION ALL
SELECT 'HOAPB' as ClientID,location_id,address_1,address_2,city,state,zip,county,location_source_value, system_source_value ,'119' as Division FROM QA_DF_119_VERATO.OMOP.location  
UNION ALL
SELECT 'CINJ - Rutgers' as ClientID,location_id,address_1,address_2,city,state,zip,county,location_source_value, system_source_value ,'125' as Division FROM QA_DF_125_VERATO.OMOP.location  
UNION ALL
SELECT 'NJCC' as ClientID,location_id,address_1,address_2,city,state,zip,county,location_source_value, system_source_value ,'127' as Division FROM QA_DF_127_VERATO.OMOP.location  
UNION ALL
SELECT 'AON' as ClientID,location_id,address_1,address_2,city,state,zip,county,location_source_value, system_source_value ,'133' as Division FROM QA_DF_133_VERATO.OMOP.location  
UNION ALL
SELECT 'FWO' as ClientID,location_id,address_1,address_2,city,state,zip,county,location_source_value,system_source_value,'130' as Division FROM QA_DF_130_VERATO.OMOP.location  
UNION ALL
SELECT 'Nebraska' as ClientID,location_id,address_1,address_2,city,state,zip,county,location_source_value,system_source_value,'131' as Division FROM QA_DF_131_VERATO.OMOP.location  
UNION ALL
SELECT 'Oregon Cancer' as ClientID,location_id,address_1,address_2,city,state,zip,county,location_source_value,system_source_value,'134' as Division FROM QA_DF_134_VERATO.OMOP.location  
UNION ALL
SELECT 'COHA' as ClientID,location_id,address_1,address_2,city,state,zip,county,location_source_value,system_source_value,'136' as Division FROM QA_DF_136_VERATO.OMOP.location  
UNION ALL
SELECT 'Oklahoma Cancer' as ClientID,location_id,address_1,address_2,city,state,zip,county,location_source_value,system_source_value,'137' as Division FROM QA_DF_137_VERATO.OMOP.location  
UNION ALL
SELECT 'GWOA' as ClientID,location_id,address_1,address_2,city,state,zip,county,location_source_value,system_source_value,'138' as Division FROM QA_DF_138_VERATO.OMOP.location
UNION ALL
SELECT 'Reno' as ClientID,location_id,address_1,address_2,city,state,zip,county,location_source_value,system_source_value,'140' as Division FROM QA_DF_140_VERATO.OMOP.location;

--STEP:5
--add modified date to EMPI_XWALK
alter table QA_ADMIN_VERATO.EMPI.EMPI_XWALK
add MODIFIED_DATE TIMESTAMP_NTZ(9);

UPDATE QA_ADMIN_VERATO.EMPI.EMPI_XWALK x
SET x.MODIFIED_DATE = x.CREATED_DATE;

--STEP:6
--RUN EMPI_HISTORY DDL
create or replace TABLE QA_ADMIN_VERATO.EMPI.EMPI_HISTORY (
	CLIENT_SOURCE_VALUE VARCHAR(500) COLLATE 'en-ci',
	SYSTEM_SOURCE_VALUE VARCHAR(500) COLLATE 'en-ci',
	PERSON_SOURCE_VALUE VARCHAR(100) COLLATE 'en-ci',
	EMPI NUMBER(38,0),
	VERATOID VARCHAR(50) COLLATE 'en-ci',
	CREATED_DATE TIMESTAMP_NTZ(9)
);

--STEP:7
INSERT INTO QA_ADMIN_VERATO.EMPI.EMPI_HISTORY (CLIENT_SOURCE_VALUE,SYSTEM_SOURCE_VALUE,PERSON_SOURCE_VALUE,EMPI,VERATOID,CREATED_DATE)
SELECT TRIM(CLIENT_SOURCE_VALUE) as CLIENT_SOURCE_VALUE,TRIM(SYSTEM_SOURCE_VALUE) as SYSTEM_SOURCE_VALUE,TRIM(PERSON_SOURCE_VALUE) as PERSON_SOURCE_VALUE,EMPI,VERATOID,current_timestamp()
FROM QA_ADMIN_VERATO.EMPI.EMPI_XWALK;

--STEP:8
--Get max INSERTIONIDENTIFIER FROM PROD_ADMIN.EMPI.ENTERPRISEMASTERPATIENTINDEX
SELECT MAX(INSERTIONIDENTIFIER) + 10000 FROM QA_ADMIN_VERATO.EMPI.ENTERPRISEMASTERPATIENTINDEX;

--STEP:9
--create temp table
create or replace TABLE QA_ADMIN_VERATO.EMPI.EnterpriseMasterPatientIndex_TEMP (
	INSERTIONIDENTIFIER NUMBER(38,0) NOT NULL autoincrement start VALUE increment 1,
	LAST_NAME VARCHAR(100) COLLATE 'en-ci',
	FIRST_NAME VARCHAR(100) COLLATE 'en-ci',
	MIDDLE_NAME VARCHAR(100) COLLATE 'en-ci',
	SSN VARCHAR(20) COLLATE 'en-ci',
	BIRTHDATE DATE,
	ZIP VARCHAR(20) COLLATE 'en-ci',
	CREATED_DATE TIMESTAMP_NTZ(9) NOT NULL,
    MODIFIED_DATE TIMESTAMP_NTZ(9) NOT NULL,
	EMPI NUMBER(38,0),
	DATEOFDEATH DATE,
	DOD_SOURCE VARCHAR(20) COLLATE 'en-ci',
	VERATOID VARCHAR(50) COLLATE 'en-ci'
);

--STEP:10
--Insert records into temp table
INSERT INTO QA_ADMIN_VERATO.EMPI.EnterpriseMasterPatientIndex_TEMP (INSERTIONIDENTIFIER ,LAST_NAME,FIRST_NAME,MIDDLE_NAME,SSN,BIRTHDATE,ZIP,CREATED_DATE,EMPI,DATEOFDEATH,DOD_SOURCE,VERATOID)
SELECT INSERTIONIDENTIFIER,LAST_NAME,FIRST_NAME,MIDDLE_NAME,SSN,BIRTHDATE,ZIP,CREATED_DATE,EMPI,DATEOFDEATH,DOD_SOURCE,VERATOID FROM QA_ADMIN_VERATO.EMPI .EnterpriseMasterPatientIndex;

--STEP:11
--Replace the PROD_ADMIN.EMPI.EnterpriseMasterPatientIndex with the PROD_ADMIN.EMPI.EnterpriseMasterPatientIndex_TEMP table
CREATE OR REPLACE TABLE QA_ADMIN_VERATO.EMPI.EnterpriseMasterPatientIndex CLONE QA_ADMIN_VERATO.EMPI.EnterpriseMasterPatientIndex_TEMP;

--STEP:12
--Drop temp table
DROP TABLE QA_ADMIN_VERATO.EMPI.EnterpriseMasterPatientIndex_TEMP;

UPDATE QA_ADMIN_VERATO.EMPI.ENTERPRISEMASTERPATIENTINDEX E
SET E.MODIFIED_DATE = E.CREATED_DATE;

--STEP:13
--Update ENTERPRISEMASTERPATIENTINDEX with new empis
UPDATE QA_ADMIN_VERATO.EMPI.ENTERPRISEMASTERPATIENTINDEX e
SET e.EMPI = t.EMPI 
    FROM (
        WITH TEMP as(
            SELECT MIN(F.MPIID) AS EMPI, E.VERATOID
            FROM PROD_DTX.CALCULATEDSET.FCTPATIENTABSTRACTIONSTATUS F
            INNER JOIN QA_ADMIN_VERATO.EMPI.ENTERPRISEMASTERPATIENTINDEX E on E.EMPI = F.MPIID
            WHERE (MPIID,STATUSDATE) IN (SELECT Fx.MPIID, MAX(Fx.STATUSDATE) as STATUSDATE
            FROM PROD_DTX.CALCULATEDSET.FCTPATIENTABSTRACTIONSTATUS Fx
            GROUP BY Fx.MPIID) AND F.ABSTRACTIONSTATUSID != 4
            GROUP BY E.VERATOID
            )

       	SELECT VERATOID, EMPI FROM TEMP
        UNION
        SELECT VERATOID, MIN(EMPI) as EMPI
        FROM QA_ADMIN_VERATO.EMPI.ENTERPRISEMASTERPATIENTINDEX
        WHERE VERATOID not in (SELECT VERATOID FROM TEMP)
        GROUP BY VERATOID
    ) t
WHERE e.VERATOID = t.VERATOID;

--STEP:14
--Update EMPI_XWALK with new empis
UPDATE QA_ADMIN_VERATO.EMPI.EMPI_XWALK e
SET e.EMPI = t.EMPI
    FROM (
        WITH TEMP as(
            SELECT MIN(F.MPIID) AS EMPI, E.VERATOID
            FROM PROD_DTX.CALCULATEDSET.FCTPATIENTABSTRACTIONSTATUS F
            INNER JOIN QA_ADMIN_VERATO.EMPI.ENTERPRISEMASTERPATIENTINDEX E on E.EMPI = F.MPIID
            WHERE (MPIID,STATUSDATE) IN (SELECT Fx.MPIID, MAX(Fx.STATUSDATE) as STATUSDATE
            FROM PROD_DTX.CALCULATEDSET.FCTPATIENTABSTRACTIONSTATUS Fx
            GROUP BY Fx.MPIID) AND F.ABSTRACTIONSTATUSID != 4
            GROUP BY E.VERATOID
            )

       	SELECT VERATOID, EMPI FROM TEMP
        UNION
        SELECT VERATOID, MIN(EMPI) as EMPI
        FROM QA_ADMIN_VERATO.EMPI.ENTERPRISEMASTERPATIENTINDEX
        WHERE VERATOID not in (SELECT VERATOID FROM TEMP)
        GROUP BY VERATOID
    ) t
WHERE e.VERATOID = t.VERATOID;

--STEP:15
--INSERT INTO EMPI_HISTORY 
INSERT INTO QA_ADMIN_VERATO.EMPI.EMPI_HISTORY (CLIENT_SOURCE_VALUE,SYSTEM_SOURCE_VALUE,PERSON_SOURCE_VALUE,EMPI,VERATOID,CREATED_DATE)
SELECT CLIENT_SOURCE_VALUE,SYSTEM_SOURCE_VALUE,PERSON_SOURCE_VALUE,EMPI,VERATOID,current_timestamp()
FROM (
  SELECT TRIM(CLIENT_SOURCE_VALUE) as CLIENT_SOURCE_VALUE,TRIM(SYSTEM_SOURCE_VALUE) as SYSTEM_SOURCE_VALUE,TRIM(PERSON_SOURCE_VALUE) as PERSON_SOURCE_VALUE,EMPI,VERATOID
  FROM QA_ADMIN_VERATO.EMPI.EMPI_XWALK
  EXCEPT
  SELECT TRIM(CLIENT_SOURCE_VALUE) as CLIENT_SOURCE_VALUE,TRIM(SYSTEM_SOURCE_VALUE) as SYSTEM_SOURCE_VALUE,TRIM(PERSON_SOURCE_VALUE) as PERSON_SOURCE_VALUE,EMPI,VERATOID
  FROM QA_ADMIN_VERATO.EMPI.EMPI_HISTORY) t;

--STEP:16
create or replace TABLE QA_DTX_VERATO.VERATO.VERATO_LASTRUN cluster by (CLIENT_SOURCE_VALUE, SYSTEM_SOURCE_VALUE, PERSON_SOURCE_VALUE)(
	CLIENT_SOURCE_VALUE VARCHAR(100) NOT NULL COLLATE 'en-ci',
	SYSTEM_SOURCE_VALUE VARCHAR(100) NOT NULL COLLATE 'en-ci',
	PERSON_SOURCE_VALUE VARCHAR(100) NOT NULL COLLATE 'en-ci',
	LAST_NAME VARCHAR(100) COLLATE 'en-ci',
	FIRST_NAME VARCHAR(100) COLLATE 'en-ci',
	MIDDLE_NAME VARCHAR(100) COLLATE 'en-ci',
	SSN VARCHAR(20) COLLATE 'en-ci',
	BIRTH_DATETIME TIMESTAMP_NTZ(9),
	GENDER_SOURCE_VALUE VARCHAR(50) COLLATE 'en-ci',
	ADDRESS_1 VARCHAR(50) COLLATE 'en-ci',
	ADDRESS_2 VARCHAR(50) COLLATE 'en-ci',
	CITY VARCHAR(50) COLLATE 'en-ci',
	STATE VARCHAR(2) COLLATE 'en-ci',
	ZIP VARCHAR(9) COLLATE 'en-ci',
	DIVISION VARCHAR(3) COLLATE 'en-ci'
);


--STEP:17
create or replace view QA_DTX_VERATO.VERATO.VERATOSOURCE(
	CLIENT_SOURCE_VALUE,
	SYSTEM_SOURCE_VALUE,
	PERSON_SOURCE_VALUE,
	LAST_NAME,
	FIRST_NAME,
	MIDDLE_NAME,
	SSN,
	BIRTH_DATE,
	GENDER_SOURCE_VALUE,
	ADDRESS_1,
	ADDRESS_2,
	CITY,
	STATE,
	ZIP,
	TYPE,
	DIVISION
) as (
SELECT   
      CLIENT_SOURCE_VALUE,
      SYSTEM_SOURCE_VALUE,
      PERSON_SOURCE_VALUE,
      LAST_NAME,  
      FIRST_NAME,  
      MIDDLE_NAME,  
      SSN,  
      BIRTH_DATE,
      GENDER_SOURCE_VALUE,
      ADDRESS_1,  
      ADDRESS_2,  
      CITY,  
      STATE,  
      ZIP,
      CASE WHEN ( TRIM(CLIENT_SOURCE_VALUE),TRIM(PERSON_SOURCE_VALUE),TRIM(SYSTEM_SOURCE_VALUE)) in (SELECT DISTINCT TRIM(CLIENT_SOURCE_VALUE),TRIM(PERSON_SOURCE_VALUE),TRIM(SYSTEM_SOURCE_VALUE) FROM QA_ADMIN_VERATO.EMPI.EMPI_XWALK) THEN 'UPDATE' ELSE 'ADD' END as TYPE,
      DIVISION
      FROM 
    (SELECT TRIM(P.CLIENT_SOURCE_VALUE) as CLIENT_SOURCE_VALUE,TRIM(P.SYSTEM_SOURCE_VALUE) as SYSTEM_SOURCE_VALUE,TRIM(P.PERSON_SOURCE_VALUE) as PERSON_SOURCE_VALUE, P.LAST_NAME, P.FIRST_NAME, P.MIDDLE_NAME, P.SSN, DATE(P.BIRTH_DATETIME) as BIRTH_DATE,P.GENDER_SOURCE_VALUE, L.ADDRESS_1, L.ADDRESS_2, L.CITY, L.STATE, L.ZIP, P.DIVISION FROM QA_DTX_VERATO.OMOP.PERSON P LEFT JOIN QA_DTX_VERATO.OMOP.LOCATION L ON P.LOCATION_ID = L.LOCATION_ID AND P.CLIENTID = L.CLIENTID
      EXCEPT
    SELECT TRIM(CLIENT_SOURCE_VALUE) as CLIENT_SOURCE_VALUE,TRIM(SYSTEM_SOURCE_VALUE) as SYSTEM_SOURCE_VALUE,TRIM(PERSON_SOURCE_VALUE) as PERSON_SOURCE_VALUE, LAST_NAME, FIRST_NAME, MIDDLE_NAME, SSN, DATE(BIRTH_DATETIME) as BIRTH_DATE,GENDER_SOURCE_VALUE, ADDRESS_1, ADDRESS_2, CITY, STATE, ZIP,DIVISION FROM QA_DTX_VERATO.VERATO.VERATO_LASTRUN P2) S
    LEFT JOIN QA_DTX_VERATO.VERATO.VERATO_QUARANTINE Q
    ON TRIM(Q.SOURCE_CODE) = concat(TRIM(S.CLIENT_SOURCE_VALUE),'_',TRIM(S.SYSTEM_SOURCE_VALUE))
    AND TRIM(Q.NATIVE_ID) = TRIM(S.PERSON_SOURCE_VALUE)
    WHERE Q.source_code IS NULL AND Q.NATIVE_ID IS NULL
);

--STEP:18
UPDATE QA_DF_100_VERATO.OMOP.PERSON P
SET P.PERSON_MPI_ID = X.EMPI
FROM QA_ADMIN_VERATO.EMPI.EMPI_XWALK X
WHERE TRIM(P.CLIENT_SOURCE_VALUE) = TRIM(X.CLIENT_SOURCE_VALUE) AND TRIM(P.SYSTEM_SOURCE_VALUE) = TRIM(X.SYSTEM_SOURCE_VALUE) AND TRIM(P.PERSON_SOURCE_VALUE) = TRIM(X.PERSON_SOURCE_VALUE);

UPDATE QA_DF_101_VERATO.OMOP.PERSON P
SET P.PERSON_MPI_ID = X.EMPI
FROM QA_ADMIN_VERATO.EMPI.EMPI_XWALK X
WHERE TRIM(P.CLIENT_SOURCE_VALUE) = TRIM(X.CLIENT_SOURCE_VALUE) AND TRIM(P.SYSTEM_SOURCE_VALUE) = TRIM(X.SYSTEM_SOURCE_VALUE) AND TRIM(P.PERSON_SOURCE_VALUE) = TRIM(X.PERSON_SOURCE_VALUE);

UPDATE QA_DF_102_VERATO.OMOP.PERSON P
SET P.PERSON_MPI_ID = X.EMPI
FROM QA_ADMIN_VERATO.EMPI.EMPI_XWALK X
WHERE TRIM(P.CLIENT_SOURCE_VALUE) = TRIM(X.CLIENT_SOURCE_VALUE) AND TRIM(P.SYSTEM_SOURCE_VALUE) = TRIM(X.SYSTEM_SOURCE_VALUE) AND TRIM(P.PERSON_SOURCE_VALUE) = TRIM(X.PERSON_SOURCE_VALUE);

UPDATE QA_DF_103_VERATO.OMOP.PERSON P
SET P.PERSON_MPI_ID = X.EMPI
FROM QA_ADMIN_VERATO.EMPI.EMPI_XWALK X
WHERE TRIM(P.CLIENT_SOURCE_VALUE) = TRIM(X.CLIENT_SOURCE_VALUE) AND TRIM(P.SYSTEM_SOURCE_VALUE) = TRIM(X.SYSTEM_SOURCE_VALUE) AND TRIM(P.PERSON_SOURCE_VALUE) = TRIM(X.PERSON_SOURCE_VALUE);

UPDATE QA_DF_105_VERATO.OMOP.PERSON P
SET P.PERSON_MPI_ID = X.EMPI
FROM QA_ADMIN_VERATO.EMPI.EMPI_XWALK X
WHERE TRIM(P.CLIENT_SOURCE_VALUE) = TRIM(X.CLIENT_SOURCE_VALUE) AND TRIM(P.SYSTEM_SOURCE_VALUE) = TRIM(X.SYSTEM_SOURCE_VALUE) AND TRIM(P.PERSON_SOURCE_VALUE) = TRIM(X.PERSON_SOURCE_VALUE);

UPDATE QA_DF_107_VERATO.OMOP.PERSON P
SET P.PERSON_MPI_ID = X.EMPI
FROM QA_ADMIN_VERATO.EMPI.EMPI_XWALK X
WHERE TRIM(P.CLIENT_SOURCE_VALUE) = TRIM(X.CLIENT_SOURCE_VALUE) AND TRIM(P.SYSTEM_SOURCE_VALUE) = TRIM(X.SYSTEM_SOURCE_VALUE) AND TRIM(P.PERSON_SOURCE_VALUE) = TRIM(X.PERSON_SOURCE_VALUE);

UPDATE QA_DF_111_VERATO.OMOP.PERSON P
SET P.PERSON_MPI_ID = X.EMPI
FROM QA_ADMIN_VERATO.EMPI.EMPI_XWALK X
WHERE TRIM(P.CLIENT_SOURCE_VALUE) = TRIM(X.CLIENT_SOURCE_VALUE) AND TRIM(P.SYSTEM_SOURCE_VALUE) = TRIM(X.SYSTEM_SOURCE_VALUE) AND TRIM(P.PERSON_SOURCE_VALUE) = TRIM(X.PERSON_SOURCE_VALUE);

UPDATE QA_DF_112_VERATO.OMOP.PERSON P
SET P.PERSON_MPI_ID = X.EMPI
FROM QA_ADMIN_VERATO.EMPI.EMPI_XWALK X
WHERE TRIM(P.CLIENT_SOURCE_VALUE) = TRIM(X.CLIENT_SOURCE_VALUE) AND TRIM(P.SYSTEM_SOURCE_VALUE) = TRIM(X.SYSTEM_SOURCE_VALUE) AND TRIM(P.PERSON_SOURCE_VALUE) = TRIM(X.PERSON_SOURCE_VALUE);

UPDATE QA_DF_114_VERATO.OMOP.PERSON P
SET P.PERSON_MPI_ID = X.EMPI
FROM QA_ADMIN_VERATO.EMPI.EMPI_XWALK X
WHERE TRIM(P.CLIENT_SOURCE_VALUE) = TRIM(X.CLIENT_SOURCE_VALUE) AND TRIM(P.SYSTEM_SOURCE_VALUE) = TRIM(X.SYSTEM_SOURCE_VALUE) AND TRIM(P.PERSON_SOURCE_VALUE) = TRIM(X.PERSON_SOURCE_VALUE);

UPDATE QA_DF_117_VERATO.OMOP.PERSON P
SET P.PERSON_MPI_ID = X.EMPI
FROM QA_ADMIN_VERATO.EMPI.EMPI_XWALK X
WHERE TRIM(P.CLIENT_SOURCE_VALUE) = TRIM(X.CLIENT_SOURCE_VALUE) AND TRIM(P.SYSTEM_SOURCE_VALUE) = TRIM(X.SYSTEM_SOURCE_VALUE) AND TRIM(P.PERSON_SOURCE_VALUE) = TRIM(X.PERSON_SOURCE_VALUE);

UPDATE QA_DF_119_VERATO.OMOP.PERSON P
SET P.PERSON_MPI_ID = X.EMPI
FROM QA_ADMIN_VERATO.EMPI.EMPI_XWALK X
WHERE TRIM(P.CLIENT_SOURCE_VALUE) = TRIM(X.CLIENT_SOURCE_VALUE) AND TRIM(P.SYSTEM_SOURCE_VALUE) = TRIM(X.SYSTEM_SOURCE_VALUE) AND TRIM(P.PERSON_SOURCE_VALUE) = TRIM(X.PERSON_SOURCE_VALUE);

UPDATE QA_DF_120_VERATO.OMOP.PERSON P
SET P.PERSON_MPI_ID = X.EMPI
FROM QA_ADMIN_VERATO.EMPI.EMPI_XWALK X
WHERE TRIM(P.CLIENT_SOURCE_VALUE) = TRIM(X.CLIENT_SOURCE_VALUE) AND TRIM(P.SYSTEM_SOURCE_VALUE) = TRIM(X.SYSTEM_SOURCE_VALUE) AND TRIM(P.PERSON_SOURCE_VALUE) = TRIM(X.PERSON_SOURCE_VALUE);

UPDATE QA_DF_121_VERATO.OMOP.PERSON P
SET P.PERSON_MPI_ID = X.EMPI
FROM QA_ADMIN_VERATO.EMPI.EMPI_XWALK X
WHERE TRIM(P.CLIENT_SOURCE_VALUE) = TRIM(X.CLIENT_SOURCE_VALUE) AND TRIM(P.SYSTEM_SOURCE_VALUE) = TRIM(X.SYSTEM_SOURCE_VALUE) AND TRIM(P.PERSON_SOURCE_VALUE) = TRIM(X.PERSON_SOURCE_VALUE);

UPDATE QA_DF_123_VERATO.OMOP.PERSON P
SET P.PERSON_MPI_ID = X.EMPI
FROM QA_ADMIN_VERATO.EMPI.EMPI_XWALK X
WHERE TRIM(P.CLIENT_SOURCE_VALUE) = TRIM(X.CLIENT_SOURCE_VALUE) AND TRIM(P.SYSTEM_SOURCE_VALUE) = TRIM(X.SYSTEM_SOURCE_VALUE) AND TRIM(P.PERSON_SOURCE_VALUE) = TRIM(X.PERSON_SOURCE_VALUE);

UPDATE QA_DF_125_VERATO.OMOP.PERSON P
SET P.PERSON_MPI_ID = X.EMPI
FROM QA_ADMIN_VERATO.EMPI.EMPI_XWALK X
WHERE TRIM(P.CLIENT_SOURCE_VALUE) = TRIM(X.CLIENT_SOURCE_VALUE) AND TRIM(P.SYSTEM_SOURCE_VALUE) = TRIM(X.SYSTEM_SOURCE_VALUE) AND TRIM(P.PERSON_SOURCE_VALUE) = TRIM(X.PERSON_SOURCE_VALUE);

UPDATE QA_DF_127_VERATO.OMOP.PERSON P
SET P.PERSON_MPI_ID = X.EMPI
FROM QA_ADMIN_VERATO.EMPI.EMPI_XWALK X
WHERE TRIM(P.CLIENT_SOURCE_VALUE) = TRIM(X.CLIENT_SOURCE_VALUE) AND TRIM(P.SYSTEM_SOURCE_VALUE) = TRIM(X.SYSTEM_SOURCE_VALUE) AND TRIM(P.PERSON_SOURCE_VALUE) = TRIM(X.PERSON_SOURCE_VALUE);

UPDATE QA_DF_130_VERATO.OMOP.PERSON P
SET P.PERSON_MPI_ID = X.EMPI
FROM QA_ADMIN_VERATO.EMPI.EMPI_XWALK X
WHERE TRIM(P.CLIENT_SOURCE_VALUE) = TRIM(X.CLIENT_SOURCE_VALUE) AND TRIM(P.SYSTEM_SOURCE_VALUE) = TRIM(X.SYSTEM_SOURCE_VALUE) AND TRIM(P.PERSON_SOURCE_VALUE) = TRIM(X.PERSON_SOURCE_VALUE);

UPDATE QA_DF_131_VERATO.OMOP.PERSON P
SET P.PERSON_MPI_ID = X.EMPI
FROM QA_ADMIN_VERATO.EMPI.EMPI_XWALK X
WHERE TRIM(P.CLIENT_SOURCE_VALUE) = TRIM(X.CLIENT_SOURCE_VALUE) AND TRIM(P.SYSTEM_SOURCE_VALUE) = TRIM(X.SYSTEM_SOURCE_VALUE) AND TRIM(P.PERSON_SOURCE_VALUE) = TRIM(X.PERSON_SOURCE_VALUE);

UPDATE QA_DF_133_VERATO.OMOP.PERSON P
SET P.PERSON_MPI_ID = X.EMPI
FROM QA_ADMIN_VERATO.EMPI.EMPI_XWALK X
WHERE TRIM(P.CLIENT_SOURCE_VALUE) = TRIM(X.CLIENT_SOURCE_VALUE) AND TRIM(P.SYSTEM_SOURCE_VALUE) = TRIM(X.SYSTEM_SOURCE_VALUE) AND TRIM(P.PERSON_SOURCE_VALUE) = TRIM(X.PERSON_SOURCE_VALUE);

UPDATE QA_DF_134_VERATO.OMOP.PERSON P
SET P.PERSON_MPI_ID = X.EMPI
FROM QA_ADMIN_VERATO.EMPI.EMPI_XWALK X
WHERE TRIM(P.CLIENT_SOURCE_VALUE) = TRIM(X.CLIENT_SOURCE_VALUE) AND TRIM(P.SYSTEM_SOURCE_VALUE) = TRIM(X.SYSTEM_SOURCE_VALUE) AND TRIM(P.PERSON_SOURCE_VALUE) = TRIM(X.PERSON_SOURCE_VALUE);

UPDATE QA_DF_136_VERATO.OMOP.PERSON P
SET P.PERSON_MPI_ID = X.EMPI
FROM QA_ADMIN_VERATO.EMPI.EMPI_XWALK X
WHERE TRIM(P.CLIENT_SOURCE_VALUE) = TRIM(X.CLIENT_SOURCE_VALUE) AND TRIM(P.SYSTEM_SOURCE_VALUE) = TRIM(X.SYSTEM_SOURCE_VALUE) AND TRIM(P.PERSON_SOURCE_VALUE) = TRIM(X.PERSON_SOURCE_VALUE);

UPDATE QA_DF_137_VERATO.OMOP.PERSON P
SET P.PERSON_MPI_ID = X.EMPI
FROM QA_ADMIN_VERATO.EMPI.EMPI_XWALK X
WHERE TRIM(P.CLIENT_SOURCE_VALUE) = TRIM(X.CLIENT_SOURCE_VALUE) AND TRIM(P.SYSTEM_SOURCE_VALUE) = TRIM(X.SYSTEM_SOURCE_VALUE) AND TRIM(P.PERSON_SOURCE_VALUE) = TRIM(X.PERSON_SOURCE_VALUE);

UPDATE QA_DF_138_VERATO.OMOP.PERSON P
SET P.PERSON_MPI_ID = X.EMPI
FROM QA_ADMIN_VERATO.EMPI.EMPI_XWALK X
WHERE TRIM(P.CLIENT_SOURCE_VALUE) = TRIM(X.CLIENT_SOURCE_VALUE) AND TRIM(P.SYSTEM_SOURCE_VALUE) = TRIM(X.SYSTEM_SOURCE_VALUE) AND TRIM(P.PERSON_SOURCE_VALUE) = TRIM(X.PERSON_SOURCE_VALUE);

UPDATE QA_DF_140_VERATO.OMOP.PERSON P
SET P.PERSON_MPI_ID = X.EMPI
FROM QA_ADMIN_VERATO.EMPI.EMPI_XWALK X
WHERE TRIM(P.CLIENT_SOURCE_VALUE) = TRIM(X.CLIENT_SOURCE_VALUE) AND TRIM(P.SYSTEM_SOURCE_VALUE) = TRIM(X.SYSTEM_SOURCE_VALUE) AND TRIM(P.PERSON_SOURCE_VALUE) = TRIM(X.PERSON_SOURCE_VALUE);

--STEP:19
INSERT INTO QA_DTX_VERATO.VERATO.VERATO_LASTRUN (CLIENT_SOURCE_VALUE,SYSTEM_SOURCE_VALUE,PERSON_SOURCE_VALUE)
SELECT CLIENT_SOURCE_VALUE,SYSTEM_SOURCE_VALUE,PERSON_SOURCE_VALUE FROM QA_ADMIN_VERATO.EMPI.EMPI_XWALK;

UPDATE QA_DTX_VERATO.VERATO.VERATO_LASTRUN L
SET L.LAST_NAME = P.LAST_NAME,L.FIRST_NAME = P.FIRST_NAME,L.MIDDLE_NAME = P.MIDDLE_NAME,L.SSN = P.SSN,L.BIRTH_DATETIME = P.BIRTH_DATETIME,L.GENDER_SOURCE_VALUE = P.GENDER_SOURCE_VALUE,L.ADDRESS_1 = LO.ADDRESS_1,L.ADDRESS_2 = LO.ADDRESS_2,L.CITY = LO.CITY,L.STATE = LO.STATE,L.ZIP = LO.ZIP,L.DIVISION = P.DIVISION
FROM QA_DTX_VERATO.OMOP.PERSON P LEFT JOIN QA_DTX_VERATO.OMOP.LOCATION LO ON TRIM(P.LOCATION_ID) = TRIM(LO.LOCATION_ID) AND P.CLIENTID = LO.CLIENTID
WHERE TRIM(P.CLIENT_SOURCE_VALUE) = TRIM(L.CLIENT_SOURCE_VALUE) AND  TRIM(P.SYSTEM_SOURCE_VALUE) = TRIM(L.SYSTEM_SOURCE_VALUE)AND TRIM(P.PERSON_SOURCE_VALUE) =  TRIM(L.PERSON_SOURCE_VALUE);
--STEP:20
--RUN OMOP_Refresh_view script to create view.

--STEP:21
ALTER TABLE QA_DTX_VERATO.VERATO.VERATO_QUARANTINE ADD COLUMN create_time_holder TIMESTAMP without time zone NULL; 
UPDATE QA_DTX_VERATO.VERATO.VERATO_QUARANTINE SET create_time_holder = CREATED_DATE::TIMESTAMP; 
UPDATE QA_DTX_VERATO.VERATO.VERATO_QUARANTINE SET CREATED_DATE = create_time_holder;
ALTER TABLE QA_DTX_VERATO.VERATO.VERATO_QUARANTINE DROP COLUMN CREATED_DATE; 
ALTER TABLE QA_DTX_VERATO.VERATO.VERATO_QUARANTINE RENAME COLUMN create_time_holder TO CREATED_DATE;

ALTER TABLE QA_DTX_VERATO.VERATO.VERATO_STAGING ADD COLUMN create_time_holder TIMESTAMP without time zone NULL; 
UPDATE QA_DTX_VERATO.VERATO.VERATO_STAGING SET create_time_holder = CREATED_DATE::TIMESTAMP; 
UPDATE QA_DTX_VERATO.VERATO.VERATO_STAGING SET CREATED_DATE = create_time_holder;
ALTER TABLE QA_DTX_VERATO.VERATO.VERATO_STAGING DROP COLUMN CREATED_DATE; 
ALTER TABLE QA_DTX_VERATO.VERATO.VERATO_STAGING RENAME COLUMN create_time_holder TO CREATED_DATE;
