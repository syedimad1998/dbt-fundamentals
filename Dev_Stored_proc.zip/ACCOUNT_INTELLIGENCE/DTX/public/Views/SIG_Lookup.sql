create or replace view PROD_DTX.PUBLIC.SIG_Lookup as

WITH Initial_sig AS (
select 
distinct 
    trim(lower(d.druggenericname)) as druggenericname
    ,lower(trim(strengthsourcevalue)) as strengthsourcevalue
    ,lower(trim(dosesourcevalue)) as dosesourcevalue
    ,lower(trim(doseunitsourcevalue)) as doseunitsourcevalue
    ,lower(trim(sig)) as sig
    ,trim(lower(d.prescribedbrand)) as prescribedbrand
from prod_dtx.calculatedset.fctcancertherapy d
inner join prod_df_000.seed_data.oraldrug_whitelist o ON trim(lower(d.druggenericname)) = trim(lower(replace(o.drugname,'%',''))) OR trim(lower(d.prescribedbrand)) = trim(lower(replace(o.drugname,'%','')))
where 
sig is not null)
, Extracted_fields as(   
SELECT
case
    when SIG ilike '%once a day%' then 'daily - qd'
	when SIG ilike '%twice a day%' then 'twice a day - bid'
	when SIG ilike '%thrice a day%' then 'three times a day - tid' 
    when SIG ilike '%twice daily%' then 'twice a day - bid'
    when SIG ilike '%thrice daily%' then 'three times a day - tid'
    when SIG ilike '%two%time%daily%' then 'twice a day - bid'
    when SIG ilike '%three%time%daily%' then 'three times a day - tid'
    when SIG ilike '%four%time%daily%' then 'four times a day - qid'
    when SIG ilike '%two%time%day%' then 'twice a day - bid'
    when SIG ilike '%three%time%day%' then 'three times a day - tid'
    when SIG ilike '%four%time%day%' then 'four times a day - qid'
    when SIG ilike '%daily%' then 'daily - qd'
    when SIG ilike '%bi%weekly%' then 'bi-weekly'
    when SIG ilike '%bi%monthly%' then 'bi-monthly'
    when SIG ilike '%weekly%' then 'weekly - qw'
    when SIG ilike '%monthly%' then 'monthly - qm'
    when SIG ilike '%bid%' then 'twice a day - bid'
    when SIG ilike '%b.i.d%' then 'twice a day - bid'
    when SIG ilike '%tid %' then 'three times a day - tid'
    when SIG ilike '%t.i.d%' then 'three times a day - tid'
    when SIG ilike '%p.%o.%q%' then 'daily - qd'
    when SIG ilike '%po q%' then 'daily - qd'
    when SIG ilike '%p.o.%' then 'daily - qd'
    when SIG ilike '%28 day%' then '28-day cycle'
    when SIG ilike '%28day%' then '28-day cycle'
    when SIG ilike '%28d%' then '28-day cycle'
    when SIG ilike '%28-day%' then '28-day cycle'
    when SIG ilike '%21 day%' then '21-day cycle'
    when SIG ilike '%21day%' then '21-day cycle'
    when SIG ilike '%21d%' then '21-day cycle'
    when SIG ilike '%21-day%' then '21-day cycle'
    when SIG ilike '%14 day%' then '14-day cycle'
    when SIG ilike '%14day%' then '14-day cycle'
    when SIG ilike '%14d%' then '14-day cycle'
    when SIG ilike '%14-day%' then '14-day cycle'
    when SIG ilike '%q%12%hr%' then 'every 12 hours - q12h'
    when SIG ilike '%every%12%hrs%' then 'every 12 hours - q12h'
    when SIG ilike '%every%12%hour%' then 'every 12 hours - q12h'
    when SIG ilike '%q%24%hr%' then 'daily - qd'
    when SIG ilike '%every%24%hrs%' then 'daily - qd'
    when SIG ilike '%every%24%hour%' then 'daily - qd'
    when SIG ilike '%q%48%hr%' then 'every other day - qod'
    when SIG ilike '%every%48%hrs%' then 'every other day - qod'
    when SIG ilike '%every%48%hour%' then 'every other day - qod'
    when SIG ilike '%q%4%hr%' then 'every 4 hours - q4h'
    when SIG ilike '%every%4%hrs%' then 'every 4 hours - q4h'
    when SIG ilike '%every%4%hour%' then 'every 4 hours - q4h'
    when SIG ilike '%q%1 %hr%' then 'every 1 hour - q1h'
    when SIG ilike '%every%1 %hrs%' then 'every 1 hour - q1h'
    when SIG ilike '%every%1 %hour%' then 'every 1 hour - q1h'
    when SIG ilike '%every%other%day%' then 'every other day - qod'
    when SIG ilike '%every%day%' then 'daily - qd'
    when SIG ilike '%a day%' then 'daily - qd'
    when SIG ilike '%q 7 days%' then 'weekly - qw'
    when SIG ilike '%q 1 week%' then 'weekly - qw'
    else NULL
    end as FREQUENCY,
    CASE
    WHEN REGEXP_SUBSTR(SIG::string ,'\\b([1-9]|10) ?(capsules|capsule|cap|tablets|tablet|tab|table|pill|pills|p.o.|p.o|po|t )') IS NOT NULL THEN
    TRY_TO_NUMBER(REPLACE(REGEXP_SUBSTR(SIG::string, '\\b([1-9]|10) ?(capsules|capsule|cap|tablets|tablet|tab|table|pill|pills|p.o.|p.o|po|t )', 1, 1, 'e', 1),
    ',', ''))
    ELSE NULL
    END as P1,
    CASE
    WHEN REGEXP_SUBSTR(LOWER(CAST(SIG AS TEXT)), '\\b(one)\\b.*?(capsules|capsule|cap|tablets|tablet|tab|table|pill|pills|p.o.|p.o|po|t )') IS NOT NULL THEN 1
    WHEN REGEXP_SUBSTR(LOWER(CAST(SIG AS TEXT)), '\\b(two)\\b.*?(capsules|capsule|cap|tablets|tablet|tab|table|pill|pills|p.o.|p.o|po|t )') IS NOT NULL THEN 2
    WHEN REGEXP_SUBSTR(LOWER(CAST(SIG AS TEXT)), '\\b(three)\\b.*?(capsules|capsule|cap|tablets|tablet|tab|table|pill|pills|p.o.|p.o|po|t )') IS NOT NULL THEN 3
    WHEN REGEXP_SUBSTR(LOWER(CAST(SIG AS TEXT)), '\\b(four)\\b.*?(capsules|capsule|cap|tablets|tablet|tab|table|pill|pills|p.o.|p.o|po|t )') IS NOT NULL THEN 4
    ELSE NULL
    END AS P2,
    TRY_TO_DOUBLE(REPLACE(REGEXP_SUBSTR(SIG::string, 'take ([\\d,.]+) ?mg', 1, 1, 'e', 1), ',', '')) AS after_take_value,
    TRY_TO_DOUBLE(REPLACE(REGEXP_SUBSTR(SIG::string, '([\\d,.]+) ?mg', 1, 1, 'e', 1), ',', '')) AS first_mg_value,
    TRY_TO_DOUBLE(STRENGTHSOURCEVALUE::string)as strengthvalue,
    NULLIF(ROUND(DIV0NULL(GREATEST(COALESCE(after_take_value, 0), COALESCE(first_mg_value, 0)), COALESCE(strengthvalue, 0)), 2), 0) AS P3,
    TRY_TO_DOUBLE(REGEXP_SUBSTR(REPLACE(REPLACE(SIG::string,',',''),'.',''), '\\b([1-4])\\b')) AS P4,
    CASE 
    WHEN (ROUND(COALESCE(P1,P2,P3,P4),2) < 11 and REGEXP_LIKE(SIG::string, '\\d+ \\(\\d+.?\\d+? .*')) THEN ROUND(COALESCE(P1,P2,P4,P3),2)
    WHEN (ROUND(COALESCE(P1,P2,P3,P4),2) < 11 and not REGEXP_LIKE(SIG::string, '\\d+ \\(\\d+.?\\d+? .*')) THEN ROUND(COALESCE(P1,P2,P3,P4),2)
    ELSE NULL
    END as QUANTITYPERFREQUENCY
    ,druggenericname
    ,strengthsourcevalue
    ,dosesourcevalue
    ,doseunitsourcevalue
    ,sig
    ,prescribedbrand
FROM Initial_sig)

SELECT 
	DRUGGENERICNAME,
	STRENGTHSOURCEVALUE,
	DOSESOURCEVALUE,
	DOSEUNITSOURCEVALUE,
	SIG,
	PRESCRIBEDBRAND,
	FREQUENCY,
	CASE
        WHEN QUANTITYPERFREQUENCY ilike '%.%' THEN NULL
        ELSE QUANTITYPERFREQUENCY
	END AS QUANTITYPERFREQUENCY
FROM EXTRACTED_FIELDS
;