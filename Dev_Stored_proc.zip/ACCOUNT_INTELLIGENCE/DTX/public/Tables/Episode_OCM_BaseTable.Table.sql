CREATE TABLE PUBLIC.Episode_OCM_BaseTable(
	TypeOFRun varchar(500) NULL,
	ClientName varchar(100) NULL,
	ClientID varchar(50) NULL,
	Status varchar(200) NULL,
	Flag boolean NULL,
	LastOMOPRefresh_InDays int NULL,
	CalculatedSetStatus varchar(50) NULL,
	ECRFDailyFlag boolean NULL,
	ExecutionCounter int NULL default 0
) ;