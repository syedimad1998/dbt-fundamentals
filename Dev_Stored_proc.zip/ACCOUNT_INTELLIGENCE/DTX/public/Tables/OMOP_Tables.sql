create or replace table PROD_DTX.public.OMOP_TABLES (
  OMOP_Table_Type varchar (100), 
  OMOP_Table_Name varchar (100)
);