CREATE TABLE public.Provider_XWalk(
	Provider_XWalkId int not null
	, ClientId int not null
	, client_source_value varchar not null
	, system_source_value varchar not null
	, provider_source_value varchar (50) not null
	, MasterProviderId int not null
	, client_source_value_hash_512 char (130)not null
	, system_source_value_hash_512 char (130)not null
	, provider_source_value_hash_512 char (130)not null
);
