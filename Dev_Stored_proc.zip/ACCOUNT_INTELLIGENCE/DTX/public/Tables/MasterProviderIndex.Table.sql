CREATE TABLE public.MasterProviderIndex(
	MasterProviderId int not null
	, ClientId int not null
	, first_name varchar (100) not null
	, first_name_mutated varchar (100) not null
	, last_name varchar (100) not null
	, last_name_mutated varchar (100) not null
	, provider_name varchar (255) not null
	, provider_name_mutated varchar (255) not null
	, email_address varchar (1000) not null
	, phone_number varchar (50) not null
	, fax_number varchar (50) not null
	, federal_tax_id varchar (20) not null
	, NPI varchar (20) not null
	, DEA varchar (20) not null
);
