CREATE TABLE public.DTX_Patient_LOTS(
	Division varchar (100) not null
	, person_mpi_id varchar (100) null
	, StartDate date null
	, EndDate date null
	, LOT int null
	, Duration int null
	, REGIMEN nvarchar null
	, Intent varchar (10) not null
	, MetastaticStartDate date null
	, MetastaticType varchar null
	, adjuvant_lot varchar (30) null
	, CombinedDivisionMpi varchar (100) null
);
