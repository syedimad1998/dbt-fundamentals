CREATE OR REPLACE TABLE PROD_DTX.PUBLIC.WaitAlertDetails(
	ProcessName varchar,
	WaitTimeInMins int 
) ;