CREATE TABLE PUBLIC.EnterpriseMasterPatientIndex(
	EMPI bigint not null
	, last_name varchar (100) null
	, last_name_2 varchar (100) null
	, first_name varchar (100) null
	, first_name_2 varchar (100) null
	, middle_name varchar (100) null
	, ssn varchar (20) null
	, birthdate date null
	, birthdate_string varchar (10) null
	, zip varchar (20) null
	, created_date datetime null
);
