CREATE OR REPLACE TABLE PROD_DTX.PUBLIC.CalculatedSets_failed_variance(
    tablename varchar(100) ,
	division varchar(20),
	p_change int); 