CREATE TABLE PUBLIC.Measure_ProviderWhitelist(
	DivisionId int null
	, MeasureName varchar (100) null
	, ProviderNpiId varchar (100) null
);
