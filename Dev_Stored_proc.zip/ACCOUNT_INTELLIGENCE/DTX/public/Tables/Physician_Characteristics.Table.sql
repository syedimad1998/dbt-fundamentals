CREATE TABLE PUBLIC.Physician_Characteristics(
	NPI varchar (50) null
	, Practice varchar (50) null
	, ClientID varchar (50) null
	, Location varchar (100) null
	, LastName varchar (50) null
	, FirstName varchar (50) null
	, ProviderName varchar (50) null
	, ProviderActiveStartDate date null
	, ProviderActiveEndDate date null
	, TIN varchar (50) null
);
