CREATE OR REPLACE TABLE PROD_DTX.PUBLIC.CalculatedSets_new_rowcounts(
	tablename varchar(100) ,
	row_count int,
    division int );