CREATE TABLE PUBLIC.MST_Client(
    MST_ClientID int NOT NULL PRIMARY KEY,
    ClientID int NULL,
    ClientName varchar(500) NULL,
    ClientNameLong varchar(500) NULL,
    Specialty varchar(50) NULL
) ;