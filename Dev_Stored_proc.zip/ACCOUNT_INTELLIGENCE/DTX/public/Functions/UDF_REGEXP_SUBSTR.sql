CREATE OR REPLACE FUNCTION public.UDF_REGEXP_SUBSTR(SUBJECT STRING, PATTERN STRING)
RETURNS STRING
LANGUAGE JAVASCRIPT STRICT IMMUTABLE
AS
$$    
    var regex = new RegExp(PATTERN);
    let match = regex.exec(SUBJECT);

    if (match !== null) {
        return match[1];
    } else {
        return "";
    }
$$;