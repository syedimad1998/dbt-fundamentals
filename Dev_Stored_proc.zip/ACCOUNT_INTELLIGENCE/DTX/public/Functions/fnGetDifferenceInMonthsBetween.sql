create or replace function public.fnGetDifferenceInMonthsBetween(v_date_a datetime, v_date_b datetime)
returns int 
language sql
as 
$$

    with cte_vars as (
        select 
             case when v_date_a < v_date_b then v_date_a else v_date_b end as v_date_x
            ,case when v_date_a < v_date_b then v_date_b else v_date_a end as v_date_y
    )
    
    select 
        case 
            when date_part(day, v_date_x) > date_part(day, v_date_y)
                then datediff(month, v_date_x, v_date_y) -1
                else datediff(month, v_date_x, v_date_y)
        end
    from cte_vars
    

$$