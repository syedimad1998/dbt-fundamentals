create or replace function PUBLIC.fnConvert_Char1To32_ToSpace(SUBJECT VARCHAR)
RETURNS STRING
LANGUAGE JAVASCRIPT STRICT IMMUTABLE
as 
$$

    var regex = new RegExp('[\x00-\x1f]', 'g');
    var rtn = SUBJECT.replace(regex, ' ');
    return rtn;

$$
;