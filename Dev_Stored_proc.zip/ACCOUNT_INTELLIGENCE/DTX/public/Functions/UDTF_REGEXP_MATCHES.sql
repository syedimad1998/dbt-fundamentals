CREATE OR REPLACE FUNCTION public.UDTF_REGEXP_MATCHES ( SUBJECT VARCHAR, PATTERN VARCHAR )
  RETURNS TABLE ( MATCH VARCHAR, MATCHINDEX float, MATCHLENGTH float )
  LANGUAGE JAVASCRIPT
  AS 
  $$
    {
      processRow: function f(row, rowWriter, context)  {
        var regex = new RegExp(row.PATTERN,'g'); //GLOBAL

        while ((patternmatch = regex.exec(row.SUBJECT)) != null)  {
            rowWriter.writeRow( {MATCH: patternmatch[0], MATCHINDEX: patternmatch.index + 1, MATCHLENGTH: patternmatch[0].length} );
        }
      }
    }
  $$;