create or replace function public.PrimaryProvider(V_PERSON_MPI varchar(20), V_RTN_FIELD varchar(10))
returns varchar(20)
language sql
as 
$$
    -- for better performance DON'T use this function
    -- instead join to the view dbo.vw_PrimaryProvider
    
    select max(
            case 
            when V_RTN_FIELD = 'NPI' then coalesce(NPI::varchar, '')
            when V_RTN_FIELD = 'MPI' then coalesce(MPI::varchar, '')
            when V_RTN_FIELD = 'FirstName' then coalesce(FirstName::varchar, '')
            when V_RTN_FIELD = 'LastName' then coalesce(LastName::varchar, '')
            when V_RTN_FIELD = 'ClientID' then coalesce(ClientID::varchar, '')
            when V_RTN_FIELD = 'Status' then coalesce(Status::varchar,'')
        end) as rtn
    from dbo.vw_PrimaryProvider
    where person_MPI_id = V_PERSON_MPI

$$
;