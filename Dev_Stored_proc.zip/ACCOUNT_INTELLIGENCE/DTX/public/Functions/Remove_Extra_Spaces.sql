create or replace function PUBLIC.Remove_Extra_Spaces(SUBJECT VARCHAR)
RETURNS STRING
LANGUAGE JAVASCRIPT STRICT IMMUTABLE
as 
$$
	var SearchPattern = new RegExp('  +', 'g');
	var s = SUBJECT.replace(SearchPattern, ' ');
    return s;

$$
;
