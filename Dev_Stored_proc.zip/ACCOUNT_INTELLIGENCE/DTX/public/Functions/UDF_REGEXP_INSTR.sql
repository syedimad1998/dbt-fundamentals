CREATE OR REPLACE FUNCTION public.UDF_REGEXP_INSTR(SUBJECT STRING, PATTERN STRING, OCCURANCE FLOAT)
RETURNS FLOAT
LANGUAGE JAVASCRIPT STRICT IMMUTABLE
AS
$$  
    var occ = OCCURANCE;
    var c = 1;
    var position = 0;
    var regex = new RegExp(PATTERN,'gi'); //GLOBAL, CASE INSENSITIVE

    while ((match = regex.exec(SUBJECT)) != null) {

      if (occ == c) {
        position = match.index + 1;
        break;
      }
      else if (c > occ) {
        break;
      }

      c++
      
    }

    return position;

$$;