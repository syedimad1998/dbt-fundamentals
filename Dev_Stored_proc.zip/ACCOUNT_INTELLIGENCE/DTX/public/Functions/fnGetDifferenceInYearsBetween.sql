create or replace function public.fnGetDifferenceInYearsBetween(v_date_a date, v_date_b date)
returns int 
language sql
as 
$$  /* if start date > end date, swap the values */
    with cte_vars as (
        select 
             case when v_date_a < v_date_b then v_date_a else v_date_b end as StartDate
            ,case when v_date_a < v_date_b then v_date_b else v_date_a end as EndDate
            ,case when  v_date_a < v_date_b then 0 else 1 end as ReturnValueIsNegative
        )
        select case when ReturnValueIsNegative=0 
        	then (DATEDIFF(YEAR,StartDate,EndDate)
        - (
            CASE
					WHEN MONTH(StartDate)> MONTH(EndDate) THEN 1
					WHEN MONTH(StartDate)= MONTH(EndDate) AND DAY(StartDate) > DAY(EndDate) THEN 1
					ELSE 0 
				END
          )) else
          -(DATEDIFF(YEAR,StartDate,EndDate)
        - (
            CASE
					WHEN MONTH(StartDate)> MONTH(EndDate) THEN 1
					WHEN MONTH(StartDate)= MONTH(EndDate) AND DAY(StartDate) > DAY(EndDate) THEN 1
					ELSE 0 
				END
          ))
          end from cte_vars
$$