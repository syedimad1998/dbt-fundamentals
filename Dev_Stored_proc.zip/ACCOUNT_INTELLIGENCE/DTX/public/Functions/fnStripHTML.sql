create or replace function PUBLIC.fnStripHTML(SUBJECT VARCHAR)
RETURNS STRING
LANGUAGE JAVASCRIPT STRICT IMMUTABLE
as 
$$
    var HTMLText = SUBJECT;
    
    // Remove anything between <whatever> tags
    var regex = new RegExp('<[^>]*>', 'g');
    var HTMLText = HTMLText.replace(regex, '');
    
    // Replace &amp;amp; with &
    // Replace &amp; with &
    var regex = new RegExp('&amp;amp;|&amp;', 'g');
    var HTMLText = HTMLText.replace(regex, '&');
    
    // Replace the HTML entity &lt; with the '<' character
    var regex = new RegExp('&lt;', 'g');
    var HTMLText = HTMLText.replace(regex, '<');
    
    // Replace the HTML entity &gt; with the '>' character
    var regex = new RegExp('&gt;', 'g');
    var HTMLText = HTMLText.replace(regex, '>');
 
    // Replace the HTML entity &nbsp; with the ' ' character
    // Replace any <br> tags with a space
    // Replace any <br/> tags with a space
    // Replace any <br /> tags with a space
    var regex = new RegExp('<br>|<br/>|<br />|&nbsp;', 'g');
    var HTMLText = HTMLText.replace(regex, ' ');

    
    return HTMLText;

$$
;