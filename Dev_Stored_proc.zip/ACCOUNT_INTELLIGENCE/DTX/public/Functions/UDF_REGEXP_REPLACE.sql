CREATE OR REPLACE FUNCTION public.UDF_REGEXP_REPLACE(SUBJECT STRING, PATTERN STRING, VALUE STRING)
RETURNS STRING
LANGUAGE JAVASCRIPT STRICT IMMUTABLE
AS
$$    
    var regex = new RegExp(PATTERN);
    if (VALUE.search('{') >= 0) { //templated string
        if ((match = regex.exec(SUBJECT)) !== null) {
            const { groups: { firstNumber, secondNumber } } = regex.exec(SUBJECT)
            return SUBJECT.replace(match[0],VALUE.replace('{firstNumber}',firstNumber).replace('{secondNumber}',secondNumber));
    } 
    else {
        return SUBJECT;
    }
}
else {
  if ((match = regex.exec(SUBJECT)) !== null) {
    for (let i = 1; i < match.length; i++) {
        SUBJECT = SUBJECT.replace(match[i],VALUE);
    }    
  }
  
  return SUBJECT;
}
$$;