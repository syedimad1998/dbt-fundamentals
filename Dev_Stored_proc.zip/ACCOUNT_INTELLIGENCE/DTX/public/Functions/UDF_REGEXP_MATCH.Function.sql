CREATE OR REPLACE FUNCTION PUBLIC.UDF_REGEXP_MATCH(SUBJECT STRING, PATTERN STRING)
RETURNS boolean
LANGUAGE JAVASCRIPT STRICT IMMUTABLE
AS
$$    
    var regex = new RegExp(PATTERN);
    let match = regex.exec(SUBJECT);

    if (match !== null) {
       return true;
    } else {
       return false;
    }
$$;