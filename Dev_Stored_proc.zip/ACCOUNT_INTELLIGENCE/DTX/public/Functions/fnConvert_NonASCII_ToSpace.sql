create or replace function PUBLIC.fnConvert_NonASCII_ToSpace(SUBJECT VARCHAR)
RETURNS STRING
LANGUAGE JAVASCRIPT STRICT IMMUTABLE
as 
$$

    var regex = new RegExp('[^\x00-\x7F]', 'g');
    var rtn = SUBJECT.replace(regex, ' ');
    return rtn;

$$
;