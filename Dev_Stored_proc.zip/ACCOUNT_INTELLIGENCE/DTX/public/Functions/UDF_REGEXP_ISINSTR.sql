CREATE OR REPLACE FUNCTION public.UDF_REGEXP_ISINSTR(SUBJECT STRING, PATTERN STRING)
RETURNS STRING
LANGUAGE JAVASCRIPT STRICT IMMUTABLE
AS
$$    
    var regex = new RegExp(PATTERN,'gi');
    let match = regex.exec(SUBJECT);

    if (match !== null) {
      return true;
    } else {
        return false;
    }
$$;
