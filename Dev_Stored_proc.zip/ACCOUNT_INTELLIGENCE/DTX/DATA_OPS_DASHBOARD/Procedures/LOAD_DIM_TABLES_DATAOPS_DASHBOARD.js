CREATE OR REPLACE PROCEDURE DATA_OPS_DASHBOARD.LOAD_DIM_TABLES_DATAOPS_DASHBOARD(DATABASE VARCHAR(50))
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
EXECUTE AS CALLER
AS '
 // CHECK TO MAKE SURE ALL PARAMETERS ARE SQL INJECTION RISK FREE
    try
    {
        var alloweddatabasenames = /^[a-zA-Z]+$/;
        if (DATABASE.match(alloweddatabasenames) == null)
        {
            return ''Possible SQL Injection:'' + DATABASE;
        }
    }   
    catch(err)
    {
        return ''SQL Injection query error:'' + err;
    }
	// This function is used to execute command that are sent to it
	function executesql(command)
	{
		var cmd_dict = {sqlText: command};
		var stmt = snowflake.createStatement(cmd_dict);
		return stmt.execute();
	}
	
	var LOAD_DIM_DIVISION = `
			MERGE INTO ` +  DATABASE + `_DTX.DATA_OPS_DASHBOARD.DIM_DIVISION AS T																	\\															
			USING (SELECT MC.CLIENTID, MC.CLIENTNAME, (CASE WHEN IFNULL(PBD.DIVISION,'''') = '''' THEN ''NO'' ELSE ''YES'' END) IS_PBD 
					FROM ` +  DATABASE + `_DTX.PUBLIC.MST_CLIENT MC																					\\
					LEFT JOIN (SELECT * FROM ` +  DATABASE + `_DTX.DATA_OPS_DASHBOARD.DIM_PQBLACKLISTEDDIVISION											\\
							) PBD ON MC.CLIENTID = PBD.DIVISION
				) AS S	
			ON S.CLIENTID = T.DIVISION
			WHEN MATCHED THEN
			UPDATE SET T.DIVISION = S.CLIENTID, T.CLIENTNAME = S.CLIENTNAME, T.IS_PQBLACKLISTED = S.IS_PBD
			WHEN NOT MATCHED THEN
			INSERT (DIVISION, CLIENTNAME, IS_PQBLACKLISTED, LOADDATE)
			VALUES (S.CLIENTID,S.CLIENTNAME, S.IS_PBD, GETDATE());
		`
	
	var LOAD_DIM_DIM_DIAGNOSISCATEGORIES = `
			MERGE INTO ` +  DATABASE + `_DTX.DATA_OPS_DASHBOARD.DIM_DIAGNOSISCATEGORIES AS T															\\
            USING ` +  DATABASE + `_DTX.OPERATIONSDASHBOARD.DIAGNOSISCATEGORIES	AS S																		\\
            ON S.CodeType = T.CodeType AND (S.BEGINCODE = T.BEGINCODE AND S.ENDCODE = T.ENDCODE)
            WHEN MATCHED THEN 
                UPDATE SET T.DESCRIPTION = S.DESCRIPTION
            WHEN NOT MATCHED THEN
                INSERT (
                CATEGORY 
              , CODETYPE
              , BEGINCODE
              , ENDCODE
              , DESCRIPTION
              , DIAGNOSISCODESET
              , LOADDATE)
                VALUES (S.CATEGORY,S.CODETYPE, S.BEGINCODE, S.ENDCODE, S.DESCRIPTION, CONCAT(S.BEGINCODE, ''-'', S.ENDCODE), GETDATE());
	`
	
	var rsTruncTbl = `
				TRUNCATE TABLE ` +  DATABASE + `_DTX.DATA_OPS_DASHBOARD.DIM_CALENDAR																\\
	`

    var LOAD_Dim_Calendar = `
			INSERT INTO ` +  DATABASE + `_DTX.DATA_OPS_DASHBOARD.DIM_CALENDAR																					\\
            (DATE, YEAR, DAY, WEEKYEAR, MONTHNAME, MONTH_NAME, MONTH_NUM, MONTH_YEAR)    

             WITH CTE_DIM_DATE AS 
             (
             SELECT DATEADD(DAY, SEQ4(), DATEADD(''YEAR'', -7, date_trunc(''YEAR'',current_date()))) AS DIM_DATE
               FROM TABLE(GENERATOR(ROWCOUNT=>10000))  
             )
             SELECT DIM_DATE Date
                   ,YEAR(DIM_DATE) Year 
                   ,DAY(DIM_DATE) Day 
                   ,CONCAT(''Week'',CONCAT(WEEKOFYEAR(DIM_DATE),CONCAT(''-'',YEAR(DIM_DATE)))) WEEKYEAR
                   ,TO_CHAR(DIM_DATE,''MMMM'') MONTHNAME
                   ,MONTHNAME(DIM_DATE) MONTH_NAME
                   ,MONTH(DIM_DATE) MONTH_NUM
                   ,CONCAT(MONTHNAME(DIM_DATE), CONCAT('' '',YEAR(DIM_DATE))) MONTH_YEAR
               FROM CTE_DIM_DATE CD                                                                                                                                                   
               WHERE DIM_DATE <= (SELECT TO_DATE(SYSDATE())) AND
               NOT EXISTS (SELECT 1 FROM ` +  DATABASE + `_DTX.DATA_OPS_DASHBOARD.DIM_CALENDAR DC WHERE DC.DATE = CD.DIM_DATE);										\\
	`

    var LOAD_DIM_CANCERCODES = `
			MERGE INTO ` +  DATABASE + `_DTX.DATA_OPS_DASHBOARD.DIM_CANCERCODES AS T																					\\
            USING (WITH CTE_ICD10 AS ( 
               SELECT DISTINCT ''ICD10'' AS CODETYPE, LEFT(PO.PROCEDURE_SOURCE_VALUE, 3) AS CancerCode, I10.DESCRIPTION FROM ` +  DATABASE + `_DTX.OMOP.PROCEDURE_OCCURRENCE PO								\\
                   JOIN (SELECT * FROM ` +  DATABASE + `_DTX.DATA_OPS_DASHBOARD.DIM_DIAGNOSISCATEGORIES																							\\
                            WHERE CodeType = ''ICD10'') I10 ON LEFT(PO.PROCEDURE_SOURCE_VALUE, 1) = LEFT(I10.BEGINCODE, 1)
                                                        AND SUBSTR(PO.PROCEDURE_SOURCE_VALUE, 2, 2) BETWEEN RIGHT(BEGINCODE, 2) AND RIGHT(ENDCODE, 2)
                        UNION
                   SELECT DISTINCT ''ICD10'' AS CODETYPE,LEFT(CO.CONDITION_SOURCE_VALUE, 3) AS CancerCode, I10.DESCRIPTION FROM ` +  DATABASE + `_DTX.OMOP.CONDITION_OCCURRENCE CO								\\
                   JOIN (SELECT * FROM ` +  DATABASE + `_DTX.DATA_OPS_DASHBOARD.DIM_DIAGNOSISCATEGORIES																									\\
                            WHERE CodeType = ''ICD10'') I10 ON LEFT(CO.CONDITION_SOURCE_VALUE, 1) = LEFT(I10.BEGINCODE, 1)
                                                        AND SUBSTR(CO.CONDITION_SOURCE_VALUE, 2, 2) BETWEEN RIGHT(BEGINCODE, 2) AND RIGHT(ENDCODE, 2)
                ),
                CTE_ICD9 AS (
                    SELECT * FROM (SELECT DISTINCT ''ICD9'' AS CODETYPE,LEFT(PO.PROCEDURE_SOURCE_VALUE, 3) AS CancerCode, I9.DESCRIPTION FROM ` +  DATABASE + `_DTX.OMOP.PROCEDURE_OCCURRENCE PO						\\
                        JOIN (SELECT * FROM ` +  DATABASE + `_DTX.DATA_OPS_DASHBOARD.DIM_DIAGNOSISCATEGORIES																										\\
                            WHERE CodeType = ''ICD9'') I9 ON LEFT(PO.PROCEDURE_SOURCE_VALUE, 3) BETWEEN BEGINCODE AND ENDCODE
                        UNION
                    SELECT DISTINCT ''ICD9'' AS CODETYPE,LEFT(CO.CONDITION_SOURCE_VALUE, 3) AS CancerCode, I9.DESCRIPTION FROM ` +  DATABASE + `_DTX.OMOP.CONDITION_OCCURRENCE CO												\\
                        JOIN (SELECT * FROM ` +  DATABASE + `_DTX.DATA_OPS_DASHBOARD.DIM_DIAGNOSISCATEGORIES																										\\
                            WHERE CodeType = ''ICD9'') I9 ON LEFT(CO.CONDITION_SOURCE_VALUE, 3) BETWEEN BEGINCODE AND ENDCODE) TBL
                     WHERE NOT EXISTS (SELECT 1 FROM CTE_ICD10 WHERE CTE_ICD10.CANCERCODE = TBL.CANCERCODE) 
                   ),
                CTE_FINAL AS (
                    SELECT *, ROW_NUMBER() OVER(PARTITION BY CANCERCODE ORDER BY CANCERCODE) ROWN FROM (SELECT * FROM CTE_ICD10 UNION SELECT * FROM CTE_ICD9) TBL
                    )
               SELECT DESCRIPTION, CANCERCODE FROM CTE_FINAL WHERE ROWN = 1) AS S ON S.CancerCode = T.ICDCODE
            WHEN MATCHED THEN
                UPDATE SET T.CANCERTYPE = S.DESCRIPTION
            WHEN NOT MATCHED THEN
                INSERT (
                CANCERTYPE
              , ICDCODE
              , LOADDATE)
                VALUES (S.DESCRIPTION, S.CancerCode, GETDATE())
	`

	try
    {
        executesql(LOAD_DIM_DIVISION);
		
        executesql(LOAD_DIM_DIM_DIAGNOSISCATEGORIES);
		
		executesql(rsTruncTbl);
		executesql(LOAD_Dim_Calendar);
		
        executesql(LOAD_DIM_CANCERCODES);
    }
    catch(err)
    {
        return ''Error loading FACT tables:'' + err;
    }

    return ''SUCCESS'';
    
    ';