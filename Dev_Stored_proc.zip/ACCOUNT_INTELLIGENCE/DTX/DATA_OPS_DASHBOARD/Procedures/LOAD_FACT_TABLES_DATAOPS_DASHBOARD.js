CREATE OR REPLACE PROCEDURE LOAD_FACT_TABLES_DATAOPS_DASHBOARD(DATABASE VARCHAR(50))
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
EXECUTE AS CALLER
AS '
 // CHECK TO MAKE SURE ALL PARAMETERS ARE SQL INJECTION RISK FREE
    try
    {
        var alloweddatabasenames = /^[a-zA-Z]+$/;
        if (DATABASE.match(alloweddatabasenames) == null)
        {
            return ''Possible SQL Injection:'' + DATABASE;
        }
    }   
    catch(err)
    {
        return ''SQL Injection query error:'' + err;
    }
	// This function is used to execute command that are sent to it
	function executesql(command)
	{
		var cmd_dict = {sqlText: command};
		var stmt = snowflake.createStatement(cmd_dict);
		return stmt.execute();
	}
	
	var rsTruncTbl = `
				TRUNCATE TABLE ` +  DATABASE + `_DTX.DATA_OPS_DASHBOARD.FACT_PATIENT_HEALTH 														\\
		`
	
	var LOAD_FACT_IC2 = `
		INSERT INTO ` +  DATABASE + `_DTX.DATA_OPS_DASHBOARD.FACT_PATIENT_HEALTH 														\\
		(ENVIRONMENT, EARLIESTDATE, DIVISION, CANCERCODE, MPI, GENDER, PATIENTSTATUS, ENVIRON_MPI, DIAGNOSISCODESET, IS_PHI, LOADDATE)

          WITH Genders AS 
			(
			SELECT concept_id, concept_name AS Gender FROM ` +  DATABASE + `_DF_000.OMOP.concept WHERE domain_id = ''Gender'' 														\\ 							 
				UNION ALL
			SELECT 0, ''UNKNOWN''
			),
		DataPoints AS 
			(SELECT P.SYSTEM_SOURCE_VALUE, P.DIVISION, P.PERSON_MPI_ID, G.GENDER, PO.PROCEDURE_DATE AS WORKDATE, I10.DIAGNOSISCODESET
			, (CASE WHEN D.DEATH_DATE > CAST(P.BIRTH_DATETIME AS DATE) THEN ''EXPIRED'' ELSE ''ALIVE'' END) PAT_STATUS
			, LEFT(PO.PROCEDURE_SOURCE_VALUE, 3) AS CancerCode
			FROM ` +  DATABASE + `_DTX.OMOP.PERSON P																	 														\\
			JOIN Genders G ON G.concept_id = P.gender_concept_id
			JOIN ` +  DATABASE + `_DTX.OMOP.PROCEDURE_OCCURRENCE PO ON P.PERSON_ID = PO.PERSON_ID AND P.DIVISION = PO.DIVISION 														\\
			JOIN (SELECT * FROM ` +  DATABASE + `_DTX.DATA_OPS_DASHBOARD.DIM_DIAGNOSISCATEGORIES 														\\														
					WHERE CodeType = ''ICD10'') I10 ON LEFT(PO.PROCEDURE_SOURCE_VALUE, 1) = LEFT(I10.BEGINCODE, 1)
												AND SUBSTR(PO.PROCEDURE_SOURCE_VALUE, 2, 2) BETWEEN RIGHT(BEGINCODE, 2) AND RIGHT(ENDCODE, 2)
			LEFT JOIN ` +  DATABASE + `_DTX.OMOP.DEATH D ON D.PATIENTID = P.PATIENTID 														\\																		
			UNION ALL
			SELECT P.SYSTEM_SOURCE_VALUE, P.DIVISION, P.PERSON_MPI_ID, G.GENDER, CO.CONDITION_START_DATE AS WORKDATE, I10.DIAGNOSISCODESET
			, (CASE WHEN D.DEATH_DATE > CAST(P.BIRTH_DATETIME AS DATE) THEN ''EXPIRED'' ELSE ''ALIVE'' END) PAT_STATUS
			, LEFT(CO.CONDITION_SOURCE_VALUE, 3) AS CancerCode
			FROM ` +  DATABASE + `_DTX.OMOP.PERSON P 														\\ 																										
			JOIN Genders G ON G.concept_id = P.gender_concept_id
			JOIN ` +  DATABASE + `_DTX.OMOP.CONDITION_OCCURRENCE CO ON P.PERSON_ID = CO.PERSON_ID AND P.DIVISION = CO.DIVISION 														\\
			JOIN (SELECT * FROM ` +  DATABASE + `_DTX.DATA_OPS_DASHBOARD.DIM_DIAGNOSISCATEGORIES 														\\														
					WHERE CodeType = ''ICD10'') I10 ON LEFT(CO.CONDITION_SOURCE_VALUE, 1) = LEFT(I10.BEGINCODE, 1)
												AND SUBSTR(CO.CONDITION_SOURCE_VALUE, 2, 2) BETWEEN RIGHT(BEGINCODE, 2) AND RIGHT(ENDCODE, 2)
			LEFT JOIN ` +  DATABASE + `_DTX.OMOP.DEATH D ON D.PATIENTID = P.PATIENTID	 														\\																		
			UNION ALL
			SELECT P.SYSTEM_SOURCE_VALUE, P.DIVISION, P.PERSON_MPI_ID, G.GENDER, PO.PROCEDURE_DATE AS WORKDATE, I9.DIAGNOSISCODESET
			, (CASE WHEN D.DEATH_DATE > CAST(P.BIRTH_DATETIME AS DATE) THEN ''EXPIRED'' ELSE ''ALIVE'' END) PAT_STATUS
			, LEFT(PO.PROCEDURE_SOURCE_VALUE, 3) AS CancerCode
			FROM ` +  DATABASE + `_DTX.OMOP.PERSON P				 														\\																							
			JOIN Genders G ON G.concept_id = P.gender_concept_id
			JOIN ` +  DATABASE + `_DTX.OMOP.PROCEDURE_OCCURRENCE PO ON P.PERSON_ID = PO.PERSON_ID AND P.DIVISION = PO.DIVISION 														\\									
			JOIN (SELECT * FROM ` +  DATABASE + `_DTX.DATA_OPS_DASHBOARD.DIM_DIAGNOSISCATEGORIES 														\\																
					WHERE CodeType = ''ICD9'') I9 ON LEFT(PO.PROCEDURE_SOURCE_VALUE, 3) BETWEEN BEGINCODE AND ENDCODE
			LEFT JOIN ` +  DATABASE + `_DTX.OMOP.DEATH D ON D.PATIENTID = P.PATIENTID 														\\																				
			UNION ALL
			SELECT P.SYSTEM_SOURCE_VALUE, P.DIVISION, P.PERSON_MPI_ID, G.GENDER, CO.CONDITION_START_DATE AS WORKDATE, I9.DIAGNOSISCODESET
			, (CASE WHEN D.DEATH_DATE > CAST(P.BIRTH_DATETIME AS DATE) THEN ''EXPIRED'' ELSE ''ALIVE'' END) PAT_STATUS
			, LEFT(CO.CONDITION_SOURCE_VALUE, 3) AS CancerCode
			FROM ` +  DATABASE + `_DTX.OMOP.PERSON P 														\\ 																												
			JOIN Genders G ON G.concept_id = P.gender_concept_id
			JOIN ` +  DATABASE + `_DTX.OMOP.CONDITION_OCCURRENCE CO ON P.PERSON_ID = CO.PERSON_ID AND P.DIVISION = CO.DIVISION 														\\ 														\\  										
			JOIN (SELECT * FROM ` +  DATABASE + `_DTX.DATA_OPS_DASHBOARD.DIM_DIAGNOSISCATEGORIES 														\\																	
					WHERE CodeType = ''ICD9'') I9 ON LEFT(CO.CONDITION_SOURCE_VALUE, 3) BETWEEN BEGINCODE AND ENDCODE
			LEFT JOIN ` +  DATABASE + `_DTX.OMOP.DEATH D ON D.PATIENTID = P.PATIENTID 														\\
			),
		DataPoints1 AS (
			SELECT SYSTEM_SOURCE_VALUE,CM.classification, D.DIVISION, PERSON_MPI_ID, GENDER, MIN(WORKDATE) EARLIESTDATE, DIAGNOSISCODESET, PAT_STATUS, CANCERCODE, CASE 
					WHEN CM.classification = ''ElectronicHealthRecord'' THEN 1
					WHEN CM.classification = ''PracticeManagement'' THEN 2
					WHEN CM.classification = ''Pharmacy'' THEN 3
					WHEN CM.classification = ''Other'' THEN 4
					WHEN CM.classification = ''CMS'' THEN 5
					WHEN CM.classification = ''ChartAbstraction'' THEN 6
					WHEN CM.classification = ''Unknown'' THEN 7
					ELSE 8 END AS MRNPriority
				FROM DataPoints D
			LEFT JOIN ` +  DATABASE + `_DTX.CalculatedSet.Control_SourceSystemDivisionMapping CM ON D.system_source_value = CM.MatchCode AND CM.Division = D.DIVISION 														\\
			WHERE PERSON_MPI_ID IS NOT NULL
			GROUP BY SYSTEM_SOURCE_VALUE, D.DIVISION, PERSON_MPI_ID, GENDER,DIAGNOSISCODESET, PAT_STATUS, CANCERCODE,CM.classification
			),
		RESULTS AS (
			SELECT *, ROW_NUMBER() OVER(PARTITION BY DIVISION, PERSON_MPI_ID ORDER BY DIVISION, PERSON_MPI_ID, MRNPRIORITY, EARLIESTDATE) ROWN FROM DataPoints1
		)
		
		SELECT DISTINCT ''IC2'', EARLIESTDATE, DIVISION, CANCERCODE, PERSON_MPI_ID, GENDER, PAT_STATUS, CONCAT(''IC2_'',PERSON_MPI_ID), DIAGNOSISCODESET, ''YES'', GETDATE() 
			FROM Results WHERE ROWN = 1
    `

    var LOAD_FACT_IC3 = `
		INSERT INTO ` +  DATABASE + `_DTX.DATA_OPS_DASHBOARD.FACT_PATIENT_HEALTH 														\\ 																									\\	
		(ENVIRONMENT, EARLIESTDATE, DIVISION, CANCERCODE, MPI, GENDER, PATIENTSTATUS, ENVIRON_MPI, DIAGNOSISCODESET, IS_PHI, LOADDATE)

        WITH DATAPOINTS1 AS (    
			SELECT DPM.METADATATYPE, FPD.DIVISION, FPD.MPIID, DP.GENDERNAME, I10.CATEGORY, I10.DESCRIPTION, FPD.DATEINSTANCEOFCANCERCODE
			, (CASE WHEN DATEOFDEATH IS NOT NULL THEN ''EXPIRED'' ELSE ''ALIVE'' END) AS PAT_STATUS, I10.DIAGNOSISCODESET, FPD.CANCERCODE
			FROM ` +  DATABASE + `_DTX.CALCULATEDSET.DIMPATIENTCANCER FPD 														\\
			JOIN ` +  DATABASE + `_DTX.CALCULATEDSET.DIMPATIENT DP ON DP.DIVISION = FPD.DIVISION AND DP.MPIID = FPD.MPIID 														\\
			JOIN (SELECT * FROM ` +  DATABASE + `_DTX.DATA_OPS_DASHBOARD.DIM_DIAGNOSISCATEGORIES 														\\
			WHERE CodeType = ''ICD10'') I10 ON LEFT(FPD.CANCERCODE, 1) = LEFT(I10.BEGINCODE, 1) AND SUBSTR(FPD.CANCERCODE, 2, 2) BETWEEN RIGHT(BEGINCODE, 2) AND RIGHT(ENDCODE, 2)
			LEFT JOIN ` +  DATABASE + `_DTX.CALCULATEDSET.DIMPATIENTMETADATA DPM ON DPM.DIVISION = FPD.DIVISION AND DPM.MPIID = FPD.MPIID 														\\
				WHERE FPD.CODETYPE = ''ICD10''                              
			UNION
			SELECT DPM.METADATATYPE, FPD.DIVISION, FPD.MPIID, DP.GENDERNAME, I9.CATEGORY, I9.DESCRIPTION, FPD.DATEINSTANCEOFCANCERCODE
				, (CASE WHEN DATEOFDEATH IS NOT NULL THEN ''EXPIRED'' ELSE ''ALIVE'' END) AS PAT_STATUS, I9.DIAGNOSISCODESET, FPD.CANCERCODE
			FROM ` +  DATABASE + `_DTX.CALCULATEDSET.DIMPATIENTCANCER FPD 														\\
			JOIN ` +  DATABASE + `_DTX.CALCULATEDSET.DIMPATIENT DP ON DP.DIVISION = FPD.DIVISION AND DP.MPIID = FPD.MPIID 														\\
			JOIN (SELECT * FROM ` +  DATABASE + `_DTX.DATA_OPS_DASHBOARD.DIM_DIAGNOSISCATEGORIES 														\\
			WHERE CodeType = ''ICD9'') I9 ON LEFT(FPD.CANCERCODE, 3) BETWEEN BEGINCODE AND ENDCODE
			LEFT JOIN ` +  DATABASE + `_DTX.CALCULATEDSET.DIMPATIENTMETADATA DPM ON DPM.DIVISION = FPD.DIVISION AND DPM.MPIID = FPD.MPIID 														\\
				WHERE FPD.CODETYPE = ''ICD9''),
		DATAPOINTS2 AS (
			SELECT D.DIVISION, MPIID, GENDERNAME, MIN(DATEINSTANCEOFCANCERCODE) EARLIESTDATE, PAT_STATUS, DIAGNOSISCODESET, CANCERCODE, CASE 
						WHEN CM.classification = ''ElectronicHealthRecord'' THEN 1
						WHEN CM.classification = ''PracticeManagement'' THEN 2
						WHEN CM.classification = ''Pharmacy'' THEN 3
						WHEN CM.classification = ''Other'' THEN 4
						WHEN CM.classification = ''CMS'' THEN 5
						WHEN CM.classification = ''ChartAbstraction'' THEN 6
						WHEN CM.classification = ''Unknown'' THEN 7
						ELSE 8 END AS MRNPriority
			FROM DATAPOINTS1 D
			LEFT JOIN ` +  DATABASE + `_DTX.CalculatedSet.Control_SourceSystemDivisionMapping CM ON D.METADATATYPE = CM.MatchCode AND CM.Division = D.DIVISION 														\\
			WHERE MPIID IS NOT NULL
			GROUP BY CM.CLASSIFICATION, METADATATYPE, D.DIVISION, MPIID, GENDERNAME, CATEGORY, DESCRIPTION, DATEINSTANCEOFCANCERCODE, PAT_STATUS, DIAGNOSISCODESET, CANCERCODE
		),
		RESULTS AS (
			SELECT *, ROW_NUMBER() OVER(PARTITION BY DIVISION, MPIID ORDER BY DIVISION, MPIID, MRNPriority, EARLIESTDATE) ROWN FROM DATAPOINTS2
			)
		SELECT DISTINCT ''IC3'', EARLIESTDATE, DIVISION, CANCERCODE, MPIID, GENDERNAME, PAT_STATUS, CONCAT(''IC3_'',MPIID), DIAGNOSISCODESET, ''YES'', GETDATE() 
		FROM RESULTS WHERE ROWN = 1
          `
		  
    var LOAD_FACT_IC1 = `
		INSERT INTO ` +  DATABASE + `_DTX.DATA_OPS_DASHBOARD.FACT_PATIENT_HEALTH 																		\\
		(ENVIRONMENT, EARLIESTDATE, DIVISION, CANCERCODE, MPI, GENDER, PATIENTSTATUS, ENVIRON_MPI, DIAGNOSISCODESET, IS_PHI, LOADDATE)

		SELECT ''IC1'' ENVIRONMENT, NULL EARLIESTDATE, DIVISION, NULL CANCERCODE, person_source_value MPI
			, (CASE WHEN GenderIdentity IS NULL THEN ''(Blank)''
                          WHEN GenderIdentity = ''M'' OR GenderIdentity = ''Male'' THEN ''MALE'' 
                          WHEN GenderIdentity = ''F'' OR GenderIdentity = ''Female'' THEN ''FEMALE'' ELSE ''Unknown'' END) GENDERNAME
			, (CASE WHEN death_date IS NULL THEN ''ALIVE'' ELSE ''EXPIRED'' END) PATIENTSTATUS
			, person_source_value ENVIRON_MPI, ''(Blank)'' DIAGNOSISCODESET, ''YES'', GETDATE() LOADDATE 
		 FROM (
			SELECT DISTINCT TO_VARCHAR(t.PatientGuid) AS person_source_value, TO_DATE(DeathDate) AS death_date,
				ad.GenderIdentity, ''100'' AS DIVISION
			FROM ` +  DATABASE + `_DF_100.ICEHR.t_patients t																							\\
			JOIN ` +  DATABASE + `_DF_100.ICEHR.t_patients_Additional_data AD ON AD.PatientGuid = t.PatientGuid											\\
		UNION ALL
			SELECT DISTINCT TO_VARCHAR(pt_id) AS Person_source_value, TO_DATE(pt_dod) AS death_date, sex_cd, ''101'' AS Division
			FROM ` +  DATABASE + `_DF_101.ARIA.pt																										\\
		UNION ALL
			SELECT DISTINCT TO_VARCHAR(PatientID) AS Person_source_value, TO_DATE(DOD) as death_date,
				IFNULL(TargetGender, Gender) AS gender_source_value, ''102''
			FROM ` +  DATABASE + `_DF_102.EPICEHR.Demographics																							\\
		UNION ALL
			SELECT DISTINCT TO_VARCHAR(PatientID) AS Person_source_value, TO_DATE(DOD) as death_date,
				IFNULL(TargetGender, Gender) AS gender_source_value, ''103''
			FROM ` +  DATABASE + `_DF_103.Onco.Demographics																									\\
		UNION ALL
			SELECT TO_VARCHAR(pt_id) AS Person_source_value, TO_DATE(pt_dod) AS death_date, sex_cd, ''105''
			FROM ` +  DATABASE + `_DF_105.RAWBAK.Pt																										\\
		UNION ALL
			SELECT DISTINCT TO_VARCHAR(pt_id) AS Person_source_value, TO_DATE(pt_dod) AS death_date, sex_cd, ''107'' AS Division
			FROM ` +  DATABASE + `_DF_107.ARIA.pt 																											\\
		UNION ALL
			SELECT DISTINCT TO_VARCHAR(sPatientID) AS Person_source_value, TO_DATE(ddateofdeath) as death_date,
				GENDERIDENTITY AS gender_source_value, ''111''
			FROM ` +  DATABASE + `_DF_111.OncoRaw.Demographics_History																						\\
		UNION ALL
			SELECT DISTINCT TO_VARCHAR(t.PatientGuid) AS person_source_value, TO_DATE(DeathDate) AS death_date,
				ad.GenderIdentity, ''112'' AS DIVISION
			FROM ` +  DATABASE + `_DF_112.ICEHR.t_patients t																								\\
			JOIN ` +  DATABASE + `_DF_112.ICEHR.t_patients_Additional_data AD ON AD.PatientGuid = t.PatientGuid 											\\
		UNION ALL
			SELECT DISTINCT TO_VARCHAR(t.PatientGuid) AS person_source_value, TO_DATE(DeathDate) AS death_date,
				ad.GenderIdentity, ''114'' AS DIVISION
			FROM ` +  DATABASE + `_DF_114.ICEHR.t_patients t																								\\
			JOIN ` +  DATABASE + `_DF_114.ICEHR.t_patients_Additional_data AD ON AD.PatientGuid = t.PatientGuid													\\
		UNION ALL
			SELECT DISTINCT TO_VARCHAR(PatientID) AS Person_source_value, TO_DATE(DOD) as death_date,
				IFNULL(TargetGender, Gender) AS gender_source_value, ''117''
			FROM ` +  DATABASE + `_DF_117.Onco.Demographics    																								\\  
		UNION ALL
			SELECT DISTINCT TO_VARCHAR(pt_id) AS Person_source_value, TO_DATE(pt_dod) AS death_date, sex_cd, ''119'' AS Division
			FROM ` +  DATABASE + `_DF_119.ARIA.pt																												\\
		UNION ALL
			SELECT DISTINCT TO_VARCHAR(PatientID) AS Person_source_value, TO_DATE(DOD) as death_date,
				IFNULL(TargetGender, Gender) AS gender_source_value, ''120''
			FROM ` +  DATABASE + `_DF_120.Onco.Demographics																											\\
		UNION ALL
			SELECT DISTINCT TO_VARCHAR(PatientID) AS Person_source_value, TO_DATE(DOD) as death_date,
				IFNULL(TargetGender, Gender) AS gender_source_value, ''121''
			FROM ` +  DATABASE + `_DF_121.Onco.Demographics																										\\
		UNION ALL
			SELECT DISTINCT TO_VARCHAR(PatientID) AS Person_source_value, TO_DATE(DOD) as death_date,
				IFNULL(TargetGender, Gender) AS gender_source_value, ''123''
			FROM ` +  DATABASE + `_DF_123.Onco.Demographics																											\\
		UNION ALL
			SELECT DISTINCT TO_VARCHAR(pt_id) AS Person_source_value, TO_DATE(pt_dod) AS death_date,
				sex_cd, ''125'' AS Division
			FROM ` +  DATABASE + `_DF_125.ARIA.pt																												\\
		UNION ALL
			SELECT DISTINCT TO_VARCHAR(PatientID) AS Person_source_value, TO_DATE(DOD) as death_date,
				IFNULL(TargetGender, Gender) AS gender_source_value, ''127''
			FROM ` +  DATABASE + `_DF_127.Onco.Demographics																											\\
		UNION ALL
			SELECT DISTINCT TO_VARCHAR(PatientID) AS Person_source_value, TO_DATE(DOD) as death_date,
				IFNULL(TargetGender, Gender) AS gender_source_value, ''130''
			FROM ` +  DATABASE + `_DF_130.Onco.Demographics																											\\
		UNION ALL
			SELECT DISTINCT TO_VARCHAR(PatientID) AS Person_source_value, TO_DATE(DOD) as death_date,
				IFNULL(TargetGender, Gender) AS gender_source_value, ''131''
			FROM ` +  DATABASE + `_DF_131.Onco.Demographics																												\\
		UNION ALL
			SELECT DISTINCT TO_VARCHAR(t.PatientGuid) AS person_source_value, TO_DATE(DeathDate) AS death_date,
				ad.GenderIdentity, ''133'' AS DIVISION
			FROM ` +  DATABASE + `_DF_133.ICEHR.t_patients t																											\\
			JOIN ` +  DATABASE + `_DF_133.ICEHR.t_patients_Additional_data AD ON AD.PatientGuid = t.PatientGuid																\\
		UNION ALL
			SELECT DISTINCT TO_VARCHAR(ID) AS Person_source_value, TO_DATE(DATEOFDEATH) AS death_date,
				gender, ''134''
			FROM ` +  DATABASE + `_DF_134.Iknowmed.g2_patient																												\\																									\\
		UNION ALL
			SELECT DISTINCT TO_VARCHAR(t.PatientGuid) AS person_source_value, TO_DATE(DeathDate) AS death_date,
				ad.GenderIdentity, ''136'' AS DIVISION
			FROM ` +  DATABASE + `_DF_136.ICEHR.t_patients t																									\\
			JOIN ` +  DATABASE + `_DF_136.ICEHR.t_patients_Additional_data AD ON AD.PatientGuid = t.PatientGuid																\\
		UNION ALL
			SELECT DISTINCT TO_VARCHAR(PatientID) AS Person_source_value, TO_DATE(DOD) as death_date,
				IFNULL(TargetGender, Gender) AS gender_source_value, ''137''
			FROM ` +  DATABASE + `_DF_137.Onco.Demographics																												\\
		UNION ALL
			SELECT DISTINCT TO_VARCHAR(t.PatientGuid) AS person_source_value, TO_DATE(DeathDate) AS death_date,
				ad.GenderIdentity, ''138'' AS DIVISION
			FROM ` +  DATABASE + `_DF_138.ICEHR.t_patients t																												\\
			JOIN ` +  DATABASE + `_DF_138.ICEHR.t_patients_Additional_data AD ON AD.PatientGuid = t.PatientGuid																\\
		UNION ALL
			SELECT DISTINCT TO_VARCHAR(PatientID) AS Person_source_value, TO_DATE(DOD) as death_date,
				IFNULL(TargetGender, Gender) AS gender_source_value, ''140''
			FROM ` +  DATABASE + `_DF_140.Onco.Demographics																														\\
		UNION ALL
			SELECT DISTINCT TO_VARCHAR(pt_id) AS Person_source_value, TO_DATE(pt_dod) AS death_date, sex_cd, ''142'' AS Division
			FROM ` +  DATABASE + `_DF_142.ARIA.pt																																\\
		) TBL
    `
	var rsInsert_IC4_IC5 = `
		INSERT INTO ` +  DATABASE + `_DTX.DATA_OPS_DASHBOARD.FACT_PATIENT_HEALTH 																				\\
		(ENVIRONMENT, EARLIESTDATE, DIVISION, CANCERCODE, MPI, GENDER, PATIENTSTATUS, ENVIRON_MPI, DIAGNOSISCODESET, IS_PHI, LOADDATE)
			SELECT ENVIRONMENT, EARLIESTDATE, COALESCE(DIVISION,''-99''), CANCERCODE, MPI, GENDERNAME, COALESCE(PATIENTSTATUS,''(Blank)''), ENVIRON_MPI, DIAGNOSISCODESET, IS_PHI, LOADDATE \\
				FROM ` +  DATABASE + `_DTX.DATA_OPS_DASHBOARD.PATIENT_HEALTH																						\\
		`

	try
    {
        executesql(rsTruncTbl);
        executesql(LOAD_FACT_IC1);
		executesql(LOAD_FACT_IC2);
		executesql(LOAD_FACT_IC3);
        executesql(rsInsert_IC4_IC5);
	
    }
    catch(err)
    {
        return ''Error loading FACT tables:'' + err;
    }

    return ''SUCCESS'';
    
    ';