CREATE TABLE LBQ.OCM_24(
	Division varchar (100) not null
	, TreatmentYear int not null
	, TreatmentQuarter int not null
	, ReportingPeriodStartDateInclusive date not null
	, ReportingPeriodEndDateInclusive date not null
	, MpiId int not null
	, FirstName varchar (100) null
	, LastName varchar (100) null
	, Gender varchar null
	, EpisodeRelated_OCMCancerDx varchar null
	, EpisodeRelated_OCMCancerDxStartDate date null
	, EpisodeRelated_EpisodeStartDate date null
	, EpisodeRelated_EpisodeEndDate date null
	, VisitDate date not null
	, VisitCPTCode varchar null
	, VisitProcedureOccurrenceId int null
	, ProviderId int null
	, ProviderMpiId int null
	, ProviderName varchar (255) null
	, PayerDuringVisit_Payer varchar null
	, PayerDuringVisit_EffectiveDate date null
	, PayerDuringVisit_InactiveDate date null
	, PayerDuringVisit_PrimaryIndicator varchar null
	, MostRecentPayer_Payer varchar null
	, MostRecentPayer_EffectiveDate date null
	, MostRecentPayer_InactiveDate date null
	, MostRecentPayer_PrimaryIndicator varchar null
	, AdvancedDirective_EventDate date null
	, AdvancedDirective_DataSource varchar (100) null
	, AdvancedDirective_DataSourceKey int null
	, AdvancedDirective_DataSourceValue varchar null
	, HospiceStartDateInReportingPeriod date null
	, HospiceEndDateInReportingPeriod date null
	, HadAdvancedDirectiveBeforeOrAtThisVisit boolean null
	, HadHospiceDuringReportingPeriod boolean null
	, PatientMrn varchar (100) null
	, ProviderNpiId varchar (100) null
	, RecordInsertionDate datetime (8) not null
	, CalculationFlag_Met_DenominatorPopulation boolean not null
	, CalculationFlag_Met_DenominatorExclusion boolean not null
	, CalculationFlag_Met_NumeratorPopulation boolean not null
	, CalculationFlag_Met_DenominatorException boolean not null
	, CalculationFlag_Met_EpisodeRelated boolean not null
	, TIN varchar (100) null
);
