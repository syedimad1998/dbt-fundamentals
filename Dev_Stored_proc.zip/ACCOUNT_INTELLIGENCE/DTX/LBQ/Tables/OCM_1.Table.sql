CREATE TABLE LBQ.OCM_1(
	Division nvarchar null
	, BENE_ID varchar (255) null
	, MPI int null
	, BENE_HICN varchar (200) null
	, FIRST_NAME varchar (200) null
	, LAST_NAME varchar (200) null
	, SEX varchar (1) null
	, MRN varchar (100) null
	, DOB date null
	, AGE int null
	, DOD date null
	, ZIPCODE varchar (12) null
	, EP_ID varchar (403) null
	, EP_BEG date null
	, EP_END date null
	, EP_LENGTH int null
	, CANCER_TYPE varchar (200) null
	, RECON_ELIG int null
	, DUAL_PTD_LIS varchar (255) null
	, INST int not null
	, RADIATION varchar (200) null
	, HCC_GRP varchar (200) null
	, HRR_REL_COST varchar (200) null
	, SURGERY varchar (200) null
	, CLINICAL_TRIAL varchar (200) null
	, BMT varchar (200) null
	, CLEAN_PD varchar (200) null
	, PTD_CHEMO varchar (200) null
	, ACTUAL_EXP decimal (12,2) null
	, BASELINE_PRICE decimal (12,2) null
	, EXPERIENCE_ADJ varchar (200) null
	, ACTUAL_EXP_UNADJ varchar (200) null
	, LOW_RISK_BLAD varchar (200) null
	, CAST_SENS_PROS varchar (200) null
	, MBI varchar (200) null
	, BENCHMARK_PRICE varchar (200) null
	, TARGET_PRICE varchar (200) null
	, OCM_DISCOUNT_ACO varchar (200) null
	, NOVEL_THERAPIES varchar (200) null
	, NUM_OCM1 varchar (200) null
	, NUM_OCM2 varchar (200) null
	, NUM_OCM3 varchar (200) null
	, DEN_OCM3 varchar (200) null
	, EXP_ALL_SERVICES varchar (200) null
	, EXP_INP_ADMSNS varchar (200) null
	, EXP_OBS_STAY varchar (200) null
	, EXP_ED varchar (200) null
	, EXP_RAD_ONCLGY varchar (200) null
	, EXP_PHY_SRVC varchar (200) null
	, EXP_MEOS varchar (200) null
	, EXP_ANC_SRVC varchar (200) null
	, EXP_OUT_OTHER varchar (200) null
	, EXP_HHA varchar (200) null
	, EXP_SNF varchar (200) null
	, EXP_LTCH varchar (200) null
	, EXP_IRF varchar (200) null
	, EXP_HSP varchar (200) null
	, EXP_DME_EXCL_DRUGS varchar (200) null
	, EXP_PART_B_DRUGS varchar (200) null
	, EXP_PD varchar (200) null
	, EXP_OTHER varchar (200) null
	, HIGH_RISK varchar (20) null
	, Reporting_Period varchar (255) null
	, NPI varchar (250) null
	, ProviderName varchar (50) null
	, PerfPeriod varchar (200) null
	, CMS_reporting_period_quarter varchar (50) null
	, CMS_PP_range varchar (50) null
	, CMS_reporting_period_order varchar (50) null
	, OCM_CareSite varchar (50) null
	, OCM_ProviderName varchar (50) null
	, OCM_CareSiteTIN varchar (50) null
	, DIV_OCM_CareSiteTIN varchar (50) null
	, OCM_NPI varchar (50) null
	, DIV_NPI varchar (100) null
	, Cancer_Type_Mapped varchar (200) null
	, EP_View int null
	, IP_Admission int not null
	, Admission_Count int null
	, Total_LOS int null
	, Total_IP_Reimbursement decimal (12,2) null
	, Load_Date datetime null
	, Display_OCM_TIN varchar (50) null
	, Display_OCM_TIN_List varchar (50) null
);
