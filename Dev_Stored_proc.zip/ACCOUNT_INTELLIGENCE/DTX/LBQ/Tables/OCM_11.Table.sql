CREATE TABLE LBQ.OCM_11(
	Division varchar (100) not null
	, TreatmentYear int null
	, TreatmentQuarter int null
	, ReportingPeriodStartDateInclusive date not null
	, ReportingPeriodEndDateInclusive date not null
	, MpiId int not null
	, FirstName varchar (100) null
	, LastName varchar (100) null
	, Gender varchar null
	, EpisodeRelated_OCMCancerDx varchar null
	, EpisodeRelated_OCMCancerDxStartDate date null
	, EpisodeRelated_EpisodeStartDate date null
	, EpisodeRelated_EpisodeEndDate date null
	, CancerDiagnosisDate date null
	, CancerDiagnosis varchar null
	, ProviderId int null
	, ProviderMpiId int null
	, ProviderName varchar (255) null
	, PayerDuringVisit_Payer varchar null
	, PayerDuringVisit_EffectiveDate date null
	, PayerDuringVisit_InactiveDate date null
	, PayerDuringVisit_PrimaryIndicator varchar null
	, MostRecentPayer_Payer varchar null
	, MostRecentPayer_EffectiveDate date null
	, MostRecentPayer_InactiveDate date null
	, MostRecentPayer_PrimaryIndicator varchar null
	, DenominatorFlag_NotInDenominatorBecauseIsNotFemale boolean not null
	, DenominatorFlag_NotInDenominatorBecauseNotAtLeast18 boolean not null
	, ProviderEncounter_EventDate date null
	, ProviderEncounter_SourceLocation varchar (100) null
	, ProviderEncounter_SourceLocationKey int null
	, ProviderEncounter_SourceValue varchar null
	, ProviderEncounter_AgeInYearsOnVisit int null
	, DenominatorFlag_NotInDenominatorBecauseHasIncorrectPathology boolean not null
	, Pathology_EventDate date null
	, Pathology_SourceLocation varchar (100) not null
	, Pathology_SourceLocationKey int null
	, Pathology_SourceValue varchar null
	, Pathology_MatchedPathologyType varchar (100) null
	, DenominatorFlag_NotInDemoninatorBecauseNegativeEstrogenReceptor boolean not null
	, EstrogenReceptor_TestDate date null
	, EstrogenReceptor_SourceLocation varchar (100) null
	, EstrogenReceptor_SourceKey int null
	, EstrogenReceptor_SourceValue varchar null
	, DenominatorFlag_NotInDemoninatorBecauseNegativeProgesteroneReceptor boolean not null
	, ProgesteroneReceptor_TestDate date null
	, ProgesteroneReceptor_SourceLocation varchar (100) null
	, ProgesteroneReceptor_SourceKey int null
	, ProgesteroneReceptor_SourceValue varchar null
	, Exception_ReceivedChemoOrRadiationInMeasurementPeriod boolean not null
	, RadiationOrChemo_EventDate date null
	, RadiationOrChemo_SourceLocation varchar (100) null
	, RadiationOrChemo_SourceKey int null
	, RadiationOrChemo_SourceValue varchar null
	, Exception_WasInvolvedInClinicalTrial boolean not null
	, ClinicalTrial_EventStartDate date null
	, ClinicalTrial_EventEndDate date null
	, ClinicalTrial_SourceLocation varchar (100) null
	, ClinicalTrial_SourceKey int null
	, ClinicalTrial_SourceValue varchar null
	, Exception_PatientReceivedOophorectomy boolean not null
	, Oophorectomy_EventDate date null
	, Oophorectomy_SourceLocation varchar (100) null
	, Oophorectomy_SourceKey int null
	, Oophorectomy_SourceValue varchar null
	, Exception_PatientRefusedMedication boolean not null
	, MedicationRefusal_EventDate date null
	, MedicationRefusal_SourceLocation varchar (100) null
	, MedicationRefusal_SourceKey int null
	, MedicationRefusal_SourceValue varchar null
	, Exception_HadMetastaticCancer boolean not null
	, MetastaticPatientDetail_EventDate date null
	, MetastaticPatientDetail_SourceLocation varchar (100) null
	, MetastaticPatientDetail_SourceKey int null
	, MetastaticPatientDetail_SourceValue varchar null
	, NumeratorFlag_PatientInNumeratorBecauseTheyTookMedication boolean not null
	, PatientsWithMedication_EventDate date null
	, PatientsWithMedication_SourceLocation varchar (100) null
	, PatientsWithMedication_SourceKey int null
	, PatientsWithMedication_SourceValue varchar null
	, Flag_ThisDataBelongsToFloridaBlueVariant boolean not null
	, PatientMrn varchar (100) null
	, DOB date null
	, ProviderNpiId varchar (100) null
	, RecordInsertionDate datetime (8) not null
	, CalculationFlag_Met_DenominatorPopulation boolean null
	, CalculationFlag_Met_DenominatorExclusion boolean null
	, CalculationFlag_Met_NumeratorPopulation boolean null
	, CalculationFlag_Met_DenominatorException boolean null
	, CalculationFlag_Met_EpisodeRelated boolean null
	, TIN varchar (100) null
);
