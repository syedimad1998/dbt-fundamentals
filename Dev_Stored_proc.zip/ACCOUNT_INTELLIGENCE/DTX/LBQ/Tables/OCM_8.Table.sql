CREATE TABLE LBQ.OCM_8(
	Division nvarchar not null
	, TreatmentYear int null
	, TreatmentQuarter int null
	, ReportingPeriodStartDateInclusive date not null
	, ReportingPeriodEndDateInclusive date not null
	, MpiId int not null
	, FirstName varchar (100) null
	, LastName varchar (100) null
	, Gender varchar null
	, EpisodeRelated_OCMCancerDx varchar null
	, EpisodeRelated_OCMCancerDxStartDate date null
	, EpisodeRelated_EpisodeStartDate date null
	, EpisodeRelated_EpisodeEndDate date null
	, CancerDiagnosisDate date null
	, CancerDiagnosis varchar null
	, ProviderId int null
	, ProviderMpiId int null
	, ProviderName varchar (255) null
	, PayerDuringVisit_Payer varchar null
	, PayerDuringVisit_EffectiveDate date null
	, PayerDuringVisit_InactiveDate date null
	, PayerDuringVisit_PrimaryIndicator varchar null
	, MostRecentPayer_Payer varchar null
	, MostRecentPayer_EffectiveDate date null
	, MostRecentPayer_InactiveDate date null
	, MostRecentPayer_PrimaryIndicator varchar null
	, Flag_NotInDenominatorBecauseOfAge int not null
	, AgeAtCancerDiagnosis int null
	, Flag_NotInDenominatorBecauseNotFirstOrOnlyCancerDiagnosis int not null
	, CancerDiagnosis_ColonCancerSourceLocation varchar (19) not null
	, CancerDiagnosis_ColonCancerSourceLocationKey int null
	, CancerDiagnosis_ColonCancerConditionStartDate date null
	, CancerDiagnosis_ColonCancerConditionEndDate date null
	, CancerDiagnosis_ColonCancerSourceValue varchar null
	, CancerDiagnosis_FirstCancerDiagnosisSourceLocation varchar (19) not null
	, CancerDiagnosis_FirstCancerDiagnosisSourceLocationKey int null
	, CancerDiagnosis_FirstCancerDiagnosisConditionStartDate date null
	, CancerDiagnosis_FirstCancerDiagnosisConditionEndDate date null
	, CancerDiagnosis_FirstCancerDiagnosisSourceValue varchar null
	, Flag_NotInDenominatorBecauseDidNotHaveSurgery int not null
	, SurgeryData_EventDate date null
	, SurgeryData_SourceLocation varchar (100) null
	, SurgeryData_SourceLocationKey int null
	, SurgeryData_SourceValue varchar null
	, Flag_NotInDenominatorBecauseNotEpithilialMalignancy int not null
	, EpithelialMalignancy_EventDate date null
	, EpithelialMalignancy_SourceLocation varchar (100) null
	, EpithelialMalignancy_SourceLocationKey int null
	, EpithelialMalignancy_SourceValue varchar null
	, Flag_NotInDenominatorBecauseBehaviorCodeIsNotInvasive int not null
	, BehaviorInvasive_EventDate date null
	, BehaviorInvasive_SourceLocation varchar (100) null
	, BehaviorInvasive_SourceLocationKey int null
	, BehaviorInvasive_SourceValue varchar null
	, Flag_NotInDenominatorBecauseNoRegionalLymphNodePositiveForCancer int not null
	, ImpactsLymphNodes_EventDate date null
	, ImpactsLymphNodes_SourceLocation varchar (100) null
	, ImpactsLymphNodes_SourceLocationKey int null
	, ImpactsLymphNodes_SourceValue varchar null
	, Flag_NotInDenominatorBecauseTreatmentHandledFullyOutsideReportingPractice boolean null
	, Exclusion_IsExcludedBecauseMetastaticDiseaseStageIV int not null
	, Stage4MetastaticDisease_EventDate date null
	, Stage4MetastaticDisease_SourceLocation varchar (100) null
	, Stage4MetastaticDisease_SourceLocationKey int null
	, Stage4MetastaticDisease_SourceValue varchar null
	, Exclusion_IsExcludedBecauseInappropriateCancerTValues int not null
	, InappropriateCancerTValues_EventDate date null
	, InappropriateCancerTValues_SourceLocation varchar (100) null
	, InappropriateCancerTValues_SourceLocationKey int null
	, InappropriateCancerTValues_SourceValue varchar null
	, Exclusion_IsExcludedBecauseInSituDisease int not null
	, InSituDisease_EventDate date null
	, InSituDisease_SourceLocation varchar (100) null
	, InSituDisease_SourceLocationKey int null
	, InSituDisease_SourceValue varchar null
	, Exclusion_IsExcludedBecauseTheyDiedWithinFourMonthsOfDiagnosis int not null
	, DateOfDeath date null
	, Exclusion_IsExcludedBecauseParticipatingInClinicalTrialThatCoversPartOfReportingPeriod int not null
	, ClinicalTrialParticipant_EventDateStart date null
	, ClinicalTrialParticipant_EventDateEnd date null
	, ClinicalTrialParticipant_SourceLocation varchar (100) null
	, ClinicalTrialParticipant_SourceLocationKey int null
	, ClinicalTrialParticipant_SourceValue varchar null
	, NumeratorInclusion_ChemotherapyAdministeredWithin120DaysDiagnosis int not null
	, GivenChemotherapyTreatment_EventDate date null
	, GivenChemotherapyTreatment_SourceLocation varchar (100) null
	, GivenChemotherapyTreatment_SourceLocationKey int null
	, GivenChemotherapyTreatment_SourceValue varchar null
	, NumeratorInclusion_ChemotherapyRecommendedOrDiscussedbutNotReceivedWithin120DaysofDiagnosis int not null
	, RecommendedChemotherapyTreatment_EventDate date null
	, RecommendedChemotherapyTreatment_SourceLocation varchar (100) null
	, RecommendedChemotherapyTreatment_SourceLocationKey int null
	, RecommendedChemotherapyTreatment_SourceValue varchar null
	, PatientMrn varchar (100) null
	, ProviderNpiId varchar (100) null
	, RecordInsertionDate datetime (8) not null
	, CalculationFlag_Met_DenominatorPopulation boolean null
	, CalculationFlag_Met_DenominatorExclusion boolean null
	, CalculationFlag_Met_NumeratorPopulation boolean null
	, CalculationFlag_Met_DenominatorException boolean null
	, CalculationFlag_Met_EpisodeRelated boolean null
	, TIN varchar (100) null
);
