CREATE TABLE LBQ.OCM_10(
	Division varchar (100) not null
	, TreatmentYear int null
	, TreatmentQuarter int null
	, ReportingPeriodStartDateInclusive date not null
	, ReportingPeriodEndDateInclusive date not null
	, MpiId int not null
	, FirstName varchar (100) null
	, LastName varchar (100) null
	, Gender varchar null
	, EpisodeRelated_OCMCancerDx varchar null
	, EpisodeRelated_OCMCancerDxStartDate date null
	, EpisodeRelated_EpisodeStartDate date null
	, EpisodeRelated_EpisodeEndDate date null
	, CancerDiagnosisDate date null
	, CancerDiagnosis varchar null
	, ProviderId int null
	, ProviderMpiId int null
	, ProviderName varchar (255) null
	, PayerDuringVisit_Payer varchar null
	, PayerDuringVisit_EffectiveDate date null
	, PayerDuringVisit_InactiveDate date null
	, PayerDuringVisit_PrimaryIndicator varchar null
	, MostRecentPayer_Payer varchar null
	, MostRecentPayer_EffectiveDate date null
	, MostRecentPayer_InactiveDate date null
	, MostRecentPayer_PrimaryIndicator varchar null
	, Flag_NotInDenominatorBecauseNotFemale boolean null
	, Flag_NotInDenominatorBecauseNoQualifyingProviderEncounter boolean null
	, VisitData_EventDate date null
	, VisitData_SourceLocation varchar (100) not null
	, VisitData_SourceLocationKey int null
	, VisitData_SourceValue varchar null
	, Flag_NotInDenominatorBecauseOfAge boolean null
	, AgeAtCancerDiagnosis int null
	, CancerDiagnosis_BreastCancerSourceLocation varchar (100) not null
	, CancerDiagnosis_BreastCancerSourceLocationKey int null
	, CancerDiagnosis_BreastCancerConditionStartDate date null
	, CancerDiagnosis_BreastCancerConditionEndDate date null
	, CancerDiagnosis_BreastCancerSourceValue varchar null
	, Flag_NotInDenominatorBecauseNoChemotherapyWithin12MonthsBeforeEndOfMeasurementPeriod boolean null
	, ChemotherapyAdministration_EventDate date null
	, ChemotherapyAdministration_SourceLocation varchar (100) null
	, ChemotherapyAdministration_SourceLocationKey int null
	, ChemotherapyAdministration_SourceValue varchar null
	, Flag_NotInDenominatorBecauseHer2ResultNegativeOrUnknown boolean null
	, Her2TestResults_IhcMeasurementDate date null
	, Her2TestResults_IhcSourceLocation varchar (100) null
	, Her2TestResults_IhcSourceKey int null
	, Her2TestResults_IhcSourceValue varchar null
	, Her2TestResults_FishMeasurementDate date null
	, Her2TestResults_FishSourceLocation varchar (100) null
	, Her2TestResults_FishSourceKey int null
	, Her2TestResults_FishSourceValue varchar null
	, Her2TestResults_IhcValue varchar null
	, Her2TestResults_FishValue varchar null
	, Her2TestResults_IhcTestNotedAsPositive boolean null
	, Her2TestResults_FishTestNotedAsPositive boolean null
	, Her2TestResults_CombinedResultNotedAsWeaklyPositive boolean null
	, Flag_NotInDenominatorBecauseInappropriateCancerSTGTNMValues boolean null
	, InappropriateCancerStgTNMValues_EventDate date null
	, InappropriateCancerStgTNMValues_SourceLocation varchar (100) null
	, InappropriateCancerStgTNMValues_SourceLocationKey int null
	, InappropriateCancerStgTNMValues_SourceValue varchar null
	, Exclusion_IsExcludedBecauseMetastaticDiseaseStageIV boolean null
	, Stage4MetastaticDisease_EventDate date null
	, Stage4MetastaticDisease_SourceLocation varchar (100) null
	, Stage4MetastaticDisease_SourceLocationKey int null
	, Stage4MetastaticDisease_SourceValue varchar null
	, Exclusion_IsExcludedBecauseHasMultiplePrimaryCancers boolean null
	, MultiplePrimaryCodes nvarchar null
	, Exclusion_IsExcludedBecauseTheyDiedWithin12MonthsDiagnosis boolean null
	, DateOfDeath date null
	, Exclusion_IsExcludedBecauseTheyWereStillReceivingAnthracyclineBasedChemo boolean null
	, AnthracyclineBasedChemo_EventDate date null
	, AnthracyclineBasedChemo_SourceLocation varchar (100) null
	, AnthracyclineBasedChemo_SourceLocationKey int null
	, AnthracyclineBasedChemo_SourceValue varchar null
	, NumeratorInclusion_TrastuzumabAdministered boolean null
	, TrastuzumabAdministered_EventDate date null
	, TrastuzumabAdministered_SourceLocation varchar (100) null
	, TrastuzumabAdministered_SourceLocationKey int null
	, TrastuzumabAdministered_SourceValue varchar null
	, NumeratorInclusion_ClinicalTrial boolean null
	, ClinicalTrial_EventDateStart date null
	, ClinicalTrial_EventDateEnd date null
	, ClinicalTrial_SourceLocation varchar (100) null
	, ClinicalTrial_SourceLocationKey int null
	, ClinicalTrial_SourceValue varchar null
	, DenominatorException_TrastuzumabRefused boolean null
	, TrastuzumabRefused_EventDate date null
	, TrastuzumabRefused_SourceLocation varchar (100) null
	, TrastuzumabRefused_SourceLocationKey int null
	, TrastuzumabRefused_SourceValue varchar null
	, PatientMrn varchar (100) null
	, ProviderNpiId varchar (100) null
	, RecordInsertionDate datetime (8) not null
	, CalculationFlag_Met_DenominatorPopulation boolean null
	, CalculationFlag_Met_DenominatorExclusion boolean null
	, CalculationFlag_Met_NumeratorPopulation boolean null
	, CalculationFlag_Met_DenominatorException boolean null
	, CalculationFlag_Met_EpisodeRelated boolean null
	, TIN varchar (100) null
);
