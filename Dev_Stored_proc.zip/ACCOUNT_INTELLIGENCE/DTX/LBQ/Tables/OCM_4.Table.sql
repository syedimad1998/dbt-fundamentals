CREATE TABLE LBQ.OCM_4(
	Division varchar (100) not null
	, TreatmentYear int null
	, TreatmentQuarter int null
	, ReportingPeriodStartDateInclusive date not null
	, ReportingPeriodEndDateInclusive date not null
	, MpiId int not null
	, FirstName varchar (100) null
	, LastName varchar (100) null
	, Gender varchar (100) null
	, EpisodeRelated_OCMCancerDx varchar null
	, EpisodeRelated_OCMCancerDxStartDate date null
	, EpisodeRelated_EpisodeStartDate date null
	, EpisodeRelated_EpisodeEndDate date null
	, VisitDate date not null
	, VisitCPTCode varchar null
	, VisitProcedureOccurrenceId int null
	, ProviderId int null
	, ProviderMpiId int null
	, ProviderName varchar (255) null
	, RadiationVisitCPTCode varchar null
	, RadiationVisitDate date null
	, PriorChemoCPTCode varchar null
	, PriorChemoDate date null
	, PostChemoCPTCode varchar null
	, PostChemoDate date null
	, PayerDuringVisit_Payer varchar null
	, PayerDuringVisit_EffectiveDate date null
	, PayerDuringVisit_InactiveDate date null
	, PayerDuringVisit_PrimaryIndicator varchar null
	, MostRecentPayer_Payer varchar null
	, MostRecentPayer_EffectiveDate date null
	, MostRecentPayer_InactiveDate date null
	, MostRecentPayer_PrimaryIndicator varchar null
	, PainIntensityQuantifiedThisVisitDate boolean not null
	, PainIntensityValueMeasuredThisVisitDate varchar (10) null
	, PlanOfCareForPainDiscussedThisVisitDate boolean not null
	, HadActiveCancerEpisodeThatIncludesThisVisitDate boolean not null
	, HadApplicableDiagnosisCodeForCancerOnThisVisit boolean not null
	, HadApplicableDiagnosisCodeForCancerDuringThisPeriod boolean not null
	, PatientMrn varchar (100) null
	, ProviderNpiId varchar (100) null
	, RecordInsertionDate datetime (8) not null
	, FLAG_OCM4A_PassedRadiationAndChemoVisitDateRequirement boolean null
	, FLAG_OCM4A_PassedEpisodeVisitDateComparisonRequirement boolean null
	, CalculationFlag_OCM4A_Met_DenominatorPopulation boolean null
	, CalculationFlag_OCM4A_Met_DenominatorExclusion boolean null
	, CalculationFlag_OCM4A_Met_NumeratorPopulation boolean null
	, CalculationFlag_OCM4A_Met_DenominatorException boolean null
	, CalculationFlag_OCM4A_Met_EpisodeRelated boolean null
	, CalculationFlag_OCM4B_Met_DenominatorPopulation boolean null
	, CalculationFlag_OCM4B_Met_DenominatorExclusion boolean null
	, CalculationFlag_OCM4B_Met_NumeratorPopulation boolean null
	, CalculationFlag_OCM4B_Met_DenominatorException boolean null
	, CalculationFlag_OCM4B_Met_EpisodeRelated boolean null
	, TIN varchar (100) null
	, ProviderLocation varchar (255) null
	, PainScale varchar null
	, PainPlanOfCareNotes varchar null
	, PainIntensityValueMeasuredThisVisitDate_Int int null
	, VisitLocation varchar (255) null
	, DisplayProviderName varchar (255) null
);
