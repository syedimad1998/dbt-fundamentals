CREATE TABLE LBQ.OCM_5(
	Division varchar (100) not null
	, TreatmentYear int null
	, TreatmentQuarter int null
	, ReportingPeriodStartDateInclusive date not null
	, ReportingPeriodEndDateInclusive date not null
	, MpiId int not null
	, FirstName varchar (100) null
	, LastName varchar (100) null
	, Gender varchar (100) null
	, AgeAtTimeOfVisit int null
	, EpisodeRelated_OCMCancerDx varchar null
	, EpisodeRelated_OCMCancerDxStartDate date null
	, EpisodeRelated_EpisodeStartDate date null
	, EpisodeRelated_EpisodeEndDate date null
	, VisitDate date null
	, VisitCPTCode varchar null
	, VisitProcedureOccurrenceId int null
	, ProviderId int null
	, ProviderMpiId int null
	, ProviderName varchar (255) null
	, DepressionMeasuredUsingAllowedTestThisDay boolean not null
	, DepressionTest_ProcedureOccurrenceId int null
	, DepressionTest_ProcedureSourceValue varchar null
	, DepressionTest_MeasurementSourceValue varchar null
	, DepressionTest_MeasureRawValue varchar null
	, DepressionTest_TestThatWasIdentified varchar (100) null
	, DepressionTest_IsDepressed int null
	, DepressionDiagnosis_PresentPriorToVisitThatIncludesVisit boolean not null
	, DepressionrDiagnosis_DiagnosisDate date null
	, DepressionDiagnosis_SourceValue varchar null
	, BiPolarDiagnosis_PresentPriorToVisitThatIncludesVisit boolean not null
	, BiPolarDiagnosis_DiagnosisDate date null
	, BiPolarDiagnosis_SourceValue varchar null
	, MedicationPrescribed_DidThisOccur boolean not null
	, MedicationPrescribed_PrescriptionDate date null
	, MedicationPrescribed_DrugExposureId int null
	, MedicationPrescribed_SourceValue varchar null
	, ProviderDepressionFollowup_DidThisOccur boolean not null
	, ProviderDepressionFollowup_FollowupDate date null
	, ProviderDepressionFollowup_FollowupSource varchar (9) null
	, ProviderDepressionFollowup_FollowupSourceKey int null
	, ProviderDepressionFollowup_FollowupSourceValue varchar null
	, ProviderDepressionReferral_DidThisOccur boolean not null
	, ProviderDepressionReferral_ReferralDate date null
	, ProviderDepressionReferral_FollowupSource varchar (9) null
	, ProviderDepressionReferral_FollowupSourceKey int null
	, ProviderDepressionReferral_FollowupSourceValue varchar null
	, PatientFollowupRefusal_DidThisOccur boolean not null
	, PatientFollowupRefusal_RefusalDate date null
	, PatientFollowupRefusal_RefusalSource varchar (100) null
	, PatientFollowupRefusal_RefusalSourceSubType varchar (18) null
	, PatientFollowupRefusal_RefusalSourceKey int null
	, PatientFollowupRefusal_RefusalSourceValue varchar null
	, IsLastDepressionScreeningThisReportingPeriod int not null
	, PatientMrn varchar (100) null
	, ProviderNpiId varchar (100) null
	, RecordInsertionDate datetime (8) not null
	, CalculationFlag_Met_DenominatorPopulation boolean null
	, CalculationFlag_Met_DenominatorExclusion boolean null
	, CalculationFlag_Met_NumeratorPopulation boolean null
	, CalculationFlag_Met_DenominatorException boolean null
	, CalculationFlag_Met_EpisodeRelated boolean null
	, TIN varchar (100) null
	, ProviderLocation varchar (255) null
	, DepressionTest_LastDepressionScreenDate date null
	, DepressionTest_MeasurementValueDetermined varchar (50) null
	, PayerDuringVisit_Payer varchar null
	, NextScheduledVisit date null
	, VisitLocation varchar (255) null
	, DisplayProviderName varchar (255) null
);
