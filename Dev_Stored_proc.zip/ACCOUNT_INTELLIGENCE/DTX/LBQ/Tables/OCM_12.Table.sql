CREATE TABLE LBQ.OCM_12(
	Division varchar (100) not null
	, TreatmentYear int not null
	, TreatmentQuarter int not null
	, ReportingPeriodStartDateInclusive date not null
	, ReportingPeriodEndDateInclusive date not null
	, MpiId int not null
	, FirstName varchar (100) null
	, LastName varchar (100) null
	, Gender varchar null
	, EpisodeRelated_OCMCancerDx varchar null
	, EpisodeRelated_OCMCancerDxStartDate date null
	, EpisodeRelated_EpisodeStartDate date null
	, EpisodeRelated_EpisodeEndDate date null
	, VisitDate date not null
	, VisitCPTCode varchar null
	, VisitProcedureOccurrenceId int null
	, ProviderId int null
	, ProviderMpiId int null
	, ProviderName varchar (255) null
	, PayerDuringVisit_Payer varchar null
	, PayerDuringVisit_EffectiveDate date null
	, PayerDuringVisit_InactiveDate date null
	, PayerDuringVisit_PrimaryIndicator varchar null
	, MostRecentPayer_Payer varchar null
	, MostRecentPayer_EffectiveDate date null
	, MostRecentPayer_InactiveDate date null
	, MostRecentPayer_PrimaryIndicator varchar null
	, MedicationReview_DidThisOccur boolean not null
	, MedicationReview_ReviewDate date null
	, MedicationReview_SourceLocation varchar (100) null
	, MedicationReview_SourceKey int null
	, MedicationReview_SourceValue varchar null
	, ExceptionMedicationReview_DidThisOccur boolean not null
	, ExceptionMedicationReview_ReviewDate date null
	, ExceptionMedicationReview_SourceLocation varchar (100) null
	, ExceptionMedicationReview_SourceKey int null
	, ExceptionMedicationReview_SourceValue varchar null
	, PatientMrn varchar (100) null
	, ProviderNpiId varchar (100) null
	, RecordInsertionDate datetime (8) not null
	, CalculationFlag_Met_DenominatorPopulation boolean not null
	, CalculationFlag_Met_DenominatorExclusion boolean not null
	, CalculationFlag_Met_NumeratorPopulation boolean not null
	, CalculationFlag_Met_DenominatorException boolean not null
	, CalculationFlag_Met_EpisodeRelated boolean not null
	, TIN varchar (100) null
);
