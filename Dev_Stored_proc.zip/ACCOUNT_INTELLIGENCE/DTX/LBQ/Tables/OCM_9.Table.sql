CREATE TABLE LBQ.OCM_9(
	Division varchar (100) not null
	, TreatmentYear int null
	, TreatmentQuarter int null
	, ReportingPeriodStartDateInclusive date not null
	, ReportingPeriodEndDateInclusive date not null
	, MpiId int not null
	, FirstName varchar (100) null
	, LastName varchar (100) null
	, Gender varchar null
	, EpisodeRelated_OCMCancerDx varchar null
	, EpisodeRelated_OCMCancerDxStartDate date null
	, EpisodeRelated_EpisodeStartDate date null
	, EpisodeRelated_EpisodeEndDate date null
	, CancerDiagnosisDate date null
	, CancerDiagnosis varchar null
	, ProviderId int null
	, ProviderMpiId int null
	, ProviderName varchar (255) null
	, PayerDuringVisit_Payer varchar null
	, PayerDuringVisit_EffectiveDate date null
	, PayerDuringVisit_InactiveDate date null
	, PayerDuringVisit_PrimaryIndicator varchar null
	, MostRecentPayer_Payer varchar null
	, MostRecentPayer_EffectiveDate date null
	, MostRecentPayer_InactiveDate date null
	, MostRecentPayer_PrimaryIndicator varchar null
	, Flag_NotInDenominatorBecauseNotFemale boolean null
	, Flag_NotInDenominatorBecauseOfAge boolean null
	, AgeAtCancerDiagnosis int null
	, Flag_NotInDenominatorBecauseNotFirstOrOnlyCancerDiagnosis boolean null
	, CancerDiagnosis_BreastCancerSourceLocation varchar (100) not null
	, CancerDiagnosis_BreastCancerSourceLocationKey int null
	, CancerDiagnosis_BreastCancerConditionStartDate date null
	, CancerDiagnosis_BreastCancerConditionEndDate date null
	, CancerDiagnosis_BreastCancerSourceValue varchar null
	, CancerDiagnosis_FirstCancerDiagnosisSourceLocation varchar (100) not null
	, CancerDiagnosis_FirstCancerDiagnosisSourceLocationKey int null
	, CancerDiagnosis_FirstCancerDiagnosisConditionStartDate date null
	, CancerDiagnosis_FirstCancerDiagnosisConditionEndDate date null
	, CancerDiagnosis_FirstCancerDiagnosisSourceValue varchar null
	, Flag_NotInDenominatorBecauseDidNotHaveSurgery boolean null
	, SurgeryData_EventDate date null
	, SurgeryData_SourceLocation varchar (100) null
	, SurgeryData_SourceLocationKey int null
	, SurgeryData_SourceValue varchar null
	, Flag_NotInDenominatorBecauseNotEpithilialMalignancy boolean null
	, EpithelialMalignancy_EventDate date null
	, EpithelialMalignancy_SourceLocation varchar (100) null
	, EpithelialMalignancy_SourceLocationKey int null
	, EpithelialMalignancy_SourceValue varchar null
	, Flag_NotInDenominatorBecauseBehaviorCodeIsNotInvasive boolean null
	, BehaviorInvasive_EventDate date null
	, BehaviorInvasive_SourceLocation varchar (100) null
	, BehaviorInvasive_SourceLocationKey int null
	, BehaviorInvasive_SourceValue varchar null
	, Flag_NotInDenominatorBecauseInappropriateCancerSTGTNMValues boolean null
	, InappropriateCancerStgTNMValues_EventDate date null
	, InappropriateCancerStgTNMValues_SourceLocation varchar (100) null
	, InappropriateCancerStgTNMValues_SourceLocationKey int null
	, InappropriateCancerStgTNMValues_SourceValue varchar null
	, Flag_NotInDenominatorBecausePositiveOrUnknownEstrogenReceptor boolean null
	, EstrogenReceptorTest_EventDate date null
	, EstrogenReceptorTest_SourceLocation varchar (100) null
	, EstrogenReceptorTest_SourceLocationKey int null
	, EstrogenReceptorTest_SourceValue varchar null
	, Flag_NotInDenominatorBecausePositiveOrUnknownProgesteroneReceptor boolean null
	, ProgesteroneReceptorTest_EventDate date null
	, ProgesteroneReceptorTest_SourceLocation varchar (100) null
	, ProgesteroneReceptorTest_SourceLocationKey int null
	, ProgesteroneReceptorTest_SourceValue varchar null
	, Flag_NotInDenominatorBecauseTreatmentHandledFullyOutsideReportingPractice boolean null
	, Exclusion_IsExcludedBecauseOfPhyllodeTumor boolean null
	, PhyllodeTumorData_EventDate date null
	, PhyllodeTumorData_SourceLocation varchar (100) null
	, PhyllodeTumorData_SourceLocationKey int null
	, PhyllodeTumorData_SourceValue varchar null
	, Exclusion_IsExcludedBecauseMetastaticDiseaseStageIV boolean null
	, Stage4MetastaticDisease_EventDate date null
	, Stage4MetastaticDisease_SourceLocation varchar (100) null
	, Stage4MetastaticDisease_SourceLocationKey int null
	, Stage4MetastaticDisease_SourceValue varchar null
	, Exclusion_IsExcludedBecauseInSituDisease boolean null
	, InSituDisease_EventDate date null
	, InSituDisease_SourceLocation varchar (100) null
	, InSituDisease_SourceLocationKey int null
	, InSituDisease_SourceValue varchar null
	, Exclusion_IsExcludedBecauseTheyDiedWithinFourMonthsOfDiagnosis boolean null
	, DateOfDeath date null
	, Exclusion_IsExcludedBecauseParticipatingInClinicalTrialThatCoversPartOfReportingPeriod boolean null
	, ClinicalTrialParticipant_EventDateStart date null
	, ClinicalTrialParticipant_EventDateEnd date null
	, ClinicalTrialParticipant_SourceLocation varchar (100) null
	, ClinicalTrialParticipant_SourceLocationKey int null
	, ClinicalTrialParticipant_SourceValue varchar null
	, Numerator_Path1_Her2Neg_CombinationChemoAdminsteredWithin120days boolean null
	, Numerator_Path2_Her2Neg_ChemoRecommendedWithin120days boolean null
	, Numerator_Path3_Her2Pos_ChemoAdministeredAndImmunotherapyAdministerd boolean null
	, Numerator_Path4_Her2Pos_ChemoAdministeredAndImmunotherapyRecommended boolean null
	, Her2TestResults_IhcMeasurementDate date null
	, Her2TestResults_IhcSourceLocation varchar (100) null
	, Her2TestResults_IhcSourceKey int null
	, Her2TestResults_IhcSourceValue varchar null
	, Her2TestResults_FishMeasurementDate date null
	, Her2TestResults_FishSourceLocation varchar (100) null
	, Her2TestResults_FishSourceKey int null
	, Her2TestResults_FishSourceValue varchar null
	, Her2TestResults_IhcValue varchar null
	, Her2TestResults_FishValue varchar null
	, Her2TestResults_IhcTestNotedAsPositive boolean null
	, Her2TestResults_FishTestNotedAsPositive boolean null
	, Her2TestResults_CombinedResultNotedAsWeaklyPositive boolean null
	, GivenChemotherapyTreatment_EventDate date null
	, GivenChemotherapyTreatment_SourceLocation varchar (100) null
	, GivenChemotherapyTreatment_SourceLocationKey int null
	, GivenChemotherapyTreatment_SourceValue varchar null
	, RecommendedChemotherapyTreatment_EventDate date null
	, RecommendedChemotherapyTreatment_SourceLocation varchar (100) null
	, RecommendedChemotherapyTreatment_SourceLocationKey int null
	, RecommendedChemotherapyTreatment_SourceValue varchar null
	, ImmunotherapyTreatment_EventDate date null
	, ImmunotherapyTreatment_SourceLocation varchar (100) null
	, ImmunotherapyTreatment_SourceLocationKey int null
	, ImmunotherapyTreatment_SourceValue varchar null
	, ImmunotherapyTreatment_WasAdministered boolean null
	, Mrn varchar (100) null
	, ProviderNpiId varchar (100) null
	, RecordInsertionDate datetime (8) not null
	, CalculationFlag_Met_DenominatorPopulation boolean null
	, CalculationFlag_Met_DenominatorExclusion boolean null
	, CalculationFlag_Met_NumeratorPopulation boolean null
	, CalculationFlag_Met_DenominatorException boolean null
	, CalculationFlag_Met_EpisodeRelated boolean null
	, TIN varchar (100) null
);
