CREATE OR REPLACE SECURE VIEW PQDataWarehouse_WithDeathInformation.Control_CombinedDrugMatch
as
	select 
		MatchCode
		, MatchType
		, GenericName
		, NdcProductId
		, NdcId
		, DrugCategory
		, DrugSubCategory
		, Priority   -- ExpertDetermination_DateOfDeathView_2019-10-18
		, BrandName    -- ExpertDetermination_DateOfDeathView_2019-10-18
	from
		CalculatedSet.Control_CombinedDrugMatch
	;