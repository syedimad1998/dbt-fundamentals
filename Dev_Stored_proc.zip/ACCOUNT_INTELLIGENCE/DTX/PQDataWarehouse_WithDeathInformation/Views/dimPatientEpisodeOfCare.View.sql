CREATE OR REPLACE SECURE VIEW PQDataWarehouse_WithDeathInformation.dimPatientEpisodeOfCare
AS
	SELECT 
		care.RecordInsertionDate		-- Expert Determination - Death View - 2020-08-14
		,care.MpiId						-- Expert Determination - Death View - 2020-08-14
		,care.RecordValidFromDate		-- Expert Determination - Death View - 2020-08-14
		,care.RecordValidToDate			-- Expert Determination - Death View - 2020-08-14
		,care.EpisodeStartDate			-- Expert Determination - Death View - 2020-08-14
		,care.EpisodeEndDate			-- Expert Determination - Death View - 2020-08-14
		,care.EpisodeNumber				-- Expert Determination - Death View - 2020-08-14
		,care.RecordSourceIdentifier	-- Expert Determination - Death View - 2021-02-02
		,care.IsCMS						-- Expert Determination - Death View - 2021-02-08
	FROM
		CalculatedSet.dimPatientEpisodeOfCare AS care
		INNER JOIN PQDataWarehouse_AncillaryTables.PQDataWarehouseWithDeathInformation_AllowedDivision AS ad
			ON ad.Division = care.Division
	;