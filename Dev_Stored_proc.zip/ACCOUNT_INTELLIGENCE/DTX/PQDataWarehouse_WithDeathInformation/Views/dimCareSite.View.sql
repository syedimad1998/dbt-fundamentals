CREATE OR REPLACE SECURE VIEW PQDataWarehouse_WithDeathInformation.dimCareSite
AS
SELECT
	  RecordInsertionDate
	, CareSiteIsConfirmedByDivision
	, RecordSourceIdentifier
FROM
		CalculatedSet.dimCareSite dcs
        INNER JOIN PQDataWarehouse_AncillaryTables.PQDataWarehouseWithDeathInformation_AllowedDivision ad
			ON ad.Division = dcs.Division		
	;