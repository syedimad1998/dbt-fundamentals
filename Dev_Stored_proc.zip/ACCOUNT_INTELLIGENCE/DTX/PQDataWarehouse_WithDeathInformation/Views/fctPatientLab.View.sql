CREATE OR REPLACE SECURE VIEW PQDataWarehouse_WithDeathInformation.fctPatientLab
as
	select 
		RecordInsertionDate
		, MpiId
		, TestDate
		, TestName
		, TestConceptId
		, ValueAsInt
		, ValueAsFloat
		, ValueAsString
		, UnitValue -- Cleaned - https://jira.integraconnect.com:8443/browse/PQ-6366
		, MatchTerm
		-- Not Included, unnecessary and require a ticket to clean of free-text before we can use it. NO ROI.  , RawData_Source
		-- Not Included, unnecessary and require a ticket to clean of free-text before we can use it. NO ROI.  , RawData_Value
		, NormalRangeLow
		, NormalRangeHigh
		, SourceLocation
		, case 
				when collate(GenomicPanelTested, 'en-ci') in ('DNA - NGS', 'DNA - Sanger', 'DNA - FISH', 'DNA - Other or Unknown', 'Protein - IHC', 'Protein - Other or Unknown', 'RNA - PCR', 'RNA - RNA-Seq', 'RNA - Other', 'Other', 'Unknown') then GenomicPanelTested
				when GenomicPanelTested is null then 'Unknown'
				else 'Other'
			end as GenomicPanelTested --  ExpertDetermination_DateOfDeathView_2020-03-02  - we are aware that the length tested and the values are in conflict, we are falling to length as that is more restrictive.
		, case
				when cast(null as varchar(20)) in ('Lung', 'Regional Lymph Node', 'Regional Site', 'Distant Site', 'Unknown') then cast(null as varchar(20))
				else cast(null as varchar(20))
			end as SpecimenSite --  ExpertDetermination_DateOfDeathView_2020-03-02  - we are aware that the length tested and the values are in conflict, we are falling to length as that is more restrictive.
		, case
				when collate(fpl.SpecimenCollectionMethod, 'en-ci') in ('Buccal Swab/Saliva', 'Fine needle aspirate (FNA)', 'Image-guided biopsy', 'Other', 'Surgery', 'Unknown') then fpl.SpecimenCollectionMethod
				when fpl.SpecimenCollectionMethod IS NOT NULL then 'Other'
				else cast(null as varchar(10))
			end as SpecimenCollectionMethod --  ExpertDetermination_DateOfDeathView_2020-03-02
		, RecordSourceIdentifier --  ExpertDetermination_DateOfDeathView_2020-03-02
		, ResultDate --  ExpertDetermination_DateOfDeathView_2020-03-02
		, cast(null as varchar(20)) as TestingMethod -- Expert Determination - Death View - 20200623 
		, SampleType
		, ServiceCodeDescriptionId -- Expert Determination - Death View - 20200814 
		, SpecimenCollectionDate  -- Expert Determination - Death View - 20210627
	from 
		CalculatedSet.fctPatientLab fpl
		INNER JOIN PQDataWarehouse_AncillaryTables.PQDataWarehouseWithDeathInformation_AllowedDivision ad
			ON ad.Division = fpl.Division
	;