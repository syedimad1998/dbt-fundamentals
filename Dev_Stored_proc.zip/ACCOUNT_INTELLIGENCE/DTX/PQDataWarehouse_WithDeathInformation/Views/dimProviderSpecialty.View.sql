CREATE OR REPLACE SECURE VIEW PQDataWarehouse_WithDeathInformation.dimProviderSpecialty
as
	select  
		RecordInsertionDate
		, SpecialtyNumber
		, case when TaxonomyCode ilike '%Naprapath%' or TaxonomyCode ilike '%Poetry%' then 'Other' else TaxonomyCode end as TaxonomyCode
		, case when Specialty ilike '%Naprapath%' or Specialty ilike '%Poetry%' then 'Other' else Specialty end as Specialty
		, IndicatesSpecialtyInRadiationOncology
		, IndicatesSpecialtyInHematologyOncology
		, IndicatesSpecialtyInMedicalOncology
		, IndicatesSpecialtyInUrology
		, IndicatesSpecialtyInAdvancedPracticePractitioner
		, case when ProviderTypeDescription ilike '%Naprapath%' or ProviderTypeDescription ilike '%Poetry%' then 'Other' else ProviderTypeDescription end as ProviderTypeDescription
		, case when ProviderTaxonomyDescription ilike '%Naprapath%' or ProviderTaxonomyDescription ilike '%Poetry%' then 'Other' else ProviderTaxonomyDescription end as ProviderTaxonomyDescription
		, case when ExtendedProviderTaxonomyDescription ilike '%Naprapath%' or ExtendedProviderTaxonomyDescription ilike '%Poetry%' then 'Other' else ExtendedProviderTaxonomyDescription end as ExtendedProviderTaxonomyDescription
		, RecordSourceIdentifier	-- ExpertDetermination_DateOfDeathView_2020-08-26
	from
		CalculatedSet.dimProviderSpecialty dps
		INNER JOIN PQDataWarehouse_AncillaryTables.PQDataWarehouseWithDeathInformation_AllowedDivision ad
			ON ad.Division = dps.Division
	where 
		not (
				concat(coalesce(ProviderTypeDescription, ''), coalesce(ProviderTaxonomyDescription, ''), coalesce(ExtendedProviderTaxonomyDescription, ''), coalesce(Specialty, ''), coalesce(TaxonomyCode, ''), '') ilike '%Poetry%'			-- PQ-11580
				or concat(coalesce(ProviderTypeDescription, ''), coalesce(ProviderTaxonomyDescription, ''), coalesce(ExtendedProviderTaxonomyDescription, ''), coalesce(Specialty, ''), coalesce(TaxonomyCode, ''),'') ilike '%Naprapath%'		-- PQ-11580
			)
	;