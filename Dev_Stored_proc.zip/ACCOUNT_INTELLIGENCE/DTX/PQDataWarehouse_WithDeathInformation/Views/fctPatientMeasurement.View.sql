CREATE OR REPLACE SECURE VIEW PQDataWarehouse_WithDeathInformation.fctPatientMeasurement
as
	select                                                        
		  RecordInsertionDate        -- ExpertDetermination_DateOfDeathView_20200428
		, MpiId                              -- ExpertDetermination_DateOfDeathView_20200428
		, MeasurementDate                 -- ExpertDetermination_DateOfDeathView_20200428
		, MeasurementCategory      -- ExpertDetermination_DateOfDeathView_20200428
		, AnatomicSiteLocation     -- ExpertDetermination_DateOfDeathView_20200428
		, ObservationMethod        -- ExpertDetermination_DateOfDeathView_20200428
		, MeasurementClass         -- ExpertDetermination_DateOfDeathView_20200428
		, ValueAsString              -- ExpertDetermination_DateOfDeathView_20200428
		, Unit                     -- ExpertDetermination_DateOfDeathView_20200428
		, ValueAsInt                         -- ExpertDetermination_DateOfDeathView_20200428
		, ValueAsFloat                     -- ExpertDetermination_DateOfDeathView_20200428
		, RecordSourceIdentifier     -- ExpertDetermination_DateOfDeathView_20200428
	from
		CalculatedSet.fctPatientMeasurement fpm
		INNER JOIN PQDataWarehouse_AncillaryTables.PQDataWarehouseWithDeathInformation_AllowedDivision ad
			ON ad.Division = fpm.Division
	;