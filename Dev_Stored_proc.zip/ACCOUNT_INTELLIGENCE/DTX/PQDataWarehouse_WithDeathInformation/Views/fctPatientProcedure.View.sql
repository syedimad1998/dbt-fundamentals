CREATE OR REPLACE SECURE VIEW PQDataWarehouse_WithDeathInformation.fctPatientProcedure
as
	select 
		  RecordInsertionDate
		, MpiId
		, DateOfEvent
		, ProcedureName
		, ProcedureSourceCode
		, ProcedureSourceCodeName
		, ProcedureSourceCodeType
		, ValueAsString -- ExpertDetermination_DateOfDeathView_2019-10-18
		, DateOfEventEnd                   		-- ExpertDetermination_DateOfDeathView_20200428
		, PrimaryAnatomicSiteLocation      -- ExpertDetermination_DateOfDeathView_20200428
		, SecondaryAnatomicSiteLocation    -- ExpertDetermination_DateOfDeathView_20200428
		, PrimaryUnit                      -- ExpertDetermination_DateOfDeathView_20200428
		, PrimaryValueAsInt                -- ExpertDetermination_DateOfDeathView_20200428
		, PrimaryValueAsFloat              -- ExpertDetermination_DateOfDeathView_20200428
		, SecondaryUnit                    -- ExpertDetermination_DateOfDeathView_20200428
		, SecondaryValueAsInt              -- ExpertDetermination_DateOfDeathView_20200428
		, SecondaryValueAsFloat            -- ExpertDetermination_DateOfDeathView_20200428
		, RecordSourceIdentifier           -- ExpertDetermination_DateOfDeathView_20200428
		, cast(null as varchar(50)) as ProcedureObjective -- Expert Determination - Death - 20200623
		, CostId						   -- ExpertDetermination_DateOfDeathView_2020814
		, GeneralizedProcedureCategory	   -- ExpertDetermination_DateOfDeathView_2020814
		, ServiceCodeDescriptionId         -- ExpertDetermination_DateOfDeathView_2020814
	from 
		CalculatedSet.fctPatientProcedure fp
		INNER JOIN PQDataWarehouse_AncillaryTables.PQDataWarehouseWithDeathInformation_AllowedDivision ad
			ON ad.Division = fp.Division
	;