CREATE OR REPLACE SECURE VIEW PQDataWarehouse_WithDeathInformation.dimPatientCancerStaging
as
	select 
		RecordInsertionDate
		, MpiId
		-- Not including, dirty field, not enough roi - , ConditionSourceValueId
		, ConditionSourceValue
		, StagingId
		, StagingDate
		, CancerStage
		, CancerTValue
		, CancerNValue
		, CancerMValue
		, CancerGValue
		, CancerHistology
		-- Not including, dirty field, not enough roi -  CancerCritDescr
		, CancerStageMajorCategory
		, CancerStageMinorCategory -- ExpertDetermination_DateOfDeathView_2019-10-18
		, RecordSourceIdentifier   -- ExpertDetermination_DateOfDeathView_2020-03-02
	from
		CalculatedSet.dimPatientCancerStaging dpcs
		INNER JOIN PQDataWarehouse_AncillaryTables.PQDataWarehouseWithDeathInformation_AllowedDivision ad
           ON dpcs.Division = ad.Division
	;