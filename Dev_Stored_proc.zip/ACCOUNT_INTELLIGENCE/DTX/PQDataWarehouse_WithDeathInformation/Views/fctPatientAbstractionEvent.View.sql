CREATE OR REPLACE SECURE VIEW PQDataWarehouse_WithDeathInformation.fctPatientAbstractionEvent
as
	select                                     -- ExpertDetermination_DateOfDeathView_2020-03-02
		  RecordInsertionDate                  -- ExpertDetermination_DateOfDeathView_2020-03-02
		, MpiId                                -- ExpertDetermination_DateOfDeathView_2020-03-02
		, EarliestAbstractionRelatedDate       -- ExpertDetermination_DateOfDeathView_2020-03-02
		, LastAbstractionRelatedDate           -- ExpertDetermination_DateOfDeathView_2020-03-02
        , LastAbstractionCompletionDate		   -- ExpertDetermination_DateOfDeathView_20200428
        , NumberOfTimesAbstracted			   -- ExpertDetermination_DateOfDeathView_20200428
        , LastAbstractionAbandonDate		   -- ExpertDetermination_DateOfDeathView_20200428
        , LastAbstractionAbandonReason		   -- ExpertDetermination_DateOfDeathView_20200428
	from
		CalculatedSet.fctPatientAbstractionEvent ae
        INNER JOIN PQDataWarehouse_AncillaryTables.PQDataWarehouseWithDeathInformation_AllowedDivision ad
			ON ad.Division = ae.Division
	;