CREATE OR REPLACE SECURE VIEW PQDataWarehouse_WithDeathInformation.fctPatientSocialHistory
as
	select 
		RecordInsertionDate
		, MpiId
		, SocialAttributeName
		, NormalizedValue
		, SocialAttributeAnswerMinDate
		, SocialAttributeAnswerMaxDate
		, RecordSourceIdentifier              -- ExpertDetermination_DateOfDeathView_2020-08-26
	from
		CalculatedSet.fctPatientSocialHistory fps
		INNER JOIN PQDataWarehouse_AncillaryTables.PQDataWarehouseWithDeathInformation_AllowedDivision ad
			ON ad.Division = fps.Division
	;