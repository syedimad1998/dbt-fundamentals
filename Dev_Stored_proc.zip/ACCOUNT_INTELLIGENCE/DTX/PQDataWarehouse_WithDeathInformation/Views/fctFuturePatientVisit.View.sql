CREATE OR REPLACE SECURE VIEW PQDataWarehouse_WithDeathInformation.fctFuturePatientVisit
as
	select                                -- ExpertDetermination_DateOfDeathView_2019-10-18
		RecordInsertionDate               -- ExpertDetermination_DateOfDeathView_2019-10-18
		, VisitDefinitionCriteriaId       -- ExpertDetermination_DateOfDeathView_2019-10-18
		, MpiId                           -- ExpertDetermination_DateOfDeathView_2019-10-18
		, Year                          -- ExpertDetermination_DateOfDeathView_2019-10-18
		, Quarter                         -- ExpertDetermination_DateOfDeathView_2019-10-18
		, TotalVisits                     -- ExpertDetermination_DateOfDeathView_2019-10-18
		, RecordSourceIdentifier		  -- ExpertDetermination_DateOfDeathView_2020-08-26
	from 
		CalculatedSet.fctFuturePatientVisit fpv
	    INNER JOIN PQDataWarehouse_AncillaryTables.PQDataWarehouseWithDeathInformation_AllowedDivision ad
			ON ad.Division = fpv.Division
	;