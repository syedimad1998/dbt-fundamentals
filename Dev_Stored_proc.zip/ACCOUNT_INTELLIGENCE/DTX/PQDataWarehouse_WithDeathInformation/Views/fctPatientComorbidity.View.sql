CREATE OR REPLACE SECURE VIEW PQDataWarehouse_WithDeathInformation.fctPatientComorbidity
as
	select 
		RecordInsertionDate
		, MpiId
		, ConditionDescription
		, SampleFoundIcdCode
		, ConditionStartDate
		, ConditionEndDate
		, ComorbidityDefinitionSource
		, ComorbidityDefaultVisibleInUserFacingDashboards
		, RecordSourceIdentifier
	from
		CalculatedSet.fctPatientComorbidity fpc
		INNER JOIN PQDataWarehouse_AncillaryTables.PQDataWarehouseWithDeathInformation_AllowedDivision ad
			ON ad.Division = fpc.Division
	;