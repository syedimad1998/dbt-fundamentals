CREATE OR REPLACE SECURE VIEW PQDataWarehouse_WithDeathInformation.dimProvider
as
	select 
		RecordInsertionDate
		, HasSpecialtyInRadiationOncology
		, HasSpecialtyInHematologyOncology
		, HasSpecialtyInMedicalOncology
		, HasSpecialtyInUrology
		, HasSpecialtyInAdvancedPracticePractitioner
		, case when PrimarySpecialty ilike '%Poetry%' or PrimarySpecialty ilike '%Naprapath%' then 'Other' else PrimarySpecialty end as PrimarySpecialty
		, case when NonFlaggedSpecialty ilike '%Poetry%' or NonFlaggedSpecialty ilike '%Naprapath%' then 'Other' else NonFlaggedSpecialty end as NonFlaggedSpecialty
		, case when AllSpecialty ilike '%Poetry%' or AllSpecialty ilike '%Naprapath%' then 'Other' else AllSpecialty end as AllSpecialty
		, GenderName
		, EpisodeRelatedScore_OCM1
		, EpisodeRelatedScore_OCM2
		, EpisodeRelatedScore_OCM3
		, EpisodeRelatedScore_OCM4a
		, EpisodeRelatedScore_OCM4b
		, EpisodeRelatedScore_OCM5
		, EpisodeRelatedScore_OCM8
		, EpisodeRelatedScore_OCM9
		, EpisodeRelatedScore_OCM10
		, EpisodeRelatedScore_OCM11
		, EpisodeRelatedScore_OCM12
		, EpisodeRelatedScore_OCM24
		, EpisodeRelatedScore_OCM30
		, IdentifyingDataProhibitedFromDisclosureToThirdParties -- ExpertDetermination_DateOfDeathView_2020-03-02
		, RecordSourceIdentifier              -- Expert Determination Death View 20200623
		, ProviderIsConfirmedByDivision       -- Expert Determination Death View 20200623
	from 
		CalculatedSet.dimProvider dp
		INNER JOIN PQDataWarehouse_AncillaryTables.PQDataWarehouseWithDeathInformation_AllowedDivision ad
			ON ad.Division = dp.Division
	;