CREATE OR REPLACE SECURE VIEW PQDataWarehouse_WithDeathInformation.dimPatientMetadata
AS
	SELECT 
		  dpmd.Mpiid			   -- ExpertDetermination_DateOfDeathView_2020-08-14
		, dpmd.MetadataDate		   -- ExpertDetermination_DateOfDeathView_2020-08-14
		, dpmd.MetadataSource	   -- ExpertDetermination_DateOfDeathView_2020-08-14
	FROM
		CalculatedSet.dimPatientMetaData dpmd
		INNER JOIN PQDataWarehouse_AncillaryTables.PQDataWarehouseWithDeathInformation_AllowedDivision ad
			ON dpmd.Division = ad.Division
	;