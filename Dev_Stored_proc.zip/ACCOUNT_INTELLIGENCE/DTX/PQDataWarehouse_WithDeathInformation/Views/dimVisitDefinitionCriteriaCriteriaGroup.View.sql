CREATE OR REPLACE SECURE VIEW PQDataWarehouse_WithDeathInformation.dimVisitDefinitionCriteriaCriteriaGroup
as
	select 
		VisitDefinitionCriteriaGroupId
		, VisitDefinitionCriteriaId
	from
		CalculatedSet.dimVisitDefinitionCriteriaCriteriaGroup
	;