CREATE OR REPLACE SECURE VIEW PQDataWarehouse_WithDeathInformation.dimPatientVisit
as
	select 
		RecordInsertionDate
		, MpiId
		, VisitDate
		, VisitDefinitionCriteriaId
		, TotalCharge
		, RecordSourceIdentifier
		, CostId
		, ServiceCodeDescriptionId -- Expert Determination - Death View - 20200814
	from
		CalculatedSet.dimPatientVisit dpv
		INNER JOIN PQDataWarehouse_AncillaryTables.PQDataWarehouseWithDeathInformation_AllowedDivision ad
			ON ad.Division = dpv.Division
     	;