CREATE OR REPLACE SECURE VIEW PQDataWarehouse_WithDeathInformation.Control_EquivalentIcd9And10Code
as
	select 
		  ICD9       -- Expert Determination Death View 20200826
		, ICD10      -- Expert Determination Death View 20200826
	from
		CalculatedSet.Control_EquivalentIcd9And10Code
	;