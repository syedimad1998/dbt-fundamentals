CREATE OR REPLACE SECURE VIEW PQDataWarehouse_WithDeathInformation.Control_LookupCode_Comorbidity
as
	select 
		GeneralComorbidityName                          -- Expert Determination Death View 20200623
		, CodeSystem                                    -- Expert Determination Death View 20200623
		, ConditionMatchCode_MajorCategory              -- Expert Determination Death View 20200623
		, ConditionMatchCode_FullCode                   -- Expert Determination Death View 20200623
		, TestDefinitionSource                          -- Expert Determination Death View 20200623
		, TestDefaultVisibleInUserFacingDashboards      -- Expert Determination Death View 20200623
	from
		CalculatedSet.Control_LookupCode_Comorbidity
	;