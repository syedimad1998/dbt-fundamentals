CREATE OR REPLACE SECURE VIEW PQDataWarehouse_WithDeathInformation.dimPatientCancer
as
	select                                              -- ExpertDetermination_DateOfDeathView_2019-10-18 
		  RecordInsertionDate                           -- ExpertDetermination_DateOfDeathView_2019-10-18 
		, MpiId                                         -- ExpertDetermination_DateOfDeathView_2019-10-18 
		, CodeType                                      -- ExpertDetermination_DateOfDeathView_2019-10-18 
		, CancerCode                                    -- ExpertDetermination_DateOfDeathView_2019-10-18 
		, CancerCodeMajorCategory                       -- ExpertDetermination_DateOfDeathView_2019-10-18 
		, DateInstanceOfCancerCode                      -- ExpertDetermination_DateOfDeathView_2019-10-18 
		, Control_CancerCodeToDescriptionMatchingId     -- ExpertDetermination_DateOfDeathView_2019-10-18 
		, RecordSourceIdentifier						-- ExpertDetermination_DateOfDeathView_2020-06-23
		, DateOfProgression								-- ExpertDetermination_DateOfDeathView_2021-02-08
	from 
		CalculatedSet.dimPatientCancer dpc
		INNER JOIN PQDataWarehouse_AncillaryTables.PQDataWarehouseWithDeathInformation_AllowedDivision ad
		ON dpc.Division = ad.Division	
	;