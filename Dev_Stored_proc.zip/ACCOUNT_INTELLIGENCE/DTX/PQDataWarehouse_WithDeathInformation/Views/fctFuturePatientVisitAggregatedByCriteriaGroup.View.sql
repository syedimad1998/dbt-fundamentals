CREATE OR REPLACE SECURE VIEW PQDataWarehouse_WithDeathInformation.fctFuturePatientVisitAggregatedByCriteriaGroup
as
	select 
		RecordInsertionDate                 -- ExpertDetermination_DateOfDeathView_2019-10-18
		, VisitDefinitionCriteriaGroupId    -- ExpertDetermination_DateOfDeathView_2019-10-18
		, MpiId                             -- ExpertDetermination_DateOfDeathView_2019-10-18
		, TotalVisits                       -- ExpertDetermination_DateOfDeathView_2019-10-18
		, RecordSourceIdentifier            -- ExpertDetermination_DateOfDeathView_2020-10-13
	from 
		CalculatedSet.fctFuturePatientVisitAggregatedByCriteriaGroup fpv
	    INNER JOIN PQDataWarehouse_AncillaryTables.PQDataWarehouseWithDeathInformation_AllowedDivision ad
			ON ad.Division = fpv.Division
	;