CREATE OR REPLACE SECURE VIEW PQDataWarehouse_WithDeathInformation.fctPatientVisitAggregatedByCriteriaGroup
as
	select 
		RecordInsertionDate
		, VisitDefinitionCriteriaGroupId
		, MpiId
		, TotalVisits
		, RecordSourceIdentifier     -- ExpertDetermination_DateOfDeathView_2020-10-13
	from
		CalculatedSet.fctPatientVisitAggregatedByCriteriaGroup fpv
		INNER JOIN PQDataWarehouse_AncillaryTables.PQDataWarehouseWithDeathInformation_AllowedDivision ad
			ON ad.Division = fpv.Division
	;