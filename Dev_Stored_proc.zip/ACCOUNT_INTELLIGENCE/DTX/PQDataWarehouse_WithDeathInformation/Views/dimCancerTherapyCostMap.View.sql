CREATE OR REPLACE SECURE VIEW PQDataWarehouse_WithDeathInformation.dimCancerTherapyCostMap
as
	select 
		MpiId
		, CostId
		, CancerTherapyHashId
	from
		CalculatedSet.dimCancerTherapyCostMap dcm
		INNER JOIN PQDataWarehouse_AncillaryTables.PQDataWarehouseWithDeathInformation_AllowedDivision ad
			on dcm.Division = ad.Division
	;