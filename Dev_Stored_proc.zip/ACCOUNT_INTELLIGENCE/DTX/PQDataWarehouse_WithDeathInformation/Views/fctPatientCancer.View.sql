CREATE OR REPLACE SECURE VIEW PQDataWarehouse_WithDeathInformation.fctPatientCancer
as
	select 
		RecordInsertionDate
		, MpiId
		, CodeType
		, CancerCode
		, CancerCodeMajorCategory
		, DateFirstInstanceOfCancerCode
		, DateLastInstanceOfCancerCode
		, ConditionConceptId
		, MinConditionStartDate
		, MaxConditionStartDate
		, MinConditionEndDate
		, MaxConditionEndDate
		, DescriptionMajorClassification
		, DescriptionMinorClassification
		, CancerPrimarySecondaryClassification
		, ExactLocation
		, GeneralLocation
		, case
				when cast(null as varchar(15)) in ('Right', 'Left', 'Bilateral', 'None', 'Unknown') then cast(null as varchar(15))
				else cast(null as varchar(15))
			end as Laterality -- ExpertDetermination_DateOfDeathView_2020-03-02 - Included even though data not available yet, with coding rules.
		, RecordSourceIdentifier
		, CancerCodeMajorFirstDiagnosisDate
	from 
		CalculatedSet.fctPatientCancer fpc
		INNER JOIN PQDataWarehouse_AncillaryTables.PQDataWarehouseWithDeathInformation_AllowedDivision ad
			ON ad.Division = fpc.Division
	;