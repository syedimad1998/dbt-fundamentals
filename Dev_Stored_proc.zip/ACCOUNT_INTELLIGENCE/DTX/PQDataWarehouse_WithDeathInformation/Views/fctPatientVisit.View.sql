CREATE OR REPLACE SECURE VIEW PQDataWarehouse_WithDeathInformation.fctPatientVisit
as
	select 
		RecordInsertionDate
		, VisitDefinitionCriteriaId
		, MpiId
		, Year
		, Quarter
		, TotalVisits
		, RecordSourceIdentifier    -- ExpertDetermination_DateOfDeathView_2020-08-26
	from 
		CalculatedSet.fctPatientVisit v
		INNER JOIN PQDataWarehouse_AncillaryTables.PQDataWarehouseWithDeathInformation_AllowedDivision ad
			ON ad.Division = v.Division
	;