CREATE OR REPLACE SECURE VIEW PQDataWarehouse_WithDeathInformation.Control_ServiceCodeDescription
AS
SELECT cscd.ServiceCodeDescriptionId
	, CASE WHEN collate(cscd.PlaceOfServiceName, 'en-ci') IN (
				'Indian Health Service (Free-standing Facility)'
				,'Indian Health Service (Provider-based Facility)'
				,'Tribal 638 (Free-standing Facility)'
				,'Tribal 638 (Provider-based Facility)'
				,'Prison/Correctional Facility'
				,'Military Treatment Facility')
			THEN 0 ELSE cscd.PlaceOfServiceCode END AS PlaceOfServiceCode
	, CASE WHEN collate(cscd.PlaceOfServiceName, 'en-ci') IN (
				'Indian Health Service (Free-standing Facility)'
				,'Indian Health Service (Provider-based Facility)'
				,'Tribal 638 (Free-standing Facility)'
				,'Tribal 638 (Provider-based Facility)'
				,'Prison/Correctional Facility'
				,'Military Treatment Facility')
			THEN 'Other Place of Service' ELSE cscd.PlaceOfServiceName END AS PlaceOfServiceName
	, cscd.PlaceOfServiceGeneralizedName
	, CASE WHEN collate(cscd.PlaceOfServiceName, 'en-ci') IN (
				'Indian Health Service (Free-standing Facility)'
				,'Indian Health Service (Provider-based Facility)'
				,'Tribal 638 (Free-standing Facility)'
				,'Tribal 638 (Provider-based Facility)'
				,'Prison/Correctional Facility'
				,'Military Treatment Facility')
			THEN 'Other Place of Service' ELSE cscd.PlaceOfServiceDescription END AS PlaceOfServiceDescription
FROM CalculatedSet.Control_ServiceCodeDescription cscd
;