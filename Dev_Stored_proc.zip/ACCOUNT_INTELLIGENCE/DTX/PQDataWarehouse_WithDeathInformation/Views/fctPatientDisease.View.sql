CREATE OR REPLACE SECURE VIEW PQDataWarehouse_WithDeathInformation.fctPatientDisease
as
	select
		RecordInsertionDate                -- ExpertDetermination_DateOfDeathView_2019-10-18
		, MpiId                            -- ExpertDetermination_DateOfDeathView_2019-10-18
		, CodeType                         -- ExpertDetermination_DateOfDeathView_2019-10-18
		, DiseaseCode                      -- ExpertDetermination_DateOfDeathView_2019-10-18
		, DiseaseCodeMajorCategory         -- ExpertDetermination_DateOfDeathView_2019-10-18
		, DateFirstInstanceOfDiseaseCode   -- ExpertDetermination_DateOfDeathView_2019-10-18
		, DateLastInstanceOfDiseaseCode    -- ExpertDetermination_DateOfDeathView_2019-10-18
		, ConditionConceptId               -- ExpertDetermination_DateOfDeathView_2019-10-18
		, MinConditionStartDate            -- ExpertDetermination_DateOfDeathView_2019-10-18
		, MaxConditionStartDate            -- ExpertDetermination_DateOfDeathView_2019-10-18
		, MinConditionEndDate              -- ExpertDetermination_DateOfDeathView_2019-10-18
		, MaxConditionEndDate              -- ExpertDetermination_DateOfDeathView_2019-10-18
		, DescriptionMajorClassification   -- ExpertDetermination_DateOfDeathView_2019-10-18
		, DescriptionMinorClassification   -- ExpertDetermination_DateOfDeathView_2019-10-18
		, RecordSourceIdentifier           -- ExpertDetermination_DateOfDeathView_2020-08-26
	from
		Calculatedset.fctPatientDisease fpd
		INNER JOIN PQDataWarehouse_AncillaryTables.PQDataWarehouseWithDeathInformation_AllowedDivision ad
			ON ad.Division = fpd.Division
	;