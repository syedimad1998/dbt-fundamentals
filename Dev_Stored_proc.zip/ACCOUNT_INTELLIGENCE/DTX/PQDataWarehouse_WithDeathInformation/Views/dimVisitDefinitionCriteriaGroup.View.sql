CREATE OR REPLACE SECURE VIEW PQDataWarehouse_WithDeathInformation.dimVisitDefinitionCriteriaGroup
as
	select 
		VisitDefinitionCriteriaGroupId
		, FriendlyName
		, FriendlyDescription
	from
		CalculatedSet.dimVisitDefinitionCriteriaGroup
	;