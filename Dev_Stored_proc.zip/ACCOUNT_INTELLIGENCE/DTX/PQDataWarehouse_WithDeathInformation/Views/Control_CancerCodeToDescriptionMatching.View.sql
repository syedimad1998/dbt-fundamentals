CREATE OR REPLACE SECURE VIEW PQDataWarehouse_WithDeathInformation.Control_CancerCodeToDescriptionMatching
as
	select
		CodeSystem
		, CancerMatchCode
		, DescriptionMajorClassification
		, DescriptionMinorClassification
		, CancerPrimarySecondaryClassification
		, ExactLocation
		, GeneralLocation
		, Control_CancerCodeToDescriptionMatchingId -- ExpertDetermination_DateOfDeathView_2019-10-18
	from
		CalculatedSet.Control_CancerCodeToDescriptionMatching
	;