CREATE OR REPLACE SECURE VIEW PQDataWarehouse_WithDeathInformation.Control_ProcedureCode
AS
	SELECT 
		Code										-- Expert Determination - Death View - 20210107
		,ProcedureName								-- Expert Determination - Death View - 20210107
		,ProcedureDescription						-- Expert Determination - Death View - 20210107
		,ProcedureSourceCodeType					-- Expert Determination - Death View - 20210107
		,GeneralizedProcedureCategory				-- Expert Determination - Death View - 20210107
	FROM
		CalculatedSet.Control_ProcedureCode
	;