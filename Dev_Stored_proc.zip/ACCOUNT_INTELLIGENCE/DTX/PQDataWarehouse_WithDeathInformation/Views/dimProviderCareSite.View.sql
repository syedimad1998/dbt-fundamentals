CREATE OR REPLACE SECURE VIEW PQDataWarehouse_WithDeathInformation.dimProviderCareSite
as
	select 		  
		RecordInsertionDate
		, RecordSourceIdentifier -- ExpertDetermination_DateOfDeathView_2020-03-02
	from
		CalculatedSet.dimProviderCareSite dpcs
        INNER JOIN PQDataWarehouse_AncillaryTables.PQDataWarehouseWithDeathInformation_AllowedDivision ad
			ON ad.Division = dpcs.Division
	;