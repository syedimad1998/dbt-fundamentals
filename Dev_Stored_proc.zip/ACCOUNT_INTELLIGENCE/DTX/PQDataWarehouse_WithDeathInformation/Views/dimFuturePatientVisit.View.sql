CREATE OR REPLACE SECURE VIEW PQDataWarehouse_WithDeathInformation.dimFuturePatientVisit
as
	select                                                                                                  -- ExpertDetermination_DateOfDeathView_2019-10-18
		RecordInsertionDate                                                                                 -- ExpertDetermination_DateOfDeathView_2019-10-18
		, MpiId	                                                                                            -- ExpertDetermination_DateOfDeathView_2019-10-18
		, dateadd(day, -2, dateadd(week, 1, date_trunc('week', VisitDate))) as VisitWeek					-- ExpertDetermination_DateOfDeathView_2019-10-18
		, VisitDate as VisitDay                                                                             -- ExpertDetermination_DateOfDeathView_2019-11-20 and ExpertDetermination_DateOfDeathView_2020-03-02
		, VisitDefinitionCriteriaId                                                                         -- ExpertDetermination_DateOfDeathView_2019-10-18
		, TotalCharge                                                                                       -- ExpertDetermination_DateOfDeathView_2019-10-18
		, RecordSourceIdentifier                                                                            -- ExpertDetermination_DateOfDeathView_2020-10-13
	from 
		CalculatedSet.dimFuturePatientVisit dfpv
		INNER JOIN PQDataWarehouse_AncillaryTables.PQDataWarehouseWithDeathInformation_AllowedDivision ad
			ON dfpv.Division = ad.Division
	;