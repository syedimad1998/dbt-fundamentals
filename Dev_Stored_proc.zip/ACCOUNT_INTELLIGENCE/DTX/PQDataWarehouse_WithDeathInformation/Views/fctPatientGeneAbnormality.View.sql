CREATE OR REPLACE SECURE VIEW PQDataWarehouse_WithDeathInformation.fctPatientGeneAbnormality
as
	select 		
		RecordInsertionDate
		, MpiId
		, TestDate
		, GeneticAbnormalityType
		, Gene
		, RawGene
		, GeneDefinition
		, AbnormalityFinding
		, IsCancerRelated
		, SourceLocation
		, RecordSourceIdentifier    --ExpertDetermination_DateOfDeathView_2020-07-16
		-- , Context - Impossible to clean of free text as it is, by design, free text.  Had to be removed.
		, GeneGranularity			  --ExpertDetermination_DateOfDeathView_2021-03-25
		, Mutation					  --ExpertDetermination_DateOfDeathView_2021-06-07	
		, RawMutation				  --ExpertDetermination_DateOfDeathView_2021-06-07
	from
		CalculatedSet.fctPatientGeneAbnormality fpg
		INNER JOIN PQDataWarehouse_AncillaryTables.PQDataWarehouseWithDeathInformation_AllowedDivision ad
			ON ad.Division = fpg.Division
	;