CREATE OR REPLACE SECURE VIEW PQDataWarehouse_WithDeathInformation.fctPatientVital
as
	select 
		RecordInsertionDate
		, MpiId
		, TestDate
		, TestName
		, ValueAsNumber
		, UnitValue
		, NormalRangeLow
		, NormalRangeHigh
		, cast('' as varchar(10)) as RecordSourceIdentifier  -- ExpertDetermination_DateOfDeathView_20200428
	from 
		CalculatedSet.fctPatientVital fpv
		INNER JOIN PQDataWarehouse_AncillaryTables.PQDataWarehouseWithDeathInformation_AllowedDivision ad
			ON ad.Division = fpv.Division
	;