CREATE OR REPLACE SECURE VIEW PQDataWarehouse_WithDeathInformation.dimPatientReferral
as	
		select 
			RecordInsertionDate
			,MpiId			
			,Direction
			,DateReferralWasGenerated
			,DateReferralWasActedOn
		    ,case when ReferToProviderSpecialty ilike '%Naprapath%' or ReferToProviderSpecialty ilike '%Poetry%' then 'Other' else ReferToProviderSpecialty end as ReferToProviderSpecialty
			,ReferDueToProblemCodeType
			,ReferDueToProblemCode
			,ReferDueToProblemDescription
			,ReferDueToProcedureCodeType
			,ReferDueToProcedureCode
			,ReferDuetoProcedureDescription	  
			,RecordSourceIdentifier			-- ExpertDetermination_DateOfDeathView_2020-10-13
	from 
		CalculatedSet.dimPatientReferral r
		INNER JOIN PQDataWarehouse_AncillaryTables.PQDataWarehouseWithDeathInformation_AllowedDivision ad
			ON r.Division = ad.Division
	;