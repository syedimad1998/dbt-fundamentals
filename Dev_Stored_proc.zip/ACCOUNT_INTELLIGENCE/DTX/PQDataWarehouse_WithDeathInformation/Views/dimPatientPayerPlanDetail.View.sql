CREATE OR REPLACE SECURE VIEW PQDataWarehouse_WithDeathInformation.dimPatientPayerPlanDetail
as
	select 
		RecordInsertionDate
		, MpiId
		, PayerPlanPeriodId
		, PayerPlanPeriodStartDate
		, PayerPlanPeriodEnddate
		, PayerPrimaryIndicator
		, DeductibleAmount
		-- , PayerName	   - We can't show as they violate the rules from expert, PayerCategory will abide by such rules.
		-- , PayerType	   - We can't show as they violate the rules from expert, PayerCategory will abide by such rules.
		, PayerCategory				-- ExpertDetermination_DateOfDeathView_2019-10-18
		, RecordSourceIdentifier	-- ExpertDetermination_DateOfDeathView_2020-08-26
	from
		calculatedset.dimPatientPayerPlanDetail dpd
		INNER JOIN PQDataWarehouse_AncillaryTables.PQDataWarehouseWithDeathInformation_AllowedDivision ad
			ON dpd.Division = ad.Division
	;