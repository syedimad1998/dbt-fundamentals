CREATE OR REPLACE SECURE VIEW PQDataWarehouse_WithDeathInformation.Control_DiagnosisCode
AS
	SELECT 
		  CodeSystem									   -- Expert Determination Death View 20210228
		, MatchCode										   -- Expert Determination Death View 20210228
		, DiagnosisName									   -- Expert Determination Death View 20210228
		, DescriptionMajorClassification				   -- Expert Determination Death View 20210228
		, DescriptionMinorClassification				   -- Expert Determination Death View 20210228
		, PrimarySecondaryClassification				   -- Expert Determination Death View 20210228
		, ExactLocation									   -- Expert Determination Death View 20210228
		, GeneralLocation								   -- Expert Determination Death View 20210228
		, TestDefinitionSource							   -- Expert Determination Death View 20210228
		, IsCancer										   -- Expert Determination Death View 20210228
		, IsDisease										   -- Expert Determination Death View 20210228
		, IsAdverseEvent								   -- Expert Determination Death View 20210228
		, IsComorbidity									   -- Expert Determination Death View 20210228
		, Control_CancerCodeToDescriptionMatchingId		   -- Expert Determination Death View 20210228
		, TestDefaultVisibleInUserFacingDashboards 		   -- Expert Determination Death View 20210228
	FROM 
		CalculatedSet.Control_DiagnosisCode
	;