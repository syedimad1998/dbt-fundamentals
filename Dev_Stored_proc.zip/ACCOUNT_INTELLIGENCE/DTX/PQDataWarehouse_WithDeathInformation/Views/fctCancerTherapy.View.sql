CREATE OR REPLACE SECURE VIEW PQDataWarehouse_WithDeathInformation.fctCancerTherapy
as
	select 
		RecordInsertionDate
		, MpiId
		, DrugGenericName
		, MatchCode
		, MatchType
		, SourceLocation
		, MatchLocation
		, DrugConceptId
		, DrugExposureStartDate
		, DrugExposureEndDate
		, DrugTypeConceptId
		-- , StopReason -- waiting for PQ-6842
		, Refills
		, Quantity
		, QuantityPerDay
		, DaysSupply
		-- Not including - very dirty column, can't include without cleansing of free text, very hard without roi.  , Sig
		, RouteConceptId
		, VaccineFlag
		, NDC
		-- Not including - very dirty column, can't include without cleansing of free text, very hard without roi. , DrugSourceValue
		, TherapyRoute -- cleaned via PQ-6522, in place of TherapySourceValue which was approved (without phi). - also ExpertDetermination_DateOfDeathView_2020-03-02
		, DoseUnitSourceValue -- cleaned via PQ-6364
		, QuantitySourceValue -- cleaned via PQ-6520
		, DoseSourceValue -- cleaned via PQ-6360
		, StrengthSourceValue -- cleaned via PQ-6365
		, SourceKey
		, HeightInMeters
		, WeightInKg
		, BMIFromChart
		, BSAFromChart
		, BMICalculated
		, BSACalculated
		, DosePerKg
		, DosePerMeterSquared
		, DoseSourceUnit -- cleaned via PQ-6364
		, DoseNormalizedUnit -- cleaned via PQ-6361
		, ChangeInDosePercentageSinceFirstAdministration
		, ChangeInDosePerKgSinceFirstAdministration
		, ChangeInDosePerMeterSquaredSinceFirstAdministration
		, NewAgent
		, DaysSinceLastAdministrationOfDrug
		, DrugCategory
		, DrugSubCategory
		, CostId					  -- ExpertDetermination_DateOfDeathView_2020-08-14
		, TotalCharge
		, CancerTherapyHashId
		, PrescribedBrand             -- ExpertDetermination_DateOfDeathView_2019-10-18
		, Classification         	  -- ExpertDetermination_DateOfDeathView_2020-03-02
		, RecordSourceIdentifier   	  -- ExpertDetermination_DateOfDeathView_2020-03-02
		, IntentToTreat
		, ServiceCodeDescriptionId	  -- ExpertDetermination_DateOfDeathView_2020-08-14
		, CASE 
			WHEN collate(TherapyForm, 'en-ci') IN (
					'capsule',
					'concentrate',
					'cream',
			        'for solution', 
					'for suspension', 
					'gel',
					'implant',
					'injectable',
					'injection',
					'solution',
					'spray', 
					'suspension',
					'system',
					'tablet',
					'vial'
				) THEN TherapyForm
		  ELSE
			NULL
		END AS TherapyForm			-- ExpertDetermination_DateOfDeathView_2021-06-27 - Only include TherapyForm's referenced in Therapy Form tab
		, CASE
			WHEN collate(Frequency, 'en-ci') IN ( 
				'daily - qd',
				'every other day - qod',
				'twice a day - bid',
				'three times a week - tiw' ,
				'four times a week - qiw', 
				'weekly - qw', 
				'monthly - qm', 
				'after meals - pc',
				'as needed - prn', 
				'at bedtime - hs', 
				'bi-monthly', 
				'bi-weekly', 
				'evening; after noon - pm', 
				'every 1 hour - q1h', 
				'every 1 to 2 hours - q1-2h',
				'every 12 hours - q12h', 
				'every 4 hours - q4h', 
				'every 4 to 6 hours - q4-6h',
				'every week - qwk',
				'Every two months',
				'Twice a week',
				'four times a day - qid',
				'morning; before noon - am',
				'one half - ss',
				'three times a day - tid',
				'5+2 days',
				'7+3 days',
				'14-day cycle',
				'21-day cycle',
				'28-day cycle'
			) THEN Frequency
		  ELSE 
		    NULL
        END AS Frequency              -- ExpertDetermination_DateOfDeathView_2021-06-27 - Only include Frequency's referenced in Drug Frequency tab
		, QuantityPerFrequency  -- ExpertDetermination_DateOfDeathView_2021-06-27
		, NumberOfAdministrations	  -- ExpertDetermination_DateOfDeathView_2021-06-27
	from
		CalculatedSet.fctCancerTherapy ct
        INNER JOIN PQDataWarehouse_AncillaryTables.PQDataWarehouseWithDeathInformation_AllowedDivision ad
			ON ad.Division = ct.Division
	;