CREATE OR REPLACE SECURE VIEW PQDataWarehouse_WithDeathInformation.dimCost
as
	select 
		  MpiId						-- ExpertDetermination_DateOfDeathView_2019-09-30
		, CostId				    -- ExpertDetermination_DateOfDeathView_2020-08-14
		, DateOfService				-- ExpertDetermination_DateOfDeathView_2019-09-30
		, TotalCharge				-- ExpertDetermination_DateOfDeathView_2019-09-30
		, cast(null AS float) AS TotalCost
		, TotalPaid					-- ExpertDetermination_DateOfDeathView_2019-09-30
		, cast(null AS float) AS PaidByPayer
		, cast(null AS float) AS PaidByPatient
		, GeneralizedPayerCategory  -- Cleaned in https://jira.integraconnect.com:8443/browse/PQ-6841 -- ExpertDetermination_GeoView_2020-02-24
		, IsOcmPayer                -- ExpertDetermination_DateOfDeathView_2020-08-14
		, RecordSourceIdentifier    -- ExpertDetermination_DateOfDeathView_2020-08-26
	from
		CalculatedSet.dimCost dc
		INNER JOIN PQDataWarehouse_AncillaryTables.PQDataWarehouseWithDeathInformation_AllowedDivision ad
			on dc.Division = ad.Division
	;