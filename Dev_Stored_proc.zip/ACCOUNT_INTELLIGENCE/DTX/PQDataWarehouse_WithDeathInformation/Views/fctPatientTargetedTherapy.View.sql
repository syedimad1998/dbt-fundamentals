CREATE OR REPLACE SECURE VIEW PQDataWarehouse_WithDeathInformation.fctPatientTargetedTherapy
as
	select 
		  RecordInsertionDate                                             --  ExpertDetermination_DateOfDeathView_2020-03-02
		, MpiId                                                           --  ExpertDetermination_DateOfDeathView_2020-03-02
		, ConditionType                                                   --  ExpertDetermination_DateOfDeathView_2020-03-02
		, ConditionDescription                                            --  ExpertDetermination_DateOfDeathView_2020-03-02
		, ConditionSampleIcdCode                                          --  ExpertDetermination_DateOfDeathView_2020-03-02
		, ConditionDate                                                   --  ExpertDetermination_DateOfDeathView_2020-03-02
		, TherapyProvided                                                 --  ExpertDetermination_DateOfDeathView_2020-03-02
		, TherapyStartDate                                                --  ExpertDetermination_DateOfDeathView_2020-03-02
		, TherapyEndDate                                                  --  ExpertDetermination_DateOfDeathView_2020-03-02
		, IsPositiveForConditionIsPositiveForTargetTherapy                --  ExpertDetermination_DateOfDeathView_2020-03-02
		, IsPositiveForConditionIsNegativeForTargetTherapy                --  ExpertDetermination_DateOfDeathView_2020-03-02
		, IsNegativeForConditionIsPositiveForTargetTherapy                --  ExpertDetermination_DateOfDeathView_2020-03-02
		, RecordSourceIdentifier                                          --  ExpertDetermination_DateOfDeathView_2020-03-02
	from 
		CalculatedSet.fctPatientTargetedTherapy tt
		INNER JOIN PQDataWarehouse_AncillaryTables.PQDataWarehouseWithDeathInformation_AllowedDivision ad
			ON ad.Division = tt.Division
	;