CREATE OR REPLACE SECURE VIEW PQDataWarehouse_WithDeathInformation.fctPatientToxicity
as
	select 
		RecordInsertionDate
		, MpiId
		, AdverseEventDescription
		, SourceLocation
		, LabSpecificTestName
		, SourceValue -- Cleansed via PQ-6836
		, SourceUnit
		, SourceValueComparison
		, EventDateInstance
		, DaysSinceLastChemotherapyTreatment
		, EventObserver             -- ExpertDetermination_DateOfDeathView_20200428
		, QualitativeAssessment     -- ExpertDetermination_DateOfDeathView_20200428
		, Grade                   -- ExpertDetermination_DateOfDeathView_20200428
		, SymptomCategory          -- ExpertDetermination_DateOfDeathView_20200428
		, AdverseEventPresent                  -- ExpertDetermination_DateOfDeathView_20200428
		, RecordSourceIdentifier    -- ExpertDetermination_DateOfDeathView_20200428
	from 
		CalculatedSet.fctPatientToxicity t
		INNER JOIN PQDataWarehouse_AncillaryTables.PQDataWarehouseWithDeathInformation_AllowedDivision ad
			ON ad.Division = t.Division
	;