CREATE OR REPLACE SECURE VIEW PQDataWarehouse_WithDeathInformation.dimVisitDefinitionCriteria
as
	select 
		VisitDefinitionCriteriaId
		, FriendlyDescription
		, VisitProcedureOccurrenceQualifierSourceValue
		, VisitProcedureOccurrenceProcedureSourceValue
		, VisitVisitOccurrenceVisitConceptId
		, AnyEmrNotedVisitNotFlaggedInOtherCategories
	from
		CalculatedSet.dimVisitDefinitionCriteria
	;