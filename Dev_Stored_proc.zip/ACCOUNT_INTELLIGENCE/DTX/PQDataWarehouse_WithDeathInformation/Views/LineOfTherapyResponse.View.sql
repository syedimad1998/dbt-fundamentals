-- Developer Note - 2019-11-19:  This is approved for use via expert determination.
CREATE OR REPLACE SECURE VIEW PQDataWarehouse_WithDeathInformation.LineOfTherapyResponse
as
	select
		  RecordInsertionDate							-- ExpertDetermination_DateOfDeathView_2019-10-18
		, MpiId										-- ExpertDetermination_DateOfDeathView_2019-10-18
		, LineOfTherapyStartDate						-- ExpertDetermination_DateOfDeathView_2019-10-18
		, LineOfTherapyEndDate						-- ExpertDetermination_DateOfDeathView_2019-10-18
		, Regimen										-- ExpertDetermination_DateOfDeathView_2019-10-18
		, ResponseAtStartOfTherapy					-- ExpertDetermination_DateOfDeathView_2019-10-18
		, ResponseAtEndOfTherapy						-- ExpertDetermination_DateOfDeathView_2019-10-18
		, cast(null as varchar(50)) as IntentToTreat	-- Expert Determination - Death - 20200623
		, RecordSourceIdentifier						-- ExpertDetermination_DateOfDeathView_2020-10-13
	from
		CalculatedSet.LineOfTherapyResponse lt
		INNER JOIN PQDataWarehouse_AncillaryTables.PQDataWarehouseWithDeathInformation_AllowedDivision ad
			ON ad.Division = lt.Division
	;