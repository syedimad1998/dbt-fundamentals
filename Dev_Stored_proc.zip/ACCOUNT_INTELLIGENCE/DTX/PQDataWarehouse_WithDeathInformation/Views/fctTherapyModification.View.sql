CREATE OR REPLACE SECURE VIEW PQDataWarehouse_WithDeathInformation.fctTherapyModification
as
	select
		  RecordInsertionDate      -- ExpertDetermination_DateOfDeathView_20200428
		, MpiId                            -- ExpertDetermination_DateOfDeathView_20200428
		, ChangeDate                      -- ExpertDetermination_DateOfDeathView_20200428
		, CareType                -- ExpertDetermination_DateOfDeathView_20200428
		, ChangeType              -- ExpertDetermination_DateOfDeathView_20200428
		, ChangeReasonCSV         -- ExpertDetermination_DateOfDeathView_20200428
		, RelevantTherapyName     -- ExpertDetermination_DateOfDeathView_20200428
		-- PQ-11506 20200923 - BEGIN
		-- Data smoothing until harmonizer can be adjusted to remove 'extra data' from this column.
		, trim(substring(FromAsString, 1, case when FromAsString like '%|%' then charindex('|', FromAsString, 1)-1 else 999999 end))  as FromAsString
		-- Comment out previous column for now.
		--, FromAsString          -- ExpertDetermination_DateOfDeathView_20200428
		-- PQ-11506 20200923 - END
		, ToAsString            -- ExpertDetermination_DateOfDeathView_20200428
		, FromTreatmentIntention -- ExpertDetermination_DateOfDeathView_20200428
		, cast(null as varchar(50)) as ToTreatmentIntention   -- ExpertDetermination_DateOfDeathView_20200428
		, FromAsNumber                 -- ExpertDetermination_DateOfDeathView_20200428
		, ToAsNumber                   -- ExpertDetermination_DateOfDeathView_20200428
		, RecordSourceIdentifier   -- ExpertDetermination_DateOfDeathView_20200428
		, FromDate						-- ExpertDetermination_DateOfDeathView_20221010
		, ToDate						-- ExpertDetermination_DateOfDeathView_20221010
	from 
		Calculatedset.fctTherapyModification ftm
		INNER JOIN PQDataWarehouse_AncillaryTables.PQDataWarehouseWithDeathInformation_AllowedDivision ad
			ON ad.Division = ftm.Division
	;