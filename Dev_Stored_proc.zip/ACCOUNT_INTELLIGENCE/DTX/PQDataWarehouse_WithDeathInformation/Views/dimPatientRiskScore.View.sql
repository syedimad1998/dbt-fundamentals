CREATE OR REPLACE SECURE VIEW PQDataWarehouse_WithDeathInformation.dimPatientRiskScore
as
	select 
		RecordInsertionDate    -- ExpertDetermination_DateOfDeathView_2019-10-18
		, MpiID                -- ExpertDetermination_DateOfDeathView_2019-10-18
		, RiskName             -- ExpertDetermination_DateOfDeathView_2019-10-18
		, ValueAsInt           -- ExpertDetermination_DateOfDeathView_2019-10-18
		, ValueAsFloat         -- ExpertDetermination_DateOfDeathView_2019-10-18
		, ValueAsString        -- ExpertDetermination_DateOfDeathView_2019-10-18
		, TestDate             -- ExpertDetermination_DateOfDeathView_2019-10-18
		, RecordSourceIdentifier   -- ExpertDetermination_DateOfDeathView_2020-08-26
	from
		CalculatedSet.dimPatientRiskScore dprs
		INNER JOIN PQDataWarehouse_AncillaryTables.PQDataWarehouseWithDeathInformation_AllowedDivision ad
			ON dprs.Division = ad.Division
	;