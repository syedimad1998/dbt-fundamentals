CREATE OR REPLACE SECURE VIEW PQDataWarehouse_WithDeathInformation.fctPatientCancerMetastaticSite
as
	select 
		RecordInsertionDate
		, MpiId
		, DateFirstProofOfMetastaticSpread
		, DateLastProofOfMetastaticSpread
		, SiteLocation
		, RolledUpGeneralSiteLocation
		, SiteGrouping --  ExpertDetermination_DateOfDeathView_2020-03-02
		, case
				when cast(null as varchar(10)) in ('Invasive', 'InSitu') then cast(null as varchar(10))
				else cast(null as varchar(10))
			end as InvasiveStatus  --  ExpertDetermination_DateOfDeathView_2020-03-02
		--  ExpertDetermination_DateOfDeathView_2020-03-02 - Omitted as not the right table for this concept - MetastasicSiteAtDiagnosis	the distant site in which the cancer has spread from the primary site	See tab "Metastatic Site At Diagnosis"	varchar 	20			
		, RecordSourceIdentifier	-- ExpertDetermination_DateOfDeathView_2020-08-26
	from
		CalculatedSet.fctPatientCancerMetastaticSite fpcm
		INNER JOIN PQDataWarehouse_AncillaryTables.PQDataWarehouseWithDeathInformation_AllowedDivision ad
			ON ad.Division = fpcm.Division
	;