CREATE OR REPLACE SECURE VIEW PQDataWarehouse_WithDeathInformation.Control_ProviderAllowedList
AS
	SELECT 
		DISTINCT
		ctrl.ProviderActiveStartDate	-- ExpertDetermination_DateOfDeathView_2021-04-26
		,ctrl.ProviderActiveEndDate		-- ExpertDetermination_DateOfDeathView_2021-04-26
		,ctrl.MeasureName				-- ExpertDetermination_DateOfDeathView_2021-04-26
	FROM
		CalculatedSet.Control_ProviderAllowedList AS ctrl
		INNER JOIN PQDataWarehouse_AncillaryTables.PQDataWarehouseWithDeathInformation_AllowedDivision ad
			ON ctrl.Division = ad.Division
	;