CREATE OR REPLACE SECURE VIEW PQDataWarehouse.fctPatientComorbidity
as
	select 
		Division
		, RecordInsertionDate
		, MpiId
		, CombinedDivisionMpi
		, ConditionDescription
		, SampleFoundIcdCode
		, ConditionStartDate
		, ConditionEndDate
		, ComorbidityDefinitionSource
		, ComorbidityDefaultVisibleInUserFacingDashboards
		, RecordSourceIdentifier
	from
		CalculatedSet.fctPatientComorbidity
	;