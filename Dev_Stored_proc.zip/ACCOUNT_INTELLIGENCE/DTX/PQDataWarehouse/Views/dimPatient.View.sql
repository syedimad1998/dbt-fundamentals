CREATE OR REPLACE SECURE VIEW PQDataWarehouse.dimPatient
as
	select 
		Division
		, RecordInsertionDate
		, MpiId
		, CombinedDivisionMpi
		, case 
				when (date_part('year', BirthDateTime)) < (date_part('year', getdate())-90) 
				then date_part('year', getdate())-90
				else date_part('year', BirthDateTime)
			end as BirthYear
		, ProviderId
		, ProviderMpiId
		, GenderName
		, GeneralizedRace        -- Cleansed via PQ-6844
		, GeneralizedEthnicity   -- Cleansed via PQ-6844
		, LungCancerCellSize
		, ER_WITHOUT_NOTE
		, PR_WITHOUT_NOTE
		, HER2_WITHOUT_NOTE
		, ER_WITH_NOTE
		, PR_WITH_NOTE
		, HER2_WITH_NOTE
		, NOTE_TRIPLE_NEGATIVE
		, NumberOfOcmEpisode -- ExpertDetermination_GeoView_2019-10-18
		, case
				when cast(null as varchar(15)) in ('Single', 'Other', 'Married (incuding common law)') then cast(null as varchar(15))
				else cast(null as varchar(15))
			end as MaritalStatus -- ExpertDetermination_GeoView_2020-03-02 - included recode rules embedded here now.
		, case
				when cast(null as varchar(10)) in ('<0.99', '1.0-1.99', '2.0-2.99', '3.0-3.99', '4.0-4.99', '5.0-5.99', '6.0-6.99', '7.0-7.99', '8.0-8.99', '9.0-9.99', '10.0-10.99') then cast(null as varchar(10))
				else cast(null as varchar(10))
			end NumberPackYearsSmoked -- ExpertDetermination_GeoView_2020-03-02 - included recode rules embedded here now.
		, cast(null as int) as SmokeYears -- ExpertDetermination_GeoView_2020-03-02
		--  ExpertDetermination_GeoView_2020-03-02 - Omitted as not the right table for this concept - dimPatient	HIVStatus	The patients' HIV status	No, Yes, Unknown	varchar	10
		, LastOcmEpisodeStartDate       -- ExpertDetermination_GeoView_2020-03-02
		, LastOcmEpisodeEndDate         -- ExpertDetermination_GeoView_2020-03-02
		, PatientHadAbstractionEvent    -- ExpertDetermination_GeoView_2020-03-02
		, RecordSourceIdentifier		-- ExpertDetermination_GeoView_2020-09-25
		, PrimaryProviderCareSiteHashId	-- ExpertDetermination_GeoView_2020-07-16
	from
		CalculatedSet.dimPatient
	;