CREATE OR REPLACE SECURE VIEW PQDataWarehouse.dimPatientVisit
as
	select 
		Division
		, RecordInsertionDate
		, MpiId
		, CombinedDivisionMpi
		, VisitDate
		, VisitDefinitionCriteriaId
		, ProviderCareSiteHashId
		, ProviderMpiId
		, CombinedDivisionProviderMpi
		, TotalCharge
		, RecordSourceIdentifier 
		, CostId
		, ServiceCodeDescriptionId -- Expert Determination - Geo View - 20200814
	from
		CalculatedSet.dimPatientVisit
	;