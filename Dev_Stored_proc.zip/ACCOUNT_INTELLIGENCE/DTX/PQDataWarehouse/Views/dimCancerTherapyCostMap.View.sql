CREATE OR REPLACE SECURE VIEW PQDataWarehouse.dimCancerTherapyCostMap
as
	select 
		Division
		, MpiId
		, CostId
		, CancerTherapyHashId
	from
		CalculatedSet.dimCancerTherapyCostMap
	;