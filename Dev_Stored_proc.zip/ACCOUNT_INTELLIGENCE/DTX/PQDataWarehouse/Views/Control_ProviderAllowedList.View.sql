CREATE OR REPLACE SECURE VIEW PQDataWarehouse.Control_ProviderAllowedList
AS
	SELECT 
		DISTINCT
		Division					-- ExpertDetermination_GeoView_2021-04-26
		,ProviderName				-- ExpertDetermination_GeoView_2021-04-26
		,NPI						-- ExpertDetermination_GeoView_2021-04-26
		,Location					-- ExpertDetermination_GeoView_2021-04-26
		,Region						-- ExpertDetermination_GeoView_2021-04-26
		,TIN						-- ExpertDetermination_GeoView_2021-04-26
		,ProviderActiveStartDate	-- ExpertDetermination_GeoView_2021-04-26
		,ProviderActiveEndDate		-- ExpertDetermination_GeoView_2021-04-26
		,FirstName					-- ExpertDetermination_GeoView_2021-04-26
		,LastName					-- ExpertDetermination_GeoView_2021-04-26
		,MeasureName				-- ExpertDetermination_GeoView_2021-04-26
	FROM
		CalculatedSet.Control_ProviderAllowedList
	;