CREATE OR REPLACE SECURE VIEW PQDataWarehouse.dimPatientCancer
as
	select                                                -- ExpertDetermination_GeoView_2019-10-18 
		  Division                                        -- ExpertDetermination_GeoView_2019-10-18 
		, RecordInsertionDate                             -- ExpertDetermination_GeoView_2019-10-18 
		, MpiId                                           -- ExpertDetermination_GeoView_2019-10-18 
		, CombinedDivisionMpi                             -- ExpertDetermination_GeoView_2019-10-18 
		, CodeType                                        -- ExpertDetermination_GeoView_2019-10-18 
		, CancerCode                                      -- ExpertDetermination_GeoView_2019-10-18 
		, CancerCodeMajorCategory                         -- ExpertDetermination_GeoView_2019-10-18 
		, DateInstanceOfCancerCode                        -- ExpertDetermination_GeoView_2019-10-18 
		, Control_CancerCodeToDescriptionMatchingId       -- ExpertDetermination_GeoView_2019-10-18 
		--  ExpertDetermination_GeoView_2020-03-02 - Omitted as not the right table for this concept - TumorType	The type of tumor, e.g. giant cell tumor.	See "TumorType"	varchar	20
		--  ExpertDetermination_GeoView_2020-03-02 - Omitted as not the right table for this concept - MetastasisSizeAtDiagnosis	Metastasis size at diagnosis	E.g. 85 mm	varchar	25
		--  ExpertDetermination_GeoView_2020-03-02 - Omitted as not the right table for this concept - LiverFunctionResultAtDiagnosis	Results at diagnosis 	E.g. x, x, x (add a few examples here)	varchar	20
		--  ExpertDetermination_GeoView_2020-03-02 - Omitted as not the right table for this concept - RenalFunctionResultAtDiagnosis	Results at diagnosis	E.g. x, x, x (add a few examples here)	varchar	20
		--  ExpertDetermination_GeoView_2020-03-02 - Omitted as not the right table for this concept - RecurrenceStatus	Local, locoregional, distant	True, False, Never disease free	varchar	15
		--  ExpertDetermination_GeoView_2020-03-02 - Omitted as not the right table for this concept - RecurrenceStatusDaysFromDiagnosis	Local, locoregional, distant days from initial diagnosis	Count of distant days	varchar	20
		, RecordSourceIdentifier						  -- ExpertDetermination_GeoView_2020-06-23
		, DateOfProgression			  					  -- ExpertDetermination_GeoView_2021-02-08
	from 
		CalculatedSet.dimPatientCancer
	;