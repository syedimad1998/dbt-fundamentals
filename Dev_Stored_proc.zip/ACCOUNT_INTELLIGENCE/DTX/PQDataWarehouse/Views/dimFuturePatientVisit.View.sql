CREATE OR REPLACE SECURE VIEW PQDataWarehouse.dimFuturePatientVisit
as
	select 
		Division                                                                                             -- ExpertDetermination_GeoView_2019-10-18
		, RecordInsertionDate                                                                                -- ExpertDetermination_GeoView_2019-10-18
		, MpiId                                                                                              -- ExpertDetermination_GeoView_2019-10-18
		, CombinedDivisionMpi                                                                                -- ExpertDetermination_GeoView_2019-10-18
		, dateadd(day, -2, dateadd(week, 1, date_trunc('week', VisitDate)))	as VisitWeek					 -- ExpertDetermination_GeoView_2019-10-18
		, VisitDate                                                                                          -- ExpertDetermination_GeoView_2020-03-02
		, VisitDefinitionCriteriaId                                                                          -- ExpertDetermination_GeoView_2019-10-18
		, ProviderCareSiteHashId                                                                             -- ExpertDetermination_GeoView_2019-10-18
		, ProviderMpiId                                                                                      -- ExpertDetermination_GeoView_2019-10-18
		, CombinedDivisionProviderMpi                                                                        -- ExpertDetermination_GeoView_2019-10-18
		, TotalCharge                                                                                        -- ExpertDetermination_GeoView_2019-10-18
		, VisitDate as VisitDay                                                                              -- ExpertDetermination_GeoView_2019-11-20
		, RecordSourceIdentifier                                                                             -- ExpertDetermination_GeoView_2020-10-13
	from 
		CalculatedSet.dimFuturePatientVisit
	;