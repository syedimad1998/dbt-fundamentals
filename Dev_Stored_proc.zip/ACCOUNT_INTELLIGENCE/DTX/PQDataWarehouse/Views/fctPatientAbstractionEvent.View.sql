CREATE OR REPLACE SECURE VIEW PQDataWarehouse.fctPatientAbstractionEvent
as
	select                                     -- ExpertDetermination_GeoView_2020-03-02
		  Division                             -- ExpertDetermination_GeoView_2020-03-02
		, RecordInsertionDate                  -- ExpertDetermination_GeoView_2020-03-02
		, MpiId                                -- ExpertDetermination_GeoView_2020-03-02
		, CombinedDivisionMpi                  -- ExpertDetermination_GeoView_2020-03-02
		, AbstractionTypeId                    -- ExpertDetermination_GeoView_2020-03-02
		, EarliestAbstractionRelatedDate       -- ExpertDetermination_GeoView_2020-03-02
		, LastAbstractionRelatedDate           -- ExpertDetermination_GeoView_2020-03-02
        , LastAbstractionCompletionDate		   -- ExpertDetermination_GeoView_20200428
        , NumberOfTimesAbstracted			   -- ExpertDetermination_GeoView_20200428
        , LastAbstractionAbandonDate		   -- ExpertDetermination_GeoView_20200428
        , LastAbstractionAbandonReason		   -- ExpertDetermination_GeoView_20200428
	from
		CalculatedSet.fctPatientAbstractionEvent
	;