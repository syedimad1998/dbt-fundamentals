CREATE OR REPLACE SECURE VIEW PQDataWarehouse.fctPatientVisitAggregatedByCriteriaGroup
as
	select 
		Division
		, RecordInsertionDate
		, VisitDefinitionCriteriaGroupId
		, MpiId
		, CombinedDivisionMpi
		, TotalVisits
		, RecordSourceIdentifier     -- ExpertDetermination_GeoView_2020-10-13
	from
		CalculatedSet.fctPatientVisitAggregatedByCriteriaGroup
	;