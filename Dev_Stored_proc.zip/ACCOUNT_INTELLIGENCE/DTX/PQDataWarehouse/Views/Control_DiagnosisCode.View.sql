CREATE OR REPLACE SECURE VIEW PQDataWarehouse.Control_DiagnosisCode
AS
	SELECT 
		  CodeSystem									   -- Expert Determination GEO View 20210228
		, MatchCode										   -- Expert Determination GEO View 20210228
		, DiagnosisName									   -- Expert Determination GEO View 20210228
		, DescriptionMajorClassification				   -- Expert Determination GEO View 20210228
		, DescriptionMinorClassification				   -- Expert Determination GEO View 20210228
		, PrimarySecondaryClassification				   -- Expert Determination GEO View 20210228
		, ExactLocation									   -- Expert Determination GEO View 20210228
		, GeneralLocation								   -- Expert Determination GEO View 20210228
		, TestDefinitionSource							   -- Expert Determination GEO View 20210228
		, IsCancer										   -- Expert Determination GEO View 20210228
		, IsDisease										   -- Expert Determination GEO View 20210228
		, IsAdverseEvent								   -- Expert Determination GEO View 20210228
		, IsComorbidity									   -- Expert Determination GEO View 20210228
		, Control_CancerCodeToDescriptionMatchingId		   -- Expert Determination GEO View 20210228
		, TestDefaultVisibleInUserFacingDashboards 		   -- Expert Determination GEO View 20210228
	FROM 
		CalculatedSet.Control_DiagnosisCode
	;