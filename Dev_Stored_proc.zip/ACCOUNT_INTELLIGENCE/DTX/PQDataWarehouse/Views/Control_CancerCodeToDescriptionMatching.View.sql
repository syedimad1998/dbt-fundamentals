CREATE OR REPLACE SECURE VIEW PQDataWarehouse.Control_CancerCodeToDescriptionMatching
as
	select 
		CodeSystem
		, CancerMatchCode
		, DescriptionMajorClassification
		, DescriptionMinorClassification
		, CancerPrimarySecondaryClassification
		, ExactLocation
		, GeneralLocation
		, Control_CancerCodeToDescriptionMatchingId  -- ExpertDetermination_GeoView_2019-10-18
	from
		CalculatedSet.Control_CancerCodeToDescriptionMatching
	;