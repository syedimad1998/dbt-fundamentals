CREATE OR REPLACE SECURE VIEW PQDataWarehouse.Control_CombinedDrugMatch
as
	select 
		MatchCode
		, MatchType
		, GenericName
		, NdcProductId
		, NdcId
		, DrugCategory
		, DrugSubCategory
		, Priority     -- ExpertDetermination_GeoView_2019-10-18
		, BrandName      -- ExpertDetermination_GeoView_2019-10-18
	from
		CalculatedSet.Control_CombinedDrugMatch
	;