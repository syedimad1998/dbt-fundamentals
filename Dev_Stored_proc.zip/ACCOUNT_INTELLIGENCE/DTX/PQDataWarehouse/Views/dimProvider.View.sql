CREATE OR REPLACE SECURE VIEW PQDataWarehouse.dimProvider
as	
		select 
		Division
		, RecordInsertionDate
		, ProviderMpiId
		, CombinedDivisionProviderMpi
		, case when IdentifyingDataProhibitedFromDisclosureToThirdParties = 1 then '' else FullProviderName END AS FullProviderName
		, case when IdentifyingDataProhibitedFromDisclosureToThirdParties = 1 then '' else FirstName END AS FirstName
		, case when IdentifyingDataProhibitedFromDisclosureToThirdParties = 1 then '' else LastName END AS LastName
		, case when IdentifyingDataProhibitedFromDisclosureToThirdParties = 1 then '' else EmailAddress END AS EmailAddress
		, case when IdentifyingDataProhibitedFromDisclosureToThirdParties = 1 then '' else PhoneNumber END AS PhoneNumber
		, case when IdentifyingDataProhibitedFromDisclosureToThirdParties = 1 then '' else FaxNumber END AS FaxNumber
		, case when IdentifyingDataProhibitedFromDisclosureToThirdParties = 1 then '' else FederalTaxId END AS FederalTaxId
		, case when IdentifyingDataProhibitedFromDisclosureToThirdParties = 1 then '' else NPI END AS NPI
		, case when IdentifyingDataProhibitedFromDisclosureToThirdParties = 1 then '' else DEA END AS DEA
		, PracticeSite
		, HasSpecialtyInRadiationOncology
		, HasSpecialtyInHematologyOncology
		, HasSpecialtyInMedicalOncology
		, HasSpecialtyInUrology
		, HasSpecialtyInAdvancedPracticePractitioner
		, case when PrimarySpecialty ilike '%Poetry%' or PrimarySpecialty ilike '%Naprapath%' then 'Other' else PrimarySpecialty end as PrimarySpecialty
		, case when NonFlaggedSpecialty ilike '%Poetry%' or NonFlaggedSpecialty ilike '%Naprapath%' then 'Other' else NonFlaggedSpecialty end as NonFlaggedSpecialty
		, case when AllSpecialty ilike '%Poetry%' or AllSpecialty ilike '%Naprapath%' then 'Other' else AllSpecialty end as AllSpecialty
		, GenderName
		, EpisodeRelatedScore_OCM1
		, EpisodeRelatedScore_OCM2
		, EpisodeRelatedScore_OCM3
		, EpisodeRelatedScore_OCM4a
		, EpisodeRelatedScore_OCM4b
		, EpisodeRelatedScore_OCM5
		, EpisodeRelatedScore_OCM8
		, EpisodeRelatedScore_OCM9
		, EpisodeRelatedScore_OCM10
		, EpisodeRelatedScore_OCM11
		, EpisodeRelatedScore_OCM12
		, EpisodeRelatedScore_OCM24
		, EpisodeRelatedScore_OCM30
		, IdentifyingDataProhibitedFromDisclosureToThirdParties -- ExpertDetermination_GeoView_2020-03-02
		, RecordSourceIdentifier              -- Expert Determination GEO View 20200623
		, ProviderIsConfirmedByDivision       -- Expert Determination GEO View 20200623
	from 
		CalculatedSet.dimProvider
	;