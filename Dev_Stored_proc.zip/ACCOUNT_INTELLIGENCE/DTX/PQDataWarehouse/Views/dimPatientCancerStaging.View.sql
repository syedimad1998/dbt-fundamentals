CREATE OR REPLACE SECURE VIEW PQDataWarehouse.dimPatientCancerStaging
as
	select 
		Division
		, RecordInsertionDate
		, MpiId
		, CombinedDivisionMpi
		-- Not including, dirty field, not enough roi - , ConditionSourceValueId
		, ConditionSourceValue
		, StagingId
		, StagingDate
		, CareSiteId
		, CareSiteName
		, CancerStage
		, CancerTValue
		, CancerNValue
		, CancerMValue
		, CancerGValue
		, CancerHistology
		-- Not including, dirty field, not enough roi -  CancerCritDescr
		, CancerStageMajorCategory
		, CancerStageMinorCategory -- ExpertDetermination_GeoView_2019-10-18
		, RecordSourceIdentifier -- ExpertDetermination_GeoView_2020-03-02
	from
		CalculatedSet.dimPatientCancerStaging
	;