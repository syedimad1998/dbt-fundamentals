CREATE OR REPLACE SECURE VIEW PQDataWarehouse.Control_StaticHealthcareTaxonomy
as
	select 
		ProviderTaxonomyCode
		, case when ProviderTypeDescription ilike '%Poetry%' or ProviderTypeDescription ilike '%Naprapath%' then 'Other' else ProviderTypeDescription end as ProviderTypeDescription
		, case when ProviderTaxonomyDescription ilike '%Poetry%' or ProviderTaxonomyDescription ilike '%Naprapath%' then 'Other' else ProviderTaxonomyDescription end as ProviderTaxonomyDescription
		, case when ExtendedProviderTaxonomyDescription ilike '%Poetry%' or ExtendedProviderTaxonomyDescription ilike '%Naprapath%' then 'Other' else ExtendedProviderTaxonomyDescription end as ExtendedProviderTaxonomyDescription
		, case when DisplayDescription ilike '%Poetry%' or DisplayDescription ilike '%Naprapath%' then 'Other' else DisplayDescription end as DisplayDescription
	from
		CalculatedSet.Control_StaticHealthcareTaxonomy
	;