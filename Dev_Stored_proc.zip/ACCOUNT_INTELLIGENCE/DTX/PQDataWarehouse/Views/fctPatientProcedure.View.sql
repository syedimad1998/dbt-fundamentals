CREATE OR REPLACE SECURE VIEW PQDataWarehouse.fctPatientProcedure
as
	select 
		  Division
		, RecordInsertionDate
		, MpiId
		, CombinedDivisionMpi
		, DateOfEvent
		, ProcedureName
		, ProcedureSourceCode
		, ProcedureSourceCodeName
		, ProcedureSourceCodeType
		, CombinedDivisionProviderMpi
		, ProviderCareSiteHashId
		, ValueAsString -- ExpertDetermination_GeoView_2019-10-18
		--  ExpertDetermination_GeoView_2020-03-02 - Omitted as not the right table for this concept - CellMorphologyICD-O	Coding system for classification of tumor type	example: 8140/Adenocarcinoma, 8046/Non-small cell carcinoma	varchar	25	
		, DateOfEventEnd                   		-- ExpertDetermination_GeoView_20200428
		, PrimaryAnatomicSiteLocation      -- ExpertDetermination_GeoView_20200428
		, SecondaryAnatomicSiteLocation    -- ExpertDetermination_GeoView_20200428
		, PrimaryUnit                      -- ExpertDetermination_GeoView_20200428
		, PrimaryValueAsInt                -- ExpertDetermination_GeoView_20200428
		, PrimaryValueAsFloat              -- ExpertDetermination_GeoView_20200428
		, SecondaryUnit                    -- ExpertDetermination_GeoView_20200428
		, SecondaryValueAsInt              -- ExpertDetermination_GeoView_20200428
		, SecondaryValueAsFloat            -- ExpertDetermination_GeoView_20200428
		, RecordSourceIdentifier           -- ExpertDetermination_GeoView_20200428
		, cast(null as varchar(50)) as ProcedureObjective -- Expert Determination - GEO - 20200623
		, CostId						   -- ExpertDetermination_GeoView_2020814
		, GeneralizedProcedureCategory	   -- ExpertDetermination_GeoView_2020814
		, ServiceCodeDescriptionId         -- ExpertDetermination_GeoView_2020814
	from 
		CalculatedSet.fctPatientProcedure
	;