CREATE OR REPLACE SECURE VIEW PQDataWarehouse.fctPatientSocialHistory
as
	select 
		Division
		, RecordInsertionDate
		, MpiId
		, CombinedDivisionMpi
		, SocialAttributeName
		, NormalizedValue
		, SocialAttributeAnswerMinDate
		, SocialAttributeAnswerMaxDate
		, RecordSourceIdentifier            -- ExpertDetermination_GeoView_2020-08-26
	from
		CalculatedSet.fctPatientSocialHistory
	;