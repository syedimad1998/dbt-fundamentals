CREATE OR REPLACE SECURE VIEW PQDataWarehouse.dimPatientMetadata
AS
	SELECT 
		  Division			   -- ExpertDetermination_GeoView_2020-08-14
		, Mpiid				   -- ExpertDetermination_GeoView_2020-08-14
		, CombinedDivisionMPI  -- ExpertDetermination_GeoView_2020-08-14
		, MetadataDate		   -- ExpertDetermination_GeoView_2020-08-14
		, MetadataSource	   -- ExpertDetermination_GeoView_2020-08-14
		, MetadataType		   -- ExpertDetermination_GeoView_2020-08-14
		, MetadataValue		   -- ExpertDetermination_GeoView_2020-08-14
	FROM
		CalculatedSet.dimPatientMetaData
	;