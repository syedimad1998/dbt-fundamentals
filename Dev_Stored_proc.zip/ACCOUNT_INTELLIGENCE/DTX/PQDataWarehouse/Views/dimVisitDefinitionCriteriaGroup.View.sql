CREATE OR REPLACE SECURE VIEW PQDataWarehouse.dimVisitDefinitionCriteriaGroup
as
	select 
		VisitDefinitionCriteriaGroupId
		, FriendlyName
		, FriendlyDescription
	from
		CalculatedSet.dimVisitDefinitionCriteriaGroup
	;