CREATE OR REPLACE SECURE VIEW PQDataWarehouse.dimPatientEpisodeOfCare
AS
	SELECT 
		Division                        -- ExpertDetermination_GeoView_2020-08-14
		,RecordInsertionDate            -- ExpertDetermination_GeoView_2020-08-14
		,MpiId                          -- ExpertDetermination_GeoView_2020-08-14
		,CombinedDivisionMpi            -- ExpertDetermination_GeoView_2020-08-14
		,RecordValidFromDate            -- ExpertDetermination_GeoView_2020-08-14
		,RecordValidToDate              -- ExpertDetermination_GeoView_2020-08-14
		,EpisodeType                    -- ExpertDetermination_GeoView_2020-08-14
		,EpisodeStartDate               -- ExpertDetermination_GeoView_2020-08-14
		,EpisodeEndDate                 -- ExpertDetermination_GeoView_2020-08-14
		,EpisodeNumber                  -- ExpertDetermination_GeoView_2020-08-14
		,CombinedDivisionProviderMpi	-- ExpertDetermination_GeoView_2020-08-14
		,CombinedDivisionProviderMpiId  -- ExpertDetermination_GeoView_2020-08-14
		,RecordSourceIdentifier			-- ExpertDetermination_GeoView_2021-02-02
		,IsCMS							-- ExpertDetermination_GeoView_2021-02-08
	FROM
		CalculatedSet.dimPatientEpisodeOfCare
	;