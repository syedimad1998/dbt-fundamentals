CREATE OR REPLACE SECURE VIEW PQDataWarehouse.dimVisitDefinitionCriteria
as
	select 
		VisitDefinitionCriteriaId
		, FriendlyDescription
		, VisitProcedureOccurrenceQualifierSourceValue
		, VisitProcedureOccurrenceProcedureSourceValue
		, VisitVisitOccurrenceVisitConceptId
		, AnyEmrNotedVisitNotFlaggedInOtherCategories
	from
		CalculatedSet.dimVisitDefinitionCriteria
	;