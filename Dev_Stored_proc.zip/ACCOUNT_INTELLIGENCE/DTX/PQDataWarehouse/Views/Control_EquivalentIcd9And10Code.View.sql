CREATE OR REPLACE SECURE VIEW PQDataWarehouse.Control_EquivalentIcd9And10Code
as
	select 
		  ICD9       -- Expert Determination GEO View 20200826
		, ICD10      -- Expert Determination GEO View 20200826
	from
		CalculatedSet.Control_EquivalentIcd9And10Code
	;