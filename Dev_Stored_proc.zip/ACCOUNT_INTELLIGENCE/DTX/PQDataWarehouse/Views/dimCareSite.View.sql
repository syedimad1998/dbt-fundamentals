CREATE OR REPLACE SECURE VIEW PQDataWarehouse.dimCareSite
AS
SELECT
	  Division
	, RecordInsertionDate
	, CareSiteHashId
	, CareSiteName
	, TIN
	, CareSiteNPI
	, Address_Line1
	, Address_Line2
	, Address_City
	, Address_State
	, CASE WHEN Division = '105'			-- PQ-13309: We need to make sure that we send only 5-digit zip through ED for dimCareSite 
		   THEN CAST(NULL as varchar(250))	--			 instead of 9 digits for all divisions (Note: for 105 - no Zipcode at all).
		   ELSE LEFT(TRIM(Address_ZIP), 5)	--			 ******** This is due to contractual obligation ********
		   END 
		   AS Address_ZIP
	, CareSiteIsConfirmedByDivision
	, RecordSourceIdentifier
FROM
		CalculatedSet.dimCareSite
	;