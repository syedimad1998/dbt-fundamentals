CREATE OR REPLACE SECURE VIEW PQDataWarehouse.Control_LookupCode_Comorbidity
as
	select 
		GeneralComorbidityName                          -- Expert Determination GEO View 20200623
		, CodeSystem                                    -- Expert Determination GEO View 20200623
		, ConditionMatchCode_MajorCategory              -- Expert Determination GEO View 20200623
		, ConditionMatchCode_FullCode                   -- Expert Determination GEO View 20200623
		, TestDefinitionSource                          -- Expert Determination GEO View 20200623
		, TestDefaultVisibleInUserFacingDashboards      -- Expert Determination GEO View 20200623
	from
		CalculatedSet.Control_LookupCode_Comorbidity
	;