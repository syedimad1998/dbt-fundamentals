CREATE OR REPLACE SECURE VIEW PQDataWarehouse.fctPatientDailyCostOfCare
as
	select 		
		Division
		, RecordInsertionDate
		, MpiId
		, CombinedDivisionMpi
		, CareDate
        , GeneralizedPayerCategory	-- cleansed via https://jira.integraconnect.com:8443/browse/PQ-6840 renamed from PayerCategory allowed by ED
		, IsOcmPayer
		, TotalCost
		, RecordSourceIdentifier	-- ExpertDetermination_GeoView_2020-08-26
	from 
		CalculatedSet.fctPatientDailyCostOfCare
	;