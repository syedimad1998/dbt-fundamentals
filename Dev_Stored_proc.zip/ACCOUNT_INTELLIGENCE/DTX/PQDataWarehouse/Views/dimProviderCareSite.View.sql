CREATE OR REPLACE SECURE VIEW PQDataWarehouse.dimProviderCareSite
as
	select 		  
		Division
		, RecordInsertionDate
		, ProviderMpiId
		, CombinedDivisionProviderMpi
		, ProviderCareSiteHashId
		, CareSiteHashId
		, RecordSourceIdentifier -- ExpertDetermination_GeoView_2020-03-02
	from
		CalculatedSet.dimProviderCareSite
	;