CREATE OR REPLACE SECURE VIEW PQDataWarehouse.fctCancerTherapy
as
	select 
		Division
		, RecordInsertionDate
		, MpiId
		, CombinedDivisionMpi
		, DrugGenericName
		, MatchCode
		, MatchType
		, SourceLocation
		, MatchLocation
		, DrugConceptId
		, DrugExposureStartDate
		, DrugExposureEndDate
		, DrugTypeConceptId
		, StopReason -- waiting for PQ-6842
		, Refills
		, Quantity
		, QuantityPerDay
		, DaysSupply
		-- Not including - very dirty column, can't include without cleansing of free text, very hard without roi.  , Sig
		, RouteConceptId
		, VaccineFlag
		, NDC
		, ProviderId
		-- Not including - very dirty column, can't include without cleansing of free text, very hard without roi. , DrugSourceValue
		, TherapyRoute -- cleaned via PQ-6522, in place of TherapySourceValue which was approved (without phi). - also ExpertDetermination_GeoView_2020-03-02
		, DoseUnitSourceValue -- cleaned via PQ-6364
		, QuantitySourceValue -- cleaned via PQ-6520
		, DoseSourceValue -- cleaned via PQ-6360
		, StrengthSourceValue -- cleaned via PQ-6365
		, CareSiteName
		, CareSiteAddress1
		, CareSiteCity
		, CareSiteState
		, case when division = '105' then cast(null as varchar(9)) else CareSiteZipCode end as CareSiteZipCode  -- 20200515 - Requested John V, not required by ED but required from John V.
		, SourceKey
		, HeightInMeters
		, WeightInKg
		, BMIFromChart
		, BSAFromChart
		, BMICalculated
		, BSACalculated
		, DosePerKg
		, DosePerMeterSquared
		, DoseSourceUnit -- cleaned via PQ-6364
		, DoseNormalizedUnit -- cleaned via PQ-6361
		, ChangeInDosePercentageSinceFirstAdministration
		, ChangeInDosePerKgSinceFirstAdministration
		, ChangeInDosePerMeterSquaredSinceFirstAdministration
		, NewAgent
		, DaysSinceLastAdministrationOfDrug
		, DrugCategory
		, DrugSubCategory
		, CostId				   -- ExpertDetermination_GeoView_2020-08-14
		, TotalCharge
		, CancerTherapyHashId
		, PrescribedBrand          -- ExpertDetermination_GeoView_2019-10-18
		, Classification         -- ExpertDetermination_GeoView_2020-03-02
		, RecordSourceIdentifier   -- ExpertDetermination_GeoView_2020-03-02
		--  ExpertDetermination_GeoView_2020-03-02 - Omitted as not the right table for this concept - LOTNumber	Line of therapy sequence	LOT1, LOT2, LOT3, LOT4, etc	varchar	10
		--  ExpertDetermination_GeoView_2020-03-02 - Omitted as not the right table for this concept - TreatmentReasonCategories	The reason why the treatment was delivered	Neoadjuvant, Primary, Adjuvant, Not administered	varchar	15
		--  ExpertDetermination_GeoView_2020-03-02 - Omitted as not the right table for this concept - TreatmentCompletedAsPrescribed	Whether treatment was given according to original treatment plan	Completed as described, Discontinued early, Ongoing, Unknown	varchar	15
		, ProviderMpiId -- ExpertDetermination_GeoView_20200428
		, IntentToTreat
		, ServiceCodeDescriptionId -- ExpertDetermination_GeoView_2020-08-14
		, CASE 
			WHEN collate(TherapyForm, 'en-ci') IN (
					'capsule',
					'concentrate',
					'cream',
			        'for solution', 
					'for suspension', 
					'gel',
					'implant',
					'injectable',
					'injection',
					'solution',
					'spray', 
					'suspension',
					'system',
					'tablet',
					'vial'
				) THEN TherapyForm
		  ELSE
			NULL
		END AS TherapyForm			-- ExpertDetermination_GeoView_20210627 - Only include TherapyForm's referenced in Therapy Form tab
		, CASE
			WHEN collate(Frequency, 'en-ci') IN ( 
				'daily - qd',
				'every other day - qod',
				'twice a day - bid',
				'three times a week - tiw' ,
				'four times a week - qiw', 
				'weekly - qw', 
				'monthly - qm', 
				'after meals - pc',
				'as needed - prn', 
				'at bedtime - hs', 
				'bi-monthly', 
				'bi-weekly', 
				'evening; after noon - pm', 
				'every 1 hour - q1h', 
				'every 1 to 2 hours - q1-2h',
				'every 12 hours - q12h', 
				'every 4 hours - q4h', 
				'every 4 to 6 hours - q4-6h',
				'every week - qwk',
				'Every two months',
				'Twice a week',
				'four times a day - qid',
				'morning; before noon - am',
				'one half - ss',
				'three times a day - tid',
				'5+2 days',
				'7+3 days',
				'14-day cycle',
				'21-day cycle',
				'28-day cycle'
			) THEN Frequency
		  ELSE 
		    NULL
		END AS Frequency		   -- ExpertDetermination_GeoView_20210627 - Only include Frequency's referenced in Drug Frequency tab
		, QuantityPerFrequency     -- ExpertDetermination_GeoView_20210627
		, NumberOfAdministrations  -- ExpertDetermination_GeoView_20210627
	from
		CalculatedSet.fctCancerTherapy
	;