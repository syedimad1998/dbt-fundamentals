CREATE OR REPLACE SECURE VIEW PQDataWarehouse.dimPatientReferral
as	
		select 
			Division
			,RecordInsertionDate
			,MpiId
			,CombinedDivisionMpi
			,Direction
			,DateReferralWasGenerated
			,DateReferralWasActedOn
			,ReferFromCareSiteHashId
			,ReferFromProviderMpiId
			,ReferFromProviderLastName
			,ReferFromProviderFirstName
			,ReferFromProviderFullName
			,ReferToCareSiteHashId
			,ReferToProviderMpiId
			,ReferToProviderLastName
			,ReferToProviderFirstName
			,ReferToProviderFullName
			,case when ReferToProviderSpecialty ilike '%Naprapath%' or ReferToProviderSpecialty ilike '%Poetry%' then 'Other' else ReferToProviderSpecialty end as ReferToProviderSpecialty
			,ReferDueToProblemCodeType
			,ReferDueToProblemCode
			,ReferDueToProblemDescription
			,ReferDueToProcedureCodeType
			,ReferDueToProcedureCode
			,ReferDuetoProcedureDescription			
			,RecordSourceIdentifier			-- ExpertDetermination_GeoView_2020-10-13
	from 
		CalculatedSet.dimPatientReferral
	;