CREATE OR REPLACE SECURE VIEW PQDataWarehouse.dimDivision
as
	select 
		Division                         -- ExpertDetermination_GeoView_2020-03-02
		, RecordInsertionDate          -- ExpertDetermination_GeoView_2020-03-02
		, ClientName                   -- ExpertDetermination_GeoView_2020-03-02
		, ClientNameLong               -- ExpertDetermination_GeoView_2020-03-02
		, Specialty                    -- ExpertDetermination_GeoView_2020-03-02
	from
		CalculatedSet.dimDivision
	;