CREATE OR REPLACE SECURE VIEW PQDataWarehouse.fctPatientVisit
as
	select 
		Division
		, RecordInsertionDate
		, VisitDefinitionCriteriaId
		, MpiId
		, CombinedDivisionMpi
		, Year
		, Quarter
		, TotalVisits
		, RecordSourceIdentifier    -- ExpertDetermination_GeoView_2020-08-26
	from 
		CalculatedSet.fctPatientVisit
	;