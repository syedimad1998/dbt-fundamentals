CREATE OR REPLACE SECURE VIEW PQDataWarehouse.fctPatientLab
as
	select 
		Division
		, RecordInsertionDate
		, MpiId
		, CombinedDivisionMpi
		, TestDate
		, TestName
		, TestConceptId
		, ValueAsInt
		, ValueAsFloat
		, ValueAsString
		, UnitValue -- Cleaned - https://jira.integraconnect.com:8443/browse/PQ-6366
		, MatchTerm
		-- Not Included, unnecessary and require a ticket to clean of free-text before we can use it. NO ROI.  , RawData_Source
		-- Not Included, unnecessary and require a ticket to clean of free-text before we can use it. NO ROI.  , RawData_Value
		, NormalRangeLow
		, NormalRangeHigh
		, SourceLocation
		, case 
				when collate(GenomicPanelTested, 'en-ci') in ('DNA - NGS', 'DNA - Sanger', 'DNA - FISH', 'DNA - Other', 'Protein - IHC', 'Protein - Other or Unknown', 'RNA - PCR', 'RNA - RNA-Seq', 'RNA - Other', 'Other', 'Unknown') then GenomicPanelTested
				else 'Unknown'
			end as GenomicPanelTested --  ExpertDetermination_GeoView_2020-03-02  - we are aware that the length tested and the values are in conflict, we are falling to length as that is more restrictive.
		, case
				when cast(null as varchar(20)) in ('Lung', 'Regional Lymph Node', 'Regional Site', 'Distant Site', 'Unknown') then cast(null as varchar(20))
				else cast(null as varchar(20))
			end as SpecimenSite --  ExpertDetermination_GeoView_2020-03-02  - we are aware that the length tested and the values are in conflict, we are falling to length as that is more restrictive.
		, case
				when collate(fpl.SpecimenCollectionMethod, 'en-ci') in ('Buccal Swab/Saliva', 'Fine needle aspirate (FNA)', 'Image-guided biopsy', 'Other', 'Surgery', 'Unknown') then fpl.SpecimenCollectionMethod
				when fpl.SpecimenCollectionMethod IS NOT NULL then 'Other'
				else cast(null as varchar(10))
			end as SpecimenCollectionMethod --  ExpertDetermination_GeoView_2020-03-02  - we are aware that the length tested and the values are in conflict, we are falling to length as that is more restrictive.
		, RecordSourceIdentifier --  ExpertDetermination_GeoView_2020-03-02
		, ResultDate --  ExpertDetermination_GeoView_2020-03-02
		, case
				when collate(TestingCompany, 'en-ci') in (
											  'Acupath Laboratories'
											, 'Ambry Genetics'
											, 'Arup Laboratories'
											, 'Atlantic Consolidated Laboratory'
											, 'Beaumont Cancer Genetics'
											, 'Biocept'
											, 'Biodesix'
											, 'BioReference Laboratories'
											, 'Biospecific Fx'
											, 'Cancer Genetics'
											, 'Caris Life Sciences'
											, 'Caris'
											, 'Clarient Diagnostic Services'
											, 'Counsyl'
											, 'CSI Laboratories'
											, 'Foundation Medicine'
											, 'Foundation'
											, 'Fulgent'			-- PQ-13180
											, 'GeneDx'
											, 'Genomic Health'	-- PQ-13180
											, 'Genomic Testing Cooperative'
											, 'Genoptix'
											, 'Genpath'
											, 'Guardant Health'
											, 'Guardant'
											, 'Hematogenix Laboratory Services'
											, 'In-house pathology'
											, 'Inform Diagnostics'
											, 'Invitae'
											, 'Invivoscribe'	-- PQ-13180
											, 'LabCorp'
											, 'Liquid Genomics'
											, 'Mayo Clinic'
											, 'Miraca Life Sciences'
											, 'Moffitt Cancer Center'
											, 'Moffitt'
											, 'Myriad Genetic Laboratories'
											, 'Myriad Genetics'
											, 'Myvision'
											, 'NeoGenomics'
											, 'Oncology Genpath'
											, 'Other'
											, 'Paradigm Diagnostics'
											, 'Pathline Labs'
											, 'Quest Diagnostics'
											, 'Resolution Bioscience'	-- PQ-13180
											, 'siParadigm Diagnostic Informatics'
											, 'Sterling Pathology National Laboratories'
											, 'Tempus'
											, 'Thermofisher Scientific'
											, 'Unknown'
									) then TestingCompany
				when TestingCompany IS NULL THEN 'Unknown'
				else 'Other'
			end as TestingCompany  --  ExpertDetermination_GeoView_2020-10-13
		, cast(null as varchar(113)) as OrderingCombinedDivisionProviderMpi -- ExpertDetermination_GeoView_20200428
		, cast(null as varchar(20)) as TestingMethod -- Expert Determination - Geo View - 20200623 
		, SampleType
		, ServiceCodeDescriptionId  -- Expert Determination - Geo View - 20200814 
		, CASE 
			WHEN collate(CommercialTestName, 'en-ci') in (
											  'AML Panel'
											, 'Biodesix Lung Reflex'
											, 'BRACAnalysisCDx'
											, 'BRCANext'
											, 'BRCANext-Expanded'
											, 'BRCAplus'
											, 'Breast and Gyn Cancers Panel'
											, 'Breast Cancer Panel'
											, 'CancerNext'
											, 'Caris Molecular Intelligence'
											, 'CLL Panel'
											, 'Colorectal Cancer Panel'
											, 'EndoPredict'
											, 'FoundationACT'
											, 'FoundationOne CDx'
											, 'FoundationOne Heme'
											, 'FoundationOne Liquid CDx'
											, 'FoundationOne'
											, 'Gastric Cancer Panel'
											, 'GeneStrat'
											, 'Guardant 360'
											, 'Guardant360 CDx'
											, 'Hematology Profile'
											, 'LeukoVantage Acute myeloid leukemia'
											, 'LeukoVantage General Myeloid Panel'
											, 'LeukoVantage Myelodysplastic syndrome'
											, 'LeukoVantage Myeloproliferative neoplasms'
											, 'Lung Cancer Panel'
											, 'MDS Panel'
											, 'Melanoma Panel'
											, 'MI Profile'
											, 'MPN Panel'
											, 'Myelodysplastic Syndrome/Leukemia Panel'
											, 'myPath'
											, 'Myriad MyChoice'
											, 'Myriad MyRisk'
											, 'NeoLab Heme'
											, 'NeoLab Solid Tumor'
											, 'NeoTYPE Cancer Profiles'
											, 'Nervous System/Brain Cancer Panel'
											, 'NSCLC and CRC NGS Panel'
											, 'Oncomine Focus Panel'
											, 'Oncomine Plus'
											, 'Oncomine'
											, 'OnkoSight Advanced Hematologic NGS Panel'
											, 'OnkoSight Advanced Solid Tumor NGS Panel'
											, 'Other'
											, 'Pan-Myeloid Panel'
											, 'Pancreatic Cancer Panel'
											, 'PCDx'
											, 'Polaris'
											, 'Prostate Cancer Panel'
											, 'Renal/Urinary Tract Cancers Panel'
											, 'Sarcoma Panel'
											, 'Solid Tumor Mutation Panel'
											, 'Target Selector BRAF Mutation Test Kit'
											, 'Target Selector EGFR Mutation Test Kit'
											, 'Target Selector NGS Breast Panel'
											, 'Target Selector NGS Lung Panel'
											, 'Tempus xE'
											, 'Tempus xF'
											, 'Tempus xO'
											, 'Tempus xT'
											, 'Thyroid Cancer Panel'
											, 'TumorNext-HRD'
											, 'Unknown'
								 ) THEN CommercialTestName
			WHEN CommercialTestName IS NULL THEN 'Unknown'
			ELSE 'Other'
		  END AS CommercialTestName		--  ExpertDetermination_GeoView_2020-12-11
		  , SpecimenCollectionDate		--	ExpertDetermination_GeoView_2021-06-27
	from 
		CalculatedSet.fctPatientLab fpl
	where 
		-- ECOG = 5 ==> Patient Death.
		not (lower(fpl.testname) = 'ecog' and valueasint > 4)
	;