CREATE OR REPLACE SECURE VIEW PQDataWarehouse.fctPatientCancer
as
	select 
		Division
		, RecordInsertionDate
		, MpiId
		, CombinedDivisionMpi
		, CodeType
		, CancerCode
		, CancerCodeMajorCategory
		, DateFirstInstanceOfCancerCode
		, DateLastInstanceOfCancerCode
		, ConditionConceptId
		, MinConditionStartDate
		, MaxConditionStartDate
		, MinConditionEndDate
		, MaxConditionEndDate
		, DescriptionMajorClassification
		, DescriptionMinorClassification
		, CancerPrimarySecondaryClassification
		, ExactLocation
		, GeneralLocation
		, case
				when cast(null as varchar(15)) in ('Right', 'Left', 'Bilateral', 'None', 'Unknown') then cast(null as varchar(15))
				else cast(null as varchar(15))
			end as Laterality -- ExpertDetermination_GeoView_2020-03-02 - Included even though data not available yet, with coding rules.
		--  ExpertDetermination_GeoView_2020-03-02 - Omitted as not the right table for this concept - RecurrenceSite	The anatomic site in which the cancer recurred	See tab "Recurrence Site"	varchar 	20	
		--  ExpertDetermination_GeoView_2020-03-02 - Omitted as not the right table for this concept - RecurrenceDate	The date in which the cancer recurred	Date	date
		, RecordSourceIdentifier
		, CancerCodeMajorFirstDiagnosisDate
	from 
		CalculatedSet.fctPatientCancer
	;