CREATE OR REPLACE SECURE VIEW PQDataWarehouse.Control_ProcedureCode
AS
	SELECT 
		Code										-- Expert Determination GEO View 20210107
		,ProcedureName								-- Expert Determination GEO View 20210107
		,ProcedureDescription						-- Expert Determination GEO View 20210107
		,ProcedureSourceCodeType					-- Expert Determination GEO View 20210107
		,GeneralizedProcedureCategory				-- Expert Determination GEO View 20210107
	FROM
		CalculatedSet.Control_ProcedureCode
	;