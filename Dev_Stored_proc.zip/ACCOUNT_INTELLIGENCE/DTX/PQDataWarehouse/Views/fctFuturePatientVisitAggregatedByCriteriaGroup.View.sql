CREATE OR REPLACE SECURE VIEW PQDataWarehouse.fctFuturePatientVisitAggregatedByCriteriaGroup
as
	select 
		Division                             -- ExpertDetermination_GeoView_2019-10-18
		, RecordInsertionDate                -- ExpertDetermination_GeoView_2019-10-18
		, VisitDefinitionCriteriaGroupId     -- ExpertDetermination_GeoView_2019-10-18
		, MpiId                              -- ExpertDetermination_GeoView_2019-10-18
		, CombinedDivisionMpi                -- ExpertDetermination_GeoView_2019-10-18
		, TotalVisits                        -- ExpertDetermination_GeoView_2019-10-18
		, RecordSourceIdentifier             -- ExpertDetermination_GeoView_2020-10-13
	from 
		CalculatedSet.fctFuturePatientVisitAggregatedByCriteriaGroup
	;