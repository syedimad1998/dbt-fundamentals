CREATE OR REPLACE SECURE VIEW PQDataWarehouse.dimCost
as
	select 
		  Division				   -- ExpertDetermination_GeoView_2019-09-30
		, MpiId					   -- ExpertDetermination_GeoView_2019-09-30
		, CostId                   -- ExpertDetermination_GeoView_2020-08-14
		, DateOfService			   -- ExpertDetermination_GeoView_2019-09-30
		, TotalCharge			   -- ExpertDetermination_GeoView_2019-09-30
		, cast(null AS float) AS TotalCost
		, TotalPaid				   -- ExpertDetermination_GeoView_2019-09-30
		, cast(null AS float) AS PaidByPayer
		, cast(null AS float) AS PaidByPatient
		, GeneralizedPayerCategory  -- Cleaned in https://jira.integraconnect.com:8443/browse/PQ-6841 -- ExpertDetermination_GeoView_2020-02-24
		, IsOcmPayer                -- ExpertDetermination_GeoView_2020-08-14
		, RecordSourceIdentifier    -- ExpertDetermination_GeoView_2020-08-26
		, CombinedDivisionMpi		-- ExpertDetermination_GeoView_2020-10-13
	from
		CalculatedSet.dimCost
	;