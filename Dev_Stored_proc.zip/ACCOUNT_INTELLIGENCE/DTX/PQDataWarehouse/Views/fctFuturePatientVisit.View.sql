CREATE OR REPLACE SECURE VIEW PQDataWarehouse.fctFuturePatientVisit
as
	select                               -- ExpertDetermination_GeoView_2019-10-18
		Division                         -- ExpertDetermination_GeoView_2019-10-18
		, RecordInsertionDate            -- ExpertDetermination_GeoView_2019-10-18
		, VisitDefinitionCriteriaId      -- ExpertDetermination_GeoView_2019-10-18
		, MpiId                          -- ExpertDetermination_GeoView_2019-10-18
		, CombinedDivisionMpi            -- ExpertDetermination_GeoView_2019-10-18
		, Year                         -- ExpertDetermination_GeoView_2019-10-18
		, Quarter                        -- ExpertDetermination_GeoView_2019-10-18
		, TotalVisits                    -- ExpertDetermination_GeoView_2019-10-18
		, RecordSourceIdentifier		 -- ExpertDetermination_GeoView_2020-08-26
	from 
		CalculatedSet.fctFuturePatientVisit
	;