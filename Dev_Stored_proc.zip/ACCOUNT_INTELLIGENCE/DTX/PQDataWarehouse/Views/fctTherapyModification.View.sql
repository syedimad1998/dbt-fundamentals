CREATE OR REPLACE SECURE VIEW PQDataWarehouse.fctTherapyModification
as
	select
		  Division												-- ExpertDetermination_GeoView_20200428
		, RecordInsertionDate									-- ExpertDetermination_GeoView_20200428
		, MpiId													-- ExpertDetermination_GeoView_20200428
		, CombinedDivisionMpi									-- ExpertDetermination_GeoView_20200428
		, ChangeDate											-- ExpertDetermination_GeoView_20200428
		, CareType												-- ExpertDetermination_GeoView_20200428
		, ChangeType											-- ExpertDetermination_GeoView_20200428
		, case when replace(collate(ChangeReasonCSV, 'en-ci')
							, 'expired medication', 'cat')  	
					like '%expired%' 							-- PQ-11707
				then 'Other reason' else ChangeReasonCSV  
			end as ChangeReasonCSV								-- ExpertDetermination_GeoView_20200428
		, RelevantTherapyName									-- ExpertDetermination_GeoView_20200428
		-- PQ-11506 20200923 - BEGIN
		-- Data smoothing until harmonizer can be adjusted to remove 'extra data' from this column.
		, trim(substring(FromAsString, 1, case when FromAsString like '%|%' then charindex('|', FromAsString, 1)-1 else 999999 end))  as FromAsString
		-- Comment out previous column for now.
		--, FromAsString										-- ExpertDetermination_GeoView_20200428
		-- PQ-11506 20200923 - END
		, ToAsString											-- ExpertDetermination_GeoView_20200428
		, FromTreatmentIntention								-- ExpertDetermination_GeoView_20200428
		, cast(null as varchar(50)) as ToTreatmentIntention   -- ExpertDetermination_GeoView_20200428
		, FromAsNumber										-- ExpertDetermination_GeoView_20200428
		, ToAsNumber											-- ExpertDetermination_GeoView_20200428
		, RecordSourceIdentifier								-- ExpertDetermination_GeoView_20200428
		, FromDate												-- ExpertDetermination_GeoView_20221010
		, ToDate												-- ExpertDetermination_GeoView_20221010
	from 
		Calculatedset.fctTherapyModification
	;