CREATE OR REPLACE SECURE VIEW PQDataWarehouse.dimPatientPayerPlanDetail
as
	select 
		Division
		, RecordInsertionDate
		, MpiId
		, CombinedDivisionMpi
		, PayerPlanPeriodId
		, PayerPlanPeriodStartDate
		, PayerPlanPeriodEnddate
		, PayerPrimaryIndicator
		, DeductibleAmount
		-- , PayerName	   - We can't show as they violate the rules from expert, PayerCategory will abide by such rules.
		-- , PayerType	   - We can't show as they violate the rules from expert, PayerCategory will abide by such rules.
		, PayerCategory				-- ExpertDetermination_GeoView_2019-10-18
		, RecordSourceIdentifier	-- ExpertDetermination_GeoView_2020-08-26
	from
		calculatedset.dimPatientPayerPlanDetail
	;