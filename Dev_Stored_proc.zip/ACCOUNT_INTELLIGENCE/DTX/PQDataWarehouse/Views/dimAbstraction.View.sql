CREATE OR REPLACE SECURE VIEW PQDataWarehouse.dimAbstraction
as
	select 
		AbstractionTypeId             -- ExpertDetermination_GeoView_2020-03-02
		, Name                      -- ExpertDetermination_GeoView_2020-03-02
		, Description               -- ExpertDetermination_GeoView_2020-03-02
	from
		CalculatedSet.dimAbstraction
	;