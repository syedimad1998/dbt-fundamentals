CREATE OR REPLACE SECURE VIEW PQDataWarehouse.fctPatientTargetedTherapy
as
	select 
		  Division                                                        --  ExpertDetermination_GeoView_2020-03-02
		, RecordInsertionDate                                             --  ExpertDetermination_GeoView_2020-03-02
		, MpiId                                                           --  ExpertDetermination_GeoView_2020-03-02
		, CombinedDivisionMpi                                             --  ExpertDetermination_GeoView_2020-03-02
		, ConditionType                                                   --  ExpertDetermination_GeoView_2020-03-02
		, ConditionDescription                                            --  ExpertDetermination_GeoView_2020-03-02
		, ConditionSampleIcdCode                                          --  ExpertDetermination_GeoView_2020-03-02
		, ConditionDate                                                   --  ExpertDetermination_GeoView_2020-03-02
		, TherapyProvided                                                 --  ExpertDetermination_GeoView_2020-03-02
		, TherapyStartDate                                                --  ExpertDetermination_GeoView_2020-03-02
		, TherapyEndDate                                                  --  ExpertDetermination_GeoView_2020-03-02
		, IsPositiveForConditionIsPositiveForTargetTherapy                --  ExpertDetermination_GeoView_2020-03-02
		, IsPositiveForConditionIsNegativeForTargetTherapy                --  ExpertDetermination_GeoView_2020-03-02
		, IsNegativeForConditionIsPositiveForTargetTherapy                --  ExpertDetermination_GeoView_2020-03-02
		, RecordSourceIdentifier                                          --  ExpertDetermination_GeoView_2020-03-02
		, case
				when cast(null as varchar(20)) in ('Foundation', 'Guardant 360', 'Neo Genomics', 'Claris', 'Tempus', 'Other', 'Unknown') then cast(null as varchar(20))
				else cast(null as varchar(20))
			end as TestingCompany  --  ExpertDetermination_GeoView_2020-03-02
	from 
		CalculatedSet.fctPatientTargetedTherapy
	;