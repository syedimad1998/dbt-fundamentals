CREATE OR REPLACE SECURE VIEW PQDataWarehouse.fctPatientVital
as
	select 
		Division
		, RecordInsertionDate
		, MpiId
		, CombinedDivisionMpi
		, TestDate
		, TestName
		, ValueAsNumber
		, UnitValue
		, NormalRangeLow
		, NormalRangeHigh
		, cast('' as varchar(10)) as RecordSourceIdentifier  -- ExpertDetermination_GeoView_20200428
	from 
		CalculatedSet.fctPatientVital
	;