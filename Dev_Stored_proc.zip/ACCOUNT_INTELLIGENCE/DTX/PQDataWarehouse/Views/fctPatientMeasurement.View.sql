CREATE OR REPLACE SECURE VIEW PQDataWarehouse.fctPatientMeasurement
as
	select                                                        -- ExpertDetermination_GeoView_20200428
		  Division                  -- ExpertDetermination_GeoView_20200428
		, RecordInsertionDate        -- ExpertDetermination_GeoView_20200428
		, MpiId                              -- ExpertDetermination_GeoView_20200428
		, CombinedDivisionMpi       -- ExpertDetermination_GeoView_20200428
		, MeasurementDate                 -- ExpertDetermination_GeoView_20200428
		, MeasurementCategory      -- ExpertDetermination_GeoView_20200428
		, AnatomicSiteLocation     -- ExpertDetermination_GeoView_20200428
		, ObservationMethod        -- ExpertDetermination_GeoView_20200428
		, MeasurementClass         -- ExpertDetermination_GeoView_20200428
		, ValueAsString              -- ExpertDetermination_GeoView_20200428
		, Unit                     -- ExpertDetermination_GeoView_20200428
		, ValueAsInt                         -- ExpertDetermination_GeoView_20200428
		, ValueAsFloat                     -- ExpertDetermination_GeoView_20200428
		, RecordSourceIdentifier     -- ExpertDetermination_GeoView_20200428
	from
		CalculatedSet.fctPatientMeasurement
	;