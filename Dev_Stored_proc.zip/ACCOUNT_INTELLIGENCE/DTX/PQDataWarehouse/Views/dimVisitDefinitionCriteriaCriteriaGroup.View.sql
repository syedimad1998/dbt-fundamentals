CREATE OR REPLACE SECURE VIEW PQDataWarehouse.dimVisitDefinitionCriteriaCriteriaGroup
as
	select 
		VisitDefinitionCriteriaGroupId
		, VisitDefinitionCriteriaId
	from
		CalculatedSet.dimVisitDefinitionCriteriaCriteriaGroup
	;