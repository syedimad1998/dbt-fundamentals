CREATE OR REPLACE SECURE VIEW PQDataWarehouse.fctPatientAdverseEvent
as
	select 
		Division
		, RecordInsertionDate
		, MpiId
		, CombinedDivisionMpi
		, AdverseEventDescription
		, SourceLocation
		, LabSpecificTestName
		, SourceValue -- Cleansed via PQ-6836
		, SourceUnit
		, SourceValueComparison
		, EventDateInstance
		, EventObserver             -- ExpertDetermination_GeoView_20200428
		, QualitativeAssessment     -- ExpertDetermination_GeoView_20200428
		, Grade                   -- ExpertDetermination_GeoView_20200428
		, SymptomCategory          -- ExpertDetermination_GeoView_20200428
		, AdverseEventPresent                  -- ExpertDetermination_GeoView_20200428
		, RecordSourceIdentifier    -- ExpertDetermination_GeoView_20200428
	from 
		CalculatedSet.fctPatientAdverseEvent
	;