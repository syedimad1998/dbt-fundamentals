CREATE OR REPLACE SECURE VIEW PQDataWarehouse.dimPatientRiskScore
as
	select 
		Division                   -- ExpertDetermination_GeoView_2019-10-18
		, RecordInsertionDate      -- ExpertDetermination_GeoView_2019-10-18
		, MpiID                    -- ExpertDetermination_GeoView_2019-10-18
		, CombinedDivisionMpi      -- ExpertDetermination_GeoView_2019-10-18
		, RiskName                 -- ExpertDetermination_GeoView_2019-10-18
		, ValueAsInt               -- ExpertDetermination_GeoView_2019-10-18
		, ValueAsFloat             -- ExpertDetermination_GeoView_2019-10-18
		, ValueAsString            -- ExpertDetermination_GeoView_2019-10-18
		, TestDate                 -- ExpertDetermination_GeoView_2019-10-18
		, RecordSourceIdentifier   -- ExpertDetermination_GeoView_2020-08-26
	from
		CalculatedSet.dimPatientRiskScore
	;