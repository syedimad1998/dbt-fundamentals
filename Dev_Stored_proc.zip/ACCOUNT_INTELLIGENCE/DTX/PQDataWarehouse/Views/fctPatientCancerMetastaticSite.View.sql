CREATE OR REPLACE SECURE VIEW PQDataWarehouse.fctPatientCancerMetastaticSite
as
	select 
		Division
		, RecordInsertionDate
		, MpiId
		, CombinedDivisionMpi
		, DateFirstProofOfMetastaticSpread
		, DateLastProofOfMetastaticSpread
		, SiteLocation
		, RolledUpGeneralSiteLocation
		, SiteGrouping --  ExpertDetermination_GeoView_2020-03-02
		, case
				when cast(null as varchar(10)) in ('Invasive', 'InSitu') then cast(null as varchar(10))
				else cast(null as varchar(10))
			end as InvasiveStatus  --  ExpertDetermination_GeoView_2020-03-02
		--  ExpertDetermination_GeoView_2020-03-02 - Omitted as not the right table for this concept - MetastasicSiteAtDiagnosis	the distant site in which the cancer has spread from the primary site	See tab "Metastatic Site At Diagnosis"	varchar 	20			
		, RecordSourceIdentifier	-- ExpertDetermination_GeoView_2020-08-26
	from
		CalculatedSet.fctPatientCancerMetastaticSite
	;