CREATE OR REPLACE SECURE VIEW PQDataWarehouse.fctPatientGeneAbnormality
as
	select 		
		Division
		, RecordInsertionDate
		, MpiId
		, CombinedDivisionMpi
		, TestDate
		, GeneticAbnormalityType
		, Gene
		, RawGene
		, GeneDefinition
		, AbnormalityFinding
		, IsCancerRelated
		, SourceLocation
		, RecordSourceIdentifier   -- ExpertDetermination_GeoView_2020-07-16
		-- , Context - Impossible to clean of free text as it is, by design, free text.  Had to be removed.
		--  ExpertDetermination_GeoView_2020-03-02 - Omitted as not the right table for this concept - PD-L1TypesCells	Types of PD-L1 cells tested. 	Tissue, Cytology, Unknown	varchar	25	
		, GeneGranularity			  --ExpertDetermination_GeoView_2021-03-25
		, Mutation					  --ExpertDetermination_GeoView_2021-06-07	
		, RawMutation				  --ExpertDetermination_GeoView_2021-06-07
	from
		CalculatedSet.fctPatientGeneAbnormality
	;