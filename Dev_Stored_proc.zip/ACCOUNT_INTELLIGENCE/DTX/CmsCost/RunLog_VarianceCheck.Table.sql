CREATE TABLE CmsCost.RunLog_VarianceCheck(
    RecordInsertionDateTime datetime (8) not null
    , Division varchar (100) not null
    , TableName varchar (50) not null
    , CurrentCount number not null
    , NewCount number not null
    , AcceptableChange boolean not null
);