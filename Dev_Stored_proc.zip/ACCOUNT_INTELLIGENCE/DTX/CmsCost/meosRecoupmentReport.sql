CREATE OR REPLACE TABLE CmsCost.meosRecoupmentReport
(
	Division VARCHAR(100) NOT NULL
	, RecordInsertionDate datetime(7) NOT NULL
	, MpiId INT NOT NULL
	, CombinedDivisionMpi VARCHAR(128) NOT NULL
	, CCW_Beneficiary_ID VARCHAR(500) NULL
	, CCW_Claim_ID VARCHAR(500) NULL
	, Claim_Control_Number VARCHAR(500) NULL
	, Claim_Line_Number VARCHAR(500) NULL
	, Date_of_Birth DATE NULL
	, First_Name VARCHAR(500) NULL
	, HICN VARCHAR(500) NULL
	, Last_Name VARCHAR(500) NULL
	, MBI VARCHAR(500) NULL
	, OCM_Episode_ID VARCHAR(500) NULL
	, Payment_Amount VARCHAR(500) NULL
	, Performing_NPI VARCHAR(500) NULL
	, Procedure_Code VARCHAR(500) NULL
	, Service_Date DATE NULL
	, TIN VARCHAR(500) NULL
	, Recoupment_Reason VARCHAR(500) NULL
	, Recoupment_Reason_Detail VARCHAR(500) NULL
	, Eligibility_Assessment_Detail VARCHAR(500) NULL
	, Episodes_Initiating_MEOS_Eligibility_Assessment VARCHAR(500) NULL
	, Eligibility_Assessment VARCHAR(500) NULL
	, Perf_Period VARCHAR(20) NULL
);