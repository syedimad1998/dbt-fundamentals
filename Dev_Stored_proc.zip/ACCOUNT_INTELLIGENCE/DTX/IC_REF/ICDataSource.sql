CREATE TABLE IF NOT EXISTS IC_REF.ICDataSource
(
	DataSourceTypeId VARCHAR(300) NOT NULL  COMMENT 'Data Source Type Id is defined by the type of source system or file type from which the customer data originates. It is the third segment of four digits have designation of the source system or file type: Series 1000 = EMR/EHR/HIE Series 2000 = Practice Management (PM) Series 3000 = Pharmacy, Lab, Tumor Registry, etc. data sources Series 4000 = Payer (Anthem, CMS) Series 5000 = Curation, NLP, OCR Series 6000 = Custom Files not included in Series 1000 through 5000',
	DataSourceTypeName VARCHAR(300) NULL  COMMENT 'Data Source Type Name is a friendly name associated with the corresponding Id that identifies the type of source system or file type from which the customer data originates. Ex: EMR/EHR/HIE, Practice Management (PM) etc.'
);

ALTER TABLE IC_REF.ICDataSource
	ADD CONSTRAINT XPKICDataSource PRIMARY KEY (DataSourceTypeId);