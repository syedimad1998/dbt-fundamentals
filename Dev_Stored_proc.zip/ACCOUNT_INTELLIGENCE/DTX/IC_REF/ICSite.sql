CREATE TABLE IF NOT EXISTS IC_REF.ICSite
(
	ICSiteId VARCHAR(300) NOT NULL  COMMENT 'IC Site Id is an IC generated ID to uniquely identify the combination of Data Source System ID, Data Source System Name & Data Site ID. This will permit us to track and identiy all the data coming in to IC1 from multiple clients and sources.',
	CustomerId VARCHAR(300) NULL  COMMENT 'Customer Id Or Client Id is defined as the parent owner of a single or multiple practices or site locations. The first four digits of the ICSiteID will indicate the Customer/Client ID. The existing designation of DF-XXX will be modified to represent the new ICSiteId. Example: Current = DF-135; Future ICSiteId = 0135_XXXXX_XXXX.',
	PracticeCaresiteId VARCHAR(300) NULL  COMMENT 'Practice Caresite Id (Or Practice/Care Site/Location Identifier) is defined and assigned for a designated practice/site under a client contract/SOW. It is the second segment of five digits of the ICSiteID indicating one specific practice location. A practice may have multiple locations; each will have a specific location identifier. Example: Current = DF-135 Future ICSiteId = 0135_10001_XXXX   = Practice Location #1 Future ICSiteId = 0135_10002_XXXX   = Practice Location #2 Future ICSiteId = 0135_20000_XXXX   = Practice Location #3 Future ICSiteId = 0135_30000_XXXX   = Practice Location #4',
	DataSourceTypeId VARCHAR(300) NULL  COMMENT 'Data Source Type Id is defined by the type of source system or file type from which the customer data originates. It is the third segment of four digits have designation of the source system or file type: Series 1000 = EMR/EHR/HIE Series 2000 = Practice Management (PM) Series 3000 = Pharmacy, Lab, Tumor Registry, etc. data sources Series 4000 = Payer (Anthem, CMS) Series 5000 = Curation, NLP, OCR Series 6000 = Custom Files not included in Series 1000 through 5000',
	ActiveFlag CHAR NOT NULL  COMMENT 'Active Flag is an Y/N indicator that will identify whether the record identified by ICSiteId is active or not, whether any data needs to be expected to be received from that site.'
);

ALTER TABLE IC_REF.ICSite
	ADD CONSTRAINT PKPractice PRIMARY KEY (ICSiteId);

ALTER TABLE IC_REF.ICSite
	ADD CONSTRAINT R346 FOREIGN KEY (CustomerId) REFERENCES IC_REF.ICCustomer (CustomerId);

ALTER TABLE IC_REF.ICSite
	ADD CONSTRAINT R347 FOREIGN KEY (PracticeCaresiteId) REFERENCES IC_REF.ICPracticeCaresite (PracticeCaresiteId);

ALTER TABLE IC_REF.ICSite
	ADD CONSTRAINT R348 FOREIGN KEY (DataSourceTypeId) REFERENCES IC_REF.ICDataSource (DataSourceTypeId);