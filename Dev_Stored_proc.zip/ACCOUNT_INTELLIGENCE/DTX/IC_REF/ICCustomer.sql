CREATE TABLE IF NOT EXISTS IC_REF.ICCustomer
(
	CustomerId VARCHAR(300) NOT NULL  COMMENT 'Customer Id Or Client Id is defined as the parent owner of a single or multiple practices or site locations. The first four digits of the ICSiteID will indicate the Customer/Client ID. The existing designation of DF-XXX will be modified to represent the new ICSiteId. Example: Current = DF-135; Future ICSiteId = 0135_XXXXX_XXXX.',
	CustomerName VARCHAR(300) NULL  COMMENT 'Customer Name is the friendly name corresponding to the Customer Id and is the parent owner of a single or multiple practices or site locations. Ex: University Of Pittsburgh Medical Center.',
	ActiveFlag CHAR NOT NULL  COMMENT 'Active Flag is an Y/N indicator that will identify whether the IC Customer is still active or the contract has been terminated. If inactive, it will imply that all ICSite records should be inactive.'
);

ALTER TABLE IC_REF.ICCustomer
	ADD CONSTRAINT XPKICCustomer PRIMARY KEY (CustomerId);