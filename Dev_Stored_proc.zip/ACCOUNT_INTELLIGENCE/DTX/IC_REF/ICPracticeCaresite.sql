CREATE TABLE IF NOT EXISTS IC_REF.ICPracticeCaresite
(
	PracticeCaresiteId VARCHAR(300) NOT NULL  COMMENT 'Practice Caresite Id (Or Practice/Care Site/Location Identifier) is defined and assigned for a designated practice/site under a client contract/SOW. It is the second segment of five digits of the ICSiteID indicating one specific practice location. A practice may have multiple locations; each will have a specific location identifier. Example: Current = DF-135 Future ICSiteId = 0135_10001_XXXX   = Practice Location #1 Future ICSiteId = 0135_10002_XXXX   = Practice Location #2 Future ICSiteId = 0135_20000_XXXX   = Practice Location #3 Future ICSiteId = 0135_30000_XXXX   = Practice Location #4',
	PracticeCaresiteName VARCHAR(300) NULL  COMMENT 'Practice Caresite Name is a friendly name associated with the corresponding Id (if available) that specifically identifies a Practice/Care Site/Location by name.'
);

ALTER TABLE IC_REF.ICPracticeCaresite
	ADD CONSTRAINT XPKICPracticeCaresite PRIMARY KEY (PracticeCaresiteId);