
-- delete old concepts -- concepts <2000000000
DELETE FROM PROD_DF_000.OMOP.CONCEPT WHERE CONCEPT_ID < '2000000000';

-- insert all concepts from stage concept table (PROD_DF_000.STAGE.CONCEPT) with latest Athena concepts
INSERT INTO PROD_DF_000.OMOP.CONCEPT
	(concept_id,concept_name,domain_id,vocabulary_id,concept_class_id,standard_concept,concept_code,valid_start_date,valid_end_date,INVALID_REASON)
SELECT DISTINCT 
       concept_id,concept_name,domain_id,vocabulary_id,concept_class_id,standard_concept,concept_code,valid_start_date,valid_end_date,COALESCE(invalid_reason,'') AS INVALID_REASON
FROM PROD_DF_000.STAGE.CONCEPT; 

-- insert new cost concepts
INSERT INTO PROD_DF_000.OMOP.CONCEPT(concept_id,concept_name,domain_id,vocabulary_id,concept_class_id,standard_concept,concept_code,valid_start_date,valid_end_date,invalid_reason)
SELECT '2455000001','Amount paid by the patient or reimbursed by the payer','Type Concept','Cost Type','Cost Type',NULL,'ICS0105','2023-01-01','2099-12-31','';
	   
INSERT INTO PROD_DF_000.OMOP.CONCEPT(concept_id,concept_name,domain_id,vocabulary_id,concept_class_id,standard_concept,concept_code,valid_start_date,valid_end_date,invalid_reason)
SELECT '2455000002','Amount charged to the patient or the payer by the provider, list price','Type Concept','Cost Type','Cost Type',NULL,'ICS0106','2023-01-01','2099-12-31','';


-- insert new concepts into all QA databases

CREATE OR REPLACE TABLE PROD_DF_100.OMOP.concept AS SELECT * FROM PROD_DF_000.OMOP.concept;

CREATE OR REPLACE TABLE PROD_DF_101.OMOP.concept AS SELECT * FROM PROD_DF_000.OMOP.concept;

CREATE OR REPLACE TABLE PROD_DF_102.OMOP.concept AS SELECT * FROM PROD_DF_000.OMOP.concept;

CREATE OR REPLACE TABLE PROD_DF_103.OMOP.concept AS SELECT * FROM PROD_DF_000.OMOP.concept;

CREATE OR REPLACE TABLE PROD_DF_105.OMOP.concept AS SELECT * FROM PROD_DF_000.OMOP.concept;

CREATE OR REPLACE TABLE PROD_DF_107.OMOP.concept AS SELECT * FROM PROD_DF_000.OMOP.concept;

CREATE OR REPLACE TABLE PROD_DF_111.OMOP.concept AS SELECT * FROM PROD_DF_000.OMOP.concept;

CREATE OR REPLACE TABLE PROD_DF_112.OMOP.concept AS SELECT * FROM PROD_DF_000.OMOP.concept;

CREATE OR REPLACE TABLE PROD_DF_114.OMOP.concept AS SELECT * FROM PROD_DF_000.OMOP.concept;

CREATE OR REPLACE TABLE PROD_DF_117.OMOP.concept AS SELECT * FROM PROD_DF_000.OMOP.concept;

CREATE OR REPLACE TABLE PROD_DF_119.OMOP.concept AS SELECT * FROM PROD_DF_000.OMOP.concept;

CREATE OR REPLACE TABLE PROD_DF_121.OMOP.concept AS SELECT * FROM PROD_DF_000.OMOP.concept;

CREATE OR REPLACE TABLE PROD_DF_123.OMOP.concept AS SELECT * FROM PROD_DF_000.OMOP.concept;

CREATE OR REPLACE TABLE PROD_DF_125.OMOP.concept AS SELECT * FROM PROD_DF_000.OMOP.concept;

CREATE OR REPLACE TABLE PROD_DF_127.OMOP.concept AS SELECT * FROM PROD_DF_000.OMOP.concept;

CREATE OR REPLACE TABLE PROD_DF_130.OMOP.concept AS SELECT * FROM PROD_DF_000.OMOP.concept;

CREATE OR REPLACE TABLE PROD_DF_131.OMOP.concept AS SELECT * FROM PROD_DF_000.OMOP.concept;

CREATE OR REPLACE TABLE PROD_DF_133.OMOP.concept AS SELECT * FROM PROD_DF_000.OMOP.concept;

CREATE OR REPLACE TABLE PROD_DF_134.OMOP.concept AS SELECT * FROM PROD_DF_000.OMOP.concept;

CREATE OR REPLACE TABLE PROD_DF_136.OMOP.concept AS SELECT * FROM PROD_DF_000.OMOP.concept;

CREATE OR REPLACE TABLE PROD_DF_137.OMOP.concept AS SELECT * FROM PROD_DF_000.OMOP.concept;

CREATE OR REPLACE TABLE PROD_DF_138.OMOP.concept AS SELECT * FROM PROD_DF_000.OMOP.concept;

CREATE OR REPLACE TABLE PROD_DF_139.OMOP.concept AS SELECT * FROM PROD_DF_000.OMOP.concept;

CREATE OR REPLACE TABLE PROD_DF_140.OMOP.concept AS SELECT * FROM PROD_DF_000.OMOP.concept;

CREATE OR REPLACE TABLE PROD_DF_141.OMOP.concept AS SELECT * FROM PROD_DF_000.OMOP.concept;

CREATE OR REPLACE TABLE PROD_DF_142.OMOP.concept AS SELECT * FROM PROD_DF_000.OMOP.concept;

CREATE OR REPLACE TABLE PROD_DF_143.OMOP.concept AS SELECT * FROM PROD_DF_000.OMOP.concept;

CREATE OR REPLACE TABLE PROD_DF_999.OMOP.concept AS SELECT * FROM PROD_DF_000.OMOP.concept;
	   