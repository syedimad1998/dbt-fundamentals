
-- insert relation for the new concepts
INSERT INTO PROD_DF_000.OMOP.concept_relationship(concept_id_1,concept_id_2,relationship_id,valid_start_date,valid_end_date,invalid_reason)
SELECT '2000050038','2000000482','CPT mapped to TOS','1970-01-01','2099-12-31','';

INSERT INTO PROD_DF_000.OMOP.concept_relationship(concept_id_1,concept_id_2,relationship_id,valid_start_date,valid_end_date,invalid_reason)
SELECT '2000050039','2000000482','CPT mapped to TOS','1970-01-01','2099-12-31','';
	   
-- insert new concept relationships into all PROD databases
CREATE OR REPLACE TABLE PROD_DF_100.OMOP.concept_relationship AS SELECT * FROM PROD_DF_000.OMOP.concept_relationship;

CREATE OR REPLACE TABLE PROD_DF_101.OMOP.concept_relationship AS SELECT * FROM PROD_DF_000.OMOP.concept_relationship;

CREATE OR REPLACE TABLE PROD_DF_102.OMOP.concept_relationship AS SELECT * FROM PROD_DF_000.OMOP.concept_relationship;

CREATE OR REPLACE TABLE PROD_DF_103.OMOP.concept_relationship AS SELECT * FROM PROD_DF_000.OMOP.concept_relationship;

CREATE OR REPLACE TABLE PROD_DF_105.OMOP.concept_relationship AS SELECT * FROM PROD_DF_000.OMOP.concept_relationship;

CREATE OR REPLACE TABLE PROD_DF_107.OMOP.concept_relationship AS SELECT * FROM PROD_DF_000.OMOP.concept_relationship;

CREATE OR REPLACE TABLE PROD_DF_111.OMOP.concept_relationship AS SELECT * FROM PROD_DF_000.OMOP.concept_relationship;

CREATE OR REPLACE TABLE PROD_DF_112.OMOP.concept_relationship AS SELECT * FROM PROD_DF_000.OMOP.concept_relationship;

CREATE OR REPLACE TABLE PROD_DF_114.OMOP.concept_relationship AS SELECT * FROM PROD_DF_000.OMOP.concept_relationship;

CREATE OR REPLACE TABLE PROD_DF_117.OMOP.concept_relationship AS SELECT * FROM PROD_DF_000.OMOP.concept_relationship;

CREATE OR REPLACE TABLE PROD_DF_119.OMOP.concept_relationship AS SELECT * FROM PROD_DF_000.OMOP.concept_relationship;

CREATE OR REPLACE TABLE PROD_DF_120.OMOP.concept_relationship AS SELECT * FROM PROD_DF_000.OMOP.concept_relationship;

CREATE OR REPLACE TABLE PROD_DF_121.OMOP.concept_relationship AS SELECT * FROM PROD_DF_000.OMOP.concept_relationship;

CREATE OR REPLACE TABLE PROD_DF_123.OMOP.concept_relationship AS SELECT * FROM PROD_DF_000.OMOP.concept_relationship;

CREATE OR REPLACE TABLE PROD_DF_125.OMOP.concept_relationship AS SELECT * FROM PROD_DF_000.OMOP.concept_relationship;

CREATE OR REPLACE TABLE PROD_DF_127.OMOP.concept_relationship AS SELECT * FROM PROD_DF_000.OMOP.concept_relationship;

CREATE OR REPLACE TABLE PROD_DF_130.OMOP.concept_relationship AS SELECT * FROM PROD_DF_000.OMOP.concept_relationship;

CREATE OR REPLACE TABLE PROD_DF_131.OMOP.concept_relationship AS SELECT * FROM PROD_DF_000.OMOP.concept_relationship;

CREATE OR REPLACE TABLE PROD_DF_133.OMOP.concept_relationship AS SELECT * FROM PROD_DF_000.OMOP.concept_relationship;

CREATE OR REPLACE TABLE PROD_DF_134.OMOP.concept_relationship AS SELECT * FROM PROD_DF_000.OMOP.concept_relationship;

CREATE OR REPLACE TABLE PROD_DF_135.OMOP.concept_relationship AS SELECT * FROM PROD_DF_000.OMOP.concept_relationship;

CREATE OR REPLACE TABLE PROD_DF_136.OMOP.concept_relationship AS SELECT * FROM PROD_DF_000.OMOP.concept_relationship;

CREATE OR REPLACE TABLE PROD_DF_137.OMOP.concept_relationship AS SELECT * FROM PROD_DF_000.OMOP.concept_relationship;

CREATE OR REPLACE TABLE PROD_DF_138.OMOP.concept_relationship AS SELECT * FROM PROD_DF_000.OMOP.concept_relationship;

CREATE OR REPLACE TABLE PROD_DF_139.OMOP.concept_relationship AS SELECT * FROM PROD_DF_000.OMOP.concept_relationship;

CREATE OR REPLACE TABLE PROD_DF_140.OMOP.concept_relationship AS SELECT * FROM PROD_DF_000.OMOP.concept_relationship;

CREATE OR REPLACE TABLE PROD_DF_141.OMOP.concept_relationship AS SELECT * FROM PROD_DF_000.OMOP.concept_relationship;

CREATE OR REPLACE TABLE PROD_DF_142.OMOP.concept_relationship AS SELECT * FROM PROD_DF_000.OMOP.concept_relationship;

CREATE OR REPLACE TABLE PROD_DF_999.OMOP.concept_relationship AS SELECT * FROM PROD_DF_000.OMOP.concept_relationship;


-- insert new concept relationships into all DEV databases
CREATE OR REPLACE TABLE DEV_DF_000.OMOP.concept_relationship AS SELECT * FROM PROD_DF_000.OMOP.concept_relationship;

CREATE OR REPLACE TABLE DEV_DF_101.OMOP.concept_relationship AS SELECT * FROM PROD_DF_000.OMOP.concept_relationship;

CREATE OR REPLACE TABLE DEV_DF_102.OMOP.concept_relationship AS SELECT * FROM PROD_DF_000.OMOP.concept_relationship;

CREATE OR REPLACE TABLE DEV_DF_103.OMOP.concept_relationship AS SELECT * FROM PROD_DF_000.OMOP.concept_relationship;

CREATE OR REPLACE TABLE DEV_DF_105.OMOP.concept_relationship AS SELECT * FROM PROD_DF_000.OMOP.concept_relationship;

CREATE OR REPLACE TABLE DEV_DF_107.OMOP.concept_relationship AS SELECT * FROM PROD_DF_000.OMOP.concept_relationship;

CREATE OR REPLACE TABLE DEV_DF_111.OMOP.concept_relationship AS SELECT * FROM PROD_DF_000.OMOP.concept_relationship;

CREATE OR REPLACE TABLE DEV_DF_112.OMOP.concept_relationship AS SELECT * FROM PROD_DF_000.OMOP.concept_relationship;

CREATE OR REPLACE TABLE DEV_DF_114.OMOP.concept_relationship AS SELECT * FROM PROD_DF_000.OMOP.concept_relationship;

CREATE OR REPLACE TABLE DEV_DF_117.OMOP.concept_relationship AS SELECT * FROM PROD_DF_000.OMOP.concept_relationship;

CREATE OR REPLACE TABLE DEV_DF_119.OMOP.concept_relationship AS SELECT * FROM PROD_DF_000.OMOP.concept_relationship;

CREATE OR REPLACE TABLE DEV_DF_120.OMOP.concept_relationship AS SELECT * FROM PROD_DF_000.OMOP.concept_relationship;

CREATE OR REPLACE TABLE DEV_DF_121.OMOP.concept_relationship AS SELECT * FROM PROD_DF_000.OMOP.concept_relationship;

CREATE OR REPLACE TABLE DEV_DF_123.OMOP.concept_relationship AS SELECT * FROM PROD_DF_000.OMOP.concept_relationship;

CREATE OR REPLACE TABLE DEV_DF_125.OMOP.concept_relationship AS SELECT * FROM PROD_DF_000.OMOP.concept_relationship;

CREATE OR REPLACE TABLE DEV_DF_127.OMOP.concept_relationship AS SELECT * FROM PROD_DF_000.OMOP.concept_relationship;

CREATE OR REPLACE TABLE DEV_DF_130.OMOP.concept_relationship AS SELECT * FROM PROD_DF_000.OMOP.concept_relationship;

CREATE OR REPLACE TABLE DEV_DF_131.OMOP.concept_relationship AS SELECT * FROM PROD_DF_000.OMOP.concept_relationship;

CREATE OR REPLACE TABLE DEV_DF_133.OMOP.concept_relationship AS SELECT * FROM PROD_DF_000.OMOP.concept_relationship;

CREATE OR REPLACE TABLE DEV_DF_134.OMOP.concept_relationship AS SELECT * FROM PROD_DF_000.OMOP.concept_relationship;

CREATE OR REPLACE TABLE DEV_DF_135.OMOP.concept_relationship AS SELECT * FROM PROD_DF_000.OMOP.concept_relationship;

CREATE OR REPLACE TABLE DEV_DF_136.OMOP.concept_relationship AS SELECT * FROM PROD_DF_000.OMOP.concept_relationship;

CREATE OR REPLACE TABLE DEV_DF_137.OMOP.concept_relationship AS SELECT * FROM PROD_DF_000.OMOP.concept_relationship;

CREATE OR REPLACE TABLE DEV_DF_138.OMOP.concept_relationship AS SELECT * FROM PROD_DF_000.OMOP.concept_relationship;

CREATE OR REPLACE TABLE DEV_DF_139.OMOP.concept_relationship AS SELECT * FROM PROD_DF_000.OMOP.concept_relationship;

CREATE OR REPLACE TABLE DEV_DF_140.OMOP.concept_relationship AS SELECT * FROM PROD_DF_000.OMOP.concept_relationship;

CREATE OR REPLACE TABLE DEV_DF_141.OMOP.concept_relationship AS SELECT * FROM PROD_DF_000.OMOP.concept_relationship;

CREATE OR REPLACE TABLE DEV_DF_142.OMOP.concept_relationship AS SELECT * FROM PROD_DF_000.OMOP.concept_relationship;

CREATE OR REPLACE TABLE DEV_DF_999.OMOP.concept_relationship AS SELECT * FROM PROD_DF_000.OMOP.concept_relationship;
	   