Create or replace function OCM.OMCR_PatientUpload_FileFormat (client VARCHAR(100))

/*

	Dave Ott 1/15/2019 Created
			Used With Clinical And Staging files. 
			This creates the data to paste into an Excel sheet
	
	Example use
	select * from OCM.OMCR_PatientUpload_FileFormat ('VCI')
	order by MBI
*/

RETURNS TABLE (
                 TRANSACTION_ID varchar,
                 DELETE_IND varchar(1),
                 mbi varchar,
                 hicn VARCHAR(50),
                 patient_first_name VARCHAR(100),
                 PATIENT_LAST_NAME VARCHAR(100),
                 PATIENT_DOB date,
                 PATIENT_GENDER varchar(1),
                 PRACTICE_TIN Varchar(10),
                 UPDATE_IND varchar(1),
                 OCM_ID VARCHAR(100),
                 PATIENT_ID Int
               )
 as
$$
	
	SELECT distinct 
                    to_varchar(GETDATE(),'YYYYMMDD') ||'-'||
                    cast(B.clientID as VARCHAR(10))||'-'||
                    cast( ROW_NUMBER() OVER (PARTITION BY B.Clientname ORDER BY MBI) as VARCHAR(10)) as TRANSACTION_ID,	
		   'N' as DELETE_IND,
            A.MBI,
            A.HICN,
            A.PATIENT_FIRST_NAME,
            A.PATIENT_LAST_NAME,
            A.PATIENT_DOB,
		    CASE WHEN left(A.PATIENT_GENDER,1) IN ('1','M') THEN 'M'
			     WHEN left(A.PATIENT_GENDER,1) IN ('2','F') THEN 'F'
			ELSE 'U' end as PATIENT_GENDER,
		    B.TIN PRACTICE_TIN,
		    'Y' UPDATE_IND,
		    OCM_NPI OCM_ID,
		    0 PATIENT_ID
	FROM OCM.OCMR A
	JOIN OCM.DYNAMIC_VARIABLES B ON A.CLIENTName=B.Clientname
	where A.ClientName=client
$$;