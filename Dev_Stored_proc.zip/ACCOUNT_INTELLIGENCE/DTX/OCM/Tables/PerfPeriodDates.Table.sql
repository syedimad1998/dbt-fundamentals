CREATE TABLE OCM.PerfPeriodDates(
	StartDate date null
	, EndDate date null
	, PerfPeriod varchar (4) not null
);
