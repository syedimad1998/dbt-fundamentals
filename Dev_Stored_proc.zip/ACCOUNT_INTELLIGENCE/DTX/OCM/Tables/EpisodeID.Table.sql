CREATE TABLE OCM.EpisodeID(
	ClientName varchar (100) null
	, ClientId int null
	, TIN varchar (20) null
	, PersonID int not null
	, MPI int null
	, BENE_ID int null
	, HICN varchar (50) null
	, PatientFirstName varchar (100) null
	, PatientLastName varchar (100) null
	, Gender varchar (50) null
	, DOB date null
	, DOD date null
	, Diagnosis varchar null
	, DiagnosisDescription varchar (100) null
	, DiagnosisDate date not null
	, ProcedureCode varchar null
	, ProcedureType nvarchar null
	, ProcedureDate date not null
	, ProcedurePayer varchar (200) null
	, ProcedureSourceSystem varchar (200) null
	, EM varchar null
	, EMDate date not null
	, ProviderID varchar (100) null
	, ProviderFirstName varchar (100) null
	, ProviderLastName varchar (100) null
	, ProviderStatus varchar (50) null
	, CodeDescription nvarchar null
	, EMDescription nvarchar null
	, CareSiteId int null
	, LastVisitDate date null
	, PayerName varchar (255) null
	, ROWNUMBER bigint null
	, Episode int not null
	, EpisodeEndDate date null
	, Deceased int not null
	, DeceasedDate varchar (10) null
	, LoadDate date null
);
